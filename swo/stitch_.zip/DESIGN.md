---
name: Snow Wanderer Online
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#5b4041'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#8f6f70'
  outline-variant: '#e3bdbf'
  surface-tint: '#bb0f3a'
  primary: '#95002a'
  on-primary: '#ffffff'
  primary-container: '#be123c'
  on-primary-container: '#ffd0d2'
  inverse-primary: '#ffb2b7'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#41485e'
  on-tertiary: '#ffffff'
  tertiary-container: '#586076'
  on-tertiary-container: '#d4dbf5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdadb'
  primary-fixed-dim: '#ffb2b7'
  on-primary-fixed: '#40000d'
  on-primary-fixed-variant: '#920029'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 3.5rem
    fontWeight: '700'
    lineHeight: 4rem
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: 0em
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: 1.75rem
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.05em
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The visual identity embodies the discipline, solitude, and ethereal majesty of a martial sovereign traversing high mountain passes after fresh snowfall. It juxtaposes the absolute purity of undisturbed snow and polished white jade against the dramatic precision of black calligraphic brushstrokes and the stark vitality of crimson plum blossoms blooming in deep winter.

### Design Philosophy & Aesthetic Movement
This design system pairs high-order editorial minimalism with refined wuxia romanticism and frosted crystalline glassmorphism. Surfaces reflect ambient winter light, resembling thin sheets of mountain ice and translucent white jade layered over snowbanks. The visual hierarchy relies on:
- **Alabaster and Frost Canvases:** Pure, high-luminance negative space creating a quiet, contemplative atmosphere.
- **Ink-Wash Discipline:** Text and structural dividers carry the sharp, deliberate contrast of freshly grounded pine ink on fine rice paper.
- **The Vermilion Seal:** Strategic, concentrated bursts of plum blossom crimson acting as authoritative imperial stamps, pivotal martial arts prompts, and interactive focal points.
- **Glacial Translucency:** Subtle backdrop filters, pale ice-blue gradients, and whisper-thin silver filigree framing critical UI viewports.

The intended emotional response is one of supreme clarity, quiet lethality, disciplined elegance, and high prestige.

## Colors

The palette draws directly from a winter high-mountain panorama: cold ambient light, ink brushstrokes, glacial runoffs, and crimson winter flora.

### Palette Roles & Usage
- **Primary (`#be123c` - Vermilion Plum Blossom):** Serves as the primary brand signature and imperial martial seal. Reserved for critical call-to-actions, level-up milestones, critical health states, and royal emblems. It commands immediate focus against the pale snow background.
- **Secondary (`#0284c7` - Glacial Ice):** Embodies chilled internal energy (qi), passive martial states, selected states, and ethereal highlight accents. Used for badges, active navigation indicators, and mystical item attributes.
- **Tertiary (`#0f172a` - Pine Soot Ink):** The anchor for high-contrast legibility. Replaces standard interface grays with deep, authoritative indigo-black. Used for headlines, body copy, and crisp structural contours.
- **Neutral (`#f8fafc` - Alabaster Snow):** The luminous base layer representing fresh mountain snow. Extended by `#ffffff` for elevated crystalline panels, `#f1f5f9` for muted inset containers, and `#e2e8f0` for fine frost dividers.

### Color Harmonies & Surface Distribution
Dominant surfaces remain 85% snow white and pale silver mist. Ink-black controls 10% of the surface via typography and fine framing. Plum blossom vermilion and glacial cyan strictly occupy the remaining 5%, functioning as deliberate focal points rather than large fills.

## Typography

The typographic hierarchy establishes a rhythm between dramatic imperial authority and pristine contemporary legibility.

### Display & Headlines: Bodoni Moda
Headlines harness the extreme stroke contrast, razor-sharp serifs, and high-fashion verticality of Bodoni Moda. The typeface echoes the tapered flourish of classic Chinese calligraphic brushes carving into ice. It must be rendered in deep pine ink (`#0f172a`) or crimson vermilion (`#be123c`) for titles, scroll headers, martial rankings, and major system announcements.

### Body & Microcopy: Be Vietnam Pro
The body, data tables, attributes, and interaction labels employ Be Vietnam Pro. Its precise geometric proportions and open apertures offer supreme clarity across high-density inventory grids, character stat sheets, and chat logs against luminous backgrounds.

### Typographic Polish
- Headlines utilize tightened letter-spacing (`-0.01em` to `-0.02em`) to mimic disciplined sword cuts.
- Labels, stamps, and rank indicators use uppercase tracking (`0.05em` to `0.1em`) to mimic imperial seal prints.
- Chinese glyph integration defaults to standard high-contrast songti/mingti display typefaces paired naturally with the serif contrast of Bodoni Moda.

## Layout & Spacing

Layouts favor deliberate, contemplative whitespace evocative of vast, unblemished snowfields. Spatial intervals follow an 8-point base module to guarantee alignment and visual discipline across complex fantasy interface modules.

### Grid Architecture
- **Desktop (1200px+):** 12-column fluid grid with `2.5rem` (`margin`) outer margins and `1.5rem` (`gutter`) column gutters. Panels appear as floating sheets of jade or crystal with breathing room between character models and inventory arrays.
- **Tablet (768px - 1199px):** 8-column layout with `1.5rem` margins and `1rem` gutters. Side panels collapse into frosted sliding drawers.
- **Mobile (< 768px):** 4-column layout with `1rem` outer canvas padding and `0.75rem` gutters. Vertical stacked sheets with sticky bottom action anchors.

### Spacing Philosophy
Components must never feel congested. Card interiors leverage `space-lg` padding to simulate spacious ceremonial scrolls. Data elements within cards maintain compact `space-xs` and `space-sm` distances to form distinct semantic clusters.

## Elevation & Depth

Visual hierarchy does not rely on heavy murky drop shadows. Instead, depth is achieved through translucent white jade glassmorphism, cold ambient highlights, and thin crystalline border reflections.

### Surface Tiers
- **Base (Snow Canvas):** `#f8fafc` solid plane, subtly textured with microscopic falling snowflake dust (ambient low-opacity noise).
- **Tier 1 (Resting Jade Sheets):** `rgba(255, 255, 255, 0.75)` with `backdrop-filter: blur(12px)` and a subtle 1px border of `rgba(226, 232, 240, 0.8)`. Soft ambient glow: `0 8px 32px -4px rgba(15, 23, 42, 0.04)`.
- **Tier 2 (Floating Scrolls & Popovers):** `rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(20px)` and a 1px border of `rgba(186, 230, 253, 0.6)` (subtle glacial ice rim). Ambient elevation: `0 16px 40px -8px rgba(15, 23, 42, 0.08)`.
- **Tier 3 (Imperial Modals & Martial Prompts):** `#ffffff` solid core wrapped in double borders—an outer hairline of `rgba(190, 18, 60, 0.3)` and an inner 1px rim of pure ice white. Elevation: `0 24px 64px -12px rgba(190, 18, 60, 0.12)`.

### Cold Light Inset Highlights
Elevated cards feature a top inner hairline shadow `inset 0 1px 0 0 rgba(255, 255, 255, 0.9)` that evokes the glistening upper edge of carved mountain ice catching dawn sunlight.

## Shapes

The shape system adopts a refined, disciplined soft contour (`roundedness: 1`). Elements reject overly rounded or bubbly aesthetics, maintaining the controlled, crisp geometry of carved jade seals and folded ceremonial parchment.

### Border Radius Tokens
- **Base Radius (`0.25rem`):** Applied to badges, chips, standard buttons, data cells, and input fields. Corners are subtly softened to avoid harsh digital sharp edges while maintaining martial discipline.
- **Large Radius (`rounded-lg: 0.5rem`):** Applied to inventory panels, cards, dialogue windows, and status displays.
- **Extra Large Radius (`rounded-xl: 0.75rem`):** Applied to major game modals, quest scrolls, and full-screen overlay frames.

### Ornamental Corner Brackets
Primary focal containers can incorporate classical angled corner brackets or miniature vermilion plum blossom flourishes at top-left and bottom-right diagonals, anchoring the interface within ancient martial arts parchment traditions.

## Components

### Buttons
- **Primary (Imperial Vermilion Seal):** Deep crimson vermilion (`#be123c`) fill with white (`#ffffff`) text in Bodoni Moda or medium-weight Be Vietnam Pro. Delicate top inner frost line `rgba(255, 255, 255, 0.25)`. Hover states bloom with an intensified vermilion glow (`#e11d48`) and subtle `scale(1.02)` motion.
- **Secondary (Glacial Frost):** Translucent ice white `rgba(255, 255, 255, 0.85)` with a 1px glacial cyan border (`#38bdf8`) and tertiary ink text (`#0f172a`). Hover introduces an ambient icy blue aura (`rgba(2, 132, 199, 0.1)`).
- **Tertiary / Ghost:** Pure transparent background, ink text (`#0f172a`), underlining on hover with a faint plum-tinted wash.

### Cards & Panels (Jade Scrolls)
Constructed from semi-translucent alabaster glass (`rgba(255, 255, 255, 0.85)`). Cards feature a delicate 1px border tinted with silver frost (`#e2e8f0`). Critical cards (such as legendary equipment or royal quest items) feature four hairline right-angle corner markers tinted in vermilion (`#be123c`).

### Input Fields
Inputs sit on an inset pale snow background (`#f1f5f9`) with a 1px border of `#cbd5e1`. Upon focus, the background shifts to pure white (`#ffffff`), the border sharpens to glacial cyan (`#0284c7`), and a diffuse ice-blue glow (`0 0 0 3px rgba(2, 132, 199, 0.15)`) appears. Typography remains crisp pine ink (`#0f172a`).

### Chips & Badges
- **Status / Faction Badges:** Compact labels using `label-sm` typography. Enclosed within a `0.25rem` container. Faction markers utilize ice blue (`#e0f2fe`) fills with dark cyan text (`#0369a1`).
- **Rank Seals:** Square or circular vermilion stamp chips (`#be123c` background with gold or white glyphs), evoking wax seal stamps on royal dispatches.

### Selection Controls (Checkboxes & Radios)
Checkboxes use a soft `0.25rem` square; radio buttons use circles. Unchecked states feature an alabaster fill with an ink-line perimeter (`#94a3b8`). Checked states transform into a solid vermilion plum fill (`#be123c`) enclosing a clean white check or center pip, mimicking an official chop mark.

### Character Stat & Qi Progress Bars
Health, mana, and internal qi bars are housed in slender, crisp rectangular tracks with a deep slate gutter (`#e2e8f0`). Vitality uses rich vermilion (`#be123c`), internal qi uses glacial cyan (`#0284c7`), and spiritual mastery uses pure silver-white over charcoal ink.