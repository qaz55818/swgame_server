<?php
/**
 * =============================================================
 *  踏雪笑傲 · 後台「註冊管理」
 *  - 需以 GM 帳號登入（沿用 gm_accounts / $_SESSION['gm_username']）。
 *  - 所有資料透過 registration_api.php 取得；變更操作使用 POST + CSRF。
 *  - 顯示內容一律於前端進行 HTML 編碼，避免儲存型 XSS。
 * =============================================================
 */
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../register_security.php';

if (!isset($_SESSION['gm_username']) || $_SESSION['gm_username'] === '') {
    header('Location: gmlogin.php');
    exit();
}
$currentGm = (string)$_SESSION['gm_username'];

// 後台閒置逾時（8 小時）
app_session_enforce_timeout(60 * 60 * 8);

$csrfToken = register_csrf_token();
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · 註冊管理</title>
    <link rel="stylesheet" href="assets/tailwind.css">
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Noto+Sans+TC:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body {
            background-color: #080c14;
            color: #1e293b;
            font-family: 'Noto Sans TC', 'Noto Serif TC', sans-serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% 0%, rgba(190, 18, 60, 0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 90%, rgba(2, 132, 199, 0.08) 0%, transparent 50%);
        }
        #snow-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 1; }
        .glass-panel {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(226, 232, 240, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.7) inset;
        }
        .corner-accent::before { content: ''; position: absolute; top: 0; left: 0; width: 10px; height: 10px; border-top: 2px solid #be123c; border-left: 2px solid #be123c; pointer-events: none; }
        .corner-accent::after { content: ''; position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; border-bottom: 2px solid #0284c7; border-right: 2px solid #0284c7; pointer-events: none; }
        .btn-vermilion { background: linear-gradient(135deg, #be123c 0%, #9f1239 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(190,18,60,.25); }
        .btn-vermilion:hover { background: linear-gradient(135deg, #e11d48 0%, #be123c 100%); transform: translateY(-1px); }
        .btn-ice { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(2,132,199,.25); }
        .btn-ice:hover { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); transform: translateY(-1px); }
        .form-input-focus:focus { outline: none; border-color: #0284c7; box-shadow: 0 0 0 3px rgba(2,132,199,.15); }
        .reg-tab { transition: all .2s ease; }
        .reg-tab.active { color: #fff; border-color: transparent !important; background: linear-gradient(135deg, #0284c7, #0369a1); box-shadow: 0 8px 18px -6px rgba(2,132,199,.6); transform: translateY(-1px); }
        .reg-filter.active { color: #fff; border-color: transparent !important; background: linear-gradient(135deg, #be123c, #7f1d3a); transform: translateY(-1px); }
        table.reg-table th { position: sticky; top: 0; z-index: 5; }
        /* 補齊編譯版 CSS 未含的格線工具類（設定頁版面） */
        @media (min-width: 1024px) {
            .lg\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .lg\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .lg\:col-span-2 { grid-column: span 2 / span 2; }
        }
    </style>
</head>
<body class="relative min-h-screen flex flex-col">
    <canvas id="snow-canvas"></canvas>

    <!-- 提示訊息 -->
    <div id="toast" class="fixed top-4 right-4 z-[9999] hidden max-w-sm">
        <div id="toast-body" class="rounded-xl border p-3.5 text-xs shadow-lg bg-white"></div>
    </div>

    <header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center space-x-3.5">
                    <img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 object-cover">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
                            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-sky-900/80 text-sky-200 border border-sky-700/60 font-medium">註冊管理</span>
                        </div>
                        <p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Registration Control</p>
                    </div>
                </div>
                <nav class="flex items-center space-x-2">
                    <a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-arrow-left text-slate-400"></i><span class="hidden sm:inline">返回控制台</span>
                    </a>
                    <div class="hidden sm:flex items-center space-x-2 bg-slate-900/90 border border-sky-900/50 px-3 py-1 rounded-full text-xs">
                        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        <span class="text-slate-400">管理員：</span>
                        <span class="font-semibold text-sky-300 font-mono"><?php echo htmlspecialchars($currentGm, ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors">
                        <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i><span class="hidden sm:inline">登出</span>
                    </a>
                </nav>
            </div>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-5">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
                <h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider flex items-center gap-2.5">
                    <i class="fa-solid fa-user-plus text-sky-400"></i>
                    <span>註冊管理</span>
                    <span class="text-xs font-normal text-slate-400 tracking-normal font-sans border border-slate-700 px-2 py-0.5 rounded">Registration Center</span>
                </h1>
                <p class="text-xs text-slate-400 mt-1.5">管理註冊開關、限流門檻、封鎖名單與稽核紀錄。所有設定即時於註冊後端生效。</p>
            </div>
            <div id="reg-status-pill" class="text-xs px-4 py-2 rounded-xl border border-slate-700 bg-slate-900/80 text-slate-300 flex items-center gap-2 self-start">
                <span class="w-2 h-2 rounded-full bg-slate-500"></span> 載入狀態中…
            </div>
        </div>

        <!-- 分頁按鈕 -->
        <div class="flex flex-wrap items-center gap-2">
            <button type="button" data-tab="overview" class="reg-tab active inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-600 cursor-pointer"><i class="fa-solid fa-gauge-high"></i> 總覽</button>
            <button type="button" data-tab="logs" class="reg-tab inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-600 cursor-pointer"><i class="fa-solid fa-list-ul"></i> 註冊紀錄</button>
            <button type="button" data-tab="settings" class="reg-tab inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-600 cursor-pointer"><i class="fa-solid fa-sliders"></i> 註冊設定</button>
            <button type="button" data-tab="blocks" class="reg-tab inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-600 cursor-pointer"><i class="fa-solid fa-ban"></i> 封鎖管理</button>
            <button type="button" data-tab="audit" class="reg-tab inline-flex items-center gap-2 px-4 py-2 rounded-xl border border-slate-300 bg-white text-xs font-semibold text-slate-600 cursor-pointer"><i class="fa-solid fa-clipboard-list"></i> 管理操作紀錄</button>
        </div>

        <!-- 總覽 -->
        <section data-panel="overview" class="glass-panel corner-accent rounded-2xl p-5 sm:p-6">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-sm font-bold text-slate-800 flex items-center gap-2"><i class="fa-solid fa-gauge-high text-sky-600"></i> 今日註冊概況</h2>
                <span id="ov-clock" class="text-[11px] text-slate-500 font-mono">—</span>
            </div>
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-3" id="ov-cards">
                <div class="rounded-xl border border-slate-200 bg-white p-3.5"><div class="text-[11px] text-slate-500">今日註冊嘗試</div><div class="text-2xl font-extrabold text-slate-800 font-mono" id="ov-total">—</div><div class="text-[10px] text-slate-400">來源 IP <span id="ov-ips" class="font-mono">0</span> 組</div></div>
                <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5"><div class="text-[11px] text-emerald-700">註冊成功</div><div class="text-2xl font-extrabold text-emerald-700 font-mono" id="ov-success">—</div><div class="text-[10px] text-emerald-600">近 7 日 <span id="ov-week-success" class="font-mono">0</span></div></div>
                <div class="rounded-xl border border-rose-200 bg-rose-50 p-3.5"><div class="text-[11px] text-rose-700">驗證失敗</div><div class="text-2xl font-extrabold text-rose-700 font-mono" id="ov-failed">—</div><div class="text-[10px] text-rose-600">近 7 日 <span id="ov-week-failed" class="font-mono">0</span></div></div>
                <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5"><div class="text-[11px] text-amber-700">限流／封鎖</div><div class="text-2xl font-extrabold text-amber-700 font-mono"><span id="ov-limited">—</span></div><div class="text-[10px] text-amber-600">封鎖 <span id="ov-blocked" class="font-mono">0</span> · 關閉 <span id="ov-disabled" class="font-mono">0</span></div></div>
            </div>
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-3">
                <div class="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">目前生效封鎖：<strong class="font-mono text-slate-800" id="ov-active-blocks">0</strong> 筆（自動 <span id="ov-auto-blocks">0</span> · 手動 <span id="ov-manual-blocks">0</span>）</div>
                <div class="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600">處理中（pending）：<strong class="font-mono text-slate-800" id="ov-pending">0</strong> 筆</div>
                <div class="rounded-xl border border-slate-200 bg-slate-50 p-3 text-xs text-slate-600 truncate" id="ov-last">最近嘗試：—</div>
            </div>
            <div class="mt-3 text-[11px] text-slate-500" id="ov-thresholds">—</div>
        </section>

        <!-- 註冊紀錄 -->
        <section data-panel="logs" class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 hidden">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-4">
                <h2 class="text-sm font-bold text-slate-800 flex items-center gap-2"><i class="fa-solid fa-list-ul text-rose-600"></i> 註冊紀錄</h2>
                <div class="flex flex-wrap items-center gap-2">
                    <select id="log-range" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                        <option value="today">今日</option>
                        <option value="7">近 7 日</option>
                        <option value="30">近 30 日</option>
                        <option value="all">全部期間</option>
                    </select>
                    <select id="log-reason" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus max-w-[180px]"></select>
                    <input type="text" id="log-search" placeholder="搜尋帳號 / IP / Email" class="px-3 py-1.5 w-48 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    <button type="button" onclick="loadLogs(true)" class="btn-ice px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-rotate-right"></i> 重整</button>
                </div>
            </div>
            <div class="flex flex-wrap items-center gap-2 mb-3" id="log-result-filters">
                <button type="button" data-result="all" class="reg-filter active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-slate-100 border-slate-200 text-slate-600">全部</button>
                <button type="button" data-result="success" class="reg-filter inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-emerald-50 border-emerald-200 text-emerald-700">成功</button>
                <button type="button" data-result="failed" class="reg-filter inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-rose-50 border-rose-200 text-rose-700">失敗</button>
                <button type="button" data-result="limited" class="reg-filter inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-amber-50 border-amber-200 text-amber-700">限流</button>
                <button type="button" data-result="blocked" class="reg-filter inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-orange-50 border-orange-200 text-orange-700">封鎖</button>
                <button type="button" data-result="disabled" class="reg-filter inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold bg-slate-100 border-slate-300 text-slate-600">關閉</button>
            </div>
            <div id="log-list" class="min-h-[180px]"></div>
            <div class="flex items-center justify-between text-xs text-slate-500 mt-3">
                <span id="log-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="log-prev" onclick="changeLogPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed">上一頁</button>
                    <button type="button" id="log-next" onclick="changeLogPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed">下一頁</button>
                </div>
            </div>
        </section>

        <!-- 註冊設定 -->
        <section data-panel="settings" class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 hidden">
            <h2 class="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4"><i class="fa-solid fa-sliders text-amber-600"></i> 註冊設定</h2>
            <form id="settings-form" class="space-y-5">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
                    <div class="rounded-xl border border-slate-200 p-4 space-y-3">
                        <h3 class="text-xs font-bold text-slate-700">註冊開關</h3>
                        <label class="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                            <input type="checkbox" id="set-enabled" class="w-4 h-4 accent-sky-600">
                            <span>開放註冊（關閉後，直接呼叫 API 也會被拒絕）</span>
                        </label>
                        <div>
                            <label class="block text-xs font-semibold text-slate-600 mb-1.5">關閉時的公告文字</label>
                            <textarea id="set-notice" rows="3" maxlength="300" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm form-input-focus" placeholder="例如：系統維護中，暫停開放註冊。"></textarea>
                        </div>
                    </div>
                    <div class="rounded-xl border border-slate-200 p-4 space-y-3">
                        <h3 class="text-xs font-bold text-slate-700">限流門檻（伺服器端，資料庫計數）</h3>
                        <div class="grid grid-cols-2 gap-3">
                            <label class="text-xs text-slate-600">視窗秒數<input type="number" id="set-window" min="30" max="86400" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                            <label class="text-xs text-slate-600">每 IP 上限<input type="number" id="set-ip" min="1" max="1000" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                            <label class="text-xs text-slate-600">每帳號上限<input type="number" id="set-account" min="1" max="1000" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                            <label class="text-xs text-slate-600">每 IP 每小時<input type="number" id="set-hour" min="1" max="100000" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                            <label class="text-xs text-slate-600">冷卻秒數<input type="number" id="set-cooldown" min="30" max="86400" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                            <label class="text-xs text-slate-600">封鎖時長（秒）<input type="number" id="set-blockdur" min="60" max="2592000" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus"></label>
                        </div>
                    </div>
                    <div class="rounded-xl border border-slate-200 p-4 space-y-3">
                        <h3 class="text-xs font-bold text-slate-700">紀錄保留</h3>
                        <label class="text-xs text-slate-600 block">保留天數
                            <input type="number" id="set-retention" min="1" max="3650" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                        </label>
                        <button type="button" onclick="purgeLogs()" class="w-full py-2 rounded-lg border border-rose-300 bg-rose-50 text-rose-700 text-xs font-semibold hover:bg-rose-100">依保留天數立即清理（單批）</button>
                    </div>
                    <div class="rounded-xl border border-slate-200 p-4 space-y-3">
                        <h3 class="text-xs font-bold text-slate-700">可信代理（僅這些來源的代理標頭才被信任）</h3>
                        <textarea id="set-proxies" rows="3" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-mono form-input-focus" placeholder="例如：10.0.0.0/8, 203.0.113.7（留空＝僅信任實際連線 IP）"></textarea>
                        <p class="text-[11px] text-slate-500">預設只信任連線來源 IP。僅當來源在主機／CDN 設定中確為可信代理時才填入，避免訪客偽造 X-Forwarded-For 繞過限流。</p>
                    </div>

                    <div class="rounded-xl border border-slate-200 p-4 space-y-3 lg:col-span-2">
                        <h3 class="text-xs font-bold text-slate-700">註冊規則</h3>
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            <label class="text-xs text-slate-600">一組 Email 可註冊帳號數
                                <input type="number" id="set-email-max" min="1" max="1000" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                                <span class="text-[10px] text-slate-400">1＝每組 Email 僅能註冊一個帳號</span>
                            </label>
                            <label class="text-xs text-slate-600">帳號長度下限
                                <input type="number" id="set-acct-min" min="1" max="32" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                            </label>
                            <label class="text-xs text-slate-600">帳號長度上限
                                <input type="number" id="set-acct-max" min="1" max="32" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                            </label>
                            <label class="text-xs text-slate-600">密碼長度下限
                                <input type="number" id="set-pass-min" min="1" max="128" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                            </label>
                            <label class="text-xs text-slate-600">密碼長度上限
                                <input type="number" id="set-pass-max" min="1" max="128" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                            </label>
                            <label class="text-xs text-slate-600">禁止的特殊符號
                                <input type="text" id="set-forbidden-symbols" maxlength="128" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm font-mono form-input-focus" placeholder="例如：!@#$%">
                                <span class="text-[10px] text-slate-400">密碼不可包含這些字元</span>
                            </label>
                        </div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-3">
                            <label class="text-xs text-slate-600">禁止用於帳號或密碼的詞彙
                                <textarea id="set-forbidden-words" rows="3" class="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 text-sm form-input-focus" placeholder="以逗號或換行分隔，例如：admin, test, 管理員"></textarea>
                                <span class="text-[10px] text-slate-400">帳號或密碼包含任一詞彙即拒絕註冊（不分大小寫）</span>
                            </label>
                            <label class="text-xs text-slate-600">禁止的 Email 格式／網域
                                <textarea id="set-forbidden-email" rows="3" class="mt-1 w-full px-3 py-2 rounded-lg border border-slate-300 text-sm font-mono form-input-focus" placeholder="以逗號或換行分隔，支援 * 萬用字元，例如：*.ru, tempmail*, spam@example.com"></textarea>
                                <span class="text-[10px] text-slate-400">符合任一格式／網域的 Email 將無法註冊</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="flex items-center gap-3">
                    <button type="submit" class="btn-vermilion px-6 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2"><i class="fa-solid fa-floppy-disk"></i> 儲存設定</button>
                    <span class="text-[11px] text-slate-500">設定儲存後立即生效，並寫入管理操作紀錄（不含機密）。</span>
                </div>
            </form>
        </section>

        <!-- 封鎖管理 -->
        <section data-panel="blocks" class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 hidden">
            <h2 class="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4"><i class="fa-solid fa-ban text-orange-600"></i> 封鎖管理</h2>
            <div class="rounded-xl border border-slate-200 p-4 mb-4">
                <h3 class="text-xs font-bold text-slate-700 mb-3">新增／延長封鎖</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                    <label class="text-xs text-slate-600">類型
                        <select id="block-new-scope" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                            <option value="ip">IP</option>
                            <option value="account">帳號</option>
                        </select>
                    </label>
                    <label class="text-xs text-slate-600">目標
                        <input type="text" id="block-new-key" placeholder="IP 或帳號" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                    </label>
                    <label class="text-xs text-slate-600">時長（小時，0＝永久）
                        <input type="number" id="block-new-ttl" min="0" max="8760" value="24" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                    </label>
                    <label class="text-xs text-slate-600 lg:col-span-2">原因
                        <input type="text" id="block-new-reason" maxlength="255" placeholder="例如：大量機器人註冊" class="mt-1 w-full px-3 py-1.5 rounded-lg border border-slate-300 text-sm form-input-focus">
                    </label>
                </div>
                <button type="button" onclick="addBlock()" class="btn-vermilion mt-3 px-5 py-2 rounded-lg text-xs font-bold flex items-center gap-2"><i class="fa-solid fa-plus"></i> 新增封鎖</button>
            </div>
            <div class="flex flex-wrap items-center gap-2 mb-3">
                <select id="block-scope" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    <option value="all">全部類型</option><option value="ip">IP</option><option value="account">帳號</option>
                </select>
                <select id="block-status" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    <option value="active">生效中</option><option value="expired">已到期</option><option value="released">已解除</option><option value="all">全部</option>
                </select>
                <input type="text" id="block-search" placeholder="搜尋目標 / 原因" class="px-3 py-1.5 w-48 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                <button type="button" onclick="loadBlocks(true)" class="btn-ice px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-rotate-right"></i> 重整</button>
            </div>
            <div id="block-list" class="min-h-[160px]"></div>
            <div class="flex items-center justify-between text-xs text-slate-500 mt-3">
                <span id="block-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="block-prev" onclick="changeBlockPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40">上一頁</button>
                    <button type="button" id="block-next" onclick="changeBlockPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40">下一頁</button>
                </div>
            </div>
        </section>

        <!-- 管理操作紀錄 -->
        <section data-panel="audit" class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 hidden">
            <h2 class="text-sm font-bold text-slate-800 flex items-center gap-2 mb-4"><i class="fa-solid fa-clipboard-list text-violet-600"></i> 管理操作紀錄</h2>
            <div class="flex flex-wrap items-center gap-2 mb-3">
                <select id="audit-action" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    <option value="all">全部動作</option>
                    <option value="settings_update">設定變更</option>
                    <option value="block_add">新增封鎖</option>
                    <option value="block_release">解除封鎖</option>
                    <option value="purge_logs">清理紀錄</option>
                    <option value="view_overview">檢視總覽</option>
                </select>
                <input type="text" id="audit-search" placeholder="搜尋管理員 / 目標" class="px-3 py-1.5 w-48 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                <button type="button" onclick="loadAdminLogs(true)" class="btn-ice px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-rotate-right"></i> 重整</button>
            </div>
            <div id="audit-list" class="min-h-[160px]"></div>
            <div class="flex items-center justify-between text-xs text-slate-500 mt-3">
                <span id="audit-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="audit-prev" onclick="changeAuditPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40">上一頁</button>
                    <button type="button" id="audit-next" onclick="changeAuditPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 disabled:opacity-40">下一頁</button>
                </div>
            </div>
        </section>
    </main>

    <!-- 紀錄詳情 -->
    <div id="detail-modal" class="fixed inset-0 z-[9999] hidden items-center justify-center bg-black/70 backdrop-blur-sm px-3">
        <div class="glass-panel corner-accent rounded-2xl w-full max-w-lg max-h-[88vh] overflow-y-auto">
            <div class="flex items-center justify-between p-4 border-b border-slate-200">
                <h3 class="text-sm font-bold text-slate-800"><i class="fa-solid fa-circle-info text-sky-600 mr-1"></i> 紀錄詳情</h3>
                <button type="button" onclick="closeDetail()" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div id="detail-body" class="p-4 text-xs text-slate-700 space-y-2"></div>
        </div>
    </div>

    <script>
    const CSRF = <?php echo json_encode($csrfToken, JSON_UNESCAPED_UNICODE); ?>;
    const API = 'registration_api.php';
    const RESULT_META = {
        success:{t:'註冊成功',c:'bg-emerald-50 text-emerald-700 border-emerald-200',d:'bg-emerald-500'},
        failed:{t:'驗證失敗',c:'bg-rose-50 text-rose-700 border-rose-200',d:'bg-rose-500'},
        limited:{t:'遭限流',c:'bg-amber-50 text-amber-700 border-amber-200',d:'bg-amber-500'},
        blocked:{t:'已封鎖',c:'bg-orange-50 text-orange-700 border-orange-200',d:'bg-orange-500'},
        disabled:{t:'註冊關閉',c:'bg-slate-100 text-slate-600 border-slate-300',d:'bg-slate-400'},
        pending:{t:'處理中',c:'bg-sky-50 text-sky-700 border-sky-200',d:'bg-sky-500'}
    };

    function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
    function fmtDT(s){return s?String(s).replace('T',' ').slice(0,19):'—';}
    function num(n){return Number(n||0).toLocaleString();}

    function toast(msg, ok=true){
        const box=document.getElementById('toast'), body=document.getElementById('toast-body');
        body.className='rounded-xl border p-3.5 text-xs shadow-lg '+(ok?'bg-emerald-50 border-emerald-200 text-emerald-800':'bg-rose-50 border-rose-200 text-rose-800');
        body.innerHTML=(ok?'<i class="fa-solid fa-circle-check mr-1"></i>':'<i class="fa-solid fa-triangle-exclamation mr-1"></i>')+esc(msg);
        box.classList.remove('hidden');
        clearTimeout(window.__toastT);
        window.__toastT=setTimeout(()=>box.classList.add('hidden'), 4000);
    }
    function loading(el){ if(el) el.innerHTML='<div class="py-12 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl block mb-3"></i>載入中…</div>'; }
    function empty(el,msg){ if(el) el.innerHTML='<div class="py-12 text-center text-slate-400 text-sm"><i class="fa-regular fa-folder-open text-2xl block mb-3"></i>'+esc(msg)+'</div>'; }
    function err(el,msg){ if(el) el.innerHTML='<div class="py-12 text-center text-rose-500 text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>'+esc(msg)+'</div>'; }

    function apiGet(action, params){
        const p=new URLSearchParams(Object.assign({action:action}, params||{}));
        return fetch(API+'?'+p.toString(), {credentials:'same-origin'}).then(r=>r.json());
    }
    function apiPost(action, data){
        const p=new URLSearchParams(Object.assign({action:action, csrf_token:CSRF}, data||{}));
        return fetch(API, {method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:p.toString()}).then(r=>r.json());
    }

    /* 分頁切換 */
    const panels={};
    document.querySelectorAll('[data-panel]').forEach(p=>panels[p.getAttribute('data-panel')]=p);
    document.querySelectorAll('.reg-tab').forEach(btn=>{
        btn.addEventListener('click',()=>{
            const tab=btn.getAttribute('data-tab');
            document.querySelectorAll('.reg-tab').forEach(b=>b.classList.toggle('active',b===btn));
            Object.keys(panels).forEach(k=>panels[k].classList.toggle('hidden',k!==tab));
            if(tab==='overview') loadOverview();
            if(tab==='logs'){ loadLogs(!logState.loaded); }
            if(tab==='settings') loadSettings();
            if(tab==='blocks'){ loadBlocks(!blockState.loaded); }
            if(tab==='audit'){ loadAdminLogs(!auditState.loaded); }
        });
    });

    /* 總覽 */
    function loadOverview(){
        apiGet('overview').then(d=>{
            if(!d||!d.ok) return;
            const s=d.stats||{};
            document.getElementById('ov-total').textContent=num(s.today_total);
            document.getElementById('ov-ips').textContent=num(s.today_unique_ips);
            document.getElementById('ov-success').textContent=num(s.today_success);
            document.getElementById('ov-week-success').textContent=num(s.week_success);
            document.getElementById('ov-failed').textContent=num(s.today_failed);
            document.getElementById('ov-week-failed').textContent=num(s.week_failed);
            document.getElementById('ov-limited').textContent=num(s.today_limited);
            document.getElementById('ov-blocked').textContent=num(s.today_blocked);
            document.getElementById('ov-disabled').textContent=num(s.today_disabled);
            document.getElementById('ov-active-blocks').textContent=num(s.active_blocks);
            document.getElementById('ov-auto-blocks').textContent=num(s.auto_blocks);
            document.getElementById('ov-manual-blocks').textContent=num(s.manual_blocks);
            document.getElementById('ov-pending').textContent=num(s.today_pending);
            const la=s.last_attempt;
            document.getElementById('ov-last').textContent=la?('最近嘗試：'+(la.username||'（未提供）')+' @ '+(la.ip||'—')+' · '+fmtDT(la.created_at)):'最近嘗試：尚無紀錄';
            const th=d.thresholds||{};
            document.getElementById('ov-thresholds').textContent='限流：每 '+th.window_seconds+' 秒每 IP '+th.max_per_ip+' 次、每帳號 '+th.max_per_account+' 次；每 IP 每小時 '+th.max_per_ip_hour+' 次；封鎖冷卻 '+th.cooldown_seconds+' 秒。';
            const clock=d.clock||{};
            document.getElementById('ov-clock').textContent='統計時區：伺服器時間 '+clock.label+'（'+(clock.db_now||'')+'）';
            const pill=document.getElementById('reg-status-pill');
            const on = String((d.settings||{}).register_enabled)==='1';
            pill.className='text-xs px-4 py-2 rounded-xl border flex items-center gap-2 self-start '+(on?'border-emerald-300 bg-emerald-900/30 text-emerald-200':'border-amber-300 bg-amber-900/30 text-amber-100');
            pill.innerHTML='<span class="w-2 h-2 rounded-full '+(on?'bg-emerald-400':'bg-amber-400')+'"></span> 註冊功能：'+(on?'開放中':'已關閉');
        }).catch(()=>toast('載入總覽失敗',false));
    }

    /* 註冊紀錄 */
    const logState={page:1,pages:1,result:'all',range:'today',reason:'all',q:'',loaded:false};
    let logTimer=null;
    function loadLogs(showLoading){
        const el=document.getElementById('log-list');
        if(showLoading) loading(el);
        apiGet('logs',{result:logState.result,range:logState.range,reason:logState.reason,q:logState.q,page:logState.page,limit:20}).then(d=>{
            if(!d||!d.ok){err(el,(d&&d.message)||'載入失敗');return;}
            logState.loaded=true; logState.pages=d.pages||1; logState.page=d.page||1;
            renderLogRows(d.logs);
            document.getElementById('log-pager-info').textContent=d.total>0?('共 '+num(d.total)+' 筆 · 第 '+d.page+' / '+(d.pages||1)+' 頁'):'共 0 筆';
            document.getElementById('log-prev').disabled=(d.page<=1);
            document.getElementById('log-next').disabled=(d.page>=(d.pages||1));
        }).catch(()=>err(el,'網路連線失敗'));
    }
    function renderLogRows(logs){
        const el=document.getElementById('log-list');
        if(!logs||!logs.length){empty(el,'沒有符合條件的註冊紀錄');return;}
        let h='<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="w-full text-left text-xs reg-table"><thead class="bg-slate-50 text-slate-600 font-semibold"><tr>'
            +'<th class="py-2.5 px-3 whitespace-nowrap">時間</th><th class="py-2.5 px-3">帳號</th><th class="py-2.5 px-3">結果</th><th class="py-2.5 px-3">來源 IP</th><th class="py-2.5 px-3">裝置</th><th class="py-2.5 px-3"></th></tr></thead><tbody class="divide-y divide-slate-100">';
        logs.forEach(l=>{
            const m=RESULT_META[l.status]||{t:l.status,c:'bg-slate-100 text-slate-600 border-slate-300',d:'bg-slate-400'};
            h+='<tr class="hover:bg-slate-50/80">'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">'+esc(fmtDT(l.created_at))+'</td>'
                +'<td class="py-2.5 px-3"><span class="font-semibold text-slate-800">'+esc(l.username||'—')+'</span>'+(l.userid>0?'<span class="text-[10px] text-slate-400 font-mono ml-1">#'+esc(l.userid)+'</span>':'')+'</td>'
                +'<td class="py-2.5 px-3"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium '+m.c+'"><span class="w-1.5 h-1.5 rounded-full '+m.d+'"></span>'+esc(m.t)+'</span>'+(l.reason_text?'<div class="text-[10px] text-slate-400 mt-0.5">'+esc(l.reason_text)+'</div>':'')+'</td>'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-600">'+esc(l.ip||'—')+(l.forwarded&&l.forwarded!==l.ip?'<div class="text-[10px] text-slate-400 truncate max-w-[160px]">via '+esc(l.forwarded)+'</div>':'')+'</td>'
                +'<td class="py-2.5 px-3 text-[11px] text-slate-500 truncate max-w-[160px]">'+esc(l.ua||'—')+'</td>'
                +'<td class="py-2.5 px-3 text-right"><button type="button" onclick="showDetail('+esc(l.id)+')" class="px-2.5 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-[11px]">詳情</button></td>'
                +'</tr>';
        });
        h+='</tbody></table></div>';
        el.innerHTML=h;
    }
    function changeLogPage(delta){const t=logState.page+delta;if(t<1||t>logState.pages)return;logState.page=t;loadLogs(true);}
    document.querySelectorAll('#log-result-filters .reg-filter').forEach(btn=>{
        btn.addEventListener('click',()=>{
            logState.result=btn.getAttribute('data-result');logState.page=1;
            document.querySelectorAll('#log-result-filters .reg-filter').forEach(b=>b.classList.toggle('active',b===btn));
            loadLogs(true);
        });
    });
    document.getElementById('log-range').addEventListener('change',function(){logState.range=this.value;logState.page=1;loadLogs(true);});
    document.getElementById('log-reason').addEventListener('change',function(){logState.reason=this.value;logState.page=1;loadLogs(true);});
    document.getElementById('log-search').addEventListener('input',function(){clearTimeout(logTimer);logTimer=setTimeout(()=>{logState.q=this.value.trim();logState.page=1;loadLogs(true);},350);});

    function showDetail(id){
        const modal=document.getElementById('detail-modal'), body=document.getElementById('detail-body');
        modal.classList.remove('hidden');modal.classList.add('flex');body.innerHTML='<div class="py-8 text-center text-slate-400"><i class="fa-solid fa-spinner fa-spin"></i></div>';
        apiGet('log_detail',{id:id}).then(d=>{
            if(!d||!d.ok){body.innerHTML='<p class="text-rose-500">'+esc((d&&d.message)||'讀取失敗')+'</p>';return;}
            const l=d.log;
            const row=(k,v)=>'<div class="flex gap-3 border-b border-slate-100 py-1.5"><span class="w-24 shrink-0 text-slate-400">'+esc(k)+'</span><span class="flex-1 break-all text-slate-700">'+esc(v==null||v===''?'（未提供）':v)+'</span></div>';
            body.innerHTML=row('時間',fmtDT(l.created_at))+row('帳號',l.username)+row('遊戲 ID',l.userid>0?('#'+l.userid):'—')+row('來源 IP',l.ip)
                +row('X-Forwarded-For',l.ip_forwarded)+row('User-Agent',l.ua)+row('Accept-Language',l.accept_language)+row('Referer',l.referer)
                +row('結果',((RESULT_META[l.status]||{}).t||l.status))+row('原因代碼',l.reason_code)+row('原因說明',l.reason_label||l.reason_text);
        }).catch(()=>{body.innerHTML='<p class="text-rose-500">網路連線失敗</p>';});
    }
    function closeDetail(){const m=document.getElementById('detail-modal');m.classList.add('hidden');m.classList.remove('flex');}

    /* 設定 */
    function loadSettings(){
        apiGet('settings').then(d=>{
            if(!d||!d.ok)return;
            const s=d.settings;
            document.getElementById('set-enabled').checked=String(s.register_enabled)==='1';
            document.getElementById('set-notice').value=s.closed_notice||'';
            document.getElementById('set-window').value=s.rate_window_seconds;
            document.getElementById('set-ip').value=s.rate_max_per_ip;
            document.getElementById('set-account').value=s.rate_max_per_account;
            document.getElementById('set-hour').value=s.rate_max_per_ip_hour;
            document.getElementById('set-cooldown').value=s.rate_cooldown_seconds;
            document.getElementById('set-blockdur').value=s.block_duration_seconds;
            document.getElementById('set-retention').value=s.retention_days;
            document.getElementById('set-proxies').value=s.trusted_proxies||'';
            document.getElementById('set-email-max').value=s.email_max_accounts;
            document.getElementById('set-acct-min').value=s.account_min_length;
            document.getElementById('set-acct-max').value=s.account_max_length;
            document.getElementById('set-pass-min').value=s.password_min_length;
            document.getElementById('set-pass-max').value=s.password_max_length;
            document.getElementById('set-forbidden-words').value=s.forbidden_words||'';
            document.getElementById('set-forbidden-symbols').value=s.forbidden_symbols||'';
            document.getElementById('set-forbidden-email').value=s.forbidden_email_patterns||'';
        }).catch(()=>toast('載入設定失敗',false));
    }
    document.getElementById('settings-form').addEventListener('submit',function(e){
        e.preventDefault();
        const data={
            register_enabled: document.getElementById('set-enabled').checked?'1':'0',
            closed_notice: document.getElementById('set-notice').value,
            rate_window_seconds: document.getElementById('set-window').value,
            rate_max_per_ip: document.getElementById('set-ip').value,
            rate_max_per_account: document.getElementById('set-account').value,
            rate_max_per_ip_hour: document.getElementById('set-hour').value,
            rate_cooldown_seconds: document.getElementById('set-cooldown').value,
            block_duration_seconds: document.getElementById('set-blockdur').value,
            retention_days: document.getElementById('set-retention').value,
            trusted_proxies: document.getElementById('set-proxies').value,
            email_max_accounts: document.getElementById('set-email-max').value,
            account_min_length: document.getElementById('set-acct-min').value,
            account_max_length: document.getElementById('set-acct-max').value,
            password_min_length: document.getElementById('set-pass-min').value,
            password_max_length: document.getElementById('set-pass-max').value,
            forbidden_words: document.getElementById('set-forbidden-words').value,
            forbidden_symbols: document.getElementById('set-forbidden-symbols').value,
            forbidden_email_patterns: document.getElementById('set-forbidden-email').value
        };
        apiPost('save_settings',data).then(d=>{
            if(d&&d.ok){toast(d.message||'設定已儲存');loadOverview();}
            else{const errs=d&&d.errors?Object.values(d.errors).join('；'):'';toast(((d&&d.message)||'設定儲存失敗')+(errs?('：'+errs):''),false);}
        }).catch(()=>toast('網路連線失敗',false));
    });
    function purgeLogs(){
        const days=parseInt(document.getElementById('set-retention').value||'0',10);
        if(!days||days<1){toast('請先設定有效的保留天數',false);return;}
        if(!confirm('確定要清理超過 '+days+' 天的註冊紀錄與限流計數嗎？此操作無法復原。')) return;
        apiPost('purge_logs',{days:days}).then(d=>{toast((d&&d.message)||(d&&d.ok?'已清理':'清理失敗'),!!(d&&d.ok));}).catch(()=>toast('網路連線失敗',false));
    }

    /* 封鎖 */
    const blockState={page:1,pages:1,scope:'all',status:'active',q:'',loaded:false};
    let blockTimer=null;
    function loadBlocks(showLoading){
        const el=document.getElementById('block-list');
        if(showLoading) loading(el);
        apiGet('blocks',{scope:blockState.scope,status:blockState.status,q:blockState.q,page:blockState.page,limit:20}).then(d=>{
            if(!d||!d.ok){err(el,(d&&d.message)||'載入失敗');return;}
            blockState.loaded=true;blockState.pages=d.pages||1;blockState.page=d.page||1;
            renderBlocks(d.blocks);
            document.getElementById('block-pager-info').textContent=d.total>0?('共 '+num(d.total)+' 筆 · 第 '+d.page+' / '+(d.pages||1)+' 頁'):'共 0 筆';
            document.getElementById('block-prev').disabled=(d.page<=1);
            document.getElementById('block-next').disabled=(d.page>=(d.pages||1));
        }).catch(()=>err(el,'網路連線失敗'));
    }
    function renderBlocks(blocks){
        const el=document.getElementById('block-list');
        if(!blocks||!blocks.length){empty(el,'沒有符合條件的封鎖紀錄');return;}
        let h='<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="w-full text-left text-xs reg-table"><thead class="bg-slate-50 text-slate-600 font-semibold"><tr>'
            +'<th class="py-2.5 px-3">類型</th><th class="py-2.5 px-3">目標</th><th class="py-2.5 px-3">原因</th><th class="py-2.5 px-3">來源</th><th class="py-2.5 px-3">建立 / 到期</th><th class="py-2.5 px-3">狀態</th><th class="py-2.5 px-3"></th></tr></thead><tbody class="divide-y divide-slate-100">';
        blocks.forEach(b=>{
            let status='<span class="px-2 py-0.5 rounded-full border text-[10px] bg-slate-100 text-slate-600 border-slate-300">已解除</span>';
            if(b.active===1){
                if(b.expires_at===null){status='<span class="px-2 py-0.5 rounded-full border text-[10px] bg-rose-50 text-rose-700 border-rose-200">永久生效</span>';}
                else{status='<span class="px-2 py-0.5 rounded-full border text-[10px] bg-amber-50 text-amber-700 border-amber-200">生效中</span>';}
            }
            const isActive=b.active===1 && (b.expires_at===null || new Date(String(b.expires_at).replace(' ','T')) > new Date());
            h+='<tr class="hover:bg-slate-50/80">'
                +'<td class="py-2.5 px-3 font-semibold text-slate-700">'+esc(b.scope==='ip'?'IP':'帳號')+'</td>'
                +'<td class="py-2.5 px-3 font-mono text-slate-800">'+esc(b.key)+'</td>'
                +'<td class="py-2.5 px-3 text-slate-600">'+esc(b.reason||'—')+'</td>'
                +'<td class="py-2.5 px-3 text-slate-500">'+esc(b.source==='auto'?'自動':'手動')+(b.created_by?' · '+esc(b.created_by):'')+'</td>'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500">'+esc(fmtDT(b.created_at))+'<div class="text-[10px] text-slate-400">'+(b.expires_at?('到期 '+esc(fmtDT(b.expires_at))):'永久')+'</div></td>'
                +'<td class="py-2.5 px-3">'+status+'</td>'
                +'<td class="py-2.5 px-3 text-right">'+(isActive?('<button type="button" onclick="releaseBlock('+esc(b.id)+',\''+esc(b.key)+'\')" class="px-2.5 py-1 rounded-lg border border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100 text-[11px]">解除</button>'):'')+'</td>'
                +'</tr>';
        });
        h+='</tbody></table></div>';
        el.innerHTML=h;
    }
    function changeBlockPage(delta){const t=blockState.page+delta;if(t<1||t>blockState.pages)return;blockState.page=t;loadBlocks(true);}
    document.getElementById('block-scope').addEventListener('change',function(){blockState.scope=this.value;blockState.page=1;loadBlocks(true);});
    document.getElementById('block-status').addEventListener('change',function(){blockState.status=this.value;blockState.page=1;loadBlocks(true);});
    document.getElementById('block-search').addEventListener('input',function(){clearTimeout(blockTimer);blockTimer=setTimeout(()=>{blockState.q=this.value.trim();blockState.page=1;loadBlocks(true);},350);});
    function addBlock(){
        const scope=document.getElementById('block-new-scope').value;
        const key=document.getElementById('block-new-key').value.trim();
        const ttl=document.getElementById('block-new-ttl').value;
        const reason=document.getElementById('block-new-reason').value.trim();
        if(!key){toast('請輸入封鎖目標',false);return;}
        apiPost('add_block',{scope:scope,block_key:key,ttl_hours:ttl,reason:reason}).then(d=>{
            if(d&&d.ok){toast(d.message||'已新增封鎖');document.getElementById('block-new-key').value='';document.getElementById('block-new-reason').value='';loadBlocks(true);loadOverview();}
            else toast((d&&d.message)||'新增失敗',false);
        }).catch(()=>toast('網路連線失敗',false));
    }
    function releaseBlock(id,key){
        if(!confirm('確定解除「'+key+'」的封鎖？')) return;
        apiPost('remove_block',{id:id}).then(d=>{toast((d&&d.message)||(d&&d.ok?'已解除':'操作失敗'),!!(d&&d.ok));if(d&&d.ok){loadBlocks(true);loadOverview();}}).catch(()=>toast('網路連線失敗',false));
    }

    /* 操作紀錄 */
    const auditState={page:1,pages:1,action:'all',q:'',loaded:false};
    let auditTimer=null;
    function loadAdminLogs(showLoading){
        const el=document.getElementById('audit-list');
        if(showLoading) loading(el);
        apiGet('admin_logs',{filter_action:auditState.action,q:auditState.q,page:auditState.page,limit:20}).then(d=>{
            if(!d||!d.ok){err(el,(d&&d.message)||'載入失敗');return;}
            auditState.loaded=true;auditState.pages=d.pages||1;auditState.page=d.page||1;
            renderAudit(d.logs);
            document.getElementById('audit-pager-info').textContent=d.total>0?('共 '+num(d.total)+' 筆 · 第 '+d.page+' / '+(d.pages||1)+' 頁'):'共 0 筆';
            document.getElementById('audit-prev').disabled=(d.page<=1);
            document.getElementById('audit-next').disabled=(d.page>=(d.pages||1));
        }).catch(()=>err(el,'網路連線失敗'));
    }
    function renderAudit(logs){
        const el=document.getElementById('audit-list');
        if(!logs||!logs.length){empty(el,'尚無管理操作紀錄');return;}
        const labels={settings_update:'設定變更',block_add:'新增封鎖',block_release:'解除封鎖',purge_logs:'清理紀錄',view_overview:'檢視總覽'};
        let h='<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white"><table class="w-full text-left text-xs reg-table"><thead class="bg-slate-50 text-slate-600 font-semibold"><tr>'
            +'<th class="py-2.5 px-3 whitespace-nowrap">時間</th><th class="py-2.5 px-3">管理員</th><th class="py-2.5 px-3">動作</th><th class="py-2.5 px-3">目標</th><th class="py-2.5 px-3">變更摘要</th><th class="py-2.5 px-3">來源 IP</th></tr></thead><tbody class="divide-y divide-slate-100">';
        logs.forEach(l=>{
            h+='<tr class="hover:bg-slate-50/80">'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">'+esc(fmtDT(l.created_at))+'</td>'
                +'<td class="py-2.5 px-3 font-semibold text-slate-800">'+esc(l.gm_username||'—')+'</td>'
                +'<td class="py-2.5 px-3"><span class="px-2 py-0.5 rounded-full border text-[10px] bg-violet-50 text-violet-700 border-violet-200">'+esc(labels[l.action]||l.action)+'</span></td>'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-600">'+esc(l.target||'—')+'</td>'
                +'<td class="py-2.5 px-3 text-slate-600">'+esc(l.detail||'—')+'</td>'
                +'<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500">'+esc(l.ip||'—')+'</td>'
                +'</tr>';
        });
        h+='</tbody></table></div>';
        el.innerHTML=h;
    }
    function changeAuditPage(delta){const t=auditState.page+delta;if(t<1||t>auditState.pages)return;auditState.page=t;loadAdminLogs(true);}
    document.getElementById('audit-action').addEventListener('change',function(){auditState.action=this.value;auditState.page=1;loadAdminLogs(true);});
    document.getElementById('audit-search').addEventListener('input',function(){clearTimeout(auditTimer);auditTimer=setTimeout(()=>{auditState.q=this.value.trim();auditState.page=1;loadAdminLogs(true);},350);});

    document.getElementById('detail-modal').addEventListener('click',function(e){if(e.target===this)closeDetail();});
    document.addEventListener('keydown',function(e){if(e.key==='Escape')closeDetail();});

    // 雪花效果
    (function(){
        const c=document.getElementById('snow-canvas');if(!c)return;const ctx=c.getContext('2d');
        let w=c.width=window.innerWidth,h=c.height=window.innerHeight;
        window.addEventListener('resize',()=>{w=c.width=window.innerWidth;h=c.height=window.innerHeight;});
        const ps=[];const count=Math.min(Math.floor(window.innerWidth/26),48);
        for(let i=0;i<count;i++)ps.push({x:Math.random()*w,y:Math.random()*h,r:Math.random()*2+0.6,vy:Math.random()*0.7+0.25,vx:(Math.random()-0.5)*0.4,o:Math.random()*0.6+0.2});
        (function render(){ctx.clearRect(0,0,w,h);ps.forEach(p=>{p.y+=p.vy;p.x+=p.vx;if(p.y>h){p.y=-5;p.x=Math.random()*w;}if(p.x<0)p.x=w;if(p.x>w)p.x=0;ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle='rgba(255,255,255,'+p.o+')';ctx.shadowBlur=4;ctx.shadowColor='rgba(255,255,255,0.5)';ctx.fill();});requestAnimationFrame(render);})();
    })();

    // 初始化：載入總覽與篩選選項
    (function init(){
        const reasonSel=document.getElementById('log-reason');
        const reasons={ok:'註冊成功',account_exists:'帳號已被使用',account_invalid:'帳號格式錯誤',password_mismatch:'兩次密碼不一致',password_invalid:'密碼格式錯誤',password_weak:'密碼與帳號相同',email_invalid:'電子郵件格式錯誤',csrf_invalid:'CSRF 失效',honeypot:'蜜罐觸發',registration_disabled:'註冊已關閉',ip_blocked:'IP 已封鎖',account_blocked:'帳號已封鎖',rate_limited:'IP 限流',account_rate_limited:'帳號限流',request_too_large:'請求過大',server_error:'系統錯誤',db_error:'資料庫錯誤',concurrent_duplicate:'併發重複',unknown:'未知'};
        let opt='<option value="all">全部原因</option>';
        Object.keys(reasons).forEach(k=>{opt+='<option value="'+esc(k)+'">'+esc(reasons[k])+'</option>';});
        reasonSel.innerHTML=opt;
        loadOverview();
    })();
    </script>
</body>
</html>
