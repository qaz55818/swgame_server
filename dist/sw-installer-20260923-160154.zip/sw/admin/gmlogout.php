<?php
session_start();

// 只清除 GM 專屬的 session 鍵值，保留其他遊戲帳號的 session
unset($_SESSION['gm_username']);
unset($_SESSION['gm_id']);
unset($_SESSION['gm_form_token']);

header("Location: gmlogin.php");
exit();