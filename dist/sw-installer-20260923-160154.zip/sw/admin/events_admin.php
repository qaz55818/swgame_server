<?php
/**
 * =============================================================
 *  踏雪笑傲 · 江湖盛典（活動）管理後台
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *  資料庫：獨立資料庫 swo_events（見 events_schema.sql）
 *  功能：儀表板、活動管理（含獎勵）、分類、注意事項、系統設定
 * =============================================================
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../events_config.php';

if (!isset($_SESSION['gm_username'])) {
    header('Location: gmlogin.php');
    exit();
}
$currentGm = (string)$_SESSION['gm_username'];

$db = events_db();
$SET = ev_settings_all($db);

if (empty($_SESSION['ev_admin_token'])) {
    $_SESSION['ev_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['ev_admin_token'];

function ea_flash(string $type, string $msg): void
{
    $_SESSION['ev_flash'] = ['type' => $type, 'msg' => $msg];
}

$notice = '';
$noticeType = 'success';
if (!empty($_SESSION['ev_flash'])) {
    $notice = (string)$_SESSION['ev_flash']['msg'];
    $noticeType = (string)$_SESSION['ev_flash']['type'];
    unset($_SESSION['ev_flash']);
}

/* ------------------------------------------------------------------
 * POST 處理（PRG）
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['form_token'] ?? '') !== $formToken) {
        ea_flash('danger', '工作階段已過期，請重新操作。');
        header('Location: events_admin.php');
        exit();
    }
    $action = (string)($_POST['action'] ?? '');
    $redirect = 'events_admin.php?section=events';

    if ($action === 'save_event') {
        $id       = (int)($_POST['id'] ?? 0);
        $catCode  = trim((string)($_POST['category_code'] ?? 'ongoing'));
        $catId    = 0;
        $stmt = $db->prepare("SELECT `id` FROM `ev_categories` WHERE `code` = ? LIMIT 1");
        $stmt->bind_param('s', $catCode);
        $stmt->execute();
        $crow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $catId = $crow ? (int)$crow['id'] : 0;

        $title          = trim((string)($_POST['title'] ?? ''));
        $badgeText      = trim((string)($_POST['badge_text'] ?? ''));
        $badgeClass     = trim((string)($_POST['badge_class'] ?? ''));
        $cornerText     = trim((string)($_POST['corner_text'] ?? ''));
        $threshold      = trim((string)($_POST['threshold'] ?? ''));
        $sideTag        = trim((string)($_POST['side_tag'] ?? ''));
        $sideClass      = trim((string)($_POST['side_class'] ?? ''));
        $summary        = trim((string)($_POST['summary'] ?? ''));
        $description    = (string)($_POST['description'] ?? '');
        $rewardSummary  = trim((string)($_POST['reward_summary'] ?? ''));
        $image          = trim((string)($_POST['image'] ?? ''));
        $accent         = trim((string)($_POST['accent'] ?? 'rose'));
        $periodText     = trim((string)($_POST['period_text'] ?? ''));
        $countdownInput = trim((string)($_POST['countdown_at'] ?? ''));
        $isFeatured     = !empty($_POST['is_featured']) ? 1 : 0;
        $featuredKicker = trim((string)($_POST['featured_kicker'] ?? ''));
        $enabled        = !empty($_POST['enabled']) ? 1 : 0;
        $sortOrder      = (int)($_POST['sort_order'] ?? 0);

        if ($title === '') {
            ea_flash('danger', '活動標題不得為空。');
            header('Location: events_admin.php?section=event_editor' . ($id ? '&id=' . $id : ''));
            exit();
        }
        $countdownVal = ($countdownInput !== '') ? date('Y-m-d H:i:s', strtotime($countdownInput)) : null;

        if ($isFeatured) {
            $db->query("UPDATE `ev_events` SET `is_featured` = 0");
        }

        if ($id > 0) {
            $stmt = $db->prepare(
                "UPDATE `ev_events` SET
                    `category_id`=?, `category_code`=?, `title`=?, `badge_text`=?, `badge_class`=?, `corner_text`=?,
                    `threshold`=?, `side_tag`=?, `side_class`=?, `summary`=?, `description`=?, `reward_summary`=?,
                    `image`=?, `accent`=?, `period_text`=?, `countdown_at`=?, `is_featured`=?, `featured_kicker`=?,
                    `enabled`=?, `sort_order`=?
                 WHERE `id`=?"
            );
            $stmt->bind_param(
                'isssssssssssssssisiii',
                $catId, $catCode, $title, $badgeText, $badgeClass, $cornerText,
                $threshold, $sideTag, $sideClass, $summary, $description, $rewardSummary,
                $image, $accent, $periodText, $countdownVal, $isFeatured, $featuredKicker,
                $enabled, $sortOrder, $id
            );
            $ok = $stmt->execute();
            $stmt->close();
            $evId = $id;
            ea_flash($ok ? 'success' : 'danger', $ok ? '活動已更新。' : '更新失敗：' . mysqli_error($db));
        } else {
            $stmt = $db->prepare(
                "INSERT INTO `ev_events`
                    (`category_id`,`category_code`,`title`,`badge_text`,`badge_class`,`corner_text`,
                     `threshold`,`side_tag`,`side_class`,`summary`,`description`,`reward_summary`,
                     `image`,`accent`,`period_text`,`countdown_at`,`is_featured`,`featured_kicker`,
                     `enabled`,`sort_order`)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->bind_param(
                'isssssssssssssssisii',
                $catId, $catCode, $title, $badgeText, $badgeClass, $cornerText,
                $threshold, $sideTag, $sideClass, $summary, $description, $rewardSummary,
                $image, $accent, $periodText, $countdownVal, $isFeatured, $featuredKicker,
                $enabled, $sortOrder
            );
            $ok = $stmt->execute();
            $evId = (int)$db->insert_id;
            $stmt->close();
            ea_flash($ok ? 'success' : 'danger', $ok ? '活動已新增。' : '新增失敗：' . mysqli_error($db));
        }

        // 獎勵清單
        if ($evId > 0 && isset($_POST['rewards']) && is_array($_POST['rewards'])) {
            foreach ($_POST['rewards'] as $row) {
                $rId   = (int)($row['id'] ?? 0);
                $rDel  = !empty($row['_delete']);
                $rStage = trim((string)($row['stage_label'] ?? ''));
                $rItem = trim((string)($row['item'] ?? ''));
                $rNote = trim((string)($row['note'] ?? ''));
                $rHi   = !empty($row['highlight']) ? 1 : 0;
                $rSort = (int)($row['sort_order'] ?? 0);
                if ($rDel) { if ($rId > 0) { $db->query("DELETE FROM `ev_rewards` WHERE `id` = " . $rId); } continue; }
                if ($rStage === '' && $rItem === '') { continue; }
                if ($rId > 0) {
                    $stmt = $db->prepare("UPDATE `ev_rewards` SET `stage_label`=?,`item`=?,`note`=?,`highlight`=?,`sort_order`=? WHERE `id`=? AND `event_id`=?");
                    $stmt->bind_param('sssiiii', $rStage, $rItem, $rNote, $rHi, $rSort, $rId, $evId);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $db->prepare("INSERT INTO `ev_rewards` (`event_id`,`stage_label`,`item`,`note`,`highlight`,`sort_order`) VALUES (?,?,?,?,?,?)");
                    $stmt->bind_param('isssii', $evId, $rStage, $rItem, $rNote, $rHi, $rSort);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
        $redirect = 'events_admin.php?section=events';
    } elseif ($action === 'delete_event') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $db->query("DELETE FROM `ev_rewards` WHERE `event_id` = " . $id);
            $db->query("DELETE FROM `ev_events` WHERE `id` = " . $id);
            ea_flash('success', '活動已刪除。');
        }
    } elseif ($action === 'toggle_event') {
        $id = (int)($_POST['id'] ?? 0);
        $db->query("UPDATE `ev_events` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $id);
        ea_flash('success', '活動啟用狀態已切換。');
    } elseif ($action === 'set_featured') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $db->query("UPDATE `ev_events` SET `is_featured` = 0");
            $db->query("UPDATE `ev_events` SET `is_featured` = 1 WHERE `id` = " . $id);
            ea_flash('success', '已設為精選主打活動。');
        }
    } elseif ($action === 'save_category') {
        $cid    = (int)($_POST['category_id'] ?? 0);
        $code   = trim((string)($_POST['code'] ?? ''));
        $name   = trim((string)($_POST['name'] ?? ''));
        $nameEn = trim((string)($_POST['name_en'] ?? ''));
        $icon   = trim((string)($_POST['icon'] ?? 'celebration'));
        $accent = trim((string)($_POST['accent'] ?? 'rose'));
        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($code === '' || $name === '') {
            ea_flash('danger', '分類代碼與名稱不得為空。');
        } elseif ($cid > 0) {
            $stmt = $db->prepare("UPDATE `ev_categories` SET `code`=?,`name`=?,`name_en`=?,`icon`=?,`accent`=?,`enabled`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('sssssiii', $code, $name, $nameEn, $icon, $accent, $enabled, $sort, $cid);
            $stmt->execute();
            $stmt->close();
            ea_flash('success', '分類已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `ev_categories` (`code`,`name`,`name_en`,`icon`,`accent`,`enabled`,`sort_order`) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param('sssssii', $code, $name, $nameEn, $icon, $accent, $enabled, $sort);
            $stmt->execute();
            $stmt->close();
            ea_flash('success', '分類已新增。');
        }
        $redirect = 'events_admin.php?section=categories';
    } elseif ($action === 'toggle_category') {
        $cid = (int)($_POST['category_id'] ?? 0);
        $db->query("UPDATE `ev_categories` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $cid);
        ea_flash('success', '分類啟用狀態已切換。');
        $redirect = 'events_admin.php?section=categories';
    } elseif ($action === 'delete_category') {
        $cid = (int)($_POST['category_id'] ?? 0);
        $cnt = 0;
        $r = $db->query("SELECT COUNT(*) AS c FROM `ev_events` WHERE `category_id` = " . $cid);
        if ($r) { $cnt = (int)$r->fetch_assoc()['c']; }
        if ($cnt > 0) {
            ea_flash('danger', '此分類仍有 ' . $cnt . ' 個活動，請先調整活動分類後再刪除。');
        } else {
            $db->query("DELETE FROM `ev_categories` WHERE `id` = " . $cid);
            ea_flash('success', '分類已刪除。');
        }
        $redirect = 'events_admin.php?section=categories';
    } elseif ($action === 'save_note') {
        $nid    = (int)($_POST['note_id'] ?? 0);
        $no     = trim((string)($_POST['no_label'] ?? ''));
        $question = trim((string)($_POST['question'] ?? ''));
        $answer = (string)($_POST['answer'] ?? '');
        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($question === '') {
            ea_flash('danger', '注意事項標題不得為空。');
        } elseif ($nid > 0) {
            $stmt = $db->prepare("UPDATE `ev_notes` SET `no_label`=?,`question`=?,`answer`=?,`enabled`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('sssiii', $no, $question, $answer, $enabled, $sort, $nid);
            $stmt->execute();
            $stmt->close();
            ea_flash('success', '注意事項已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `ev_notes` (`no_label`,`question`,`answer`,`enabled`,`sort_order`) VALUES (?,?,?,?,?)");
            $stmt->bind_param('sssii', $no, $question, $answer, $enabled, $sort);
            $stmt->execute();
            $stmt->close();
            ea_flash('success', '注意事項已新增。');
        }
        $redirect = 'events_admin.php?section=notes';
    } elseif ($action === 'toggle_note') {
        $nid = (int)($_POST['note_id'] ?? 0);
        $db->query("UPDATE `ev_notes` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $nid);
        ea_flash('success', '注意事項啟用狀態已切換。');
        $redirect = 'events_admin.php?section=notes';
    } elseif ($action === 'delete_note') {
        $nid = (int)($_POST['note_id'] ?? 0);
        $db->query("DELETE FROM `ev_notes` WHERE `id` = " . $nid);
        ea_flash('success', '注意事項已刪除。');
        $redirect = 'events_admin.php?section=notes';
    } elseif ($action === 'save_settings') {
        $textKeys = [
            'hero_kicker','hero_season','hero_title','hero_subtitle',
            'stat1_label','stat1_value','stat1_sub','stat2_label','stat2_sub',
            'grid_title','rules_title','rules_subtitle',
            'assist_title','assist_text','assist_btn_text','assist_btn_url'
        ];
        foreach ($textKeys as $k) {
            if (array_key_exists('set_' . $k, $_POST)) {
                ev_setting_put($db, $k, trim((string)$_POST['set_' . $k]));
            }
        }
        foreach (['show_stats','show_rules','show_assist'] as $k) {
            ev_setting_put($db, $k, isset($_POST['set_' . $k]) ? '1' : '0');
        }
        ea_flash('success', '活動系統設定已儲存並立即生效。');
        $redirect = 'events_admin.php?section=settings';
    }

    header('Location: ' . $redirect);
    exit();
}

/* ------------------------------------------------------------------
 * 讀取資料
 * ------------------------------------------------------------------ */
$section = (string)($_GET['section'] ?? 'dashboard');
$allowed = ['dashboard','events','event_editor','categories','notes','settings'];
if (!in_array($section, $allowed, true)) { $section = 'dashboard'; }

$categories = ev_categories($db, false);
$catMap = ev_category_map($db);

$stats = ['events' => 0, 'categories' => 0, 'rewards' => 0, 'notes' => 0, 'featured' => 0, 'views' => 0];
foreach (['events' => 'ev_events', 'categories' => 'ev_categories', 'rewards' => 'ev_rewards', 'notes' => 'ev_notes'] as $k => $tbl) {
    $r = mysqli_query($db, "SELECT COUNT(*) AS c FROM `$tbl`");
    if ($r) { $stats[$k] = (int)$r->fetch_assoc()['c']; }
}
$r = mysqli_query($db, "SELECT COUNT(*) AS c FROM `ev_events` WHERE `is_featured` = 1");
if ($r) { $stats['featured'] = (int)$r->fetch_assoc()['c']; }
$r = mysqli_query($db, "SELECT IFNULL(SUM(`view_count`),0) AS c FROM `ev_events`");
if ($r) { $stats['views'] = (int)$r->fetch_assoc()['c']; }

$recentEvents = [];
$res = mysqli_query($db, "SELECT * FROM `ev_events` ORDER BY `updated_at` DESC LIMIT 6");
if ($res) { $recentEvents = $res->fetch_all(MYSQLI_ASSOC); }

$allEvents = [];
if ($section === 'events') {
    $res = mysqli_query($db, "SELECT * FROM `ev_events` ORDER BY `category_code` ASC, `is_featured` DESC, `sort_order` ASC, `id` DESC");
    if ($res) { $allEvents = $res->fetch_all(MYSQLI_ASSOC); }
}

$editEvent = null;
$editRewards = [];
$isEditEvent = false;
if ($section === 'event_editor') {
    $eid = (int)($_GET['id'] ?? 0);
    if ($eid > 0) {
        $stmt = $db->prepare("SELECT * FROM `ev_events` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $eid);
        $stmt->execute();
        $editEvent = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($editEvent) {
            $isEditEvent = true;
            $editRewards = ev_rewards($db, $eid);
        }
    }
}

$allNotes = [];
if ($section === 'notes') { $allNotes = ev_notes($db, false); }

$navItems = [
    ['key' => 'dashboard',    'label' => '總覽儀表板', 'en' => 'Dashboard',   'icon' => 'fa-gauge-high',      'grad' => 'from-slate-600 to-slate-800'],
    ['key' => 'event_editor', 'label' => '新增活動',   'en' => 'New Event',   'icon' => 'fa-wand-magic-sparkles',        'grad' => 'from-rose-600 to-rose-800'],
    ['key' => 'events',       'label' => '活動管理',   'en' => 'Events',      'icon' => 'fa-calendar-check',   'grad' => 'from-sky-600 to-sky-700'],
    ['key' => 'categories',   'label' => '分類管理',   'en' => 'Categories',  'icon' => 'fa-layer-group',     'grad' => 'from-amber-600 to-amber-800'],
    ['key' => 'notes',        'label' => '注意事項',   'en' => 'Regulations', 'icon' => 'fa-scale-balanced',  'grad' => 'from-violet-600 to-violet-800'],
    ['key' => 'settings',     'label' => '系統設定',   'en' => 'Settings',    'icon' => 'fa-sliders',         'grad' => 'from-emerald-600 to-emerald-800'],
];
$activeNav = $section;
if ($section === 'event_editor') { $activeNav = 'events'; }
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · 江湖盛典管理 · GM 控制台</title>
    <link rel="stylesheet" href="assets/tailwind.css">
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="stylesheet" href="assets/events-admin-tailwind.css?v=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root { --vermilion: #be123c; --ice-blue: #0284c7; --ink-black: #0b0f19; }
        body {
            background-color: #080c14; color: #1e293b; font-family: 'Noto Serif TC', serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% 0%, rgba(190, 18, 60, 0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 90%, rgba(2, 132, 199, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 20% 60%, rgba(15, 23, 42, 0.8) 0%, transparent 70%);
        }
        #snow-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 1; transform: translateZ(0); will-change: transform; }
        .glass-panel { background: rgba(255, 255, 255, 0.94); border: 1px solid rgba(226, 232, 240, 0.85); backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px); box-shadow: 0 10px 30px -5px rgba(0,0,0,.25), 0 0 0 1px rgba(255,255,255,.7) inset; position: relative; transform: translateZ(0); }
        .corner-accent::before { content: ''; position: absolute; top: 0; left: 0; width: 10px; height: 10px; border-top: 2px solid var(--vermilion); border-left: 2px solid var(--vermilion); pointer-events: none; }
        .corner-accent::after { content: ''; position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; border-bottom: 2px solid var(--ice-blue); border-right: 2px solid var(--ice-blue); pointer-events: none; }
        .ink-divider { height: 1px; background: linear-gradient(90deg, transparent 0%, rgba(190,18,60,.3) 25%, rgba(2,132,199,.3) 75%, transparent 100%); }
        .btn-vermilion { background: linear-gradient(135deg, #be123c 0%, #9f1239 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(190,18,60,.25); }
        .btn-vermilion:hover { background: linear-gradient(135deg, #e11d48 0%, #be123c 100%); box-shadow: 0 6px 20px rgba(190,18,60,.38); transform: translateY(-1px); }
        .btn-ice { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(2,132,199,.25); }
        .btn-ice:hover { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); box-shadow: 0 6px 20px rgba(2,132,199,.38); transform: translateY(-1px); }
        .na-input, .na-select, .na-textarea { width: 100%; padding: .55rem .75rem; font-size: .8rem; color: #0f172a; background: #fff; border: 1px solid #cbd5e1; border-radius: .5rem; transition: all .2s ease; font-family: 'Noto Serif TC', serif; }
        .na-input:focus, .na-select:focus, .na-textarea:focus { outline: none; border-color: #0284c7; box-shadow: 0 0 0 3px rgba(2,132,199,.15); }
        .na-label { display: block; font-size: .72rem; font-weight: 700; color: #334155; letter-spacing: .06em; margin-bottom: .35rem; }
        .na-help { font-size: .68rem; color: #94a3b8; margin-top: .25rem; }
        .na-nav-btn { position: relative; overflow: hidden; border-radius: .75rem; padding: .7rem .95rem; color: #fff; font-size: .78rem; font-weight: 700; display: flex; align-items: center; gap: .65rem; box-shadow: 0 8px 20px -6px rgba(0,0,0,.45); transition: all .22s ease; text-decoration: none; }
        .na-nav-btn:hover { transform: translateY(-2px); box-shadow: 0 12px 26px -8px rgba(0,0,0,.55); }
        .na-nav-btn.is-active { outline: 2px solid rgba(255,255,255,.85); outline-offset: -2px; }
        .na-nav-btn .na-nav-icon { width: 2rem; height: 2rem; border-radius: .5rem; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.22); flex: none; }
        .na-badge { display: inline-flex; align-items: center; gap: .25rem; padding: .1rem .45rem; border-radius: .375rem; border: 1px solid; font-size: .65rem; font-weight: 700; font-family: 'Manrope', sans-serif; }
        .na-strip { width: 4px; border-radius: 2px; align-self: stretch; flex: none; }
        table.na-table { width: 100%; border-collapse: collapse; }
        table.na-table th { text-align: left; font-size: .68rem; letter-spacing: .08em; text-transform: uppercase; color: #64748b; padding: .6rem .7rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc; white-space: nowrap; }
        table.na-table td { padding: .65rem .7rem; font-size: .78rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        table.na-table tbody tr:hover { background: #f8fafc; }
        .ev-reward-row { display: grid; grid-template-columns: 1.2fr 1.6fr 1.8fr auto auto auto; gap: .5rem; align-items: center; }
        @media (max-width: 900px) { .ev-reward-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body class="relative min-h-screen flex flex-col selection:bg-rose-900 selection:text-white">
    <canvas id="snow-canvas"></canvas>

    <header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="gmpanel.php" class="flex items-center space-x-3.5 no-underline group">
                    <img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
                            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-rose-900/80 text-rose-200 border border-rose-700/60 font-medium">活動管理</span>
                        </div>
                        <p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Snow Wanderer Online</p>
                    </div>
                </a>
                <nav class="flex items-center space-x-2 sm:space-x-4">
                    <a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-arrow-left text-slate-400"></i><span class="hidden sm:inline">返回 GM 控制台</span></a>
                    <a href="events_admin.php?section=events" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-calendar-check text-sky-400"></i><span class="hidden sm:inline">活動列表</span></a>
                    <a href="../swo/events.php" target="_blank" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-eye text-emerald-400"></i><span class="hidden sm:inline">檢視前台</span></a>
                    <div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
                        <div class="flex items-center space-x-2 bg-slate-900/90 border border-rose-900/50 px-3 py-1 rounded-full text-xs">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span class="text-slate-400">管理員：</span>
                            <span class="font-semibold text-rose-300 font-mono"><?= ev_h($currentGm) ?></span>
                        </div>
                        <a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors" title="登出 GM 控制台"><i class="fa-solid fa-arrow-right-from-bracket mr-1"></i><span class="hidden sm:inline">登出</span></a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">
        <div class="flex flex-col gap-3 pb-3 border-b border-slate-800">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="px-2 py-0.5 text-[11px] font-semibold text-rose-800 bg-rose-50 border border-rose-200 rounded">盛典活動系統</span>
                        <span class="text-xs text-slate-400">獨立資料庫 swo_events · 資料同步正常</span>
                    </div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider flex items-center gap-2.5">
                        <span>江湖盛典管理中心</span>
                        <span class="text-xs font-normal text-slate-400 tracking-normal font-sans border border-slate-700 px-2 py-0.5 rounded">Events Control Center</span>
                    </h1>
                </div>
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5"><i class="fa-solid fa-calendar-check text-rose-400"></i><span>活動數：</span><strong class="text-rose-400 font-mono text-sm font-bold"><?= (int)$stats['events'] ?></strong><span class="text-slate-500">項</span></div>
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5"><i class="fa-solid fa-eye text-emerald-400"></i><span>累計瀏覽：</span><strong class="text-emerald-400 font-mono text-sm font-bold"><?= number_format((int)$stats['views']) ?></strong></div>
                </div>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2.5 pt-1">
                <?php foreach ($navItems as $n): ?>
                    <a href="events_admin.php?section=<?= ev_h($n['key']) ?>" class="na-nav-btn bg-gradient-to-br <?= ev_h($n['grad']) ?> <?= $activeNav === $n['key'] ? 'is-active' : '' ?>">
                        <span class="na-nav-icon"><i class="fa-solid <?= ev_h($n['icon']) ?> text-sm"></i></span>
                        <span class="flex flex-col items-start leading-tight"><span><?= ev_h($n['label']) ?></span><span class="text-[10px] font-normal text-white/70 font-['Cinzel']"><?= ev_h($n['en']) ?></span></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ($notice !== ''): ?>
            <?php $isDanger = ($noticeType === 'danger'); ?>
            <div class="p-3.5 rounded-lg border text-xs flex items-center justify-between <?= $isDanger ? 'border-rose-500/30 bg-rose-950/40 text-rose-200' : 'border-emerald-500/30 bg-emerald-950/40 text-emerald-200' ?>">
                <div class="flex items-center gap-2.5"><i class="fa-solid <?= $isDanger ? 'fa-circle-exclamation text-rose-400' : 'fa-circle-check text-emerald-400' ?> text-sm"></i><span><?= ev_h($notice) ?></span></div>
                <span class="text-[11px] font-mono <?= $isDanger ? 'text-rose-400/70' : 'text-emerald-400/70' ?>"><?= date('H:i:s') ?></span>
            </div>
        <?php endif; ?>
<?php if ($section === 'dashboard'): ?>
        <?php
        $cards = [
            ['label' => '活動總數', 'value' => $stats['events'],     'icon' => 'fa-calendar-check', 'grad' => 'from-rose-500 to-rose-700',      'sub' => '含各分類'],
            ['label' => '精選主打', 'value' => $stats['featured'],   'icon' => 'fa-star',           'grad' => 'from-amber-500 to-amber-700',    'sub' => '首頁大型展示'],
            ['label' => '活動分類', 'value' => $stats['categories'], 'icon' => 'fa-layer-group',    'grad' => 'from-sky-500 to-sky-700',        'sub' => '頁籤狀態'],
            ['label' => '獎勵條目', 'value' => $stats['rewards'],    'icon' => 'fa-gift',           'grad' => 'from-emerald-500 to-emerald-700','sub' => '獎勵清單'],
            ['label' => '注意事項', 'value' => $stats['notes'],      'icon' => 'fa-scale-balanced', 'grad' => 'from-violet-500 to-violet-700',  'sub' => '規則說明'],
            ['label' => '累計瀏覽', 'value' => $stats['views'],      'icon' => 'fa-eye',            'grad' => 'from-cyan-500 to-cyan-700',      'sub' => '所有活動'],
        ];
        ?>
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
            <?php foreach ($cards as $c): ?>
                <div class="glass-panel corner-accent rounded-xl p-4 text-slate-800">
                    <span class="w-9 h-9 rounded-lg bg-gradient-to-br <?= ev_h($c['grad']) ?> text-white flex items-center justify-center shadow mb-2"><i class="fa-solid <?= ev_h($c['icon']) ?> text-sm"></i></span>
                    <div class="text-2xl font-bold font-mono text-slate-900"><?= number_format((int)$c['value']) ?></div>
                    <div class="text-[11px] font-semibold text-slate-600 mt-0.5"><?= ev_h($c['label']) ?></div>
                    <div class="text-[10px] text-slate-400"><?= ev_h($c['sub']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700"><i class="fa-solid fa-clock-rotate-left"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900 tracking-wide">最近更新活動</h2><p class="text-[11px] text-slate-500">依最後編輯時間排序</p></div>
                </div>
                <a href="events_admin.php?section=events" class="text-[11px] font-semibold text-rose-700 hover:text-rose-900">查看全部 <i class="fa-solid fa-arrow-right ml-0.5"></i></a>
            </div>
            <div class="overflow-x-auto">
                <table class="na-table">
                    <thead><tr><th>活動</th><th>分類</th><th>期間</th><th class="text-center">瀏覽</th><th class="text-right">操作</th></tr></thead>
                    <tbody>
                    <?php if (empty($recentEvents)): ?><tr><td colspan="5" class="text-center text-slate-400 py-6">尚無活動，立即新增吧！</td></tr><?php endif; ?>
                    <?php foreach ($recentEvents as $e): $cat = $catMap[$e['category_code']] ?? null; ?>
                        <tr>
                            <td class="max-w-[300px]">
                                <a href="events_admin.php?section=event_editor&id=<?= (int)$e['id'] ?>" class="font-semibold text-slate-800 hover:text-rose-800">
                                    <?php if ((int)$e['is_featured'] === 1): ?><i class="fa-solid fa-star text-amber-500 text-[10px] mr-1"></i><?php endif; ?><?= ev_h($e['title']) ?>
                                </a>
                            </td>
                            <td class="text-slate-500"><?= ev_h($cat['name'] ?? $e['category_code']) ?></td>
                            <td class="text-slate-500 text-[11px] font-mono"><?= ev_h($e['period_text'] ?: '—') ?></td>
                            <td class="text-center font-mono text-slate-500"><?= number_format((int)$e['view_count']) ?></td>
                            <td class="text-right whitespace-nowrap">
                                <a href="events_admin.php?section=event_editor&id=<?= (int)$e['id'] ?>" class="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i>編輯</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php elseif ($section === 'events'): ?>
        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700"><i class="fa-solid fa-calendar-check"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900 tracking-wide">活動管理</h2><p class="text-[11px] text-slate-500">共 <?= count($allEvents) ?> 項活動 · 管理活動內容、獎勵與上架狀態</p></div>
                </div>
                <a href="events_admin.php?section=event_editor" class="btn-vermilion inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg self-start"><i class="fa-solid fa-wand-magic-sparkles"></i> 新增活動</a>
            </div>
            <div class="overflow-x-auto rounded-lg border border-slate-200">
                <table class="na-table">
                    <thead><tr><th>活動</th><th>分類</th><th>門檻</th><th class="text-center">獎勵</th><th class="text-center">瀏覽</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                    <tbody>
                    <?php if (empty($allEvents)): ?><tr><td colspan="7" class="text-center text-slate-400 py-8">尚無活動資料</td></tr><?php endif; ?>
                    <?php foreach ($allEvents as $e): $cat = $catMap[$e['category_code']] ?? null; $rcnt = count(ev_rewards($db, (int)$e['id'])); ?>
                        <tr>
                            <td class="max-w-[300px]">
                                <div class="flex items-start gap-2">
                                    <span class="na-strip <?= (int)$e['enabled'] === 1 ? 'bg-sky-500' : 'bg-slate-400' ?>"></span>
                                    <div class="min-w-0">
                                        <a href="events_admin.php?section=event_editor&id=<?= (int)$e['id'] ?>" class="font-semibold text-slate-800 hover:text-rose-800 block truncate">
                                            <?php if ((int)$e['is_featured'] === 1): ?><i class="fa-solid fa-star text-amber-500 text-[10px] mr-1"></i><?php endif; ?><?= ev_h($e['title']) ?>
                                        </a>
                                        <div class="text-[10px] text-slate-400 truncate"><?= ev_h($e['reward_summary']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="text-slate-500"><?= ev_h($cat['name'] ?? $e['category_code']) ?></td>
                            <td class="text-slate-500 text-[11px]"><?= ev_h($e['threshold']) ?></td>
                            <td class="text-center font-mono text-slate-500"><?= $rcnt ?></td>
                            <td class="text-center font-mono text-slate-500"><?= number_format((int)$e['view_count']) ?></td>
                            <td class="text-center">
                                <form method="POST" action="events_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                    <input type="hidden" name="action" value="toggle_event">
                                    <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                                    <button type="submit" class="na-badge <?= (int)$e['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$e['enabled'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$e['enabled'] === 1 ? '上架' : '下架' ?></button>
                                </form>
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="events_admin.php?section=event_editor&id=<?= (int)$e['id'] ?>" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium" title="編輯"><i class="fa-solid fa-pen"></i></a>
                                <?php if ((int)$e['is_featured'] !== 1): ?>
                                <form method="POST" action="events_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                    <input type="hidden" name="action" value="set_featured">
                                    <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-amber-100 text-slate-600 hover:text-amber-800 border border-slate-300 text-[11px] font-medium ml-1" title="設為精選主打"><i class="fa-solid fa-star"></i></button>
                                </form>
                                <?php endif; ?>
                                <a href="../swo/events.php?view=<?= (int)$e['id'] ?>" target="_blank" class="px-2 py-1 rounded bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 border border-slate-300 text-[11px] font-medium ml-1" title="前台預覽"><i class="fa-solid fa-eye"></i></a>
                                <form method="POST" action="events_admin.php" class="inline" onsubmit="return eaConfirmSubmit(this, '確定刪除此活動（含獎勵）？');">
                                    <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                    <input type="hidden" name="action" value="delete_event">
                                    <input type="hidden" name="id" value="<?= (int)$e['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1" title="刪除"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php elseif ($section === 'event_editor'): ?>
        <?php
        $ef = [
            'id' => $editEvent['id'] ?? 0,
            'category_code' => $editEvent['category_code'] ?? 'ongoing',
            'title' => $editEvent['title'] ?? '',
            'badge_text' => $editEvent['badge_text'] ?? '',
            'badge_class' => $editEvent['badge_class'] ?? 'bg-primary text-white',
            'corner_text' => $editEvent['corner_text'] ?? '',
            'threshold' => $editEvent['threshold'] ?? '',
            'side_tag' => $editEvent['side_tag'] ?? '',
            'side_class' => $editEvent['side_class'] ?? 'text-primary',
            'summary' => $editEvent['summary'] ?? '',
            'description' => $editEvent['description'] ?? '',
            'reward_summary' => $editEvent['reward_summary'] ?? '',
            'image' => $editEvent['image'] ?? '',
            'accent' => $editEvent['accent'] ?? 'rose',
            'period_text' => $editEvent['period_text'] ?? '',
            'countdown_at' => $editEvent['countdown_at'] ?? '',
            'is_featured' => (int)($editEvent['is_featured'] ?? 0),
            'featured_kicker' => $editEvent['featured_kicker'] ?? '',
            'enabled' => (int)($editEvent['enabled'] ?? 1),
            'sort_order' => (int)($editEvent['sort_order'] ?? 0),
        ];
        $cdLocal = '';
        if (!empty($ef['countdown_at']) && $ef['countdown_at'] !== '0000-00-00 00:00:00') {
            $ts = strtotime($ef['countdown_at']); if ($ts) { $cdLocal = date('Y-m-d\TH:i', $ts); }
        }
        ?>
        <form method="POST" action="events_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
            <input type="hidden" name="action" value="save_event">
            <input type="hidden" name="id" value="<?= (int)$ef['id'] ?>">

            <div class="lg:col-span-8 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                        <div class="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
                        <div><h2 class="text-base font-bold text-slate-900"><?= $isEditEvent ? '編輯活動' : '新增活動' ?></h2><p class="text-[11px] text-slate-500">設定活動標題、標籤、門檻、期間與主視覺</p></div>
                    </div>
                    <div class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="md:col-span-2">
                                <label class="na-label">活動標題 <span class="text-rose-600">*</span></label>
                                <input type="text" name="title" value="<?= ev_h($ef['title']) ?>" maxlength="200" required class="na-input" placeholder="例：寒淵破曉 · 登入七日贈絕版水墨披風">
                            </div>
                            <div>
                                <label class="na-label">分類</label>
                                <select name="category_code" class="na-select">
                                    <?php foreach ($categories as $c): ?>
                                        <option value="<?= ev_h($c['code']) ?>" <?= $ef['category_code'] === $c['code'] ? 'selected' : '' ?>><?= ev_h($c['name']) ?><?= (int)$c['enabled'] === 0 ? '（停用）' : '' ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div><label class="na-label">左上標籤文字</label><input type="text" name="badge_text" value="<?= ev_h($ef['badge_text']) ?>" class="na-input" placeholder="例：限時盛典 · 萬人登入"></div>
                            <div><label class="na-label">標籤樣式 (className)</label><input type="text" name="badge_class" value="<?= ev_h($ef['badge_class']) ?>" class="na-input font-mono text-[11px]" placeholder="bg-primary text-white"></div>
                            <div><label class="na-label">右下角提示文字</label><input type="text" name="corner_text" value="<?= ev_h($ef['corner_text']) ?>" class="na-input" placeholder="例：倒數 5 天截止"></div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div><label class="na-label">參與門檻</label><input type="text" name="threshold" value="<?= ev_h($ef['threshold']) ?>" class="na-input" placeholder="例：等級達到 75 級"></div>
                            <div><label class="na-label">右側側標</label><input type="text" name="side_tag" value="<?= ev_h($ef['side_tag']) ?>" class="na-input" placeholder="例：首殺爭奪"></div>
                            <div><label class="na-label">側標顏色 (className)</label><input type="text" name="side_class" value="<?= ev_h($ef['side_class']) ?>" class="na-input font-mono text-[11px]" placeholder="text-primary"></div>
                        </div>
                        <div><label class="na-label">活動摘要</label><textarea name="summary" rows="3" maxlength="500" class="na-textarea" placeholder="一段話說明活動重點，將顯示於列表卡片..."><?= ev_h($ef['summary']) ?></textarea></div>
                        <div><label class="na-label">活動內文（支援 HTML）</label><textarea name="description" rows="10" class="na-textarea font-mono text-[12px]" placeholder="<p>活動詳細說明...</p>"><?= ev_h($ef['description']) ?></textarea></div>
                        <div><label class="na-label">重點獎勵一覽（卡片）</label><input type="text" name="reward_summary" value="<?= ev_h($ef['reward_summary']) ?>" class="na-input" placeholder="例：十萬金元寶、全服專屬雕像"></div>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <h2 class="text-sm font-bold text-slate-900"><i class="fa-solid fa-gift text-rose-600 mr-1.5"></i>活動獎勵清單</h2>
                        <button type="button" onclick="eaAddRewardRow()" class="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600 text-[11px] font-semibold"><i class="fa-solid fa-plus mr-1"></i>新增獎勵</button>
                    </div>
                    <div id="reward-rows" class="space-y-2.5">
                        <?php if (empty($editRewards)): ?>
                            <div class="ev-reward-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                                <input type="hidden" name="rewards[0][id]" value="0">
                                <input class="na-input" name="rewards[0][stage_label]" placeholder="階段標籤（如 首日登臨）">
                                <input class="na-input" name="rewards[0][item]" placeholder="獎勵內容">
                                <input class="na-input" name="rewards[0][note]" placeholder="獎勵說明">
                                <label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="rewards[0][highlight]" value="1"> 壓軸</label>
                                <input type="hidden" name="rewards[0][sort_order]" value="0">
                                <button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest('.ev-reward-row').remove()"><i class="fa-solid fa-trash"></i> 移除</button>
                            </div>
                        <?php else: foreach ($editRewards as $ri => $r): ?>
                            <div class="ev-reward-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                                <input type="hidden" name="rewards[<?= $ri ?>][id]" value="<?= (int)$r['id'] ?>">
                                <input class="na-input" name="rewards[<?= $ri ?>][stage_label]" value="<?= ev_h($r['stage_label']) ?>" placeholder="階段標籤">
                                <input class="na-input" name="rewards[<?= $ri ?>][item]" value="<?= ev_h($r['item']) ?>" placeholder="獎勵內容">
                                <input class="na-input" name="rewards[<?= $ri ?>][note]" value="<?= ev_h($r['note']) ?>" placeholder="獎勵說明">
                                <label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="rewards[<?= $ri ?>][highlight]" value="1" <?= (int)$r['highlight'] === 1 ? 'checked' : '' ?>> 壓軸</label>
                                <input type="hidden" name="rewards[<?= $ri ?>][sort_order]" value="<?= (int)$r['sort_order'] ?>">
                                <button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest('.ev-reward-row').remove()"><i class="fa-solid fa-trash"></i> 移除</button>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                    <p class="na-help">精選主打活動的獎勵矩陣，以及活動詳情頁的獎勵清單皆由此產生。</p>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-image text-sky-600 mr-1.5"></i>主視覺與期間</h2>
                    <div class="space-y-4">
                        <div><label class="na-label">主視覺圖網址</label><input type="text" name="image" value="<?= ev_h($ef['image']) ?>" class="na-input font-mono text-[11px]" placeholder="https://..."></div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label class="na-label">活動期間文字</label><input type="text" name="period_text" value="<?= ev_h($ef['period_text']) ?>" class="na-input" placeholder="2025/04/01 ~ 2025/04/30"></div>
                            <div><label class="na-label">倒數截止時間</label><input type="datetime-local" name="countdown_at" value="<?= ev_h($cdLocal) ?>" class="na-input"></div>
                        </div>
                        <?php if (!empty($ef['image'])): ?><div class="border border-slate-200 rounded-lg overflow-hidden"><img src="<?= ev_h($ef['image']) ?>" alt="主視覺預覽" class="w-full max-h-52 object-cover"></div><?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-4 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-sliders text-sky-600 mr-1.5"></i>上架設定</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">主色系</label>
                            <select name="accent" class="na-select">
                                <?php foreach (['rose','sky','emerald','amber','violet','indigo','teal','slate'] as $ac): ?>
                                    <option value="<?= $ac ?>" <?= $ef['accent'] === $ac ? 'selected' : '' ?>><?= $ac ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="is_featured" value="1" class="w-4 h-4 accent-rose-700" <?= $ef['is_featured'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-star text-amber-500"></i> 設為精選主打（前台大型展示）</label>
                        <div><label class="na-label">精選上方標籤</label><input type="text" name="featured_kicker" value="<?= ev_h($ef['featured_kicker']) ?>" class="na-input" placeholder="LIMITED GRAND FESTIVAL"></div>
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="enabled" value="1" class="w-4 h-4 accent-emerald-600" <?= $ef['enabled'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-power-off text-emerald-600"></i> 上架此活動</label>
                        <div><label class="na-label">排序</label><input type="number" name="sort_order" value="<?= (int)$ef['sort_order'] ?>" class="na-input"></div>
                    </div>
                    <div class="flex flex-col gap-2 mt-5 pt-4 border-t border-slate-200">
                        <button type="submit" class="btn-vermilion w-full py-2.5 text-sm font-bold rounded-lg flex items-center justify-center gap-2"><i class="fa-solid fa-floppy-disk"></i> <?= $isEditEvent ? '儲存並更新' : '建立活動' ?></button>
                        <a href="events_admin.php?section=events" class="w-full py-2.5 text-sm font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600 text-center">取消返回</a>
                    </div>
                    <?php if ($isEditEvent): ?>
                        <div class="ink-divider my-4"></div>
                        <div class="text-[11px] text-slate-500 space-y-1">
                            <div><i class="fa-regular fa-clock mr-1"></i>建立：<?= ev_h($editEvent['created_at']) ?></div>
                            <div><i class="fa-solid fa-rotate mr-1"></i>更新：<?= ev_h($editEvent['updated_at']) ?></div>
                            <div><i class="fa-solid fa-eye mr-1"></i>瀏覽：<?= number_format((int)$editEvent['view_count']) ?> 次</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>
<?php elseif ($section === 'categories'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700"><i class="fa-solid fa-layer-group"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">活動分類管理</h2><p class="text-[11px] text-slate-500">分類即前台的活動頁籤（進行中／常駐／即將開啟／已結束）</p></div>
                </div>
                <div class="overflow-x-auto rounded-lg border border-slate-200">
                    <table class="na-table">
                        <thead><tr><th>分類</th><th>代碼</th><th>活動數</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($categories as $c): $ccnt = 0; $r = $db->query("SELECT COUNT(*) AS n FROM `ev_events` WHERE `category_id` = " . (int)$c['id']); if ($r) { $ccnt = (int)$r->fetch_assoc()['n']; } ?>
                            <tr>
                                <td class="font-semibold text-slate-800"><i class="fa-solid <?= $c['icon'] && strpos($c['icon'], 'fa-') === 0 ? ev_h($c['icon']) : 'fa-tag' ?> text-slate-400 mr-1.5"></i><?= ev_h($c['name']) ?></td>
                                <td class="font-mono text-[11px] text-slate-500"><?= ev_h($c['code']) ?></td>
                                <td class="font-mono text-slate-600"><?= $ccnt ?></td>
                                <td class="text-center">
                                    <form method="POST" action="events_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_category">
                                        <input type="hidden" name="category_id" value="<?= (int)$c['id'] ?>">
                                        <button type="submit" class="na-badge <?= (int)$c['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$c['enabled'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$c['enabled'] === 1 ? '啟用' : '停用' ?></button>
                                    </form>
                                </td>
                                <td class="text-right whitespace-nowrap">
                                    <button type="button" onclick="eaEditCategory(<?= htmlspecialchars(json_encode($c, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="events_admin.php" class="inline" onsubmit="return eaConfirmSubmit(this, '確定刪除分類「<?= ev_h($c['name']) ?>」？');">
                                        <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_category">
                                        <input type="hidden" name="category_id" value="<?= (int)$c['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="lg:col-span-4">
                <form method="POST" action="events_admin.php" id="cf-form" class="glass-panel corner-accent rounded-xl p-5">
                    <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_category">
                    <input type="hidden" name="category_id" id="cf-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="cf-title"><i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增分類</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">分類代碼 (code) <span class="text-rose-600">*</span></label><input type="text" name="code" id="cf-code" required class="na-input font-mono text-xs" placeholder="例：ongoing"></div>
                        <div><label class="na-label">分類名稱 <span class="text-rose-600">*</span></label><input type="text" name="name" id="cf-name" required class="na-input" placeholder="例：進行中活動"></div>
                        <div><label class="na-label">英文名稱</label><input type="text" name="name_en" id="cf-name-en" class="na-input" placeholder="ONGOING"></div>
                        <div><label class="na-label">Material 圖示</label><input type="text" name="icon" id="cf-icon" class="na-input font-mono text-xs" placeholder="celebration"></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">主色系</label>
                                <select name="accent" id="cf-accent" class="na-select">
                                    <option value="rose">rose</option><option value="sky">sky</option><option value="emerald">emerald</option><option value="amber">amber</option><option value="violet">violet</option><option value="slate">slate</option>
                                </select>
                            </div>
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="cf-sort" value="0" class="na-input"></div>
                        </div>
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="enabled" value="1" id="cf-enabled" class="w-4 h-4 accent-amber-600" checked> 啟用此分類</label>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="eaResetCategory()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
<?php elseif ($section === 'notes'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-7 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-violet-50 border border-violet-200 flex items-center justify-center text-violet-700"><i class="fa-solid fa-scale-balanced"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">活動注意事項 / 領賞規則</h2><p class="text-[11px] text-slate-500">前台「注意事項」手風琴區塊內容</p></div>
                </div>
                <div class="space-y-3">
                    <?php if (empty($allNotes)): ?><div class="text-center text-slate-400 py-6">尚無注意事項</div><?php endif; ?>
                    <?php foreach ($allNotes as $n): ?>
                        <div class="border border-slate-200 rounded-lg p-3.5 bg-slate-50">
                            <div class="flex items-start justify-between gap-3">
                                <div class="min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="na-badge bg-rose-50 text-rose-700 border-rose-200"><?= ev_h($n['no_label']) ?></span>
                                        <?php if ((int)$n['enabled'] !== 1): ?><span class="na-badge bg-slate-100 text-slate-500 border-slate-300">停用</span><?php endif; ?>
                                    </div>
                                    <div class="font-semibold text-slate-800 text-[13px]"><?= ev_h($n['question']) ?></div>
                                </div>
                                <div class="flex items-center gap-1 flex-none">
                                    <button type="button" onclick="eaEditNote(<?= htmlspecialchars(json_encode($n, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-white hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="events_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_note">
                                        <input type="hidden" name="note_id" value="<?= (int)$n['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-white hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-power-off"></i></button>
                                    </form>
                                    <form method="POST" action="events_admin.php" class="inline" onsubmit="return eaConfirmSubmit(this, '確定刪除此注意事項？');">
                                        <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_note">
                                        <input type="hidden" name="note_id" value="<?= (int)$n['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-white hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="lg:col-span-5">
                <form method="POST" action="events_admin.php" id="nf-form" class="glass-panel corner-accent rounded-xl p-5">
                    <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_note">
                    <input type="hidden" name="note_id" id="nf-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="nf-title"><i class="fa-solid fa-circle-plus text-violet-600 mr-1.5"></i>新增注意事項</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">編號</label><input type="text" name="no_label" id="nf-no" class="na-input" placeholder="01"></div>
                        <div><label class="na-label">條目標題 <span class="text-rose-600">*</span></label><input type="text" name="question" id="nf-question" required class="na-input" placeholder="例：活動獎勵的發送方式與領取期限為何？"></div>
                        <div><label class="na-label">說明內容（支援 HTML）</label><textarea name="answer" id="nf-answer" rows="8" class="na-textarea font-mono text-[11px]" placeholder="<p>說明內容...</p>"></textarea></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="nf-sort" value="0" class="na-input"></div>
                            <label class="flex items-end gap-2 text-xs text-slate-700 cursor-pointer select-none pb-2"><input type="checkbox" name="enabled" value="1" id="nf-enabled" class="w-4 h-4 accent-violet-600" checked> 啟用</label>
                        </div>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="eaResetNote()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
<?php elseif ($section === 'settings'): ?>
        <form method="POST" action="events_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= ev_h($formToken) ?>">
            <input type="hidden" name="action" value="save_settings">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700"><i class="fa-solid fa-sliders"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">活動系統設定</h2><p class="text-[11px] text-slate-500">即時套用於前台活動頁文案與顯示開關</p></div>
                </div>
                <div class="mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-heading text-rose-500"></i><span>主視覺</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label class="na-label">主視覺英文標籤</label><input type="text" name="set_hero_kicker" value="<?= ev_h($SET['hero_kicker'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">主視覺季節標示</label><input type="text" name="set_hero_season" value="<?= ev_h($SET['hero_season'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">主視覺標題 (H1)</label><input type="text" name="set_hero_title" value="<?= ev_h($SET['hero_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">主視覺副標</label><textarea name="set_hero_subtitle" rows="2" class="na-textarea"><?= ev_h($SET['hero_subtitle'] ?? '') ?></textarea></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-chart-simple text-sky-500"></i><span>頁首統計卡</span></div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div><label class="na-label">統計一標題</label><input type="text" name="set_stat1_label" value="<?= ev_h($SET['stat1_label'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">統計一數值</label><input type="text" name="set_stat1_value" value="<?= ev_h($SET['stat1_value'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">統計一副標</label><input type="text" name="set_stat1_sub" value="<?= ev_h($SET['stat1_sub'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">統計二標題</label><input type="text" name="set_stat2_label" value="<?= ev_h($SET['stat2_label'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">統計二副標</label><input type="text" name="set_stat2_sub" value="<?= ev_h($SET['stat2_sub'] ?? '') ?>" class="na-input"></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-list-ul text-emerald-500"></i><span>列表與注意事項</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2"><label class="na-label">活動列表標題</label><input type="text" name="set_grid_title" value="<?= ev_h($SET['grid_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">注意事項標題</label><input type="text" name="set_rules_title" value="<?= ev_h($SET['rules_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">注意事項副標</label><textarea name="set_rules_subtitle" rows="2" class="na-textarea"><?= ev_h($SET['rules_subtitle'] ?? '') ?></textarea></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-headset text-violet-500"></i><span>客服協助</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label class="na-label">協助標題</label><input type="text" name="set_assist_title" value="<?= ev_h($SET['assist_title'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">按鈕文字</label><input type="text" name="set_assist_btn_text" value="<?= ev_h($SET['assist_btn_text'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">協助說明</label><textarea name="set_assist_text" rows="2" class="na-textarea"><?= ev_h($SET['assist_text'] ?? '') ?></textarea></div>
                    <div class="md:col-span-2"><label class="na-label">按鈕連結</label><input type="text" name="set_assist_btn_url" value="<?= ev_h($SET['assist_btn_url'] ?? '') ?>" class="na-input font-mono text-[11px]"></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200">
                    <button type="submit" class="btn-vermilion px-5 py-2.5 text-sm font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1.5"></i>儲存設定</button>
                </div>
            </div>
            <div class="lg:col-span-4 glass-panel corner-accent rounded-xl p-5">
                <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-toggle-on text-sky-600 mr-1.5"></i>顯示開關</h2>
                <div class="space-y-3">
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_stats" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_stats'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示頁首統計卡</label>
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_rules" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_rules'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示注意事項區塊</label>
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_assist" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_assist'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示客服協助區塊</label>
                </div>
                <div class="ink-divider my-4"></div>
                <ul class="text-[11px] text-slate-500 space-y-2 leading-relaxed list-disc pl-4">
                    <li>活動內容、獎勵與上架狀態請至「活動管理」維護。</li>
                    <li>「精選主打」僅能有一個，會顯示於前台大型展示區。</li>
                    <li>注意事項可自由新增／排序，前台以手風琴呈現。</li>
                    <li>所有變更即時生效，無需重新部署。</li>
                </ul>
                <div class="text-[11px] text-slate-400 font-mono mt-3">DB: <?= ev_h(EVENTS_DB_NAME) ?></div>
            </div>
        </form>
<?php endif; ?>
    </main>

    <script>
        (function initSnow() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = (canvas.width = window.innerWidth);
            let height = (canvas.height = window.innerHeight);
            window.addEventListener('resize', () => { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; });
            const particles = [];
            const count = Math.min(Math.floor(window.innerWidth / 28), 42);
            for (let i = 0; i < count; i++) { particles.push({ x: Math.random() * width, y: Math.random() * height, radius: Math.random() * 2.0 + 0.6, speedY: Math.random() * 0.7 + 0.25, speedX: (Math.random() - 0.5) * 0.4, opacity: Math.random() * 0.6 + 0.2 }); }
            function render() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    p.y += p.speedY; p.x += p.speedX;
                    if (p.y > height) { p.y = -5; p.x = Math.random() * width; }
                    if (p.x < 0) p.x = width; if (p.x > width) p.x = 0;
                    ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255,255,255,${p.opacity})`; ctx.shadowBlur = 4; ctx.shadowColor = 'rgba(255,255,255,0.5)'; ctx.fill();
                }
                requestAnimationFrame(render);
            }
            render();
        })();
        window.eaConfirmSubmit = function (form, message) { if (!message || window.confirm(message)) { form.submit(); } return false; };
        window.eaEditCategory = function (c) {
            document.getElementById('cf-id').value = c.id || 0;
            document.getElementById('cf-code').value = c.code || '';
            document.getElementById('cf-name').value = c.name || '';
            document.getElementById('cf-name-en').value = c.name_en || '';
            document.getElementById('cf-icon').value = c.icon || '';
            document.getElementById('cf-accent').value = c.accent || 'rose';
            document.getElementById('cf-sort').value = c.sort_order || 0;
            document.getElementById('cf-enabled').checked = String(c.enabled) === '1';
            document.getElementById('cf-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-amber-600 mr-1.5"></i>編輯分類 #' + c.id;
            document.getElementById('cf-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        window.eaResetCategory = function () {
            document.getElementById('cf-form').reset();
            document.getElementById('cf-id').value = 0;
            document.getElementById('cf-title').innerHTML = '<i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增分類';
        };
        window.eaEditNote = function (n) {
            document.getElementById('nf-id').value = n.id || 0;
            document.getElementById('nf-no').value = n.no_label || '';
            document.getElementById('nf-question').value = n.question || '';
            document.getElementById('nf-answer').value = n.answer || '';
            document.getElementById('nf-sort').value = n.sort_order || 0;
            document.getElementById('nf-enabled').checked = String(n.enabled) === '1';
            document.getElementById('nf-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-violet-600 mr-1.5"></i>編輯注意事項 #' + n.id;
            document.getElementById('nf-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        window.eaResetNote = function () {
            document.getElementById('nf-form').reset();
            document.getElementById('nf-id').value = 0;
            document.getElementById('nf-title').innerHTML = '<i class="fa-solid fa-circle-plus text-violet-600 mr-1.5"></i>新增注意事項';
        };
        window.eaAddRewardRow = function () {
            const box = document.getElementById('reward-rows');
            const idx = box.querySelectorAll('.ev-reward-row').length;
            const html = '<div class="ev-reward-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">' +
                '<input type="hidden" name="rewards[' + idx + '][id]" value="0">' +
                '<input class="na-input" name="rewards[' + idx + '][stage_label]" placeholder="階段標籤（如 首日登臨）">' +
                '<input class="na-input" name="rewards[' + idx + '][item]" placeholder="獎勵內容">' +
                '<input class="na-input" name="rewards[' + idx + '][note]" placeholder="獎勵說明">' +
                '<label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="rewards[' + idx + '][highlight]" value="1"> 壓軸</label>' +
                '<input type="hidden" name="rewards[' + idx + '][sort_order]" value="' + idx + '">' +
                '<button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest(\'.ev-reward-row\').remove()"><i class="fa-solid fa-trash"></i> 移除</button>' +
                '</div>';
            box.insertAdjacentHTML('beforeend', html);
        };
    </script>
</body>
</html>
