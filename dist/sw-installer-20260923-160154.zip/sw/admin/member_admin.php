<?php
/**
 * =============================================================
 *  踏雪笑傲 · 會員權限管理後台（GM 端）
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *
 *  功能：會員搜尋、功能權限細部控制（儲值 / 兌換 / 修改密碼 /
 *        申訴回報 / 檢視資產 / 遊戲下載）、一鍵全開或全關
 *  對應資料表：user_permissions（首次進入自動建立）
 *  前台檢查：../permissions.php
 * =============================================================
 */
session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../permissions.php';

if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
$currentGmUsername = (string)$_SESSION['gm_username'];
$currentGmId = (int)($_SESSION['gm_id'] ?? 0);

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($Link, "utf8mb4");

function pmd_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** 確保權限資料表存在，並為既有會員補上預設列 */
function permissions_ensure_table($Link)
{
    $sql = "CREATE TABLE IF NOT EXISTS `user_permissions` (
        `uid` int(11) NOT NULL,
        `can_recharge` tinyint(1) NOT NULL DEFAULT 1,
        `can_exchange` tinyint(1) NOT NULL DEFAULT 1,
        `can_change_password` tinyint(1) NOT NULL DEFAULT 1,
        `can_support` tinyint(1) NOT NULL DEFAULT 1,
        `can_view_assets` tinyint(1) NOT NULL DEFAULT 1,
        `can_download` tinyint(1) NOT NULL DEFAULT 1,
        `updated_by` varchar(50) NOT NULL DEFAULT '',
        `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`uid`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    try {
        $Link->query($sql);
        $Link->query("INSERT INTO `user_permissions` (`uid`) SELECT `ID` FROM `users` WHERE `ID` NOT IN (SELECT `uid` FROM `user_permissions`)");
    } catch (Throwable $e) {
        // 資料庫權限不足時略過，前台仍會以預設值運作
    }
}
permissions_ensure_table($Link);

if (empty($_SESSION['member_admin_token'])) {
    $_SESSION['member_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['member_admin_token'];

$notice = '';
$noticeType = 'success';

// ------------------------------------------------------------
// 表單處理（PRG）
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['form_token']) || !hash_equals($_SESSION['member_admin_token'], (string)$_POST['form_token'])) {
        $notice = '工作階段已過期，請重新操作。';
        $noticeType = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        $uid = (int)($_POST['uid'] ?? 0);

        if ($uid <= 0) {
            $notice = '請先選擇要設定的會員。';
            $noticeType = 'danger';
        } elseif ($action === 'save_permissions') {
            $keys = member_permission_keys();
            $values = [];
            foreach ($keys as $key) {
                $values[$key] = (isset($_POST['perm'][$key]) ? 1 : 0);
            }
            $cols = '`uid`,`' . implode('`,`', $keys) . '`,`updated_by`';
            $holders = implode(',', array_fill(0, count($keys) + 2, '?'));
            $updates = [];
            foreach ($keys as $key) { $updates[] = "`$key`=VALUES(`$key`)"; }
            $updates[] = "`updated_by`=VALUES(`updated_by`)";
            $sql = "INSERT INTO `user_permissions` ($cols) VALUES ($holders)
                    ON DUPLICATE KEY UPDATE " . implode(',', $updates);
            $types = 'i' . str_repeat('i', count($keys)) . 's';
            $params = array_merge([$uid], array_values($values), [$currentGmUsername]);
            try {
                $stmt = $Link->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();
                $off = [];
                foreach ($keys as $key) {
                    if (!$values[$key]) {
                        $map = member_permission_map();
                        $off[] = $map[$key]['label'] ?? $key;
                    }
                }
                $notice = '已更新會員 UID ' . $uid . ' 的權限設定。';
                if ($off) {
                    $notice .= ' 目前未開放：' . implode('、', $off) . '。';
                }
                $backUid = $uid;
            } catch (Throwable $e) {
                $notice = '儲存失敗：' . $e->getMessage();
                $noticeType = 'danger';
            }
        } elseif ($action === 'save_all' || $action === 'clear_all') {
            $keys = member_permission_keys();
            $values = [];
            foreach ($keys as $key) { $values[$key] = ($action === 'save_all') ? 1 : 0; }
            $cols = '`uid`,`' . implode('`,`', $keys) . '`,`updated_by`';
            $holders = implode(',', array_fill(0, count($keys) + 2, '?'));
            $updates = [];
            foreach ($keys as $key) { $updates[] = "`$key`=VALUES(`$key`)"; }
            $updates[] = "`updated_by`=VALUES(`updated_by`)";
            $sql = "INSERT INTO `user_permissions` ($cols) VALUES ($holders)
                    ON DUPLICATE KEY UPDATE " . implode(',', $updates);
            $types = 'i' . str_repeat('i', count($keys)) . 's';
            $params = array_merge([$uid], array_values($values), [$currentGmUsername]);
            try {
                $stmt = $Link->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $stmt->close();
                $notice = ($action === 'save_all') ? '已將該會員所有功能權限設為「開放」。' : '已將該會員所有功能權限設為「停用」。';
                $backUid = $uid;
            } catch (Throwable $e) {
                $notice = '儲存失敗：' . $e->getMessage();
                $noticeType = 'danger';
            }
        } else {
            $notice = '未知的操作。';
            $noticeType = 'danger';
        }

        if ($noticeType !== 'danger') {
            $_SESSION['member_admin_notice'] = ['type' => $noticeType, 'msg' => $notice];
            $redir = 'member_admin.php';
            if (!empty($backUid)) { $redir .= '?uid=' . (int)$backUid; }
            header("Location: " . $redir);
            exit();
        }
    }
}

$flash = $_SESSION['member_admin_notice'] ?? null;
unset($_SESSION['member_admin_notice']);
if ($flash) { $notice = $flash['msg']; $noticeType = $flash['type']; }

// ------------------------------------------------------------
// 統計
// ------------------------------------------------------------
$totalMembers = 0;
$restrictedMembers = 0;
$r = mysqli_query($Link, "SELECT COUNT(*) AS c FROM `users`");
if ($r && ($row = $r->fetch_assoc())) { $totalMembers = (int)$row['c']; }
$r = mysqli_query($Link, "SELECT COUNT(*) AS c FROM `user_permissions` WHERE (can_recharge=0 OR can_exchange=0 OR can_change_password=0 OR can_support=0 OR can_view_assets=0 OR can_download=0)");
if ($r && ($row = $r->fetch_assoc())) { $restrictedMembers = (int)$row['c']; }

// ------------------------------------------------------------
// 會員搜尋 / 列表
// ------------------------------------------------------------
$q = trim((string)($_GET['q'] ?? ''));
$focusUid = (int)($_GET['uid'] ?? 0);
$members = [];
if ($q !== '') {
    $like = '%' . $q . '%';
    if (ctype_digit($q)) {
        $stmt = $Link->prepare(
            "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                    p.`can_recharge`, p.`can_exchange`, p.`can_change_password`,
                    p.`can_support`, p.`can_view_assets`, p.`can_download`, p.`updated_at`
             FROM `users` u LEFT JOIN `user_permissions` p ON p.`uid` = u.`ID`
             WHERE u.`ID` = ? OR u.`name` LIKE ? OR u.`email` LIKE ?
             ORDER BY u.`ID` ASC LIMIT 50"
        );
        $uidInt = (int)$q;
        $stmt->bind_param("iss", $uidInt, $like, $like);
    } else {
        $stmt = $Link->prepare(
            "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                    p.`can_recharge`, p.`can_exchange`, p.`can_change_password`,
                    p.`can_support`, p.`can_view_assets`, p.`can_download`, p.`updated_at`
             FROM `users` u LEFT JOIN `user_permissions` p ON p.`uid` = u.`ID`
             WHERE u.`name` LIKE ? OR u.`email` LIKE ?
             ORDER BY u.`ID` ASC LIMIT 50"
        );
        $stmt->bind_param("ss", $like, $like);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $members[] = $row; }
    $stmt->close();
} else {
    $r = mysqli_query(
        $Link,
        "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                p.`can_recharge`, p.`can_exchange`, p.`can_change_password`,
                p.`can_support`, p.`can_view_assets`, p.`can_download`, p.`updated_at`
         FROM `users` u LEFT JOIN `user_permissions` p ON p.`uid` = u.`ID`
         ORDER BY u.`ID` DESC LIMIT 30"
    );
    if ($r) { while ($row = $r->fetch_assoc()) { $members[] = $row; } }
}

// ------------------------------------------------------------
// 焦點會員權限
// ------------------------------------------------------------
$focus = null;
$focusPerms = member_permission_defaults();
if ($focusUid > 0) {
    $stmt = $Link->prepare("SELECT `ID`, `name`, `email`, `creatime` FROM `users` WHERE `ID` = ? LIMIT 1");
    $stmt->bind_param("i", $focusUid);
    $stmt->execute();
    $focus = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($focus) {
        $focusPerms = member_permissions_load($Link, $focusUid);
    } else {
        $notice = '找不到該會員。';
        $noticeType = 'danger';
    }
}

mysqli_close($Link);

$permMeta = member_permission_map();
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>踏雪笑傲 · 會員權限管理</title>
<link rel="stylesheet" href="assets/tailwind.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Noto+Sans+TC:wght@300;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    :root { --vermilion:#be123c; --gold:#d97706; --ice:#0284c7; }
    * { box-sizing:border-box; }
    body {
        margin:0; background-color:#080c14; color:#1e293b;
        font-family:'Noto Sans TC','Noto Serif TC',sans-serif; min-height:100vh;
        background-image:
            radial-gradient(ellipse at 50% 0%, rgba(190,18,60,.12) 0%, transparent 60%),
            radial-gradient(ellipse at 80% 90%, rgba(2,132,199,.10) 0%, transparent 50%),
            radial-gradient(ellipse at 20% 60%, rgba(15,23,42,.82) 0%, transparent 70%);
    }
    a { text-decoration:none; }
    .md-top { border-bottom:1px solid #1e293b; background:rgba(12,16,26,.92); backdrop-filter:blur(10px); position:sticky; top:0; z-index:30; }
    .md-wrap { max-width:1200px; margin:0 auto; padding:0 16px; }
    .md-header { display:flex; align-items:center; justify-content:space-between; height:64px; }
    .md-logo { display:flex; align-items:center; gap:12px; color:#e2e8f0; }
    .md-logo img { width:36px; height:36px; border-radius:50%; border:1px solid #334155; padding:2px; background:rgba(255,255,255,.08); }
    .md-logo .brand { font-family:'Noto Serif TC',serif; font-size:19px; font-weight:700; letter-spacing:.16em; }
    .md-logo .sub { font-size:10px; color:#94a3b8; letter-spacing:.2em; text-transform:uppercase; font-family:'Cinzel',serif; margin:0; }
    .md-tag { font-size:10px; letter-spacing:.1em; padding:2px 8px; border-radius:4px; background:rgba(76,29,149,.75); color:#ddd6fe; border:1px solid rgba(109,40,217,.6); margin-left:8px; font-weight:500; }
    .md-nav { display:flex; align-items:center; gap:8px; }
    .md-nav a.link { padding:6px 12px; font-size:12px; color:#cbd5e1; border-radius:6px; transition:.2s; display:flex; align-items:center; gap:6px; }
    .md-nav a.link:hover { color:#fff; background:rgba(30,41,59,.8); }
    .md-nav a.link.active { color:#ddd6fe; background:rgba(76,29,149,.5); border:1px solid rgba(109,40,217,.6); }
    .md-user { display:flex; align-items:center; gap:10px; padding:4px 12px; background:rgba(15,23,42,.9); border:1px solid rgba(76,29,149,.5); border-radius:999px; font-size:12px; color:#94a3b8; }
    .md-user b { color:#c4b5fd; font-family:monospace; }
    .md-out { padding:5px 10px; font-size:12px; color:#fb7185; border:1px solid rgba(159,18,57,.5); border-radius:6px; transition:.2s; }
    .md-out:hover { color:#fecdd3; background:rgba(76,5,25,.5); }

    .md-main { max-width:1200px; margin:0 auto; padding:28px 16px 60px; }
    .md-title { color:#f1f5f9; font-family:'Noto Serif TC',serif; font-size:26px; letter-spacing:.06em; margin:0 0 6px; display:flex; align-items:center; gap:10px; }
    .md-title .bar { width:8px; height:26px; background:var(--vermilion); border-radius:2px; }
    .md-desc { color:#94a3b8; font-size:13px; margin:0 0 22px; }

    .md-kpis { display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:16px; margin-bottom:22px; }
    .md-kpi { background:rgba(255,255,255,.95); border:1px solid rgba(226,232,240,.85); border-radius:16px; padding:18px 20px; box-shadow:0 12px 30px -14px rgba(0,0,0,.5); }
    .md-kpi span.k { font-size:12px; color:#64748b; display:block; margin-bottom:6px; }
    .md-kpi .v { font-size:26px; font-weight:800; font-family:monospace; }
    .md-kpi .v.rose { color:#be123c; }
    .md-kpi .v.sky { color:#0284c7; }

    .md-grid { display:grid; grid-template-columns:1fr; gap:20px; }
    @media (min-width:960px) { .md-grid { grid-template-columns:380px 1fr; align-items:start; } }

    .md-panel { background:rgba(255,255,255,.96); border:1px solid rgba(226,232,240,.9); border-radius:18px; box-shadow:0 16px 40px -22px rgba(0,0,0,.6); overflow:hidden; }
    .md-panel-head { padding:16px 20px; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .md-panel-head h2 { margin:0; font-size:15px; color:#1e293b; font-family:'Noto Serif TC',serif; display:flex; align-items:center; gap:8px; }
    .md-panel-body { padding:16px 20px; }

    .md-search { display:flex; gap:8px; }
    .md-input { flex:1; border:1px solid #cbd5e1; border-radius:9px; padding:9px 12px; font-size:13px; color:#1e293b; background:#fff; transition:.2s; }
    .md-input:focus { outline:none; border-color:var(--vermilion); box-shadow:0 0 0 3px rgba(190,18,60,.12); }
    .md-btn { border:none; cursor:pointer; border-radius:9px; padding:9px 16px; font-size:13px; font-weight:600; color:#fff; transition:.22s; display:inline-flex; align-items:center; justify-content:center; gap:7px; }
    .md-btn.rose { background:linear-gradient(135deg,#e11d48,#9f1239); }
    .md-btn.rose:hover { background:linear-gradient(135deg,#fb7185,#e11d48); transform:translateY(-1px); }
    .md-btn.ice { background:linear-gradient(135deg,#0284c7,#0369a1); }
    .md-btn.ice:hover { background:linear-gradient(135deg,#0ea5e9,#0284c7); transform:translateY(-1px); }
    .md-btn.green { background:linear-gradient(135deg,#10b981,#047857); }
    .md-btn.green:hover { background:linear-gradient(135deg,#34d399,#10b981); transform:translateY(-1px); }
    .md-btn.gray { background:#64748b; }
    .md-btn.gray:hover { background:#475569; }
    .md-btn.sm { padding:7px 12px; font-size:12px; }

    .md-list { list-style:none; margin:14px 0 0; padding:0; max-height:560px; overflow-y:auto; }
    .md-list li { border:1px solid #e2e8f0; border-radius:12px; margin-bottom:9px; transition:.2s; }
    .md-list li:hover { border-color:#94a3b8; background:#f8fafc; }
    .md-list li.active { border-color:var(--vermilion); background:#fff1f2; box-shadow:0 0 0 3px rgba(190,18,60,.08); }
    .md-list a { display:block; padding:11px 13px; color:inherit; }
    .md-list .mrow { display:flex; align-items:center; justify-content:space-between; gap:8px; }
    .md-list .mname { font-weight:700; color:#1e293b; font-size:14px; }
    .md-list .muid { font-size:11px; color:#94a3b8; font-family:monospace; }
    .md-list .memail { font-size:11px; color:#64748b; margin-top:2px; word-break:break-all; }
    .md-list .offcount { font-size:10px; font-weight:700; padding:2px 7px; border-radius:999px; background:#fee2e2; color:#b91c1c; border:1px solid #fecaca; white-space:nowrap; }
    .md-list .oncount { font-size:10px; font-weight:700; padding:2px 7px; border-radius:999px; background:#dcfce7; color:#15803d; border:1px solid #bbf7d0; white-space:nowrap; }

    .perm-row { display:flex; align-items:flex-start; gap:14px; padding:14px 16px; border:1px solid #e2e8f0; border-radius:14px; margin-bottom:11px; transition:.2s; background:#fff; }
    .perm-row:hover { border-color:#cbd5e1; }
    .perm-row.enabled { border-color:#bbf7d0; background:linear-gradient(180deg,#f0fdf4,#fff); }
    .perm-row.disabled { border-color:#fecaca; background:linear-gradient(180deg,#fff1f2,#fff); }
    .perm-ico { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; color:#fff; }
    .perm-ico.amber { background:linear-gradient(135deg,#f59e0b,#d97706); }
    .perm-ico.sky { background:linear-gradient(135deg,#0284c7,#0369a1); }
    .perm-ico.rose { background:linear-gradient(135deg,#e11d48,#9f1239); }
    .perm-ico.violet { background:linear-gradient(135deg,#7c3aed,#5b21b6); }
    .perm-ico.emerald { background:linear-gradient(135deg,#10b981,#047857); }
    .perm-ico.slate { background:linear-gradient(135deg,#64748b,#334155); }
    .perm-info { flex:1; min-width:0; }
    .perm-info .pname { font-size:14px; font-weight:700; color:#1e293b; display:flex; align-items:center; gap:7px; }
    .perm-info .pdesc { font-size:12px; color:#64748b; margin-top:3px; line-height:1.5; }
    .perm-info .page { font-size:10px; color:#94a3b8; font-family:monospace; margin-top:4px; }
    .perm-switch { position:relative; display:inline-block; width:52px; height:28px; flex-shrink:0; margin-top:4px; }
    .perm-switch input { opacity:0; width:0; height:0; }
    .perm-slider { position:absolute; cursor:pointer; inset:0; background:#cbd5e1; border-radius:999px; transition:.25s; }
    .perm-slider::before { content:''; position:absolute; height:20px; width:20px; left:4px; top:4px; background:#fff; border-radius:50%; transition:.25s; box-shadow:0 2px 4px rgba(0,0,0,.2); }
    .perm-switch input:checked + .perm-slider { background:linear-gradient(135deg,#10b981,#047857); }
    .perm-switch input:checked + .perm-slider::before { transform:translateX(24px); }

    .md-empty { text-align:center; padding:60px 20px; color:#94a3b8; }
    .md-empty i { font-size:46px; margin-bottom:14px; color:#cbd5e1; display:block; }
    .md-notice { border-radius:14px; padding:14px 18px; font-size:13px; margin-bottom:20px; display:flex; align-items:flex-start; gap:10px; border-left:4px solid; background:#fff; box-shadow:0 8px 24px -16px rgba(0,0,0,.5); }
    .md-notice.success { border-left-color:#10b981; }
    .md-notice.danger { border-left-color:#e11d48; }
    .md-focus-head { display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
    .md-focus-avatar { width:52px; height:52px; border-radius:14px; background:linear-gradient(135deg,#7c3aed,#4c1d95); color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:700; font-family:'Noto Serif TC',serif; }
    .md-focus-meta h3 { margin:0; font-size:17px; color:#1e293b; }
    .md-focus-meta p { margin:2px 0 0; font-size:12px; color:#64748b; }
    .md-actions { display:flex; gap:9px; flex-wrap:wrap; margin:16px 0 4px; }
    .md-legend { font-size:11px; color:#94a3b8; margin-top:14px; }
</style>
</head>
<body>

<header class="md-top">
    <div class="md-wrap md-header">
        <a href="gmpanel.php" class="md-logo">
            <img src="../assets/logo.svg" alt="踏雪笑傲">
            <div>
                <div style="display:flex;align-items:center;">
                    <span class="brand">踏雪笑傲</span>
                    <span class="md-tag">會員權限</span>
                </div>
                <p class="sub">Member Permission Console</p>
            </div>
        </a>
        <nav class="md-nav">
            <a href="gmpanel.php" class="link"><i class="fa-solid fa-gauge-high"></i><span>GM 控制台</span></a>
            <a href="wallet_admin.php" class="link"><i class="fa-solid fa-coins" style="color:#fbbf24;"></i><span>錢包管理</span></a>
            <a href="support_admin.php" class="link"><i class="fa-solid fa-headset"></i><span>申訴回報</span></a>
            <a href="member_admin.php" class="link active"><i class="fa-solid fa-user-shield"></i><span>會員權限</span></a>
            <div class="md-user"><i class="fa-solid fa-user-tie" style="color:#a78bfa;"></i> 管理員：<b><?= pmd_h($currentGmUsername) ?></b></div>
            <a href="gmlogout.php" class="md-out"><i class="fa-solid fa-arrow-right-from-bracket"></i> 登出</a>
        </nav>
    </div>
</header>

<main class="md-main">
    <h1 class="md-title"><span class="bar"></span>會員功能權限管理</h1>
    <p class="md-desc">針對個別帳號開放或停用站內功能；未開放的項目在會員端點擊時會以彈出視窗提示，且無法進入該功能頁面。</p>

    <?php if ($notice !== ''): ?>
    <div class="md-notice <?= $noticeType === 'danger' ? 'danger' : 'success' ?>">
        <i class="fa-solid <?= $noticeType === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>" style="color:<?= $noticeType === 'danger' ? '#e11d48' : '#10b981' ?>;margin-top:2px;"></i>
        <span style="color:#334155;"><?= pmd_h($notice) ?></span>
    </div>
    <?php endif; ?>

    <div class="md-kpis">
        <div class="md-kpi"><span class="k">會員總數</span><span class="v sky"><?= number_format($totalMembers) ?></span></div>
        <div class="md-kpi"><span class="k">有限制權限的會員</span><span class="v rose"><?= number_format($restrictedMembers) ?></span></div>
        <div class="md-kpi"><span class="k">可管理功能項目</span><span class="v"><?= count($permMeta) ?></span></div>
    </div>

    <div class="md-grid">
        <!-- 會員列表 -->
        <section class="md-panel">
            <div class="md-panel-head">
                <h2><i class="fa-solid fa-list-ul" style="color:#0284c7;"></i>會員帳號</h2>
                <span style="font-size:11px;color:#94a3b8;">共 <?= count($members) ?> 筆</span>
            </div>
            <div class="md-panel-body">
                <form method="GET" action="member_admin.php" class="md-search">
                    <input type="text" name="q" class="md-input" placeholder="帳號 / 暱稱 / Email / UID" value="<?= pmd_h($q) ?>">
                    <button type="submit" class="md-btn rose"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
                <ul class="md-list">
                    <?php if (!$members): ?>
                        <li style="border:none;"><div style="text-align:center;color:#94a3b8;font-size:13px;padding:24px 0;">無符合條件的會員</div></li>
                    <?php else: foreach ($members as $m):
                        $offCnt = 0;
                        foreach (member_permission_keys() as $k) {
                            if (isset($m[$k]) && (int)$m[$k] === 0) { $offCnt++; }
                        }
                        $isActive = ((int)$m['ID'] === $focusUid);
                    ?>
                        <li class="<?= $isActive ? 'active' : '' ?>">
                            <a href="member_admin.php?uid=<?= (int)$m['ID'] ?><?= $q !== '' ? '&q=' . urlencode($q) : '' ?>">
                                <div class="mrow">
                                    <span class="mname"><?= pmd_h($m['name']) ?></span>
                                    <?php if ($offCnt > 0): ?>
                                        <span class="offcount">停用 <?= $offCnt ?> 項</span>
                                    <?php else: ?>
                                        <span class="oncount">全部開放</span>
                                    <?php endif; ?>
                                </div>
                                <div class="muid">UID: <?= (int)$m['ID'] ?><?= !empty($m['updated_at']) ? ' · 更新 ' . pmd_h(date('Y-m-d', strtotime($m['updated_at']))) : '' ?></div>
                                <?php if (!empty($m['email'])): ?><div class="memail"><i class="fa-regular fa-envelope"></i> <?= pmd_h($m['email']) ?></div><?php endif; ?>
                            </a>
                        </li>
                    <?php endforeach; endif; ?>
                </ul>
            </div>
        </section>

        <!-- 權限編輯 -->
        <section class="md-panel">
            <?php if (!$focus): ?>
                <div class="md-empty">
                    <i class="fa-solid fa-user-shield"></i>
                    <p style="font-size:15px;color:#64748b;margin:0 0 4px;">請從左側選擇會員帳號</p>
                    <p style="font-size:12px;">即可進行儲值、兌換、修改密碼、申訴回報等功能的細部權限控制。</p>
                </div>
            <?php else: ?>
                <div class="md-panel-head">
                    <h2><i class="fa-solid fa-sliders" style="color:#7c3aed;"></i>權限設定</h2>
                </div>
                <div class="md-panel-body">
                    <div class="md-focus-head">
                        <div class="md-focus-avatar"><?= pmd_h(mb_strtoupper(mb_substr((string)$focus['name'], 0, 1))) ?></div>
                        <div class="md-focus-meta">
                            <h3><?= pmd_h($focus['name']) ?></h3>
                            <p>UID: <?= (int)$focus['ID'] ?><?php if (!empty($focus['email'])): ?> · <?= pmd_h($focus['email']) ?><?php endif; ?></p>
                            <?php if (!empty($focus['creatime']) && $focus['creatime'] !== '0000-00-00 00:00:00'): ?>
                            <p>註冊時間：<?= pmd_h(date('Y-m-d', strtotime($focus['creatime']))) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <form method="POST" action="member_admin.php?uid=<?= (int)$focus['ID'] ?>" id="perm-form">
                        <input type="hidden" name="form_token" value="<?= pmd_h($formToken) ?>">
                        <input type="hidden" name="action" value="save_permissions">
                        <input type="hidden" name="uid" value="<?= (int)$focus['ID'] ?>">

                        <div class="md-actions">
                            <button type="button" class="md-btn green sm" onclick="setAllPerms(true)"><i class="fa-solid fa-toggle-on"></i>一鍵全部開放</button>
                            <button type="button" class="md-btn gray sm" onclick="setAllPerms(false)"><i class="fa-solid fa-toggle-off"></i>一鍵全部停用</button>
                        </div>

                        <?php foreach ($permMeta as $key => $meta): $on = !empty($focusPerms[$key]); ?>
                        <div class="perm-row <?= $on ? 'enabled' : 'disabled' ?>" id="row-<?= pmd_h($key) ?>">
                            <div class="perm-ico <?= pmd_h($meta['color']) ?>"><i class="fa-solid <?= pmd_h($meta['icon']) ?>"></i></div>
                            <div class="perm-info">
                                <div class="pname">
                                    <?= pmd_h($meta['label']) ?>
                                    <?php if (!$on): ?><span style="font-size:10px;font-weight:700;color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;padding:1px 6px;border-radius:999px;">已停用</span><?php endif; ?>
                                </div>
                                <div class="pdesc"><?= pmd_h($meta['desc']) ?></div>
                                <div class="page"><i class="fa-solid fa-link"></i> <?= pmd_h($meta['page']) ?></div>
                            </div>
                            <label class="perm-switch">
                                <input type="checkbox" name="perm[<?= pmd_h($key) ?>]" value="1" data-label="<?= pmd_h($meta['label']) ?>" <?= $on ? 'checked' : '' ?> onchange="togglePerm(this)">
                                <span class="perm-slider"></span>
                            </label>
                        </div>
                        <?php endforeach; ?>

                        <div class="md-actions" style="margin-top:18px;">
                            <button type="submit" class="md-btn rose" style="flex:1;"><i class="fa-solid fa-floppy-disk"></i>儲存權限設定</button>
                        </div>
                        <p class="md-legend"><i class="fa-solid fa-circle-info"></i> 綠色為開放、灰色為停用。停用後，會員於該功能頁面會看到彈出視窗提示且無法使用。</p>
                    </form>
                </div>
            <?php endif; ?>
        </section>
    </div>
</main>

<script>
function togglePerm(cb) {
    var row = cb.closest('.perm-row');
    if (!row) return;
    row.classList.toggle('enabled', cb.checked);
    row.classList.toggle('disabled', !cb.checked);
    var badge = row.querySelector('.pname span');
    if (cb.checked) {
        if (badge) badge.remove();
    } else if (!badge) {
        var span = document.createElement('span');
        span.style.cssText = 'font-size:10px;font-weight:700;color:#b91c1c;background:#fee2e2;border:1px solid #fecaca;padding:1px 6px;border-radius:999px;';
        span.textContent = '已停用';
        var pname = row.querySelector('.pname');
        if (pname) pname.appendChild(span);
    }
}
function setAllPerms(on) {
    document.querySelectorAll('#perm-form .perm-switch input[type=checkbox]').forEach(function (cb) {
        if (cb.checked !== on) {
            cb.checked = on;
            togglePerm(cb);
        }
    });
}
</script>
</body>
</html>
