<?php
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';

// 需透過 gmlogin.php 以有效的 gm_accounts 登入後才能存取
if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
// 後台閒置逾時（8 小時）
app_session_enforce_timeout(60 * 60 * 8);
$currentGmUsername = $_SESSION['gm_username'];
$currentGmId = $_SESSION['gm_id'];

// 來自 gmopgen.xml 的完整操作類型代碼清單 - 將這些授權寫入 auth 資料表，
// 正是原本 exe 逐筆手動編輯所做的事。
$AllGmOperationTypes = [
    0,1,2,3,4,5,6,7,8,9,10,11,
    100,101,102,103,104,105,
    200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,
    501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518
];

if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['form_token'];

$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    http_response_code(500);
    exit('系統暫時無法使用，請稍後再試。');
}
// passwd 是以原始二進位儲存在 utf8 varchar 欄位 - latin1 可原樣傳遞位元組
mysqli_set_charset($Link, "latin1");

$notice = "";
$noticeType = "success"; // or "danger"
$openRechargeModal = false; // 儲存儲值設定後自動重新開啟子視窗

function refreshToken() {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    return $_SESSION['form_token'];
}

/** 相對時間（供申訴回報儀表板顯示） */
function gm_ago($dt) {
    if (empty($dt) || $dt === '0000-00-00 00:00:00') { return '—'; }
    $ts = strtotime($dt);
    if ($ts === false) { return '—'; }
    $d = time() - $ts;
    if ($d < 0) { $d = 0; }
    if ($d < 60) { return '剛剛'; }
    if ($d < 3600) { return floor($d / 60) . ' 分鐘前'; }
    if ($d < 86400) { return floor($d / 3600) . ' 小時前'; }
    if ($d < 2592000) { return floor($d / 86400) . ' 天前'; }
    return date('Y-m-d', $ts);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['form_token']) || $_POST['form_token'] !== $_SESSION['form_token']) {
        $notice = "你的工作階段已過期，請再試一次。";
        $noticeType = "danger";
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'addgm') {
            $newUsername = strtolower(trim($_POST['new_gm_username']));
            $newPassword = trim($_POST['new_gm_password']);

            if (strlen($newPassword) < 8) {
                $notice = "新 GM 密碼至少需 8 個字元。";
                $noticeType = "danger";
            } elseif (!preg_match("/^[a-zA-Z0-9_-]+$/", $newUsername)) {
                $notice = "GM 使用者名稱只能包含英文字母、數字、底線或連字號。";
                $noticeType = "danger";
            } else {
                $hash = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $Link->prepare("INSERT INTO gm_accounts (username, password_hash) VALUES (?, ?)");
                $stmt->bind_param("ss", $newUsername, $hash);
                if ($stmt->execute()) {
                    $notice = "已建立 GM 帳號「$newUsername」。";
                } else {
                    $notice = "建立 GM 帳號失敗（使用者名稱可能已存在）：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'deletegm') {
            $delId = (int)$_POST['gm_account_id'];
            if ($delId === (int)$currentGmId) {
                $notice = "你無法在以此帳號登入時刪除自己的帳號。";
                $noticeType = "danger";
            } else {
                $stmt = $Link->prepare("DELETE FROM gm_accounts WHERE id = ?");
                $stmt->bind_param("i", $delId);
                if ($stmt->execute()) {
                    $notice = "已移除 GM 帳號。";
                } else {
                    $notice = "移除 GM 帳號失敗：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'grantgm') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['gm_zoneid'];

            $stmt = $Link->prepare("INSERT IGNORE INTO auth (userid, zoneid, rid) VALUES (?, ?, ?)");
            $granted = 0;
            $failed = 0;
            foreach ($AllGmOperationTypes as $opType) {
                $stmt->bind_param("iii", $userid, $zoneid, $opType);
                if ($stmt->execute()) {
                    $granted++;
                } else {
                    $failed++;
                }
            }
            $stmt->close();
            if ($failed === 0) {
                $notice = "已將完整 GM 權限組（$granted 個操作類型）授權給區域 $zoneid 上的帳號 #$userid。";
            } else {
                $notice = "已授權 $granted 個操作類型，但有 $failed 個失敗 - 請檢查 zoneid/資料表結構。";
                $noticeType = "danger";
            }

        } elseif ($action === 'revokegm') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['gm_zoneid'];

            $stmt = $Link->prepare("DELETE FROM auth WHERE userid = ? AND zoneid = ?");
            $stmt->bind_param("ii", $userid, $zoneid);
            if ($stmt->execute()) {
                $affected = $stmt->affected_rows;
                $notice = "已撤銷區域 $zoneid 上帳號 #$userid 的 GM 權限（移除了 $affected 筆資料）。";
            } else {
                $notice = "撤銷失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'ban') {
            $userid = (int)$_POST['userid'];
            $type = (int)$_POST['ban_type'];
            $hours = (int)$_POST['ban_hours'];
            $reason = trim($_POST['ban_reason']);
            $forbidSeconds = $hours * 3600;

            $stmt = $Link->prepare("CALL addForbid(?, ?, ?, ?, ?)");
            $gmRoleId = 0;
            $stmt->bind_param("iiisi", $userid, $type, $forbidSeconds, $reason, $gmRoleId);
            if ($stmt->execute()) {
                $notice = "已封鎖帳號 #$userid（類型 $type，{$hours} 小時）。";
            } else {
                $notice = "封鎖失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'unban') {
            $userid = (int)$_POST['userid'];
            $type = (int)$_POST['unban_type'];
            $stmt = $Link->prepare("DELETE FROM forbid WHERE userid = ? AND type = ?");
            $stmt->bind_param("ii", $userid, $type);
            if ($stmt->execute()) {
                $notice = "已解除封鎖帳號 #$userid（類型 $type）。";
            } else {
                $notice = "解除封鎖失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'grant') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['zoneid'];
            $aid = (int)$_POST['aid'];
            $points = (int)$_POST['points'];
            $cash = (int)$_POST['cash'];
            $status = 1;
            $sn = time(); // 近似唯一的交易序號

            $usecashQuery = "CALL usecash($userid, $zoneid, $sn, $aid, $points, $cash, $status, @error)";
            if (mysqli_query($Link, $usecashQuery)) {
                $notice = "已授予帳號 #$userid $points 點數 / $cash 現金。";
            } else {
                $notice = "授予失敗：";
                $noticeType = "danger";
            }

        } elseif ($action === 'resetpw') {
            $userid = (int)$_POST['userid'];
            $targetUsername = trim($_POST['target_username']);
            $newPass = trim($_POST['new_passwd']);

            if (strlen($newPass) < 4 || strlen($newPass) > 10) {
                $notice = "新密碼長度必須為 4-10 個字元。";
                $noticeType = "danger";
            } else {
                $newHash = md5($targetUsername . $newPass, true);
                $stmt = $Link->prepare("UPDATE users SET passwd = ? WHERE ID = ?");
                $stmt->bind_param("si", $newHash, $userid);
                if ($stmt->execute()) {
                    $notice = "已重設帳號 #$userid 的密碼。";
                } else {
                    $notice = "密碼重設失敗：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'save_recharge') {
            mysqli_set_charset($Link, "utf8");

            // 儲值方式開關
            $baseMethodKeys = ['credit_card', 'bank_transfer', 'cvs', 'crypto'];
            $methodEnabled = $_POST['method_enabled'] ?? [];
            foreach ($baseMethodKeys as $mk) {
                $en = (isset($methodEnabled[$mk]) && (int)$methodEnabled[$mk] === 1) ? 1 : 0;
                $stmt = $Link->prepare("UPDATE recharge_settings SET enabled = ? WHERE setting_type = 'method' AND setting_key = ?");
                $stmt->bind_param("is", $en, $mk);
                $stmt->execute();
                $stmt->close();
            }

            // 既有金額方案更新 / 刪除
            $tiers = $_POST['tier'] ?? [];
            $removeTiers = $_POST['remove_tier'] ?? [];
            foreach ($tiers as $tierId => $fields) {
                $tierId = (int)$tierId;
                if (isset($removeTiers[$tierId])) {
                    $stmt = $Link->prepare("DELETE FROM recharge_settings WHERE id = ? AND setting_type = 'amount'");
                    $stmt->bind_param("i", $tierId);
                    $stmt->execute();
                    $stmt->close();
                    continue;
                }
                $amt = max(1, (int)($fields['amount'] ?? 0));
                $bonus = max(0, min(500, (int)($fields['bonus_percent'] ?? 0)));
                $en = (isset($fields['enabled']) && (int)$fields['enabled'] === 1) ? 1 : 0;
                $sort = $tierId;
                $stmt = $Link->prepare("UPDATE recharge_settings SET amount = ?, bonus_percent = ?, enabled = ?, sort_order = ? WHERE id = ?");
                $stmt->bind_param("iiiii", $amt, $bonus, $en, $sort, $tierId);
                $stmt->execute();
                $stmt->close();
            }

            // 新增金額方案
            $newAmount = (int)($_POST['new_amount'] ?? 0);
            $newBonus = max(0, min(500, (int)($_POST['new_bonus_percent'] ?? 0)));
            if ($newAmount > 0) {
                $seq = $Link->query("SELECT IFNULL(MAX(sort_order), 0) + 1 AS `s` FROM recharge_settings WHERE setting_type = 'amount'");
                $rowS = $seq ? $seq->fetch_assoc() : null;
                $nextSort = isset($rowS['s']) ? (int)$rowS['s'] : 1;
                $ins = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, display_name, icon, description, amount, bonus_percent, enabled, sort_order) VALUES ('amount', '', '', '', '', ?, ?, 1, ?)");
                $ins->bind_param("iii", $newAmount, $newBonus, $nextSort);
                $ins->execute();
                $ins->close();
            }

            // 自訂金額範圍（數值存於 amount）
            $configs = $_POST['config'] ?? [];
            $minAmt = max(1, (int)($configs['min_amount'] ?? 50));
            $maxAmt = max($minAmt, (int)($configs['max_amount'] ?? 100000));
            foreach (['min_amount' => $minAmt, 'max_amount' => $maxAmt] as $cfgKey => $cfgVal) {
                $chk = $Link->prepare("SELECT id FROM recharge_settings WHERE setting_type = 'config' AND setting_key = ? LIMIT 1");
                $chk->bind_param("s", $cfgKey);
                $chk->execute();
                $existRow = $chk->get_result()->fetch_assoc();
                $chk->close();
                if ($existRow) {
                    $stmt = $Link->prepare("UPDATE recharge_settings SET amount = ? WHERE id = ?");
                    $stmt->bind_param("ii", $cfgVal, (int)$existRow['id']);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, amount, enabled, sort_order) VALUES ('config', ?, ?, 1, 0)");
                    $stmt->bind_param("si", $cfgKey, $cfgVal);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            // 金流系統參數（綠界 ECPay；字串存於 description）
            $gatewayKeys = ['ecpay_env', 'ecpay_merchant_id', 'ecpay_hash_key', 'ecpay_hash_iv', 'ecpay_action_url'];
            $gatewayInput = $_POST['gateway'] ?? [];
            foreach ($gatewayKeys as $gk) {
                $gv = trim((string)($gatewayInput[$gk] ?? ''));
                if ($gk === 'ecpay_env') {
                    $gv = ($gv === 'prod') ? 'prod' : 'stage';
                }
                if (strlen($gv) > 200) {
                    $gv = substr($gv, 0, 200);
                }
                $chk = $Link->prepare("SELECT id FROM recharge_settings WHERE setting_type = 'config' AND setting_key = ? LIMIT 1");
                $chk->bind_param("s", $gk);
                $chk->execute();
                $existRow = $chk->get_result()->fetch_assoc();
                $chk->close();
                if ($existRow) {
                    $stmt = $Link->prepare("UPDATE recharge_settings SET description = ?, enabled = 1 WHERE id = ?");
                    $stmt->bind_param("si", $gv, (int)$existRow['id']);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, amount, description, enabled, sort_order) VALUES ('config', ?, 0, ?, 1, 0)");
                    $stmt->bind_param("ss", $gk, $gv);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            mysqli_set_charset($Link, "latin1");
            $notice = "儲值系統設定已儲存並立即生效。";
            $openRechargeModal = true;
        }

        $formToken = refreshToken();
    }
}

// 帳號搜尋
$searchResults = [];
$searchTerm = trim($_GET['q'] ?? '');
if ($searchTerm !== '') {
    $stmt = $Link->prepare("SELECT ID, name, email, mobilenumber, creatime FROM users WHERE name LIKE CONCAT('%', ?, '%') ORDER BY creatime DESC LIMIT 25");
    $stmt->bind_param("s", $searchTerm);
    $stmt->execute();
    $searchResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// 選取帳號詳細資料
$selectedAccount = null;
$selectedForbids = [];
$selectedPoints = [];
$selectedId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($selectedId > 0) {
    $stmt = $Link->prepare("SELECT ID, name, email, mobilenumber, truename, creatime FROM users WHERE ID = ?");
    $stmt->bind_param("i", $selectedId);
    $stmt->execute();
    $selectedAccount = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($selectedAccount) {
        $stmt = $Link->prepare("SELECT type, ctime, forbid_time, reason, gmroleid FROM forbid WHERE userid = ?");
        $stmt->bind_param("i", $selectedId);
        $stmt->execute();
        $selectedForbids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $stmt = $Link->prepare("SELECT aid, zoneid, time, lastlogin FROM point WHERE uid = ?");
        $stmt->bind_param("i", $selectedId);
        $stmt->execute();
        $selectedPoints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    }
}

// 線上人數
$onlineStmt = mysqli_query($Link, "SELECT online.ID, users.name FROM online JOIN users ON online.ID = users.ID");
$onlineList = $onlineStmt ? $onlineStmt->fetch_all(MYSQLI_ASSOC) : [];

$gmAccountsList = mysqli_query($Link, "SELECT id, username, created_at FROM gm_accounts ORDER BY created_at ASC");
$gmAccountsList = $gmAccountsList ? $gmAccountsList->fetch_all(MYSQLI_ASSOC) : [];

// 保留查詢關鍵字，讓進入管理與操作後不遺失搜尋結果
$searchQuery = ($searchTerm !== '') ? 'q=' . urlencode($searchTerm) : '';
$preserveQHtml = ($searchQuery !== '') ? htmlspecialchars('&' . $searchQuery, ENT_QUOTES) : '';
$backUrl = htmlspecialchars(($searchQuery !== '') ? '?' . $searchQuery : 'gmpanel.php', ENT_QUOTES);
$backLabel = ($searchQuery !== '') ? '返回查詢列表' : '返回控制台首頁';

// 讀取儲值系統設定（以 utf8 正確讀取中文）
mysqli_set_charset($Link, "utf8");
$rechargeCfg = loadRechargeSettings($Link);
$rcMethods = $rechargeCfg['methods'];
$rcTiers = $rechargeCfg['tiers'];
$rcConfig = $rechargeCfg['config'];
$rcGateway = $rechargeCfg['gateway'];
mysqli_set_charset($Link, "latin1");

// ------------------------------------------------------------
// 申訴回報統計（後台首頁儀表板）
// ------------------------------------------------------------
mysqli_set_charset($Link, "utf8");
$supportStats = ['total' => 0, 'open' => 0, 'processing' => 0, 'pending_user' => 0, 'resolved' => 0, 'closed' => 0, 'awaiting' => 0, 'stale' => 0];
$recentTickets = [];
try {
    $rs = mysqli_query(
        $Link,
        "SELECT COUNT(*) AS total,
                SUM(`status` = 'open') AS open_c,
                SUM(`status` = 'processing') AS processing_c,
                SUM(`status` = 'pending_user') AS pending_c,
                SUM(`status` = 'resolved') AS resolved_c,
                SUM(`status` = 'closed') AS closed_c,
                SUM(`last_reply_by` = 'user' AND `status` IN ('open','processing')) AS awaiting_c,
                SUM(`status` IN ('open','processing','pending_user')
                    AND TIMESTAMPDIFF(HOUR, IFNULL(`last_reply_at`, `created_at`), NOW()) > 24) AS stale_c
           FROM `support_tickets`"
    );
    if ($rs && ($row = $rs->fetch_assoc())) {
        $supportStats['total'] = (int)$row['total'];
        $supportStats['open'] = (int)$row['open_c'];
        $supportStats['processing'] = (int)$row['processing_c'];
        $supportStats['pending_user'] = (int)$row['pending_c'];
        $supportStats['resolved'] = (int)$row['resolved_c'];
        $supportStats['closed'] = (int)$row['closed_c'];
        $supportStats['awaiting'] = (int)$row['awaiting_c'];
        $supportStats['stale'] = (int)$row['stale_c'];
    }
    $rs = mysqli_query(
        $Link,
        "SELECT t.`id`, t.`ticket_no`, t.`subject`, t.`username`, t.`priority`, t.`status`,
                t.`last_reply_by`, t.`last_reply_at`, t.`created_at`, c.`name` AS category_name
           FROM `support_tickets` t
           LEFT JOIN `support_categories` c ON c.`id` = t.`category_id`
          WHERE t.`status` IN ('open','processing','pending_user')
          ORDER BY FIELD(t.`priority`, 'urgent', 'high', 'normal', 'low'), t.`id` DESC
          LIMIT 4"
    );
    if ($rs) {
        while ($row = $rs->fetch_assoc()) { $recentTickets[] = $row; }
    }
} catch (Throwable $e) {
    // support 資料表尚未建立時忽略，不影響後台運作
}
mysqli_set_charset($Link, "latin1");

// 申訴狀態 / 優先度顯示對照
$supStatusMap = [
    'open'         => ['label' => '待處理',     'badge' => 'bg-amber-50 text-amber-700 border-amber-200',   'dot' => 'bg-amber-500'],
    'processing'   => ['label' => '處理中',     'badge' => 'bg-sky-50 text-sky-700 border-sky-200',         'dot' => 'bg-sky-500'],
    'pending_user' => ['label' => '待會員回覆', 'badge' => 'bg-violet-50 text-violet-700 border-violet-200', 'dot' => 'bg-violet-500'],
    'resolved'     => ['label' => '已結案',     'badge' => 'bg-emerald-50 text-emerald-700 border-emerald-200', 'dot' => 'bg-emerald-500'],
    'closed'       => ['label' => '已關閉',     'badge' => 'bg-slate-100 text-slate-600 border-slate-300',  'dot' => 'bg-slate-400'],
];
$supPrioMap = [
    'urgent' => ['label' => '緊急', 'badge' => 'bg-rose-50 text-rose-700 border-rose-200'],
    'high'   => ['label' => '高',   'badge' => 'bg-orange-50 text-orange-700 border-orange-200'],
    'normal' => ['label' => '一般', 'badge' => 'bg-slate-100 text-slate-600 border-slate-200'],
    'low'    => ['label' => '低',   'badge' => 'bg-slate-100 text-slate-500 border-slate-200'],
];

// ------------------------------------------------------------
// 後台管理工具選單設定
// ------------------------------------------------------------
// 以資料驅動方式集中管理上方工具列，未來新增功能只要在此陣列加入一筆即可，
// 無須再手動複製整段 HTML。每個項目的欄位說明：
//   label   : 主標題（中文）
//   sub     : 副標題（英文，顯示於主標題下方）
//   icon    : Font Awesome 圖示 class
//   theme   : 配色主題（t-amber / t-sky / t-rose / t-emerald / t-violet /
//             t-fuchsia / t-cyan / t-indigo / t-orange）
//   href    : 直接連結頁面（與 onclick 二擇一）
//   onclick : 開啟子視窗的 JS 函式，例如 openRechargeModal()
$adminMenuGroups = [
    [
        'label' => '營運與金流',
        'icon'  => 'fa-solid fa-sack-dollar',
        'items' => [
            ['label' => '儲值系統設定', 'sub' => 'Recharge Settings', 'icon' => 'fa-solid fa-sliders',      'theme' => 't-amber', 'onclick' => 'openRechargeModal()'],
            ['label' => '訂單管理',     'sub' => 'Order Center',      'icon' => 'fa-solid fa-receipt',      'theme' => 't-sky',   'onclick' => 'openOrderModal()'],
        ],
    ],
    [
        'label' => '會員與安全',
        'icon'  => 'fa-solid fa-shield-halved',
        'items' => [
            ['label' => '登入管理', 'sub' => 'Login Audit',          'icon' => 'fa-solid fa-shield-halved', 'theme' => 't-rose',    'onclick' => 'openLoginModal()'],
            ['label' => '註冊管理', 'sub' => 'Registration Center',  'icon' => 'fa-solid fa-user-plus',     'theme' => 't-emerald', 'href'    => 'registration_admin.php'],
        ],
    ],
    [
        'label' => '內容與站務',
        'icon'  => 'fa-solid fa-newspaper',
        'items' => [
            ['label' => '公告管理', 'sub' => 'News Center',      'icon' => 'fa-solid fa-bullhorn',              'theme' => 't-violet',  'href' => 'news_admin.php'],
            ['label' => '活動管理', 'sub' => 'Events Center',    'icon' => 'fa-solid fa-calendar-star',         'theme' => 't-fuchsia', 'href' => 'events_admin.php'],
            ['label' => '下載管理', 'sub' => 'Download Center',  'icon' => 'fa-solid fa-cloud-arrow-down',      'theme' => 't-cyan',    'href' => 'download_admin.php'],
            ['label' => '首頁管理', 'sub' => 'Landing Page',     'icon' => 'fa-solid fa-house-chimney-window',  'theme' => 't-orange',  'href' => 'site_admin.php'],
        ],
    ],
    [
        'label' => '系統維護',
        'icon'  => 'fa-solid fa-screwdriver-wrench',
        'items' => [
            ['label' => '系統備份', 'sub' => 'Auto Backup', 'icon' => 'fa-solid fa-database', 'theme' => 't-indigo', 'href' => 'backup_admin.php'],
        ],
    ],
];
$adminMenuCount = 0;
foreach ($adminMenuGroups as $grp) { $adminMenuCount += count($grp['items']); }

mysqli_close($Link);
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · GM 管理控制台 (雪白水墨版)</title>
    <link rel="stylesheet" href="assets/tailwind.css">
    <!-- 本頁專用：補齊 Tailwind 工具類（申訴回報儀表板等新樣式） -->
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- 樣式由 assets/tailwind.css 提供（編譯後靜態檔，不再使用 Tailwind CDN） -->
    <style>
        :root {
            --vermilion: #be123c;
            --ice-blue: #0284c7;
            --ink-black: #0b0f19;
        }
        body {
            background-color: #080c14;
            color: #1e293b;
            font-family: 'Noto Serif TC', serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% 0%, rgba(190, 18, 60, 0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 90%, rgba(2, 132, 199, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 20% 60%, rgba(15, 23, 42, 0.8) 0%, transparent 70%);
        }
        #snow-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 1;
            transform: translateZ(0);
            will-change: transform;
        }
        .glass-panel {
            background: rgba(255, 255, 255, 0.94);
            border: 1px solid rgba(226, 232, 240, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.7) inset;
            position: relative;
            transform: translateZ(0);
        }
        .corner-accent::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 10px;
            height: 10px;
            border-top: 2px solid var(--vermilion);
            border-left: 2px solid var(--vermilion);
            pointer-events: none;
        }
        .corner-accent::after {
            content: '';
            position: absolute;
            bottom: 0;
            right: 0;
            width: 10px;
            height: 10px;
            border-bottom: 2px solid var(--ice-blue);
            border-right: 2px solid var(--ice-blue);
            pointer-events: none;
        }
        .ink-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent 0%, rgba(190, 18, 60, 0.3) 25%, rgba(2, 132, 199, 0.3) 75%, transparent 100%);
        }
        .btn-vermilion {
            background: linear-gradient(135deg, #be123c 0%, #9f1239 100%);
            color: #ffffff;
            transition: all 0.25s ease;
            box-shadow: 0 4px 14px rgba(190, 18, 60, 0.25);
        }
        .btn-vermilion:hover {
            background: linear-gradient(135deg, #e11d48 0%, #be123c 100%);
            box-shadow: 0 6px 20px rgba(190, 18, 60, 0.38);
            transform: translateY(-1px);
        }
        .btn-ice {
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            color: #ffffff;
            transition: all 0.25s ease;
            box-shadow: 0 4px 14px rgba(2, 132, 199, 0.25);
        }
        .btn-ice:hover {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            box-shadow: 0 6px 20px rgba(2, 132, 199, 0.38);
            transform: translateY(-1px);
        }
        .form-input-focus:focus {
            outline: none;
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15);
        }
        /* 訂單管理狀態篩選按鈕 */
        .order-filter-btn { transition: all 0.2s ease; }
        .order-filter-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            box-shadow: 0 8px 18px -6px rgba(0, 0, 0, 0.45);
            transform: translateY(-1px);
        }
        .order-filter-btn.active [data-count] {
            background: rgba(255, 255, 255, 0.25) !important;
            color: #ffffff;
        }
        .order-filter-btn[data-status="all"].active { background: linear-gradient(135deg, #334155, #0f172a); }
        .order-filter-btn[data-status="pending"].active { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .order-filter-btn[data-status="paid"].active { background: linear-gradient(135deg, #10b981, #047857); }
        .order-filter-btn[data-status="failed"].active { background: linear-gradient(135deg, #f43f5e, #be123c); }
        .order-filter-btn[data-status="expired"].active { background: linear-gradient(135deg, #64748b, #334155); }
        .order-filter-btn[data-status="cancelled"].active { background: linear-gradient(135deg, #94a3b8, #475569); }
        /* 訂單管理期間篩選按鈕 */
        .order-period-btn { transition: all 0.2s ease; }
        .order-period-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            background: linear-gradient(135deg, #6366f1, #4338ca);
            box-shadow: 0 8px 18px -6px rgba(67, 56, 202, 0.6);
            transform: translateY(-1px);
        }
        .order-row-check { transition: box-shadow 0.15s ease; }
        .order-row-check:checked { box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.18); }
        /* 補齊精簡版 Tailwind 缺少的工具類 */
        .py-0\.2 { padding-top: 0.05rem; padding-bottom: 0.05rem; }
        /* 登入管理 篩選按鈕 */
        .login-filter-btn { transition: all 0.2s ease; }
        .login-filter-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            background: linear-gradient(135deg, #be123c, #7f1d3a);
            box-shadow: 0 8px 18px -6px rgba(190, 18, 60, 0.55);
            transform: translateY(-1px);
        }

        /* ===== 管理工具列（資料驅動、精簡單行可擴充） ===== */
        .cmd-bar {
            display: flex; flex-wrap: wrap; align-items: center;
            gap: 4px 6px;
            padding: 6px 10px;
            border-radius: 12px;
            background: rgba(15, 23, 42, 0.6);
            border: 1px solid rgba(51, 65, 85, 0.7);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        .cmd-bar-title {
            display: inline-flex; align-items: center; gap: 6px;
            font-size: 11px; font-weight: 700; letter-spacing: 0.12em;
            color: #cbd5e1; white-space: nowrap;
            padding-right: 9px; margin-right: 2px;
            border-right: 1px solid rgba(71, 85, 105, 0.6);
        }
        .cmd-bar-title i { color: #fda4af; font-size: 11px; }
        .cmd-cluster { display: inline-flex; flex-wrap: wrap; align-items: center; gap: 4px; }
        .cmd-sep {
            width: 1px; height: 18px; flex-shrink: 0; margin: 0 3px;
            background: linear-gradient(180deg, transparent, rgba(100, 116, 139, 0.55), transparent);
        }
        .cmd-chip {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 3px 10px 3px 4px;
            border-radius: 999px;
            border: 1px solid transparent;
            background: rgba(30, 41, 59, 0.4);
            color: #e2e8f0; font-size: 11.5px; font-weight: 600;
            text-decoration: none; cursor: pointer; white-space: nowrap;
            font-family: inherit;
            transition: background 0.18s ease, border-color 0.18s ease, transform 0.18s ease, box-shadow 0.18s ease, color 0.18s ease;
        }
        .cmd-chip-icon {
            width: 22px; height: 22px; border-radius: 50%; flex-shrink: 0;
            display: flex; align-items: center; justify-content: center;
            font-size: 10px; color: #ffffff;
            background: linear-gradient(135deg, var(--c1), var(--c2));
            box-shadow: 0 3px 8px -3px var(--c1);
            transition: transform 0.18s ease;
        }
        .cmd-chip:hover {
            background: rgba(30, 41, 59, 0.95);
            border-color: rgba(var(--c1rgb), 0.5);
            color: #ffffff;
            transform: translateY(-1px);
            box-shadow: 0 8px 20px -10px rgba(0, 0, 0, 0.9), 0 0 0 1px rgba(var(--c1rgb), 0.16);
        }
        .cmd-chip:hover .cmd-chip-icon { transform: scale(1.12); }
        .cmd-chip:active { transform: translateY(0); }
        .cmd-chip:focus-visible { outline: 2px solid var(--c1); outline-offset: 2px; }

        @media (max-width: 640px) {
            .cmd-chip { padding: 3px; }
            .cmd-chip-label { display: none; }
            .cmd-bar-title span { display: none; }
            .cmd-bar-title { padding-right: 6px; }
        }

        /* 主題配色（新增選單時只需指定 theme class） */
        .t-amber   { --c1: #f59e0b; --c2: #b45309; --c1rgb: 245, 158, 11; }
        .t-sky     { --c1: #0ea5e9; --c2: #0369a1; --c1rgb: 14, 165, 233; }
        .t-rose    { --c1: #f43f5e; --c2: #9f1239; --c1rgb: 244, 63, 94; }
        .t-emerald { --c1: #10b981; --c2: #047857; --c1rgb: 16, 185, 129; }
        .t-violet  { --c1: #8b5cf6; --c2: #6d28d9; --c1rgb: 139, 92, 246; }
        .t-fuchsia { --c1: #d946ef; --c2: #a21caf; --c1rgb: 217, 70, 239; }
        .t-cyan    { --c1: #06b6d4; --c2: #0e7490; --c1rgb: 6, 182, 212; }
        .t-indigo  { --c1: #6366f1; --c2: #3730a3; --c1rgb: 99, 102, 241; }
        .t-orange  { --c1: #fb923c; --c2: #c2410c; --c1rgb: 251, 146, 60; }
    </style>
</head>
<body class="relative min-h-screen flex flex-col justify-between selection:bg-rose-900 selection:text-white">
    <canvas id="snow-canvas"></canvas>

    <header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="home.php" class="flex items-center space-x-3.5 no-underline group">
                    <img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
                            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-rose-900/80 text-rose-200 border border-rose-700/60 font-medium">GM 控制台</span>
                        </div>
                        <p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Snow Wanderer Online</p>
                    </div>
                </a>

                <nav class="flex items-center space-x-2 sm:space-x-4">
                    <a href="home.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-house text-slate-400"></i>
                        <span class="hidden sm:inline">會員首頁</span>
                    </a>
                    <a href="usercontrol.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-regular fa-id-badge text-slate-400"></i>
                        <span class="hidden sm:inline">帳號管理</span>
                    </a>
                    <a href="support_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-headset text-slate-400"></i>
                        <span class="hidden sm:inline">申訴回報</span>
                    </a>
                    <a href="wallet_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-coins text-amber-400"></i>
                        <span class="hidden sm:inline">錢包管理</span>
                    </a>
                    <a href="member_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-user-shield text-violet-400"></i>
                        <span class="hidden sm:inline">會員權限</span>
                    </a>

                    <div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
                        <div class="flex items-center space-x-2 bg-slate-900/90 border border-rose-900/50 px-3 py-1 rounded-full text-xs">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span class="text-slate-400">管理員：</span>
                            <span class="font-semibold text-rose-300 font-mono"><?php echo htmlspecialchars($currentGmUsername); ?></span>
                        </div>
                        <a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors" title="登出 GM 控制台">
                            <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i>
                            <span class="hidden sm:inline">登出</span>
                        </a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">

        <div class="flex flex-col gap-3 pb-3 border-b border-slate-800">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="px-2 py-0.5 text-[11px] font-semibold text-rose-800 bg-rose-50 border border-rose-200 rounded">最高管理特權</span>
                        <span class="text-xs text-slate-400">系統即時運行正常 · 資料庫連線穩定</span>
                    </div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider flex items-center gap-2.5">
                        <span>伺服器管理控制台</span>
                        <span class="text-xs font-normal text-slate-400 tracking-normal font-sans border border-slate-700 px-2 py-0.5 rounded">GM Control Center</span>
                    </h1>
                </div>

                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-users text-emerald-400"></i>
                        <span>當前線上玩家：</span>
                        <strong class="text-emerald-400 font-mono text-sm font-bold"><?php echo count($onlineList); ?></strong>
                        <span class="text-slate-500">人</span>
                    </div>
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-user-shield text-sky-400"></i>
                        <span>GM 管理員：</span>
                        <strong class="text-sky-400 font-mono text-sm font-bold"><?php echo count($gmAccountsList); ?></strong>
                        <span class="text-slate-500">位</span>
                    </div>
                </div>
            </div>

            <!-- 管理工具列（資料驅動，設定集中於 $adminMenuGroups） -->
            <div class="cmd-bar">
                <span class="cmd-bar-title" title="共 <?php echo (int)$adminMenuCount; ?> 項功能">
                    <i class="fa-solid fa-table-columns"></i><span>管理工具</span>
                </span>

                <?php foreach ($adminMenuGroups as $gi => $group): ?>
                    <?php if ($gi > 0): ?><span class="cmd-sep" aria-hidden="true"></span><?php endif; ?>
                    <div class="cmd-cluster" role="group" aria-label="<?php echo htmlspecialchars($group['label']); ?>">
                        <?php foreach ($group['items'] as $item):
                            $isButton = isset($item['onclick']);
                            $tag = $isButton ? 'button' : 'a';
                            $attr = $isButton
                                ? 'type="button" onclick="' . htmlspecialchars($item['onclick'], ENT_QUOTES) . '"'
                                : 'href="' . htmlspecialchars($item['href'], ENT_QUOTES) . '"';
                        ?>
                        <<?php echo $tag; ?> <?php echo $attr; ?> class="cmd-chip <?php echo htmlspecialchars($item['theme']); ?>"
                            title="<?php echo htmlspecialchars($item['label'] . ' · ' . $item['sub']); ?>">
                            <span class="cmd-chip-icon"><i class="<?php echo htmlspecialchars($item['icon']); ?>"></i></span>
                            <span class="cmd-chip-label"><?php echo htmlspecialchars($item['label']); ?></span>
                        </<?php echo $tag; ?>>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ($notice !== ""): ?>
            <?php $isDanger = ($noticeType === 'danger'); ?>
            <div class="p-3.5 rounded-lg border text-xs flex items-center justify-between <?php echo $isDanger ? 'border-rose-500/30 bg-rose-950/40 text-rose-200' : 'border-emerald-500/30 bg-emerald-950/40 text-emerald-200'; ?>">
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid <?php echo $isDanger ? 'fa-circle-exclamation text-rose-400' : 'fa-circle-check text-emerald-400'; ?> text-sm"></i>
                    <span><?php echo htmlspecialchars($notice); ?></span>
                </div>
                <span class="text-[11px] font-mono <?php echo $isDanger ? 'text-rose-400/70' : 'text-emerald-400/70'; ?>">Token 狀態良好</span>
            </div>
        <?php else: ?>
            <div class="p-3.5 rounded-lg border border-emerald-500/30 bg-emerald-950/40 text-emerald-200 text-xs flex items-center justify-between">
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid fa-circle-check text-emerald-400 text-sm"></i>
                    <span>系統就緒，所有管理功能均可正常使用。</span>
                </div>
                <span class="text-[11px] text-emerald-400/70 font-mono">Token 狀態良好</span>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">

            <div class="lg:col-span-8 space-y-6">

                <div class="glass-panel corner-accent rounded-xl p-5 sm:p-6 text-slate-800">
                    <div class="flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
                        <div class="flex items-center gap-2.5">
                            <div class="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700">
                                <i class="fa-solid fa-magnifying-glass"></i>
                            </div>
                            <div>
                                <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif">玩家帳號查詢</h2>
                                <p class="text-[11px] text-slate-500">輸入角色名稱或關鍵字，即時調閱玩家完整資歷與處分狀態</p>
                            </div>
                        </div>
                        <span class="text-[11px] text-slate-400 font-mono">users 資料表</span>
                    </div>

                    <form method="GET" action="" class="flex gap-2 mb-4">
                        <div class="relative flex-1">
                            <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
                                <i class="fa-solid fa-user text-xs"></i>
                            </span>
                            <input type="text" name="q" value="<?php echo htmlspecialchars($searchTerm); ?>" placeholder="請輸入角色名稱或帳號關鍵字..."
                                class="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 bg-white text-slate-800 form-input-focus transition-all">
                        </div>
                        <button type="submit" class="btn-vermilion px-5 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5">
                            <i class="fa-solid fa-search"></i>
                            <span>查詢帳號</span>
                        </button>
                    </form>

                    <div class="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                                <tr>
                                    <th class="py-2.5 px-3">UID</th>
                                    <th class="py-2.5 px-3">玩家名稱</th>
                                    <th class="py-2.5 px-3">電子信箱</th>
                                    <th class="py-2.5 px-3">手機號碼</th>
                                    <th class="py-2.5 px-3">註冊時間</th>
                                    <th class="py-2.5 px-3 text-right">操作</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 font-sans">
                                <?php if ($searchTerm === ''): ?>
                                    <tr>
                                        <td colspan="6" class="py-6 text-center text-slate-400 text-xs">
                                            <i class="fa-solid fa-magnifying-glass mr-1"></i> 請輸入關鍵字以查詢玩家帳號
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($searchResults as $r): ?>
                                        <?php $isCurrent = ((int)$r['ID'] === $selectedId); ?>
                                        <tr class="hover:bg-slate-50/80 transition-colors <?php echo $isCurrent ? 'bg-rose-50/30' : ''; ?>">
                                            <td class="py-2.5 px-3 font-mono text-slate-600 font-medium">#<?php echo (int)$r['ID']; ?></td>
                                            <td class="py-2.5 px-3 font-semibold text-slate-900 flex items-center gap-1.5">
                                                <span><?php echo htmlspecialchars($r['name']); ?></span>
                                                <?php if ($isCurrent): ?>
                                                    <span class="px-1.5 py-0.2 rounded text-[10px] bg-rose-100 text-rose-700 border border-rose-200">當前選取</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="py-2.5 px-3 text-slate-600 font-mono text-[11px]"><?php echo htmlspecialchars($r['email']); ?></td>
                                            <td class="py-2.5 px-3 text-slate-600 font-mono text-[11px]"><?php echo htmlspecialchars($r['mobilenumber']); ?></td>
                                            <td class="py-2.5 px-3 text-slate-500 font-mono text-[11px]"><?php echo htmlspecialchars($r['creatime']); ?></td>
                                            <td class="py-2.5 px-3 text-right">
                                                <a href="?id=<?php echo (int)$r['ID'] . $preserveQHtml; ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-700 border border-slate-300 font-medium text-[11px] transition-colors">
                                                    <i class="fa-solid fa-sliders text-[10px]"></i>
                                                    <span>管理</span>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($searchResults)): ?>
                                        <tr>
                                            <td colspan="6" class="py-6 text-center text-slate-400 text-xs">
                                                <i class="fa-regular fa-face-frown mr-1"></i> 找不到符合條件的帳號
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <?php if ($selectedAccount): ?>
                <div class="glass-panel corner-accent rounded-xl p-5 sm:p-6 text-slate-800 space-y-6">

                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                        <div>
                            <div class="flex items-center gap-2 mb-1">
                                <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-sky-100 text-sky-800 border border-sky-300">帳號詳細管理</span>
                                <span class="text-xs text-slate-500 font-mono">UID: #<?php echo (int)$selectedAccount['ID']; ?></span>
                                <span class="inline-flex items-center gap-1 text-[11px] text-emerald-600 font-medium">
                                    <span class="w-2 h-2 rounded-full bg-emerald-500"></span> 帳號狀態良好
                                </span>
                            </div>
                            <h3 class="text-xl font-bold text-slate-900 font-serif flex items-center gap-2">
                                <span><?php echo htmlspecialchars($selectedAccount['name']); ?></span>
                            </h3>
                        </div>

                        <div class="flex flex-wrap items-center gap-2 text-[11px] font-sans">
                            <div class="bg-slate-100 border border-slate-200 px-2.5 py-1 rounded text-slate-600">
                                <i class="fa-regular fa-envelope mr-1 text-slate-400"></i> <?php echo htmlspecialchars($selectedAccount['email']); ?>
                            </div>
                            <div class="bg-slate-100 border border-slate-200 px-2.5 py-1 rounded text-slate-600">
                                <i class="fa-solid fa-mobile-screen mr-1 text-slate-400"></i> <?php echo htmlspecialchars($selectedAccount['mobilenumber']); ?>
                            </div>
                            <a href="<?php echo $backUrl; ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-900 text-white font-medium transition-colors">
                                <i class="fa-solid fa-arrow-left text-[10px]"></i>
                                <span><?php echo $backLabel; ?></span>
                            </a>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">

                        <div class="rounded-lg border border-slate-200 bg-white p-4">
                            <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                                <div class="flex items-center gap-1.5 text-xs font-bold text-slate-900 font-serif">
                                    <i class="fa-solid fa-ban text-rose-600"></i>
                                    <span>目前封鎖紀錄</span>
                                </div>
                                <span class="text-[10px] text-slate-400 font-mono">forbid 資料表</span>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-left text-xs">
                                    <thead class="bg-slate-50 text-slate-600 font-medium text-[11px]">
                                        <tr>
                                            <th class="py-1.5 px-2">類型</th>
                                            <th class="py-1.5 px-2">開始時間</th>
                                            <th class="py-1.5 px-2">時長(秒)</th>
                                            <th class="py-1.5 px-2">原因</th>
                                            <th class="py-1.5 px-2 text-right">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        <?php foreach ($selectedForbids as $f): ?>
                                            <tr>
                                                <td class="py-1.5 px-2 font-mono"><?php echo (int)$f['type']; ?></td>
                                                <td class="py-1.5 px-2 text-slate-500 font-mono text-[11px]"><?php echo htmlspecialchars($f['ctime']); ?></td>
                                                <td class="py-1.5 px-2 font-mono text-[11px]"><?php echo (int)$f['forbid_time']; ?></td>
                                                <td class="py-1.5 px-2 text-slate-600"><?php echo htmlspecialchars($f['reason']); ?></td>
                                                <td class="py-1.5 px-2 text-right">
                                                    <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="inline">
                                                        <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                                                        <input type="hidden" name="action" value="unban">
                                                        <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                                        <input type="hidden" name="unban_type" value="<?php echo (int)$f['type']; ?>">
                                                        <button type="submit" class="text-sky-600 hover:text-sky-800 text-[11px] font-medium transition-colors">解除</button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($selectedForbids)): ?>
                                            <tr>
                                                <td colspan="5" class="py-4 text-center text-slate-400 text-xs">
                                                    <i class="fa-regular fa-circle-check text-emerald-500 mr-1"></i> 目前無任何處分與封鎖紀錄
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="rounded-lg border border-slate-200 bg-white p-4">
                            <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
                                <div class="flex items-center gap-1.5 text-xs font-bold text-slate-900 font-serif">
                                    <i class="fa-solid fa-coins text-amber-500"></i>
                                    <span>點數餘額與分區</span>
                                </div>
                                <span class="text-[10px] text-slate-400 font-mono">point 資料表</span>
                            </div>

                            <div class="overflow-x-auto">
                                <table class="w-full text-left text-xs">
                                    <thead class="bg-slate-50 text-slate-600 font-medium text-[11px]">
                                        <tr>
                                            <th class="py-1.5 px-2">分區 ID</th>
                                            <th class="py-1.5 px-2">帳號 Aid</th>
                                            <th class="py-1.5 px-2">持有點數</th>
                                            <th class="py-1.5 px-2">最後登入時間</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-mono text-[11px]">
                                        <?php foreach ($selectedPoints as $p): ?>
                                            <tr class="hover:bg-slate-50">
                                                <td class="py-1.5 px-2 font-semibold text-slate-700"><?php echo (int)$p['zoneid']; ?></td>
                                                <td class="py-1.5 px-2 text-slate-600"><?php echo (int)$p['aid']; ?></td>
                                                <td class="py-1.5 px-2 font-bold text-emerald-600"><?php echo (int)$p['time']; ?> 點</td>
                                                <td class="py-1.5 px-2 text-slate-500"><?php echo htmlspecialchars($p['lastlogin']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <?php if (empty($selectedPoints)): ?>
                                            <tr>
                                                <td colspan="4" class="py-4 text-center text-slate-400 text-xs">
                                                    <i class="fa-regular fa-circle-check text-emerald-500 mr-1"></i> 沒有點數記錄
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>

                    <div class="ink-divider my-2"></div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 font-sans">

                        <div class="rounded-lg border border-rose-200/90 bg-rose-50/30 p-4 flex flex-col justify-between">
                            <div>
                                <div class="flex items-center gap-1.5 text-xs font-bold text-rose-900 pb-2 mb-3 border-b border-rose-200/80 font-serif">
                                    <i class="fa-solid fa-gavel text-rose-700"></i>
                                    <span>帳號處分封鎖</span>
                                </div>
                                <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-2.5 text-xs">
                                    <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                                    <input type="hidden" name="action" value="ban">
                                    <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">

                                    <div>
                                        <label class="block text-[11px] font-medium text-slate-700 mb-1">封鎖類型代碼</label>
                                        <select name="ban_type" class="w-full appearance-none pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                            <option value="1">1 - 登入凍結處分</option>
                                            <option value="2">2 - 遊戲內禁言處分</option>
                                            <option value="3">3 - 商城與交易限制</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-medium text-slate-700 mb-1">持續時間（小時，0 為永久）</label>
                                        <input type="number" name="ban_hours" value="24" class="w-full px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-medium text-slate-700 mb-1">處分原因備註</label>
                                        <input type="text" name="ban_reason" maxlength="255" placeholder="請輸入違規原因..." class="w-full px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                    </div>
                                    <button type="submit" class="w-full mt-2 py-2 rounded bg-rose-700 hover:bg-rose-800 text-white font-semibold text-xs shadow-sm transition-colors flex items-center justify-center gap-1.5">
                                        <i class="fa-solid fa-lock"></i>
                                        <span>執行封鎖處分</span>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="rounded-lg border border-amber-200/90 bg-amber-50/20 p-4 flex flex-col justify-between">
                            <div>
                                <div class="flex items-center gap-1.5 text-xs font-bold text-amber-900 pb-2 mb-3 border-b border-amber-200/80 font-serif">
                                    <i class="fa-solid fa-circle-dollar-to-slot text-amber-700"></i>
                                    <span>發放點數 / 現金</span>
                                </div>
                                <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-2 text-xs">
                                    <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                                    <input type="hidden" name="action" value="grant">
                                    <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">

                                    <div class="grid grid-cols-2 gap-2">
                                        <div>
                                            <label class="block text-[11px] font-medium text-slate-700 mb-1">分區 ID (zoneid)</label>
                                            <input type="number" name="zoneid" value="1" class="w-full px-2 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </div>
                                        <div>
                                            <label class="block text-[11px] font-medium text-slate-700 mb-1">Aid 標識</label>
                                            <input type="number" name="aid" value="1" class="w-full px-2 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-2 gap-2">
                                        <div>
                                            <label class="block text-[11px] font-medium text-slate-700 mb-1">增補點數</label>
                                            <input type="number" name="points" value="100" class="w-full px-2 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </div>
                                        <div>
                                            <label class="block text-[11px] font-medium text-slate-700 mb-1">增補元寶/現金</label>
                                            <input type="number" name="cash" value="0" class="w-full px-2 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </div>
                                    </div>

                                    <p class="text-[10px] text-slate-400 pt-1">呼叫 usecash 預存程序自動生成 sn 交易號</p>

                                    <button type="submit" class="w-full mt-2 py-2 rounded bg-amber-600 hover:bg-amber-700 text-white font-semibold text-xs shadow-sm transition-colors flex items-center justify-center gap-1.5">
                                        <i class="fa-solid fa-gift"></i>
                                        <span>確認授予點數</span>
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="rounded-lg border border-slate-200 bg-slate-50/50 p-4 flex flex-col justify-between">
                            <div>
                                <div class="flex items-center gap-1.5 text-xs font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200 font-serif">
                                    <i class="fa-solid fa-key text-sky-700"></i>
                                    <span>強制重設密碼</span>
                                </div>
                                <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-2.5 text-xs">
                                    <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                                    <input type="hidden" name="action" value="resetpw">
                                    <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                    <input type="hidden" name="target_username" value="<?php echo htmlspecialchars($selectedAccount['name']); ?>">

                                    <div>
                                        <label class="block text-[11px] font-medium text-slate-700 mb-1">目標帳號名稱</label>
                                        <input type="text" readonly value="<?php echo htmlspecialchars($selectedAccount['name']); ?>" class="w-full px-2.5 py-1.5 rounded border border-slate-200 bg-slate-100 text-slate-500 text-xs font-mono">
                                    </div>
                                    <div>
                                        <label class="block text-[11px] font-medium text-slate-700 mb-1">新密碼 (4-10 個字元)</label>
                                        <input type="password" name="new_passwd" placeholder="請設定新登入密碼" class="w-full px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                    </div>

                                    <p class="text-[10px] text-slate-400">使用 MD5 (名稱 + 密碼) 二進位雜湊寫入資料庫</p>

                                    <button type="submit" class="w-full mt-2 py-2 rounded bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs shadow-sm transition-colors flex items-center justify-center gap-1.5">
                                        <i class="fa-solid fa-rotate-right"></i>
                                        <span>確認重設密碼</span>
                                    </button>
                                </form>
                            </div>
                        </div>

                    </div>

                    <div class="rounded-lg border border-sky-200 bg-sky-50/40 p-4">
                        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 mb-3 border-b border-sky-200/80">
                            <div>
                                <div class="flex items-center gap-1.5 text-xs font-bold text-sky-950 font-serif">
                                    <i class="fa-solid fa-shield-halved text-sky-700"></i>
                                    <span>遊戲分區 GM 特權授權與撤銷</span>
                                </div>
                                <p class="text-[11px] text-slate-600 mt-0.5">
                                    在指定遊戲分區為該玩家寫入或清除 <code class="text-rose-700 font-mono font-semibold">auth</code> 資料表的全套操作權限清單（共 <?php echo count($AllGmOperationTypes); ?> 項 gmopgen 目錄代碼）。
                                </p>
                            </div>
                            <span class="text-[10px] text-sky-700 bg-sky-100 border border-sky-300 px-2 py-0.5 rounded font-mono shrink-0">auth 資料庫操作</span>
                        </div>

                        <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="flex flex-wrap items-end gap-3 text-xs">
                            <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                            <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">

                            <div class="w-40">
                                <label class="block text-[11px] font-semibold text-slate-700 mb-1">分區代碼 (zoneid)</label>
                                <input type="number" name="gm_zoneid" value="20586" class="w-full px-3 py-1.5 rounded border border-slate-300 bg-white font-mono form-input-focus text-xs">
                            </div>

                            <button type="submit" name="action" value="grantgm" class="btn-ice px-4 py-2 rounded font-semibold flex items-center gap-1.5">
                                <i class="fa-solid fa-circle-check"></i>
                                <span>授予完整 GM 權限 (<?php echo count($AllGmOperationTypes); ?>項)</span>
                            </button>

                            <button type="submit" name="action" value="revokegm" class="px-4 py-2 rounded bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-semibold transition-colors flex items-center gap-1.5">
                                <i class="fa-solid fa-circle-xmark"></i>
                                <span>撤銷該分區 GM 權限</span>
                            </button>
                        </form>
                    </div>

                    <!-- 底部返回操作列 -->
                    <div class="pt-4 border-t border-slate-200 flex items-center justify-between gap-3">
                        <span class="text-[11px] text-slate-400 font-mono">UID #<?php echo (int)$selectedAccount['ID']; ?> · 管理操作完成後可返回查詢列表</span>
                        <a href="<?php echo $backUrl; ?>" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs shadow-sm transition-colors flex items-center gap-1.5">
                            <i class="fa-solid fa-arrow-left"></i>
                            <span><?php echo $backLabel; ?></span>
                        </a>
                    </div>

                </div>
                <?php else: ?>
                <div class="glass-panel corner-accent rounded-xl p-8 text-center text-slate-500">
                    <i class="fa-regular fa-hand-pointer text-3xl text-slate-300 mb-3"></i>
                    <p class="text-sm font-serif">請由上方搜尋並選擇一位玩家，即可顯示完整帳號管理面板。</p>
                </div>
                <?php endif; ?>

            </div>

            <div class="lg:col-span-4 space-y-6">

                <div class="glass-panel corner-accent rounded-xl p-5 text-slate-800">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <div class="flex items-center gap-2">
                            <div class="w-7 h-7 rounded-md bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600">
                                <i class="fa-solid fa-signal text-xs"></i>
                            </div>
                            <h3 class="text-sm font-bold text-slate-900 font-serif">即時在線玩家</h3>
                        </div>
                        <span class="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                            <?php echo count($onlineList); ?> 在線
                        </span>
                    </div>

                    <div class="overflow-y-auto max-h-56 pr-1 space-y-1.5 text-xs">
                        <?php foreach ($onlineList as $o): ?>
                            <div class="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-100 hover:bg-slate-100/80 transition-colors">
                                <div class="flex items-center gap-2">
                                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                    <span class="font-medium text-slate-800"><?php echo htmlspecialchars($o['name']); ?></span>
                                </div>
                                <div class="flex items-center gap-2">
                                    <span class="text-[11px] text-slate-400 font-mono">#<?php echo (int)$o['ID']; ?></span>
                                    <a href="?id=<?php echo (int)$o['ID'] . $preserveQHtml; ?>" class="text-rose-600 hover:text-rose-800 text-[11px] font-medium">查看</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($onlineList)): ?>
                            <div class="py-6 text-center text-slate-400 text-xs">
                                <i class="fa-regular fa-moon mr-1"></i> 目前無人在線
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5 text-slate-800">
                    <?php
                    $supportTiles = [
                        ['label' => '待處理',     'value' => $supportStats['open'],         'icon' => 'fa-hourglass-half',       'badge' => 'bg-amber-50 text-amber-700 border-amber-200'],
                        ['label' => '處理中',     'value' => $supportStats['processing'],   'icon' => 'fa-gears',                'badge' => 'bg-sky-50 text-sky-700 border-sky-200'],
                        ['label' => '待會員回覆', 'value' => $supportStats['pending_user'], 'icon' => 'fa-comment-dots',         'badge' => 'bg-violet-50 text-violet-700 border-violet-200'],
                        ['label' => '待回覆',     'value' => $supportStats['awaiting'],     'icon' => 'fa-bell',                 'badge' => 'bg-rose-50 text-rose-700 border-rose-200'],
                        ['label' => '停滯 > 24h', 'value' => $supportStats['stale'],        'icon' => 'fa-triangle-exclamation', 'badge' => 'bg-orange-50 text-orange-700 border-orange-200'],
                        ['label' => '已結案',     'value' => $supportStats['resolved'],     'icon' => 'fa-circle-check',         'badge' => 'bg-emerald-50 text-emerald-700 border-emerald-200'],
                    ];
                    $supportActive = (int)($supportStats['open'] + $supportStats['processing'] + $supportStats['pending_user']);
                    ?>
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <div class="flex items-center gap-2">
                            <div class="w-7 h-7 rounded-md bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700">
                                <i class="fa-solid fa-headset text-xs"></i>
                            </div>
                            <h3 class="text-sm font-bold text-slate-900 font-serif">申訴回報狀態</h3>
                        </div>
                        <span class="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-300">
                            進行中 <?php echo $supportActive; ?>
                        </span>
                    </div>

                    <div class="flex flex-wrap gap-1.5 mb-3">
                        <?php foreach ($supportTiles as $tile): ?>
                            <span class="inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-medium <?php echo $tile['badge']; ?>" title="<?php echo htmlspecialchars($tile['label']); ?>">
                                <i class="fa-solid <?php echo $tile['icon']; ?> text-[9px] opacity-70"></i><?php echo htmlspecialchars($tile['label']); ?> <b class="font-mono"><?php echo (int)$tile['value']; ?></b>
                            </span>
                        <?php endforeach; ?>
                    </div>

                    <div class="overflow-y-auto max-h-56 pr-1 space-y-1.5 text-xs">
                        <?php if (empty($recentTickets)): ?>
                            <div class="py-6 text-center text-slate-400 text-xs">
                                <i class="fa-regular fa-circle-check mr-1"></i> 目前無待處理申訴
                            </div>
                        <?php else: ?>
                            <?php foreach ($recentTickets as $rt):
                                $sMeta = $supStatusMap[$rt['status']] ?? ['label' => $rt['status'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-200', 'dot' => 'bg-slate-400'];
                                $pMeta = $supPrioMap[$rt['priority']] ?? ['label' => $rt['priority'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-200'];
                                $rtNeedsReply = ($rt['last_reply_by'] === 'user' && in_array($rt['status'], ['open', 'processing'], true));
                            ?>
                                <a href="support_admin.php?ticket=<?php echo (int)$rt['id']; ?>" class="block p-2 rounded bg-slate-50 border border-slate-100 hover:bg-slate-100/80 no-underline transition-colors">
                                    <div class="flex items-start justify-between gap-2">
                                        <div class="min-w-0">
                                            <div class="flex items-center gap-1.5 mb-0.5 flex-wrap">
                                                <span class="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full border font-medium <?php echo $sMeta['badge']; ?>"><span class="w-1.5 h-1.5 rounded-full <?php echo $sMeta['dot']; ?>"></span><?php echo htmlspecialchars($sMeta['label']); ?></span>
                                                <span class="text-[10px] px-1.5 py-0.5 rounded-full border font-medium <?php echo $pMeta['badge']; ?>"><?php echo htmlspecialchars($pMeta['label']); ?></span>
                                                <?php if ($rtNeedsReply): ?><i class="fa-solid fa-bell text-[10px] text-rose-600"></i><?php endif; ?>
                                            </div>
                                            <p class="text-xs font-medium text-slate-800 truncate"><?php echo htmlspecialchars($rt['subject']); ?></p>
                                            <p class="text-[10px] text-slate-400 font-mono truncate"><?php echo htmlspecialchars($rt['ticket_no']); ?> · <?php echo htmlspecialchars($rt['username']); ?><?php echo $rt['category_name'] ? ' · ' . htmlspecialchars($rt['category_name']) : ''; ?></p>
                                        </div>
                                        <span class="text-[10px] font-mono shrink-0 <?php echo $rtNeedsReply ? 'text-rose-600 font-semibold' : 'text-slate-400'; ?>"><?php echo htmlspecialchars(gm_ago($rt['last_reply_at'] ?: $rt['created_at'])); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <a href="support_admin.php" class="mt-3 block text-center text-[11px] font-semibold text-rose-700 hover:text-rose-900 no-underline transition-colors">
                        前往申訴管理 <i class="fa-solid fa-arrow-right text-[9px]"></i>
                    </a>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5 text-slate-800 space-y-4">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <div class="flex items-center gap-2">
                            <div class="w-7 h-7 rounded-md bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700">
                                <i class="fa-solid fa-user-gear text-xs"></i>
                            </div>
                            <div>
                                <h3 class="text-sm font-bold text-slate-900 font-serif">GM 管理員帳號</h3>
                                <p class="text-[10px] text-slate-500">管理後台登入權限憑證</p>
                            </div>
                        </div>
                        <span class="text-[10px] text-slate-400 font-mono">gm_accounts</span>
                    </div>

                    <div class="overflow-x-auto rounded border border-slate-200 bg-white">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 text-slate-600 text-[11px] font-semibold border-b border-slate-200">
                                <tr>
                                    <th class="py-2 px-2.5">ID</th>
                                    <th class="py-2 px-2.5">使用者名稱</th>
                                    <th class="py-2 px-2.5 text-right">操作</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 font-sans">
                                <?php foreach ($gmAccountsList as $g): ?>
                                    <tr class="hover:bg-slate-50">
                                        <td class="py-2 px-2.5 font-mono text-slate-500"><?php echo (int)$g['id']; ?></td>
                                        <td class="py-2 px-2.5 font-semibold text-slate-900 flex items-center gap-1">
                                            <span><?php echo htmlspecialchars($g['username']); ?></span>
                                            <?php if ((int)$g['id'] === (int)$currentGmId): ?>
                                                <span class="text-[10px] text-rose-700 bg-rose-100 px-1 py-0.2 rounded font-normal font-sans">您</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="py-2 px-2.5 text-right text-[11px]">
                                            <?php if ((int)$g['id'] !== (int)$currentGmId): ?>
                                                <form method="POST" action="" class="inline" onsubmit="return confirm('確認要移除此 GM 帳號嗎？');">
                                                    <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                                                    <input type="hidden" name="action" value="deletegm">
                                                    <input type="hidden" name="gm_account_id" value="<?php echo (int)$g['id']; ?>">
                                                    <button type="submit" class="text-rose-600 hover:text-rose-800 font-medium transition-colors">移除</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="text-slate-400">當前使用</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="pt-2 border-t border-slate-200/80">
                        <h4 class="text-xs font-bold text-slate-800 mb-2 font-serif flex items-center gap-1">
                            <i class="fa-solid fa-plus text-rose-600 text-[10px]"></i>
                            <span>新增 GM 管理帳號</span>
                        </h4>
                        <form method="POST" action="" class="space-y-2 text-xs">
                            <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                            <input type="hidden" name="action" value="addgm">

                            <div>
                                <input type="text" name="new_gm_username" placeholder="使用者名稱 (英數、底線)" required
                                    class="w-full px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                            </div>
                            <div>
                                <input type="password" name="new_gm_password" placeholder="密碼 (至少 8 個字元)" required
                                    class="w-full px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                            </div>
                            <button type="submit" class="w-full py-1.5 rounded btn-vermilion font-semibold text-xs flex items-center justify-center gap-1.5">
                                <i class="fa-solid fa-user-plus"></i>
                                <span>建立 GM 帳號</span>
                            </button>
                        </form>
                    </div>

                </div>

            </div>

        </div>

    </main>

    <!-- 儲值系統設定 子視窗 -->
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="recharge-modal" style="margin:0;">
            <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-4xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="recharge-modal-card" style="max-height:90vh;">
                <div class="corner-accent"></div>

                <!-- 子視窗標題列 -->
                <div class="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200">
                    <div class="flex items-center gap-3">
                        <div class="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 text-lg shrink-0">
                            <i class="fa-solid fa-coins"></i>
                        </div>
                        <div>
                            <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                                儲值系統設定
                                <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">recharge_settings</span>
                            </h2>
                            <p class="text-[11px] text-slate-500 mt-0.5">管理前台儲值方式開關、金額方案與回饋比例，儲存後立即生效。</p>
                        </div>
                    </div>
                    <button type="button" onclick="closeRechargeModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                        <i class="fa-solid fa-xmark text-lg"></i>
                    </button>
                </div>

            <?php $gmBaseMethods = [
                'credit_card'   => ['name' => '線上刷卡', 'desc' => 'Visa / MasterCard / JCB 即時入帳', 'icon' => 'fa-credit-card'],
                'bank_transfer' => ['name' => '銀行轉帳', 'desc' => 'ATM 轉帳 / 網路銀行匯款', 'icon' => 'fa-building-columns'],
                'cvs'           => ['name' => '超商繳費', 'desc' => '7-11 / 全家 / 萊爾富 代碼繳費', 'icon' => 'fa-store'],
                'crypto'        => ['name' => '虛擬貨幣', 'desc' => 'USDT / BTC / ETH 鏈上支付', 'icon' => 'fa-bitcoin-sign'],
            ]; ?>
            <?php $rcMin = (int)($rcConfig['min_amount'] ?? 50); $rcMax = (int)($rcConfig['max_amount'] ?? 100000); ?>

            <form method="POST" action="" class="flex flex-col flex-1" style="min-height:0;">
                <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                <input type="hidden" name="action" value="save_recharge">

                <!-- 可滾動內容區 -->
                <div class="p-5 sm:p-6 space-y-6 overflow-y-auto" style="flex:1 1 auto; min-height:0;">

                <!-- 一、儲值方式狀態開關 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-toggle-on text-amber-600"></i> 儲值方式狀態
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php foreach ($gmBaseMethods as $key => $m): ?>
                            <?php $mEnabled = isset($rcMethods[$key]) ? !empty($rcMethods[$key]['enabled']) : true; ?>
                            <?php $mName = (isset($rcMethods[$key]) && !empty($rcMethods[$key]['name'])) ? $rcMethods[$key]['name'] : $m['name']; ?>
                            <div class="rounded-lg border p-3 flex items-center justify-between gap-3 <?php echo $mEnabled ? 'border-amber-200 bg-amber-50/40' : 'border-slate-200 bg-slate-50'; ?>">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600">
                                        <i class="fa-solid <?php echo $m['icon']; ?>"></i>
                                    </div>
                                    <div>
                                        <div class="flex items-center gap-2">
                                            <span class="font-semibold text-slate-800"><?php echo htmlspecialchars($mName); ?></span>
                                            <span class="text-[10px] <?php echo $mEnabled ? 'text-emerald-600' : 'text-rose-600'; ?> font-medium"><?php echo $mEnabled ? '開啟' : '關閉'; ?></span>
                                        </div>
                                        <p class="text-[10px] text-slate-500"><?php echo htmlspecialchars($m['desc']); ?></p>
                                    </div>
                                </div>
                                <select name="method_enabled[<?php echo $key; ?>]" class="appearance-none rounded border border-slate-300 bg-white pl-3 pr-8 py-1 text-xs form-input-focus">
                                    <option value="1" <?php echo $mEnabled ? 'selected' : ''; ?>>啟用</option>
                                    <option value="0" <?php echo !$mEnabled ? 'selected' : ''; ?>>停用</option>
                                </select>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="text-[10px] text-slate-400 mt-1.5">關閉的儲值方式在前台會顯示「暫時無法使用該支付方式」，且無法提交儲值。</p>
                </div>

                <!-- 二、自訂金額範圍 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-sliders text-amber-600"></i> 自訂金額範圍
                    </h3>
                    <div class="flex flex-wrap gap-3">
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">最低金額（NT$）</label>
                            <input type="number" name="config[min_amount]" value="<?php echo $rcMin; ?>" min="1" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">最高金額（NT$）</label>
                            <input type="number" name="config[max_amount]" value="<?php echo $rcMax; ?>" min="1" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                    </div>
                </div>

                <!-- 三、金額方案與回饋比例 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-chart-simple text-amber-600"></i> 儲值金額方案與回饋比例
                    </h3>
                    <div class="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 text-slate-600 font-semibold text-[11px] border-b border-slate-200">
                                <tr>
                                    <th class="py-2 px-3">ID</th>
                                    <th class="py-2 px-3">金額（NT$）</th>
                                    <th class="py-2 px-3">回饋比例（%）</th>
                                    <th class="py-2 px-3">狀態</th>
                                    <th class="py-2 px-3">刪除</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php foreach ($rcTiers as $t): ?>
                                    <tr>
                                        <td class="py-2 px-3 font-mono text-slate-500">#<?php echo (int)$t['id']; ?></td>
                                        <td class="py-2 px-3">
                                            <input type="number" name="tier[<?php echo (int)$t['id']; ?>][amount]" value="<?php echo (int)$t['amount']; ?>" min="1" class="w-28 px-2 py-1 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </td>
                                        <td class="py-2 px-3">
                                            <input type="number" name="tier[<?php echo (int)$t['id']; ?>][bonus_percent]" value="<?php echo (int)$t['bonus_percent']; ?>" min="0" max="500" class="w-20 px-2 py-1 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </td>
                                        <td class="py-2 px-3">
                                            <select name="tier[<?php echo (int)$t['id']; ?>][enabled]" class="appearance-none rounded border border-slate-300 bg-white pl-3 pr-8 py-1 text-[11px] form-input-focus">
                                                <option value="1" <?php echo !empty($t['enabled']) ? 'selected' : ''; ?>>啟用</option>
                                                <option value="0" <?php echo empty($t['enabled']) ? 'selected' : ''; ?>>停用</option>
                                            </select>
                                        </td>
                                        <td class="py-2 px-3">
                                            <label class="inline-flex items-center gap-1 text-rose-600 cursor-pointer">
                                                <input type="checkbox" name="remove_tier[<?php echo (int)$t['id']; ?>]" value="1" class="rounded border-slate-300 text-rose-600">
                                                <span class="text-[11px]">刪除</span>
                                            </label>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($rcTiers)): ?>
                                    <tr>
                                        <td colspan="5" class="py-4 text-center text-slate-400 text-xs">尚無金額方案，請於下方新增。</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="flex flex-wrap items-end gap-3 mt-3">
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">新增金額（NT$）</label>
                            <input type="number" name="new_amount" min="1" placeholder="例如 2000" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">新增回饋比例（%）</label>
                            <input type="number" name="new_bonus_percent" min="0" max="500" placeholder="例如 12" class="w-32 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <p class="text-[10px] text-slate-400 pb-1.5">新增方案將於「儲存」時加入，前台以金額遞增顯示。</p>
                    </div>
                </div>

                <!-- 四、金流系統參數 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-money-check-dollar text-amber-600"></i> 金流系統參數（綠界 ECPay）
                    </h3>
                    <div class="rounded-lg border border-slate-200 bg-white p-4 space-y-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">營運環境</label>
                                <select name="gateway[ecpay_env]" class="w-full appearance-none pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                    <option value="stage" <?php echo ($rcGateway['ecpay_env'] ?? 'stage') !== 'prod' ? 'selected' : ''; ?>>測試環境 (Stage)</option>
                                    <option value="prod" <?php echo ($rcGateway['ecpay_env'] ?? 'stage') === 'prod' ? 'selected' : ''; ?>>正式環境 (Production)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">商家編號 MerchantID</label>
                                <input type="text" name="gateway[ecpay_merchant_id]" value="<?php echo htmlspecialchars($rcGateway['ecpay_merchant_id'] ?? ''); ?>" placeholder="例如 3002607" class="w-full px-3 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">HashKey</label>
                                <div class="relative">
                                    <input type="password" id="ecpay-hash-key" name="gateway[ecpay_hash_key]" value="<?php echo htmlspecialchars($rcGateway['ecpay_hash_key'] ?? ''); ?>" placeholder="留空使用預設測試金鑰" class="w-full pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                    <button type="button" onclick="toggleSecret('ecpay-hash-key', this)" class="absolute inset-y-0 right-0 flex items-center px-2 text-slate-400 hover:text-slate-700 cursor-pointer" tabindex="-1" title="顯示／隱藏">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">HashIV</label>
                                <div class="relative">
                                    <input type="password" id="ecpay-hash-iv" name="gateway[ecpay_hash_iv]" value="<?php echo htmlspecialchars($rcGateway['ecpay_hash_iv'] ?? ''); ?>" placeholder="留空使用預設測試金鑰" class="w-full pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                    <button type="button" onclick="toggleSecret('ecpay-hash-iv', this)" class="absolute inset-y-0 right-0 flex items-center px-2 text-slate-400 hover:text-slate-700 cursor-pointer" tabindex="-1" title="顯示／隱藏">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">付款 API 網址（留空則依環境自動套用綠界官方端點）</label>
                            <input type="text" name="gateway[ecpay_action_url]" value="<?php echo htmlspecialchars($rcGateway['ecpay_action_url'] ?? ''); ?>" placeholder="https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5" class="w-full px-3 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        </div>

                        <div class="flex items-start gap-1.5 text-[10px] text-slate-400 pt-2 border-t border-slate-100">
                            <i class="fa-solid fa-circle-info mt-0.5"></i>
                            <span>回呼網址（ReturnURL）由系統網址自動產生：<span class="font-mono text-slate-500"><?php echo htmlspecialchars(defined('SITE_URL') ? SITE_URL : ''); ?>/recharge_notify.php</span>。金鑰僅儲存於後台資料庫，前台不會顯示。</span>
                        </div>
                    </div>
                    <p class="text-[10px] text-slate-400 mt-1.5">修改後立即套用於新的付款交易；進行中的訂單仍沿用建立時的金鑰與環境。</p>
                </div>

                </div><!-- /可滾動內容區 -->

                <!-- 子視窗底部操作列 -->
                <div class="px-5 sm:px-6 py-4 border-t border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
                    <span class="text-[11px] text-slate-400 hidden sm:flex items-center gap-1.5">
                        <i class="fa-solid fa-circle-info"></i> 變更將同步套用至前台儲值中心
                    </span>
                    <div class="flex items-center gap-3" style="margin-left:auto;">
                        <button type="button" onclick="closeRechargeModal()" class="px-5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 font-semibold text-xs transition-colors cursor-pointer">取消</button>
                        <button type="submit" class="btn-vermilion px-6 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <span>儲存所有儲值設定</span>
                        </button>
                    </div>
                </div>
            </form>
            </div><!-- /子視窗卡片 -->
        </div><!-- /子視窗遮罩 -->

    <!-- 訂單管理 子視窗 -->
    <div class="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="order-modal" style="margin:0;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-6xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="order-modal-card" style="max-height:92vh;">
            <div class="corner-accent"></div>

            <!-- 標題列 -->
            <div class="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700 text-lg shrink-0">
                        <i class="fa-solid fa-receipt"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            訂單管理
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">recharge_orders</span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-semibold">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> 即時連線
                            </span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">檢視全部儲值訂單、編輯狀態與金額，並掌握即時營運報表。</p>
                    </div>
                </div>
                <button type="button" onclick="closeOrderModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- 提示訊息 -->
            <div id="order-toast" class="hidden p-3 rounded-lg border text-xs items-center gap-2.5" style="margin:12px 20px 0;"></div>

            <!-- 報表統計 -->
            <div class="px-5 sm:px-6 pt-4">
                <div class="flex items-center justify-between mb-2.5">
                    <div class="flex items-center gap-2 text-xs">
                        <i class="fa-solid fa-chart-column text-sky-600"></i>
                        <span class="font-bold text-slate-700 font-serif">營收報表</span>
                        <span class="text-[11px] text-slate-400 font-mono" id="order-period-label">全部期間</span>
                    </div>
                    <span class="text-[11px] text-slate-400 hidden sm:inline">依所選期間即時統計</span>
                </div>
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <div class="rounded-xl border border-slate-200 bg-white p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0"><i class="fa-solid fa-receipt"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-slate-500">總訂單數</div>
                            <div class="text-lg font-extrabold text-slate-800 font-mono leading-tight" id="stat-count">0</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-amber-600 border border-amber-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-hourglass-half"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-amber-700">待付款</div>
                            <div class="text-lg font-extrabold text-amber-700 font-mono leading-tight" id="stat-pending">0</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-check"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-emerald-700">已付款</div>
                            <div class="text-lg font-extrabold text-emerald-700 font-mono leading-tight" id="stat-paid">0</div>
                            <div class="text-[10px] text-emerald-600">入帳 <span id="stat-points" class="font-mono">0</span> 點</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-rose-200 bg-rose-50/50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-rose-600 border border-rose-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-sack-dollar"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-rose-700">期間實付營收</div>
                            <div class="text-lg font-extrabold text-rose-700 font-mono leading-tight" id="stat-amount">NT$ 0</div>
                            <div class="text-[10px] text-rose-600">平均客單 <span id="stat-avg" class="font-mono">NT$ 0</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 期間營收篩選 -->
            <div class="px-5 sm:px-6 pt-4 pb-3 border-b border-slate-200">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
                    <div class="flex flex-wrap items-center gap-2">
                        <button type="button" data-period="all" class="order-period-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-infinity"></i> 全部
                        </button>
                        <button type="button" data-period="today" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-day"></i> 本日
                        </button>
                        <button type="button" data-period="yesterday" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-clock-rotate-left"></i> 昨日
                        </button>
                        <button type="button" data-period="this_week" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-week"></i> 本周
                        </button>
                        <button type="button" data-period="last_week" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-minus"></i> 上周
                        </button>
                        <button type="button" data-period="this_month" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-days"></i> 本月
                        </button>
                        <button type="button" data-period="last_month" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-check"></i> 上月
                        </button>
                        <button type="button" data-period="custom" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-sliders"></i> 自訂
                        </button>
                    </div>
                    <div id="order-custom-range" class="hidden flex-wrap items-center gap-2">
                        <input type="date" id="period-from" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        <span class="text-slate-400 text-xs">~</span>
                        <input type="date" id="period-to" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        <button type="button" onclick="applyOrderCustomRange()" class="btn-ice px-3.5 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-filter"></i> 套用
                        </button>
                    </div>
                </div>
            </div>

            <!-- 篩選工具列 -->
            <div class="px-5 sm:px-6 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-200">
                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" data-status="all" class="order-filter-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-layer-group"></i> 全部 <span data-count="count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                    <button type="button" data-status="pending" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-amber-50 border-amber-200 text-amber-700">
                        <i class="fa-solid fa-hourglass-half"></i> 待付款 <span data-count="pending_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(180,83,9,0.10);">0</span>
                    </button>
                    <button type="button" data-status="paid" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-emerald-50 border-emerald-200 text-emerald-700">
                        <i class="fa-solid fa-circle-check"></i> 已付款 <span data-count="paid_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(4,120,87,0.10);">0</span>
                    </button>
                    <button type="button" data-status="failed" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-rose-50 border-rose-200 text-rose-700">
                        <i class="fa-solid fa-circle-exclamation"></i> 付款失敗 <span data-count="failed_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(190,18,60,0.10);">0</span>
                    </button>
                    <button type="button" data-status="expired" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-clock"></i> 已逾期 <span data-count="expired_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                    <button type="button" data-status="cancelled" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-ban"></i> 已取消 <span data-count="cancelled_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                </div>
                <div class="relative w-full max-w-xs">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                    <input type="text" id="order-search" placeholder="搜尋訂單編號 / 會員 / 交易編號…" class="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus transition-all">
                </div>
            </div>

            <!-- 批次處理列 -->
            <div id="order-batch-bar" class="hidden px-5 sm:px-6 py-3 border-b border-sky-200 bg-sky-50 items-center justify-between gap-3 flex-wrap">
                <div class="flex items-center gap-3 text-xs">
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-sky-600 text-white font-bold">
                        <i class="fa-solid fa-check-double"></i> 已選 <span id="order-selected-count" class="font-mono">0</span> 筆
                    </span>
                    <button type="button" onclick="clearOrderSelection()" class="text-slate-500 hover:text-slate-700 underline text-[11px] cursor-pointer">清除選取</button>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                    <select id="batch-status" class="appearance-none pl-3 pr-8 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                        <option value="paid">設為已付款</option>
                        <option value="cancelled">設為已取消</option>
                        <option value="expired">設為已逾期</option>
                        <option value="failed">設為付款失敗</option>
                        <option value="pending">設為待付款</option>
                    </select>
                    <label class="inline-flex items-center gap-1.5 text-[11px] text-slate-600 px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-white cursor-pointer">
                        <input type="checkbox" id="batch-credit" class="rounded border-slate-300">
                        同時入帳元寶
                    </label>
                    <button type="button" id="batch-apply-btn" onclick="applyBatchUpdate()" class="btn-ice px-4 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                        <i class="fa-solid fa-bolt"></i> 批次套用
                    </button>
                </div>
            </div>

            <!-- 列表檢視 -->
            <div class="flex-1 overflow-y-auto p-4 sm:p-6" id="order-list-view" style="min-height:0;">
                <div id="order-list">
                    <div class="py-16 text-center text-slate-400 text-sm">
                        <i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>
                        載入中…
                    </div>
                </div>
            </div>

            <!-- 編輯檢視 -->
            <div class="hidden flex-1 overflow-y-auto p-5" id="order-edit-view" style="min-height:0;">
                <div class="flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
                    <div class="flex items-center gap-2.5">
                        <button type="button" onclick="showOrderList()" class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 flex items-center justify-center cursor-pointer" title="返回列表"><i class="fa-solid fa-arrow-left"></i></button>
                        <div>
                            <h3 class="text-sm font-bold text-slate-900 font-serif">編輯訂單</h3>
                            <p class="text-[11px] text-slate-500 font-mono" id="edit-order-no">—</p>
                        </div>
                    </div>
                    <span id="edit-status-badge" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-[11px] font-bold bg-slate-100 text-slate-600 border-slate-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span><span id="edit-status-badge-text">—</span>
                    </span>
                </div>

                <form id="order-edit-form" onsubmit="return submitOrderEdit(event)">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[11px] font-semibold text-slate-700 mb-1">訂單狀態</label>
                                <select id="edit-status" class="w-full appearance-none pl-3 pr-8 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                                    <option value="pending">待付款</option>
                                    <option value="paid">已付款</option>
                                    <option value="failed">付款失敗</option>
                                    <option value="expired">已逾期</option>
                                    <option value="cancelled">已取消</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">儲值金額 (NT$)</label>
                                    <input type="number" min="0" id="edit-amount" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">加贈元寶 (點)</label>
                                    <input type="number" min="0" id="edit-bonus" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">總入帳元寶 (點)</label>
                                    <input type="number" min="0" id="edit-total" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">綠界交易編號</label>
                                    <input type="text" maxlength="20" id="edit-trade-no" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-semibold text-slate-700 mb-1">備註 / 處理說明</label>
                                <input type="text" maxlength="200" id="edit-rtn-msg" placeholder="例如：客服手動入帳、異常補單…" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                            </div>
                        </div>

                        <div class="space-y-3">
                            <div class="rounded-xl border border-slate-200 bg-slate-50/80 p-4 text-xs space-y-2">
                                <div class="font-bold text-slate-700 pb-2 mb-1 border-b border-slate-200">會員與訂單資訊</div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">會員</span><span class="font-mono text-slate-700 truncate" id="edit-user">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">UID</span><span class="font-mono text-slate-700" id="edit-uid">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">付款方式</span><span class="text-slate-700" id="edit-method">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">建立時間</span><span class="font-mono text-slate-700" id="edit-created">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">付款時間</span><span class="font-mono text-slate-700" id="edit-paid-at">—</span></div>
                            </div>
                            <label class="flex items-start gap-2.5 p-3.5 rounded-xl border border-emerald-200 bg-emerald-50 cursor-pointer">
                                <input type="checkbox" id="edit-credit" class="mt-0.5 rounded border-slate-300">
                                <span class="text-[11px] text-slate-600 leading-relaxed">
                                    若狀態設為「已付款」，同時為會員入帳 <strong class="text-emerald-700 font-mono" id="edit-credit-points">0</strong> 點元寶。
                                    <br><span class="text-slate-400">僅在原狀態非「已付款」時執行一次，避免重複入帳。</span>
                                </span>
                            </label>
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-200 flex items-center justify-end gap-3" style="margin-top:1rem;">
                        <button type="button" onclick="showOrderList()" class="px-5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 font-semibold text-xs transition-colors cursor-pointer">取消</button>
                        <button type="submit" id="edit-submit-btn" class="btn-ice px-6 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <span>儲存變更</span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- 分頁 -->
            <div class="hidden px-5 sm:px-6 py-3 border-t border-slate-200 bg-slate-50/70 items-center justify-between gap-3" id="order-pager">
                <span class="text-[11px] text-slate-500" id="order-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="order-prev" onclick="changeOrderPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        <i class="fa-solid fa-chevron-left text-[10px]"></i> 上一頁
                    </button>
                    <button type="button" id="order-next" onclick="changeOrderPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        下一頁 <i class="fa-solid fa-chevron-right text-[10px]"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <footer class="relative z-10 border-t border-slate-800/80 bg-[#070a10] py-6 text-center text-xs text-slate-500">
        <div class="max-w-7xl mx-auto px-4 space-y-1.5 font-serif">
            <p class="text-slate-400 font-medium">踏雪笑傲 · GM 管理控制台 (GM Control Center)</p>
            <p class="text-[11px] text-slate-600 font-mono">© 2025 踏雪笑傲運營團隊 All Rights Reserved. 系統操作均納入稽核日誌。</p>
        </div>
    </footer>

    <!-- 登入管理 子視窗 -->
    <div class="fixed inset-0 z-[70] flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="login-modal" style="margin:0; position:fixed; top:0; left:0; right:0; bottom:0; z-index:9999;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-5xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="login-modal-card" style="max-height:90vh;">
            <div class="corner-accent"></div>

            <div class="flex items-start justify-between gap-4 p-4 sm:p-5 border-b border-slate-200 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700 text-base shrink-0">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            登入管理
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">login_logs</span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-semibold">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> 即時稽核
                            </span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">檢視會員登入帳號、來源 IP 與成功／失敗狀態，掌握異常嘗試與鎖定情形。</p>
                    </div>
                </div>
                <button type="button" onclick="closeLoginModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- 統計 -->
            <div class="px-4 sm:px-5 pt-4 shrink-0">
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <div class="rounded-xl border border-slate-200 bg-white p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0"><i class="fa-solid fa-right-to-bracket"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-slate-500">今日登入嘗試</div>
                            <div class="text-lg font-extrabold text-slate-800 font-mono leading-tight" id="login-stat-today">0</div>
                            <div class="text-[10px] text-slate-400">來源 IP <span id="login-stat-ips" class="font-mono">0</span> 組</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-check"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-emerald-700">今日成功</div>
                            <div class="text-lg font-extrabold text-emerald-700 font-mono leading-tight" id="login-stat-success">0</div>
                            <div class="text-[10px] text-emerald-600">近 7 日 <span id="login-stat-week" class="font-mono">0</span></div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-rose-200 bg-rose-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-rose-600 border border-rose-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-exclamation"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-rose-700">今日失敗</div>
                            <div class="text-lg font-extrabold text-rose-700 font-mono leading-tight" id="login-stat-failed">0</div>
                            <div class="text-[10px] text-rose-600">近 7 日 <span id="login-stat-weekfail" class="font-mono">0</span></div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-amber-600 border border-amber-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-lock"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-amber-700">目前鎖定 IP</div>
                            <div class="text-lg font-extrabold text-amber-700 font-mono leading-tight" id="login-stat-blocked">0</div>
                            <div class="text-[10px] text-amber-600" id="login-lastfail">—</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 篩選工具列 -->
            <div class="px-4 sm:px-5 py-3.5 mt-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-y border-slate-200 shrink-0">
                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" data-status="all" class="login-filter-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-layer-group"></i> 全部
                    </button>
                    <button type="button" data-status="success" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-emerald-50 border-emerald-200 text-emerald-700">
                        <i class="fa-solid fa-circle-check"></i> 成功
                    </button>
                    <button type="button" data-status="failed" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-rose-50 border-rose-200 text-rose-700">
                        <i class="fa-solid fa-circle-exclamation"></i> 失敗
                    </button>
                    <button type="button" data-status="blocked" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-amber-50 border-amber-200 text-amber-700">
                        <i class="fa-solid fa-lock"></i> 鎖定
                    </button>
                </div>
                <div class="flex items-center gap-2 flex-wrap">
                    <select id="login-range" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                        <option value="today">今日</option>
                        <option value="7">近 7 日</option>
                        <option value="30">近 30 日</option>
                        <option value="all">全部期間</option>
                    </select>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400"><i class="fa-solid fa-magnifying-glass text-[11px]"></i></span>
                        <input type="text" id="login-search" placeholder="搜尋帳號 / IP" class="pl-8 pr-3 py-1.5 w-48 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    </div>
                    <button type="button" onclick="loadLoginLogs(true)" class="btn-ice px-3.5 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                        <i class="fa-solid fa-rotate-right"></i> 重整
                    </button>
                </div>
            </div>

            <!-- 列表 -->
            <div class="flex-1 min-h-0 overflow-y-auto px-4 sm:px-5 py-4" id="login-list" style="min-height:0;"></div>

            <!-- 分頁 -->
            <div class="px-4 sm:px-5 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
                <span id="login-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="login-prev" onclick="changeLoginPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        <i class="fa-solid fa-chevron-left mr-1"></i> 上一頁
                    </button>
                    <button type="button" id="login-next" onclick="changeLoginPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        下一頁 <i class="fa-solid fa-chevron-right ml-1"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function initSnow() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = (canvas.width = window.innerWidth);
            let height = (canvas.height = window.innerHeight);

            window.addEventListener('resize', () => {
                width = canvas.width = window.innerWidth;
                height = canvas.height = window.innerHeight;
            });

            const particles = [];
            const count = Math.min(Math.floor(window.innerWidth / 26), 48);

            for (let i = 0; i < count; i++) {
                particles.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    radius: Math.random() * 2.0 + 0.6,
                    speedY: Math.random() * 0.7 + 0.25,
                    speedX: (Math.random() - 0.5) * 0.4,
                    opacity: Math.random() * 0.6 + 0.2
                });
            }

            function render() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    p.y += p.speedY;
                    p.x += p.speedX;

                    if (p.y > height) {
                        p.y = -5;
                        p.x = Math.random() * width;
                    }
                    if (p.x < 0) p.x = width;
                    if (p.x > width) p.x = 0;

                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
                    ctx.shadowBlur = 4;
                    ctx.shadowColor = 'rgba(255, 255, 255, 0.5)';
                    ctx.fill();
                }
                requestAnimationFrame(render);
            }
            render();
        })();

        // 儲值系統設定子視窗控制
        (function initRechargeModal() {
            const modal = document.getElementById('recharge-modal');
            const card = document.getElementById('recharge-modal-card');
            if (!modal || !card) return;

            window.openRechargeModal = function () {
                modal.classList.remove('opacity-0', 'pointer-events-none');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
                document.body.style.overflow = 'hidden';
            };
            window.closeRechargeModal = function () {
                modal.classList.add('opacity-0', 'pointer-events-none');
                modal.classList.remove('opacity-100');
                card.classList.remove('scale-100');
                card.classList.add('scale-95');
                document.body.style.overflow = '';
            };

            // 點擊遮罩關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) window.closeRechargeModal();
            });
            // ESC 關閉
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.classList.contains('opacity-100')) {
                    window.closeRechargeModal();
                }
            });

            <?php if ($openRechargeModal): ?>
            // 儲存後自動重新開啟，讓管理員檢視結果
            window.openRechargeModal();
            <?php endif; ?>
        })();

        // 金鑰顯示 / 隱藏切換
        window.toggleSecret = function (inputId, btn) {
            const input = document.getElementById(inputId);
            if (!input) return;
            const reveal = (input.type === 'password');
            input.type = reveal ? 'text' : 'password';
            const icon = btn ? btn.querySelector('i') : null;
            if (icon) {
                icon.className = reveal ? 'fa-solid fa-eye-slash text-xs' : 'fa-solid fa-eye text-xs';
            }
        };

        // ===== 訂單管理 =====
        const GM_FORM_TOKEN = <?php echo json_encode($formToken); ?>;

        const ORDER_STATUS_META = {
            paid:      { text: '已付款',   cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
            pending:   { text: '待付款',   cls: 'bg-amber-50 text-amber-700 border-amber-200',       dot: 'bg-amber-500' },
            failed:    { text: '付款失敗', cls: 'bg-rose-50 text-rose-700 border-rose-200',          dot: 'bg-rose-500' },
            expired:   { text: '已逾期',   cls: 'bg-slate-100 text-slate-600 border-slate-300',       dot: 'bg-slate-400' },
            cancelled: { text: '已取消',   cls: 'bg-slate-100 text-slate-600 border-slate-300',       dot: 'bg-slate-400' }
        };
        const ORDER_DEFAULT_META = { text: '未知', cls: 'bg-slate-100 text-slate-600 border-slate-300', dot: 'bg-slate-400' };

        const orderModal = document.getElementById('order-modal');
        const orderCard = document.getElementById('order-modal-card');
        const orderListEl = document.getElementById('order-list');
        const orderListView = document.getElementById('order-list-view');
        const orderEditView = document.getElementById('order-edit-view');
        const orderPager = document.getElementById('order-pager');
        const orderPagerInfo = document.getElementById('order-pager-info');
        const orderPrev = document.getElementById('order-prev');
        const orderNext = document.getElementById('order-next');
        const orderSearch = document.getElementById('order-search');

        const orderState = { page: 1, pages: 1, status: 'all', q: '', period: 'all', dateFrom: '', dateTo: '', orders: [], index: {}, editing: null, loaded: false, selected: new Set() };
        let orderDebounce = null;
        let orderToastTimer = null;

        function escapeHtml(s) {
            return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
        }
        function orderFmtMoney(n) { return 'NT$ ' + Number(n || 0).toLocaleString(); }
        function orderFmtPoints(n) { return Number(n || 0).toLocaleString(); }
        function orderFmtDT(s) { return s ? String(s).replace('T', ' ').slice(0, 16) : '—'; }

        window.openOrderModal = function () {
            if (!orderModal) return;
            orderModal.classList.remove('opacity-0', 'pointer-events-none');
            orderModal.classList.add('opacity-100');
            if (orderCard) { orderCard.classList.remove('scale-95'); orderCard.classList.add('scale-100'); }
            document.body.style.overflow = 'hidden';
            orderState.selected.clear();
            showOrderList();
            loadOrders(!orderState.loaded);
        };
        window.closeOrderModal = function () {
            if (!orderModal) return;
            orderModal.classList.add('opacity-0', 'pointer-events-none');
            orderModal.classList.remove('opacity-100');
            if (orderCard) { orderCard.classList.remove('scale-100'); orderCard.classList.add('scale-95'); }
            document.body.style.overflow = '';
        };
        window.showOrderList = function () {
            if (orderListView) orderListView.classList.remove('hidden');
            if (orderEditView) orderEditView.classList.add('hidden');
            orderState.editing = null;
        };
        function showOrderEdit() {
            if (orderListView) orderListView.classList.add('hidden');
            if (orderEditView) orderEditView.classList.remove('hidden');
            if (orderEditView) orderEditView.scrollTop = 0;
        }

        function showOrderToast(msg, ok) {
            const el = document.getElementById('order-toast');
            if (!el) return;
            el.className = 'mx-5 sm:mx-6 mt-3 p-3 rounded-lg border text-xs flex items-center gap-2.5 '
                + (ok ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700');
            el.innerHTML = '<i class="fa-solid ' + (ok ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><span>' + escapeHtml(msg) + '</span>';
            clearTimeout(orderToastTimer);
            orderToastTimer = setTimeout(() => { el.classList.add('hidden'); }, 3800);
        }

        function setOrderFilter(status) {
            orderState.status = status;
            orderState.page = 1;
            document.querySelectorAll('.order-filter-btn').forEach(btn => {
                btn.classList.toggle('active', btn.getAttribute('data-status') === status);
            });
            loadOrders(true);
        }
        window.changeOrderPage = function (delta) {
            const target = orderState.page + delta;
            if (target < 1 || target > orderState.pages) return;
            orderState.page = target;
            loadOrders(true);
        };

        function loadOrders(showLoading) {
            if (!orderListEl) return;
            if (showLoading) {
                orderListEl.innerHTML = '<div class="py-16 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>載入中…</div>';
            }
            const url = 'gm_orders_api.php?status=' + encodeURIComponent(orderState.status)
                + '&q=' + encodeURIComponent(orderState.q)
                + '&period=' + encodeURIComponent(orderState.period)
                + '&date_from=' + encodeURIComponent(orderState.dateFrom)
                + '&date_to=' + encodeURIComponent(orderState.dateTo)
                + '&page=' + encodeURIComponent(orderState.page)
                + '&limit=10';
            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (!data || !data.ok) {
                        orderListEl.innerHTML = '<div class="py-16 text-center text-rose-500 text-sm"><i class="fa-solid fa-circle-exclamation text-2xl mb-3 block"></i>' + escapeHtml((data && data.message) || '查詢失敗') + '</div>';
                        if (orderPager) { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
                        return;
                    }
                    orderState.loaded = true;
                    renderOrders(data);
                })
                .catch(() => {
                    orderListEl.innerHTML = '<div class="py-16 text-center text-rose-500 text-sm"><i class="fa-solid fa-wifi text-2xl mb-3 block"></i>網路連線異常，請稍後再試。</div>';
                });
        }

        function renderOrders(data) {
            const orders = data.orders || [];
            const stats = data.stats || {};
            orderState.page = Number(data.page || 1);
            orderState.pages = Math.max(1, Number(data.pages || 1));
            orderState.orders = orders;
            orderState.index = {};
            orders.forEach(o => { orderState.index[o.order_no] = o; });

            const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            const paidCount = Number(stats.paid_count || 0);
            const paidAmount = Number(stats.paid_amount || 0);
            setText('stat-count', Number(stats.count || 0).toLocaleString());
            setText('stat-pending', Number(stats.pending_count || 0).toLocaleString());
            setText('stat-paid', paidCount.toLocaleString());
            setText('stat-points', Number(stats.paid_points || 0).toLocaleString());
            setText('stat-amount', orderFmtMoney(paidAmount));
            setText('stat-avg', orderFmtMoney(paidCount > 0 ? Math.round(paidAmount / paidCount) : 0));

            const periodLabels = {
                all: '全部期間', today: '本日', yesterday: '昨日',
                this_week: '本周', last_week: '上周',
                this_month: '本月', last_month: '上月', custom: '自訂期間'
            };
            let plabel = periodLabels[data.period] || '全部期間';
            if (data.period && data.period !== 'all' && data.date_from && data.date_to) {
                plabel += '（' + data.date_from + ' ~ ' + data.date_to + '）';
            }
            const periodLabelEl = document.getElementById('order-period-label');
            if (periodLabelEl) periodLabelEl.textContent = plabel;

            document.querySelectorAll('[data-count]').forEach(el => {
                const key = el.getAttribute('data-count');
                el.textContent = Number(stats[key] || 0).toLocaleString();
            });

            if (!orders.length) {
                orderListEl.innerHTML = '<div class="py-16 text-center text-slate-400 text-sm"><i class="fa-regular fa-folder-open text-3xl mb-3 block"></i>查無符合的訂單</div>';
            } else {
                orderListEl.innerHTML = `
                <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">
                    <table class="w-full text-left text-xs whitespace-nowrap">
                        <thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                            <tr>
                                <th class="py-2.5 px-2 w-8 text-center"><input type="checkbox" id="order-select-all" class="rounded border-slate-300 cursor-pointer" title="全選本頁"></th>
                                <th class="py-2.5 px-3">訂單編號</th>
                                <th class="py-2.5 px-3">會員</th>
                                <th class="py-2.5 px-3">付款方式</th>
                                <th class="py-2.5 px-3 text-right">金額</th>
                                <th class="py-2.5 px-3 text-right">元寶</th>
                                <th class="py-2.5 px-3">狀態</th>
                                <th class="py-2.5 px-3">建立時間</th>
                                <th class="py-2.5 px-3 text-right">操作</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${orders.map(o => {
                                const meta = ORDER_STATUS_META[o.status] || ORDER_DEFAULT_META;
                                return `
                                <tr class="hover:bg-slate-50/80 transition-colors">
                                    <td class="py-2.5 px-2 text-center"><input type="checkbox" class="order-row-check rounded border-slate-300 cursor-pointer" data-order="${escapeHtml(o.order_no)}"></td>
                                    <td class="py-2.5 px-3 font-mono text-slate-700 font-semibold">${escapeHtml(o.order_no)}</td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-medium text-slate-800">${escapeHtml(o.username)}</div>
                                        <div class="text-[10px] text-slate-400 font-mono">UID #${Number(o.uid || 0)}</div>
                                    </td>
                                    <td class="py-2.5 px-3 text-slate-600">${escapeHtml(o.method_name)}</td>
                                    <td class="py-2.5 px-3 text-right font-mono text-slate-700">${orderFmtMoney(o.amount)}</td>
                                    <td class="py-2.5 px-3 text-right font-mono text-amber-600">+${orderFmtPoints(o.total_points)}</td>
                                    <td class="py-2.5 px-3">
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-bold ${meta.cls}">
                                            <span class="w-1.5 h-1.5 rounded-full ${meta.dot}"></span>${meta.text}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-slate-500 font-mono text-[11px]">${orderFmtDT(o.created_at)}</td>
                                    <td class="py-2.5 px-3 text-right">
                                        <button type="button" onclick="editOrder('${escapeHtml(o.order_no)}')" class="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-700 border border-slate-300 font-medium text-[11px] transition-colors cursor-pointer">
                                            <i class="fa-solid fa-pen-to-square text-[10px]"></i> 編輯
                                        </button>
                                    </td>
                                </tr>`;
                            }).join('')}
                        </tbody>
                    </table>
                </div>`;
            }

            if (orderPager) {
                if (orderState.pages > 1) { orderPager.classList.remove('hidden'); orderPager.classList.add('flex'); }
                else { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
            }
            if (orderPagerInfo) orderPagerInfo.textContent = '第 ' + orderState.page + ' / ' + orderState.pages + ' 頁 · 共 ' + Number(data.total || 0).toLocaleString() + ' 筆';
            if (orderPrev) orderPrev.disabled = orderState.page <= 1;
            if (orderNext) orderNext.disabled = orderState.page >= orderState.pages;

            syncOrderSelectionUI();
        }

        function syncOrderSelectionUI() {
            const checks = orderListEl ? orderListEl.querySelectorAll('.order-row-check') : [];
            let checkedOnPage = 0;
            checks.forEach(cb => {
                const on = orderState.selected.has(cb.getAttribute('data-order'));
                cb.checked = on;
                if (on) checkedOnPage++;
            });
            const all = document.getElementById('order-select-all');
            if (all) {
                all.checked = (checks.length > 0 && checkedOnPage === checks.length);
                all.indeterminate = (checkedOnPage > 0 && checkedOnPage < checks.length);
            }
            const bar = document.getElementById('order-batch-bar');
            const cnt = document.getElementById('order-selected-count');
            if (cnt) cnt.textContent = orderState.selected.size;
            if (bar) {
                if (orderState.selected.size > 0) { bar.classList.remove('hidden'); bar.classList.add('flex'); }
                else { bar.classList.add('hidden'); bar.classList.remove('flex'); }
            }
        }

        window.clearOrderSelection = function () {
            orderState.selected.clear();
            syncOrderSelectionUI();
        };

        window.applyBatchUpdate = function () {
            if (orderState.selected.size === 0) {
                showOrderToast('請先勾選要處理的訂單。', false);
                return;
            }
            const status = document.getElementById('batch-status').value;
            const credit = document.getElementById('batch-credit').checked ? '1' : '0';
            const btn = document.getElementById('batch-apply-btn');
            if (btn) { btn.disabled = true; btn.classList.add('opacity-60', 'cursor-not-allowed'); }

            const body = new URLSearchParams();
            body.append('action', 'batch_update');
            body.append('form_token', GM_FORM_TOKEN);
            body.append('status', status);
            body.append('credit', credit);
            orderState.selected.forEach(no => body.append('order_nos[]', no));

            fetch('gm_orders_api.php', { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (data && data.ok) {
                        orderState.selected.clear();
                        loadOrders(false);
                        showOrderToast(data.message || '批次更新完成。', true);
                    } else {
                        showOrderToast((data && data.message) || '批次更新失敗，請稍後再試。', false);
                    }
                })
                .catch(() => showOrderToast('網路連線異常，請稍後再試。', false))
                .finally(() => {
                    if (btn) { btn.disabled = false; btn.classList.remove('opacity-60', 'cursor-not-allowed'); }
                });
        };

        window.setOrderPeriod = function (period) {
            orderState.period = period;
            orderState.page = 1;
            document.querySelectorAll('.order-period-btn').forEach(b => {
                b.classList.toggle('active', b.getAttribute('data-period') === period);
            });
            const customWrap = document.getElementById('order-custom-range');
            if (customWrap) {
                if (period === 'custom') { customWrap.classList.remove('hidden'); customWrap.classList.add('flex'); }
                else { customWrap.classList.add('hidden'); customWrap.classList.remove('flex'); }
            }
            if (period !== 'custom') {
                loadOrders(true);
            }
        };
        window.applyOrderCustomRange = function () {
            const fromEl = document.getElementById('period-from');
            const toEl = document.getElementById('period-to');
            orderState.dateFrom = fromEl ? fromEl.value : '';
            orderState.dateTo = toEl ? toEl.value : '';
            orderState.page = 1;
            loadOrders(true);
        };

        function updateEditCreditPoints() {
            const total = parseInt(document.getElementById('edit-total').value, 10) || 0;
            const cp = document.getElementById('edit-credit-points');
            if (cp) cp.textContent = total.toLocaleString();
            const credit = document.getElementById('edit-credit');
            if (credit) {
                const originalPaid = orderState.editing && orderState.editing.status === 'paid';
                credit.disabled = !!originalPaid;
                if (originalPaid) credit.checked = false;
            }
        }
        function updateEditStatusBadge(status) {
            const meta = ORDER_STATUS_META[status] || ORDER_DEFAULT_META;
            const badge = document.getElementById('edit-status-badge');
            const badgeText = document.getElementById('edit-status-badge-text');
            if (badge) badge.className = 'inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-[11px] font-bold ' + meta.cls;
            if (badgeText) badgeText.textContent = meta.text;
        }

        window.editOrder = function (orderNo) {
            const o = orderState.index[orderNo];
            if (!o) return;
            orderState.editing = o;
            document.getElementById('edit-order-no').textContent = o.order_no;
            document.getElementById('edit-status').value = ORDER_STATUS_META[o.status] ? o.status : 'pending';
            document.getElementById('edit-amount').value = o.amount;
            document.getElementById('edit-bonus').value = o.bonus;
            document.getElementById('edit-total').value = o.total_points;
            document.getElementById('edit-trade-no').value = o.trade_no || '';
            document.getElementById('edit-rtn-msg').value = o.rtn_msg || '';
            document.getElementById('edit-user').textContent = o.username || '—';
            document.getElementById('edit-uid').textContent = '#' + Number(o.uid || 0);
            document.getElementById('edit-method').textContent = o.method_name || '—';
            document.getElementById('edit-created').textContent = orderFmtDT(o.created_at);
            document.getElementById('edit-paid-at').textContent = orderFmtDT(o.paid_at);
            updateEditStatusBadge(o.status);
            const credit = document.getElementById('edit-credit');
            if (credit) credit.checked = false;
            updateEditCreditPoints();
            showOrderEdit();
        };

        window.submitOrderEdit = function (e) {
            if (e) e.preventDefault();
            const o = orderState.editing;
            if (!o) return false;
            const btn = document.getElementById('edit-submit-btn');
            if (btn) { btn.disabled = true; btn.classList.add('opacity-60', 'cursor-not-allowed'); }

            const body = new URLSearchParams({
                action: 'update_order',
                form_token: GM_FORM_TOKEN,
                order_no: o.order_no,
                status: document.getElementById('edit-status').value,
                amount: document.getElementById('edit-amount').value,
                bonus: document.getElementById('edit-bonus').value,
                total_points: document.getElementById('edit-total').value,
                trade_no: document.getElementById('edit-trade-no').value,
                rtn_msg: document.getElementById('edit-rtn-msg').value,
                credit: document.getElementById('edit-credit').checked ? '1' : '0'
            });

            fetch('gm_orders_api.php', { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (data && data.ok) {
                        showOrderList();
                        const activeStatus = orderState.status;
                        document.querySelectorAll('.order-filter-btn').forEach(btn => {
                            btn.classList.toggle('active', btn.getAttribute('data-status') === activeStatus);
                        });
                        loadOrders(true);
                        showOrderToast(data.message || '訂單已更新。', true);
                    } else {
                        showOrderToast((data && data.message) || '更新失敗，請稍後再試。', false);
                    }
                })
                .catch(() => showOrderToast('網路連線異常，請稍後再試。', false))
                .finally(() => {
                    if (btn) { btn.disabled = false; btn.classList.remove('opacity-60', 'cursor-not-allowed'); }
                });
            return false;
        };

        document.querySelectorAll('.order-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => setOrderFilter(btn.getAttribute('data-status') || 'all'));
        });
        document.querySelectorAll('.order-period-btn').forEach(btn => {
            btn.addEventListener('click', () => setOrderPeriod(btn.getAttribute('data-period') || 'all'));
        });
        if (orderListEl) {
            orderListEl.addEventListener('change', (e) => {
                const allBox = e.target.closest('#order-select-all');
                if (allBox) {
                    orderListEl.querySelectorAll('.order-row-check').forEach(cb => {
                        const no = cb.getAttribute('data-order');
                        if (allBox.checked) { orderState.selected.add(no); } else { orderState.selected.delete(no); }
                    });
                    syncOrderSelectionUI();
                    return;
                }
                const rowBox = e.target.closest('.order-row-check');
                if (rowBox) {
                    const no = rowBox.getAttribute('data-order');
                    if (rowBox.checked) { orderState.selected.add(no); } else { orderState.selected.delete(no); }
                    syncOrderSelectionUI();
                }
            });
        }
        if (orderSearch) {
            orderSearch.addEventListener('input', () => {
                clearTimeout(orderDebounce);
                orderDebounce = setTimeout(() => {
                    orderState.q = orderSearch.value.trim();
                    orderState.page = 1;
                    loadOrders(false);
                }, 350);
            });
        }
        const editStatusSelect = document.getElementById('edit-status');
        if (editStatusSelect) {
            editStatusSelect.addEventListener('change', function () { updateEditStatusBadge(this.value); });
        }
        const editTotalInput = document.getElementById('edit-total');
        if (editTotalInput) {
            editTotalInput.addEventListener('input', updateEditCreditPoints);
        }
        if (orderModal) {
            orderModal.addEventListener('click', (e) => { if (e.target === orderModal) window.closeOrderModal(); });
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && orderModal.classList.contains('opacity-100')) window.closeOrderModal();
            });
        }

        /* ================= 登入管理 子視窗 ================= */
        (function () {
            const loginModal = document.getElementById('login-modal');
            const loginCard = document.getElementById('login-modal-card');
            const loginListEl = document.getElementById('login-list');
            const loginPrev = document.getElementById('login-prev');
            const loginNext = document.getElementById('login-next');
            const loginPagerInfo = document.getElementById('login-pager-info');
            const loginSearch = document.getElementById('login-search');
            const loginRange = document.getElementById('login-range');
            if (!loginModal) return;

            const LOGIN_STATUS_META = {
                success: { text: '登入成功', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
                failed:  { text: '登入失敗', cls: 'bg-rose-50 text-rose-700 border-rose-200', dot: 'bg-rose-500' },
                blocked: { text: '已鎖定',   cls: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' }
            };
            const loginState = { page: 1, pages: 1, status: 'all', range: 'today', q: '', loaded: false };
            let loginDebounce = null;

            function loginEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
            function loginFmtDT(s) { return s ? String(s).replace('T', ' ').slice(0, 19) : '—'; }
            function loginShortUA(ua) {
                if (!ua) return '—';
                let label = '未知裝置';
                if (/Edg\//.test(ua)) label = 'Edge';
                else if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) label = 'Chrome';
                else if (/Firefox\//.test(ua)) label = 'Firefox';
                else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) label = 'Safari';
                else if (/MSIE|Trident/.test(ua)) label = 'IE';
                else if (/curl|python|bot|spider|wget/i.test(ua)) label = '自動化程式';
                let os = '';
                if (/Windows/.test(ua)) os = 'Windows';
                else if (/Android/.test(ua)) os = 'Android';
                else if (/iPhone|iPad|iOS/.test(ua)) os = 'iOS';
                else if (/Mac OS X/.test(ua)) os = 'macOS';
                else if (/Linux/.test(ua)) os = 'Linux';
                return os ? (label + ' · ' + os) : label;
            }

            window.openLoginModal = function () {
                loginModal.classList.remove('opacity-0', 'pointer-events-none');
                loginModal.classList.add('opacity-100');
                if (loginCard) { loginCard.classList.remove('scale-95'); loginCard.classList.add('scale-100'); }
                document.body.style.overflow = 'hidden';
                window.loadLoginLogs(!loginState.loaded);
            };
            window.closeLoginModal = function () {
                loginModal.classList.add('opacity-0', 'pointer-events-none');
                loginModal.classList.remove('opacity-100');
                if (loginCard) { loginCard.classList.remove('scale-100'); loginCard.classList.add('scale-95'); }
                document.body.style.overflow = '';
            };

            document.querySelectorAll('.login-filter-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    loginState.status = this.getAttribute('data-status') || 'all';
                    loginState.page = 1;
                    document.querySelectorAll('.login-filter-btn').forEach(function (b) { b.classList.toggle('active', b === btn); });
                    window.loadLoginLogs(true);
                });
            });
            if (loginRange) {
                loginRange.addEventListener('change', function () { loginState.range = this.value; loginState.page = 1; window.loadLoginLogs(true); });
            }
            if (loginSearch) {
                loginSearch.addEventListener('input', function () {
                    clearTimeout(loginDebounce);
                    loginDebounce = setTimeout(function () { loginState.q = loginSearch.value.trim(); loginState.page = 1; window.loadLoginLogs(true); }, 350);
                });
            }

            window.changeLoginPage = function (delta) {
                const target = loginState.page + delta;
                if (target < 1 || target > loginState.pages) return;
                loginState.page = target;
                window.loadLoginLogs(true);
            };

            window.loadLoginLogs = function (showLoading) {
                if (showLoading && loginListEl) {
                    loginListEl.innerHTML = '<div class="py-14 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>載入中…</div>';
                }
                const params = new URLSearchParams({ status: loginState.status, range: loginState.range, q: loginState.q, page: loginState.page, limit: 20 });
                fetch('gm_login_logs_api.php?' + params.toString(), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(function (data) {
                        if (!data || !data.ok) {
                            if (loginListEl) loginListEl.innerHTML = '<div class="py-14 text-center text-rose-500 text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>' + loginEsc((data && data.message) || '載入失敗') + '</div>';
                            return;
                        }
                        loginState.loaded = true;
                        loginState.pages = data.pages || 1;
                        loginState.page = data.page || 1;
                        renderLoginStats(data.stats);
                        renderLoginRows(data.logs);
                        if (loginPagerInfo) loginPagerInfo.textContent = data.total > 0 ? ('共 ' + Number(data.total).toLocaleString() + ' 筆 · 第 ' + data.page + ' / ' + (data.pages || 1) + ' 頁') : '共 0 筆';
                        if (loginPrev) loginPrev.disabled = (data.page <= 1);
                        if (loginNext) loginNext.disabled = (data.page >= (data.pages || 1));
                    })
                    .catch(function () {
                        if (loginListEl) loginListEl.innerHTML = '<div class="py-14 text-center text-rose-500 text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>網路連線失敗</div>';
                    });
            };

            function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
            function renderLoginStats(s) {
                if (!s) return;
                setText('login-stat-today', Number(s.today_total || 0).toLocaleString());
                setText('login-stat-ips', Number(s.unique_ips_today || 0).toLocaleString());
                setText('login-stat-success', Number(s.today_success || 0).toLocaleString());
                setText('login-stat-week', Number(s.week_success || 0).toLocaleString());
                setText('login-stat-failed', Number(s.today_failed || 0).toLocaleString());
                setText('login-stat-weekfail', Number(s.week_failed || 0).toLocaleString());
                setText('login-stat-blocked', Number(s.active_blocked_ips || 0).toLocaleString());
                const lf = s.last_fail;
                setText('login-lastfail', lf ? ('最近失敗：' + (lf.username || '未知') + ' @ ' + (lf.ip || '—')) : '尚無失敗紀錄');
            }

            function renderLoginRows(logs) {
                if (!loginListEl) return;
                if (!logs || logs.length === 0) {
                    loginListEl.innerHTML = '<div class="py-14 text-center text-slate-400 text-sm"><i class="fa-regular fa-folder-open text-2xl mb-3 block"></i>沒有符合條件的登入紀錄</div>';
                    return;
                }
                let html = '<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">'
                    + '<table class="w-full text-left text-xs"><thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold sticky top-0 z-10"><tr>'
                    + '<th class="py-2.5 px-3 whitespace-nowrap">時間</th>'
                    + '<th class="py-2.5 px-3">帳號</th>'
                    + '<th class="py-2.5 px-3">結果</th>'
                    + '<th class="py-2.5 px-3">來源 IP</th>'
                    + '<th class="py-2.5 px-3">裝置 / 來源</th>'
                    + '</tr></thead><tbody class="divide-y divide-slate-100 font-sans">';
                logs.forEach(function (l) {
                    const meta = LOGIN_STATUS_META[l.status] || { text: l.status, cls: 'bg-slate-100 text-slate-600 border-slate-300', dot: 'bg-slate-400' };
                    const fwd = (l.forwarded && l.forwarded !== l.ip) ? '<div class="text-[10px] text-slate-400 font-mono truncate max-w-[180px]" title="' + loginEsc(l.forwarded) + '">via ' + loginEsc(l.forwarded) + '</div>' : '';
                    html += '<tr class="hover:bg-slate-50/80">'
                        + '<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">' + loginEsc(loginFmtDT(l.created_at)) + '</td>'
                        + '<td class="py-2.5 px-3"><span class="font-semibold text-slate-800">' + loginEsc(l.username || '—') + '</span>' + (l.user_id > 0 ? '<span class="text-[10px] text-slate-400 font-mono ml-1">#' + l.user_id + '</span>' : '') + '</td>'
                        + '<td class="py-2.5 px-3"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium ' + meta.cls + '"><span class="w-1.5 h-1.5 rounded-full ' + meta.dot + '"></span>' + meta.text + '</span>'
                        + (l.reason ? '<div class="text-[10px] text-slate-400 mt-0.5">' + loginEsc(l.reason) + '</div>' : '') + '</td>'
                        + '<td class="py-2.5 px-3 font-mono text-[11px] text-slate-600">' + loginEsc(l.ip || '—') + fwd + '</td>'
                        + '<td class="py-2.5 px-3 text-slate-500"><span class="text-[11px]">' + loginEsc(loginShortUA(l.ua)) + '</span>'
                        + '<div class="text-[10px] text-slate-400 font-mono truncate max-w-[220px]" title="' + loginEsc(l.ua) + '">' + loginEsc(l.ua) + '</div></td>'
                        + '</tr>';
                });
                html += '</tbody></table></div>';
                loginListEl.innerHTML = html;
            }

            loginModal.addEventListener('click', function (e) { if (e.target === loginModal) window.closeLoginModal(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && loginModal.classList.contains('opacity-100')) window.closeLoginModal();
            });
        })();
    </script>
</body>
</html>
