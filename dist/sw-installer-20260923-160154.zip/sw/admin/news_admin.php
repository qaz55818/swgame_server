<?php
/**
 * =============================================================
 *  踏雪笑傲 · 江湖邸報（官方公告）管理後台
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *  資料庫：獨立資料庫 swo_news（見 news_schema.sql）
 *  功能：儀表板、發表、編輯、檢視、刪除、上下架、置頂、
 *        分類管理、系統設定、飛鴿訂閱名單
 * =============================================================
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../news_config.php';

if (!isset($_SESSION['gm_username'])) {
    header('Location: gmlogin.php');
    exit();
}
$currentGm = (string)$_SESSION['gm_username'];

$db = news_db();
$SET = news_settings_all($db);

if (empty($_SESSION['news_admin_token'])) {
    $_SESSION['news_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['news_admin_token'];

/* ------------------------------------------------------------------
 * 共用小工具
 * ------------------------------------------------------------------ */
function na_log(mysqli $db, int $articleId, string $action, string $operator, string $oldStatus, string $newStatus, string $note = ''): void
{
    $stmt = $db->prepare(
        "INSERT INTO `news_status_log` (`article_id`,`action`,`operator_type`,`operator_name`,`old_status`,`new_status`,`note`)
         VALUES (?,?, 'gm', ?,?,?,?)"
    );
    if (!$stmt) { return; }
    $stmt->bind_param('isssss', $articleId, $action, $operator, $oldStatus, $newStatus, $note);
    $stmt->execute();
    $stmt->close();
}

function na_unique_slug(mysqli $db, string $slug, int $excludeId = 0): string
{
    $slug = news_slugify($slug);
    $base = $slug;
    $i = 2;
    while (true) {
        $stmt = $db->prepare("SELECT `id` FROM `news_articles` WHERE `slug` = ? AND `id` <> ? LIMIT 1");
        $stmt->bind_param('si', $slug, $excludeId);
        $stmt->execute();
        $exists = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$exists) { return $slug; }
        $slug = $base . '-' . $i;
        $i++;
    }
}

function na_flash(string $type, string $msg): void
{
    $_SESSION['news_flash'] = ['type' => $type, 'msg' => $msg];
}

$notice = '';
$noticeType = 'success';
if (!empty($_SESSION['news_flash'])) {
    $notice = (string)$_SESSION['news_flash']['msg'];
    $noticeType = (string)$_SESSION['news_flash']['type'];
    unset($_SESSION['news_flash']);
}

/* ------------------------------------------------------------------
 * POST 動作處理（PRG：處理完重新導向）
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['form_token'] ?? '') !== $formToken) {
        na_flash('danger', '工作階段已過期，請重新操作。');
        header('Location: news_admin.php');
        exit();
    }
    $action = (string)($_POST['action'] ?? '');
    $redirect = 'news_admin.php?section=articles';

    if ($action === 'save_article') {
        $id           = (int)($_POST['id'] ?? 0);
        $catCode      = trim((string)($_POST['category_code'] ?? ''));
        $catId        = 0;
        if ($catCode !== '') {
            $stmt = $db->prepare("SELECT `id` FROM `news_categories` WHERE `code` = ? LIMIT 1");
            $stmt->bind_param('s', $catCode);
            $stmt->execute();
            $catRow = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            $catId = $catRow ? (int)$catRow['id'] : 0;
        }
        $title        = trim((string)($_POST['title'] ?? ''));
        $summary      = trim((string)($_POST['summary'] ?? ''));
        $content      = (string)($_POST['content'] ?? '');
        $coverImage   = trim((string)($_POST['cover_image'] ?? ''));
        $coverCaption = trim((string)($_POST['cover_caption'] ?? ''));
        $author       = trim((string)($_POST['author'] ?? '官方團隊'));
        $priority     = in_array($_POST['priority'] ?? '', ['low','normal','high','urgent'], true) ? $_POST['priority'] : 'normal';
        $isSticky     = !empty($_POST['is_sticky']) ? 1 : 0;
        $isFeatured   = !empty($_POST['is_featured']) ? 1 : 0;
        $status       = in_array($_POST['status'] ?? '', ['draft','published','scheduled','archived'], true) ? $_POST['status'] : 'draft';
        $publishedAt  = trim((string)($_POST['published_at'] ?? ''));
        $allowComments = !empty($_POST['allow_comments']) ? 1 : 0;
        $seoTitle     = trim((string)($_POST['seo_title'] ?? ''));
        $seoKeywords  = trim((string)($_POST['seo_keywords'] ?? ''));
        $seoDesc      = trim((string)($_POST['seo_description'] ?? ''));
        $slugInput    = trim((string)($_POST['slug'] ?? ''));

        if ($title === '') {
            na_flash('danger', '公告標題不得為空。');
            header('Location: news_admin.php?section=editor' . ($id ? '&id=' . $id : ''));
            exit();
        }
        if ($catCode === '') { $catCode = 'update'; }

        $slug = na_unique_slug($db, $slugInput !== '' ? $slugInput : $title, $id);

        if ($publishedAt === '' && $status === 'published') {
            $publishedAt = date('Y-m-d H:i:s');
        }
        $publishedAtVal = ($publishedAt !== '') ? date('Y-m-d H:i:s', strtotime($publishedAt)) : null;

        if ($id > 0) {
            $stmt = $db->prepare("SELECT `status` FROM `news_articles` WHERE `id` = ? LIMIT 1");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $old = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $stmt = $db->prepare(
                "UPDATE `news_articles` SET
                    `category_id`=?, `category_code`=?, `title`=?, `slug`=?, `summary`=?, `content`=?,
                    `cover_image`=?, `cover_caption`=?, `author`=?, `priority`=?, `is_sticky`=?, `is_featured`=?,
                    `status`=?, `published_at`=?, `allow_comments`=?, `seo_title`=?, `seo_keywords`=?, `seo_description`=?, `updated_by`=?
                 WHERE `id`=?"
            );
            $stmt->bind_param(
                'isssssssssiississssi',
                $catId, $catCode, $title, $slug, $summary, $content,
                $coverImage, $coverCaption, $author, $priority, $isSticky, $isFeatured,
                $status, $publishedAtVal, $allowComments, $seoTitle, $seoKeywords, $seoDesc, $currentGm,
                $id
            );
            $ok = $stmt->execute();
            $stmt->close();
            if ($ok) {
                na_log($db, $id, 'update', $currentGm, (string)($old['status'] ?? ''), $status, '編輯公告');
                na_flash('success', '公告「' . $title . '」已更新。');
            } else {
                na_flash('danger', '更新失敗：' . mysqli_error($db));
            }
        } else {
            $stmt = $db->prepare(
                "INSERT INTO `news_articles`
                    (`category_id`,`category_code`,`title`,`slug`,`summary`,`content`,`cover_image`,`cover_caption`,
                     `author`,`priority`,`is_sticky`,`is_featured`,`status`,`published_at`,`allow_comments`,
                     `seo_title`,`seo_keywords`,`seo_description`,`created_by`,`updated_by`)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->bind_param(
                'isssssssssiississsss',
                $catId, $catCode, $title, $slug, $summary, $content, $coverImage, $coverCaption,
                $author, $priority, $isSticky, $isFeatured, $status, $publishedAtVal, $allowComments,
                $seoTitle, $seoKeywords, $seoDesc, $currentGm, $currentGm
            );
            $ok = $stmt->execute();
            $newId = (int)$db->insert_id;
            $stmt->close();
            if ($ok) {
                na_log($db, $newId, 'create', $currentGm, '', $status, '發布新公告');
                na_flash('success', '公告「' . $title . '」已建立。');
                $redirect = 'news_admin.php?section=view&view=' . $newId;
            } else {
                na_flash('danger', '建立失敗：' . mysqli_error($db));
            }
        }
    } elseif ($action === 'delete_article') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $db->query("DELETE FROM `news_articles` WHERE `id` = " . $id);
            $db->query("DELETE FROM `news_attachments` WHERE `article_id` = " . $id);
            na_log($db, $id, 'delete', $currentGm, '', '', '刪除公告');
            na_flash('success', '公告 #' . $id . ' 已刪除。');
        }
    } elseif ($action === 'toggle_publish') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT `status`,`published_at` FROM `news_articles` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $newStatus = ($row['status'] === 'published') ? 'draft' : 'published';
            if ($newStatus === 'published' && empty($row['published_at'])) {
                $db->query("UPDATE `news_articles` SET `status`='published', `published_at`=NOW() WHERE `id`=" . $id);
            } else {
                $upd = ($newStatus === 'published') ? 'published' : 'draft';
                $db->query("UPDATE `news_articles` SET `status`='" . $upd . "' WHERE `id`=" . $id);
            }
            na_log($db, $id, $newStatus === 'published' ? 'publish' : 'unpublish', $currentGm, (string)$row['status'], $newStatus, '上下架切換');
            na_flash('success', '公告狀態已切換為「' . news_status_meta($newStatus)['label'] . '」。');
        }
    } elseif ($action === 'toggle_sticky') {
        $id = (int)($_POST['id'] ?? 0);
        $db->query("UPDATE `news_articles` SET `is_sticky` = IF(`is_sticky`=1,0,1) WHERE `id` = " . $id);
        na_log($db, $id, 'sticky', $currentGm, '', '', '置頂切換');
        na_flash('success', '置頂狀態已切換。');
    } elseif ($action === 'duplicate_article') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $db->prepare("SELECT * FROM `news_articles` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $a = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($a) {
            $newTitle = $a['title'] . '（複本）';
            $slug = na_unique_slug($db, $a['slug'] . '-copy');
            $publish = date('Y-m-d H:i:s');
            $stmt = $db->prepare(
                "INSERT INTO `news_articles`
                    (`category_id`,`category_code`,`title`,`slug`,`summary`,`content`,`cover_image`,`cover_caption`,
                     `author`,`priority`,`is_sticky`,`is_featured`,`status`,`published_at`,`allow_comments`,
                     `seo_title`,`seo_keywords`,`seo_description`,`created_by`,`updated_by`)
                 SELECT `category_id`,`category_code`,?,?,`summary`,`content`,`cover_image`,`cover_caption`,
                     `author`,`priority`,0,0,'draft',?,`allow_comments`,
                     `seo_title`,`seo_keywords`,`seo_description`,?,?
                   FROM `news_articles` WHERE `id` = ?"
            );
            $stmt->bind_param('sssssi', $newTitle, $slug, $publish, $currentGm, $currentGm, $id);
            $stmt->execute();
            $newId = (int)$db->insert_id;
            $stmt->close();
            na_log($db, $newId, 'create', $currentGm, '', 'draft', '複製自 #' . $id);
            na_flash('success', '已複製公告為草稿 #' . $newId . '。');
        }
    } elseif ($action === 'save_settings') {
        $keys = ['site_version','site_codename','maintenance_next','server_status','hero_title','hero_subtitle','subscribe_blurb','list_page_size'];
        foreach ($keys as $k) {
            if (array_key_exists('set_' . $k, $_POST)) {
                news_setting_put($db, $k, trim((string)$_POST['set_' . $k]));
            }
        }
        // 顯示與否（核取方塊：未勾選時不會送出，需明確寫入 0）
        $toggleKeys = ['show_version', 'show_maintenance', 'show_server_status'];
        foreach ($toggleKeys as $k) {
            news_setting_put($db, $k, isset($_POST['set_' . $k]) ? '1' : '0');
        }
        na_flash('success', '公告系統設定已儲存並立即生效。');
        $redirect = 'news_admin.php?section=settings';
    } elseif ($action === 'save_category') {
        $cid    = (int)($_POST['category_id'] ?? 0);
        $code   = trim((string)($_POST['code'] ?? ''));
        $name   = trim((string)($_POST['name'] ?? ''));
        $nameEn = trim((string)($_POST['name_en'] ?? ''));
        $icon   = trim((string)($_POST['icon'] ?? 'campaign'));
        $badge  = trim((string)($_POST['badge_class'] ?? ''));
        $accent = trim((string)($_POST['accent'] ?? 'rose'));
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($code === '' || $name === '') {
            na_flash('danger', '分類代碼與名稱不得為空。');
        } elseif ($cid > 0) {
            $stmt = $db->prepare("UPDATE `news_categories` SET `code`=?,`name`=?,`name_en`=?,`icon`=?,`badge_class`=?,`accent`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('ssssssii', $code, $name, $nameEn, $icon, $badge, $accent, $sort, $cid);
            $stmt->execute();
            $stmt->close();
            na_flash('success', '分類已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `news_categories` (`code`,`name`,`name_en`,`icon`,`badge_class`,`accent`,`sort_order`) VALUES (?,?,?,?,?,?,?)");
            $stmt->bind_param('ssssssi', $code, $name, $nameEn, $icon, $badge, $accent, $sort);
            $stmt->execute();
            $stmt->close();
            na_flash('success', '分類已新增。');
        }
        $redirect = 'news_admin.php?section=categories';
    } elseif ($action === 'toggle_category') {
        $cid = (int)($_POST['category_id'] ?? 0);
        $db->query("UPDATE `news_categories` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $cid);
        na_flash('success', '分類啟用狀態已切換。');
        $redirect = 'news_admin.php?section=categories';
    } elseif ($action === 'delete_category') {
        $cid = (int)($_POST['category_id'] ?? 0);
        $cnt = 0;
        $res = $db->query("SELECT COUNT(*) AS c FROM `news_articles` WHERE `category_id` = " . $cid);
        if ($res) { $cnt = (int)$res->fetch_assoc()['c']; }
        if ($cnt > 0) {
            na_flash('danger', '此分類仍有 ' . $cnt . ' 篇公告，請先調整公告分類後再刪除。');
        } else {
            $db->query("DELETE FROM `news_categories` WHERE `id` = " . $cid);
            na_flash('success', '分類已刪除。');
        }
        $redirect = 'news_admin.php?section=categories';
    } elseif ($action === 'subscriber_toggle') {
        $sid = (int)($_POST['subscriber_id'] ?? 0);
        $db->query("UPDATE `news_subscribers` SET `is_active` = IF(`is_active`=1,0,1), `unsubscribed_at` = IF(`is_active`=1, NOW(), NULL) WHERE `id` = " . $sid);
        na_flash('success', '訂閱狀態已更新。');
        $redirect = 'news_admin.php?section=subscribers';
    } elseif ($action === 'subscriber_delete') {
        $sid = (int)($_POST['subscriber_id'] ?? 0);
        $db->query("DELETE FROM `news_subscribers` WHERE `id` = " . $sid);
        na_flash('success', '訂閱名單已移除。');
        $redirect = 'news_admin.php?section=subscribers';
    }

    header('Location: ' . $redirect);
    exit();
}
/* ------------------------------------------------------------------
 * 讀取資料
 * ------------------------------------------------------------------ */
$section = (string)($_GET['section'] ?? 'dashboard');
$allowedSections = ['dashboard','articles','editor','view','categories','settings','subscribers'];
if (!in_array($section, $allowedSections, true)) { $section = 'dashboard'; }

$categories = news_categories($db, false);
$catMap = news_category_map($db);

/* 儀表板統計 */
$stats = ['total' => 0, 'published' => 0, 'draft' => 0, 'scheduled' => 0, 'archived' => 0, 'sticky' => 0, 'views' => 0, 'subs' => 0];
$res = mysqli_query(
    $db,
    "SELECT COUNT(*) AS total,
            SUM(`status`='published') AS published,
            SUM(`status`='draft') AS draft,
            SUM(`status`='scheduled') AS scheduled,
            SUM(`status`='archived') AS archived,
            SUM(`is_sticky`=1) AS sticky,
            IFNULL(SUM(`view_count`),0) AS views
       FROM `news_articles`"
);
if ($res && ($row = $res->fetch_assoc())) {
    foreach ($stats as $k => $v) {
        if (isset($row[$k])) { $stats[$k] = (int)$row[$k]; }
    }
}
$res = mysqli_query($db, "SELECT COUNT(*) AS c FROM `news_subscribers` WHERE `is_active` = 1");
if ($res) { $stats['subs'] = (int)$res->fetch_assoc()['c']; }

$recentArticles = [];
$res = mysqli_query(
    $db,
    "SELECT a.`id`,a.`title`,a.`category_code`,a.`status`,a.`is_sticky`,a.`view_count`,a.`published_at`,a.`updated_at`,c.`name` AS category_name
       FROM `news_articles` a LEFT JOIN `news_categories` c ON c.`id`=a.`category_id`
      ORDER BY a.`updated_at` DESC LIMIT 6"
);
if ($res) { $recentArticles = $res->fetch_all(MYSQLI_ASSOC); }

$recentSubs = [];
$res = mysqli_query($db, "SELECT * FROM `news_subscribers` ORDER BY `created_at` DESC LIMIT 6");
if ($res) { $recentSubs = $res->fetch_all(MYSQLI_ASSOC); }

$recentLogs = [];
$res = mysqli_query(
    $db,
    "SELECT l.*, a.`title` FROM `news_status_log` l LEFT JOIN `news_articles` a ON a.`id`=l.`article_id` ORDER BY l.`id` DESC LIMIT 8"
);
if ($res) { $recentLogs = $res->fetch_all(MYSQLI_ASSOC); }

/* 列表篩選 */
$listStatus = trim((string)($_GET['status'] ?? ''));
$listCat    = trim((string)($_GET['cat'] ?? ''));
$listQ      = trim((string)($_GET['q'] ?? ''));
$listPage   = max(1, (int)($_GET['page'] ?? 1));
$listSize   = 12;
$articles = [];
$listTotal = 0;
$listPages = 1;
if ($section === 'articles') {
    $w = ['1=1'];
    $p = [];
    $t = '';
    if ($listStatus !== '' && in_array($listStatus, ['draft','published','scheduled','archived'], true)) { $w[] = 'a.`status` = ?'; $p[] = $listStatus; $t .= 's'; }
    if ($listCat !== '' && isset($catMap[$listCat])) { $w[] = 'a.`category_code` = ?'; $p[] = $listCat; $t .= 's'; }
    if ($listQ !== '') { $w[] = '(a.`title` LIKE ? OR a.`summary` LIKE ?)'; $like = '%' . $listQ . '%'; $p[] = $like; $p[] = $like; $t .= 'ss'; }
    $wSql = implode(' AND ', $w);
    $stmt = $db->prepare("SELECT COUNT(*) AS c FROM `news_articles` a WHERE $wSql");
    if ($p) { $stmt->bind_param($t, ...$p); }
    $stmt->execute();
    $listTotal = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
    $listPages = max(1, (int)ceil($listTotal / $listSize));
    if ($listPage > $listPages) { $listPage = $listPages; }
    $off = ($listPage - 1) * $listSize;
    $stmt = $db->prepare(
        "SELECT a.*, c.`name` AS category_name, c.`badge_class`
           FROM `news_articles` a LEFT JOIN `news_categories` c ON c.`id`=a.`category_id`
          WHERE $wSql ORDER BY a.`is_sticky` DESC, a.`updated_at` DESC LIMIT ? OFFSET ?"
    );
    $bt = $t . 'ii';
    $bp = array_merge($p, [$listSize, $off]);
    $stmt->bind_param($bt, ...$bp);
    $stmt->execute();
    $articles = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

/* 編輯 / 檢視 */
$editArticle = null;
if ($section === 'editor') {
    $eid = (int)($_GET['id'] ?? 0);
    if ($eid > 0) {
        $stmt = $db->prepare("SELECT * FROM `news_articles` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $eid);
        $stmt->execute();
        $editArticle = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
}
$viewArticle = null;
$viewAttachments = [];
if ($section === 'view') {
    $vid = (int)($_GET['view'] ?? 0);
    if ($vid > 0) {
        $stmt = $db->prepare(
            "SELECT a.*, c.`name` AS category_name, c.`badge_class`, c.`icon` FROM `news_articles` a LEFT JOIN `news_categories` c ON c.`id`=a.`category_id` WHERE a.`id` = ? LIMIT 1"
        );
        $stmt->bind_param('i', $vid);
        $stmt->execute();
        $viewArticle = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($viewArticle) {
            $stmt = $db->prepare("SELECT * FROM `news_attachments` WHERE `article_id` = ? ORDER BY `sort_order`,`id`");
            $stmt->bind_param('i', $vid);
            $stmt->execute();
            $viewAttachments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }
    }
}

/* 訂閱名單 */
$subs = [];
$subSearch = trim((string)($_GET['subq'] ?? ''));
if ($section === 'subscribers') {
    if ($subSearch !== '') {
        $stmt = $db->prepare("SELECT * FROM `news_subscribers` WHERE `email` LIKE ? ORDER BY `created_at` DESC LIMIT 200");
        $like = '%' . $subSearch . '%';
        $stmt->bind_param('s', $like);
        $stmt->execute();
        $subs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        $res = mysqli_query($db, "SELECT * FROM `news_subscribers` ORDER BY `created_at` DESC LIMIT 200");
        if ($res) { $subs = $res->fetch_all(MYSQLI_ASSOC); }
    }
}

/* 導覽選單 */
$navItems = [
    ['key' => 'dashboard',   'label' => '總覽儀表板', 'en' => 'Dashboard',   'icon' => 'fa-gauge-high',      'grad' => 'from-slate-600 to-slate-800'],
    ['key' => 'editor',      'label' => '發表新公告', 'en' => 'Publish',     'icon' => 'fa-feather-pointed', 'grad' => 'from-rose-600 to-rose-800'],
    ['key' => 'articles',    'label' => '公告管理',   'en' => 'Articles',    'icon' => 'fa-scroll',          'grad' => 'from-sky-600 to-sky-700'],
    ['key' => 'categories',  'label' => '分類管理',   'en' => 'Categories',  'icon' => 'fa-tags',            'grad' => 'from-amber-600 to-amber-800'],
    ['key' => 'subscribers', 'label' => '飛鴿訂閱',   'en' => 'Subscribers', 'icon' => 'fa-envelope-open-text', 'grad' => 'from-violet-600 to-violet-800'],
    ['key' => 'settings',    'label' => '系統設定',   'en' => 'Settings',    'icon' => 'fa-sliders',         'grad' => 'from-emerald-600 to-emerald-800'],
];

$activeNav = $section;
if ($section === 'view') { $activeNav = 'articles'; }
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · 江湖邸報管理 · GM 控制台</title>
    <link rel="stylesheet" href="assets/tailwind.css">
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="stylesheet" href="assets/news-admin-tailwind.css?v=2">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root { --vermilion: #be123c; --ice-blue: #0284c7; --ink-black: #0b0f19; }
        body {
            background-color: #080c14; color: #1e293b; font-family: 'Noto Serif TC', serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% 0%, rgba(190, 18, 60, 0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 90%, rgba(2, 132, 199, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 20% 60%, rgba(15, 23, 42, 0.8) 0%, transparent 70%);
        }
        #snow-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 1; transform: translateZ(0); will-change: transform; }
        .glass-panel {
            background: rgba(255, 255, 255, 0.94); border: 1px solid rgba(226, 232, 240, 0.85);
            backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.7) inset;
            position: relative; transform: translateZ(0);
        }
        .corner-accent::before { content: ''; position: absolute; top: 0; left: 0; width: 10px; height: 10px; border-top: 2px solid var(--vermilion); border-left: 2px solid var(--vermilion); pointer-events: none; }
        .corner-accent::after { content: ''; position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; border-bottom: 2px solid var(--ice-blue); border-right: 2px solid var(--ice-blue); pointer-events: none; }
        .ink-divider { height: 1px; background: linear-gradient(90deg, transparent 0%, rgba(190, 18, 60, 0.3) 25%, rgba(2, 132, 199, 0.3) 75%, transparent 100%); }
        .btn-vermilion { background: linear-gradient(135deg, #be123c 0%, #9f1239 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(190,18,60,.25); }
        .btn-vermilion:hover { background: linear-gradient(135deg, #e11d48 0%, #be123c 100%); box-shadow: 0 6px 20px rgba(190,18,60,.38); transform: translateY(-1px); }
        .btn-ice { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(2,132,199,.25); }
        .btn-ice:hover { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); box-shadow: 0 6px 20px rgba(2,132,199,.38); transform: translateY(-1px); }
        .na-input, .na-select, .na-textarea {
            width: 100%; padding: .55rem .75rem; font-size: .8rem; color: #0f172a;
            background: #fff; border: 1px solid #cbd5e1; border-radius: .5rem; transition: all .2s ease; font-family: 'Noto Serif TC', serif;
        }
        .na-input:focus, .na-select:focus, .na-textarea:focus { outline: none; border-color: #0284c7; box-shadow: 0 0 0 3px rgba(2,132,199,.15); }
        .na-label { display: block; font-size: .72rem; font-weight: 700; color: #334155; letter-spacing: .06em; margin-bottom: .35rem; }
        .na-help { font-size: .68rem; color: #94a3b8; margin-top: .25rem; }
        .na-nav-btn { position: relative; overflow: hidden; border-radius: .75rem; padding: .7rem .95rem; color: #fff; font-size: .78rem; font-weight: 700; display: flex; align-items: center; gap: .65rem; box-shadow: 0 8px 20px -6px rgba(0,0,0,.45); transition: all .22s ease; text-decoration: none; }
        .na-nav-btn:hover { transform: translateY(-2px); box-shadow: 0 12px 26px -8px rgba(0,0,0,.55); }
        .na-nav-btn.is-active { outline: 2px solid rgba(255,255,255,.85); outline-offset: -2px; }
        .na-nav-btn .na-nav-icon { width: 2rem; height: 2rem; border-radius: .5rem; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.22); flex: none; }
        .na-badge { display: inline-flex; align-items: center; gap: .25rem; padding: .1rem .45rem; border-radius: .375rem; border: 1px solid; font-size: .65rem; font-weight: 700; font-family: 'Manrope', sans-serif; }
        .na-strip { width: 4px; border-radius: 2px; align-self: stretch; flex: none; }
        table.na-table { width: 100%; border-collapse: collapse; }
        table.na-table th { text-align: left; font-size: .68rem; letter-spacing: .08em; text-transform: uppercase; color: #64748b; padding: .6rem .7rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc; white-space: nowrap; }
        table.na-table td { padding: .65rem .7rem; font-size: .78rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        table.na-table tbody tr:hover { background: #f8fafc; }
        .news-content-preview h2, .news-content-preview h3 { font-weight: 700; color: #0f172a; margin: 1rem 0 .4rem; }
        .news-content-preview p { line-height: 1.9; margin: .5rem 0; color: #334155; }
        .news-content-preview ul { list-style: disc; padding-left: 1.3rem; margin: .5rem 0; color: #334155; }

        /* ===== 公告內文 富文本編輯器 ===== */
        .na-mode-switch { display: inline-flex; background: #e2e8f0; border-radius: .5rem; padding: .15rem; }
        .na-mode-btn { display: inline-flex; align-items: center; gap: .35rem; padding: .32rem .75rem; font-size: .72rem; font-weight: 700; color: #475569; border: 0; border-radius: .4rem; background: transparent; cursor: pointer; transition: all .15s ease; font-family: 'Noto Serif TC', serif; }
        .na-mode-btn:hover { color: #be123c; }
        .na-mode-btn.is-active { background: #fff; color: #be123c; box-shadow: 0 1px 4px rgba(15,23,42,.14); }
        .na-editor { border: 1px solid #cbd5e1; border-radius: .6rem; overflow: hidden; background: #fff; }
        .na-editor-toolbar { display: flex; flex-wrap: wrap; gap: .2rem; align-items: center; padding: .45rem .5rem; background: linear-gradient(180deg, #f8fafc 0%, #eef2f7 100%); border-bottom: 1px solid #e2e8f0; }
        .na-tb-btn { width: 1.95rem; height: 1.95rem; display: inline-flex; align-items: center; justify-content: center; border-radius: .4rem; border: 1px solid transparent; color: #334155; font-size: .8rem; cursor: pointer; background: transparent; transition: all .15s ease; }
        .na-tb-btn:hover { background: #fff; border-color: #cbd5e1; color: #be123c; box-shadow: 0 1px 3px rgba(15,23,42,.1); }
        .na-tb-btn.na-tb-danger:hover { color: #dc2626; border-color: #fca5a5; background: #fef2f2; }
        .na-tb-sep { width: 1px; height: 1.4rem; background: #e2e8f0; margin: 0 .18rem; }
        .na-tb-select { height: 1.95rem; font-size: .72rem; border: 1px solid #cbd5e1; border-radius: .4rem; padding: 0 .35rem; background: #fff; color: #334155; font-family: 'Noto Serif TC', serif; cursor: pointer; max-width: 7.5rem; }
        .na-tb-colorwrap { position: relative; width: 1.95rem; height: 1.95rem; display: inline-flex; align-items: center; justify-content: center; border-radius: .4rem; border: 1px solid transparent; cursor: pointer; color: #334155; }
        .na-tb-colorwrap:hover { background: #fff; border-color: #cbd5e1; color: #be123c; box-shadow: 0 1px 3px rgba(15,23,42,.1); }
        .na-tb-colorwrap .na-tb-coloricon { position: absolute; font-size: .72rem; bottom: .28rem; right: .22rem; pointer-events: none; }
        .na-tb-color { width: 1.95rem; height: 1.95rem; padding: 0; border: 0; background: transparent; cursor: pointer; opacity: .9; }
        .na-editor-canvas { min-height: 22rem; max-height: 48rem; overflow: auto; padding: 1rem 1.15rem; font-size: .9rem; line-height: 1.9; color: #1e293b; outline: none; font-family: 'Noto Serif TC', serif; }
        .na-editor-canvas:empty::before { content: attr(data-placeholder); color: #94a3b8; }
        .na-editor-canvas.is-dragover { background: #fef2f2; box-shadow: inset 0 0 0 2px #be123c; }
        .na-editor-canvas h2 { font-size: 1.45rem; font-weight: 800; color: #0f172a; margin: 1rem 0 .5rem; letter-spacing: .02em; }
        .na-editor-canvas h3 { font-size: 1.18rem; font-weight: 700; color: #991b1b; margin: .9rem 0 .4rem; letter-spacing: .02em; }
        .na-editor-canvas h4 { font-size: 1rem; font-weight: 700; color: #0f172a; margin: .8rem 0 .35rem; }
        .na-editor-canvas p { margin: .5rem 0; }
        .na-editor-canvas ul { list-style: disc; padding-left: 1.4rem; margin: .5rem 0; }
        .na-editor-canvas ol { list-style: decimal; padding-left: 1.4rem; margin: .5rem 0; }
        .na-editor-canvas blockquote { border-left: 3px solid #be123c; background: #fef2f2; padding: .55rem .85rem; margin: .6rem 0; color: #7f1d1d; }
        .na-editor-canvas pre { background: #0f172a; color: #e2e8f0; padding: .8rem .9rem; border-radius: .4rem; overflow: auto; font-family: monospace; font-size: .8rem; line-height: 1.6; }
        .na-editor-canvas code { background: #f1f5f9; border: 1px solid #e2e8f0; padding: .05rem .35rem; border-radius: .3rem; font-family: monospace; font-size: .82em; color: #be123c; }
        .na-editor-canvas img { max-width: 100%; height: auto; border-radius: .4rem; margin: .4rem 0; box-shadow: 0 2px 10px rgba(15,23,42,.12); }
        .na-editor-canvas a { color: #991b1b; text-decoration: underline; }
        .na-editor-canvas hr { border: 0; border-top: 1px dashed #cbd5e1; margin: 1rem 0; }
        .na-editor-canvas table { border-collapse: collapse; width: 100%; margin: .6rem 0; }
        .na-editor-canvas th, .na-editor-canvas td { border: 1px solid #cbd5e1; padding: .4rem .6rem; }
        .na-editor-canvas th { background: #f8fafc; font-weight: 700; }
        .na-editor-canvas video, .na-editor-canvas iframe { max-width: 100%; border-radius: .4rem; margin: .4rem 0; }
        .na-editor-canvas iframe { width: 100%; aspect-ratio: 16 / 9; height: auto; }

        /* ===== 插入內容子視窗 ===== */
        .na-modal-mask { position: fixed; inset: 0; background: rgba(8,12,20,.62); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); z-index: 90; display: flex; align-items: center; justify-content: center; padding: 1rem; }
        .na-modal-card { width: 100%; max-width: 33rem; background: #fff; border-radius: .8rem; border: 1px solid #e2e8f0; box-shadow: 0 24px 60px rgba(0,0,0,.42); overflow: hidden; animation: naPop .18s ease; }
        @keyframes naPop { from { transform: translateY(10px) scale(.98); opacity: .4; } to { transform: none; opacity: 1; } }
        .na-modal-head { display: flex; align-items: center; justify-content: space-between; padding: .75rem 1rem; background: linear-gradient(135deg, #be123c 0%, #9f1239 100%); color: #fff; font-weight: 700; font-size: .85rem; letter-spacing: .04em; }
        .na-modal-x { width: 1.7rem; height: 1.7rem; border-radius: .4rem; border: 0; background: rgba(255,255,255,.18); color: #fff; cursor: pointer; transition: background .15s ease; }
        .na-modal-x:hover { background: rgba(255,255,255,.32); }
        .na-modal-body { padding: 1rem; max-height: 62vh; overflow: auto; }
        .na-modal-foot { display: flex; justify-content: flex-end; gap: .5rem; padding: .7rem 1rem; border-top: 1px solid #e2e8f0; background: #f8fafc; }
        .na-modal-btn { padding: .5rem 1rem; font-size: .75rem; font-weight: 700; border-radius: .5rem; cursor: pointer; }
        .na-modal-btn:not(.btn-vermilion) { background: #fff; border: 1px solid #cbd5e1; color: #475569; }
        .na-modal-btn:not(.btn-vermilion):hover { background: #f1f5f9; }
        .na-modal-body .na-label:not(:first-child) { margin-top: .8rem; }
        .na-thumb { margin-top: .5rem; display: none; }
        .na-thumb img { max-height: 9rem; border-radius: .4rem; border: 1px solid #e2e8f0; }
    </style>
</head>
<body class="relative min-h-screen flex flex-col selection:bg-rose-900 selection:text-white">
    <canvas id="snow-canvas"></canvas>

    <header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="gmpanel.php" class="flex items-center space-x-3.5 no-underline group">
                    <img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
                            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-rose-900/80 text-rose-200 border border-rose-700/60 font-medium">公告管理</span>
                        </div>
                        <p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Snow Wanderer Online</p>
                    </div>
                </a>
                <nav class="flex items-center space-x-2 sm:space-x-4">
                    <a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-arrow-left text-slate-400"></i>
                        <span class="hidden sm:inline">返回 GM 控制台</span>
                    </a>
                    <a href="news_admin.php?section=articles" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-scroll text-sky-400"></i>
                        <span class="hidden sm:inline">公告列表</span>
                    </a>
                    <a href="../swo/news.php" target="_blank" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-eye text-emerald-400"></i>
                        <span class="hidden sm:inline">檢視前台</span>
                    </a>
                    <div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
                        <div class="flex items-center space-x-2 bg-slate-900/90 border border-rose-900/50 px-3 py-1 rounded-full text-xs">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span class="text-slate-400">管理員：</span>
                            <span class="font-semibold text-rose-300 font-mono"><?= news_h($currentGm) ?></span>
                        </div>
                        <a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors" title="登出 GM 控制台">
                            <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i>
                            <span class="hidden sm:inline">登出</span>
                        </a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">
        <!-- 頁首標題 -->
        <div class="flex flex-col gap-3 pb-3 border-b border-slate-800">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="px-2 py-0.5 text-[11px] font-semibold text-rose-800 bg-rose-50 border border-rose-200 rounded">江湖邸報系統</span>
                        <span class="text-xs text-slate-400">獨立資料庫 swo_news · 資料同步正常</span>
                    </div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider flex items-center gap-2.5">
                        <span>官方公告管理中心</span>
                        <span class="text-xs font-normal text-slate-400 tracking-normal font-sans border border-slate-700 px-2 py-0.5 rounded">News Control Center</span>
                    </h1>
                </div>
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-scroll text-sky-400"></i>
                        <span>公告總數：</span>
                        <strong class="text-sky-400 font-mono text-sm font-bold"><?= (int)$stats['total'] ?></strong>
                        <span class="text-slate-500">篇</span>
                    </div>
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-eye text-emerald-400"></i>
                        <span>累計閱覽：</span>
                        <strong class="text-emerald-400 font-mono text-sm font-bold"><?= number_format((int)$stats['views']) ?></strong>
                    </div>
                </div>
            </div>

            <!-- 精美按鈕選單 -->
            <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2.5 pt-1">
                <?php foreach ($navItems as $n): ?>
                    <a href="news_admin.php?section=<?= news_h($n['key']) ?>" class="na-nav-btn bg-gradient-to-br <?= news_h($n['grad']) ?> <?= $activeNav === $n['key'] ? 'is-active' : '' ?>">
                        <span class="na-nav-icon"><i class="fa-solid <?= news_h($n['icon']) ?> text-sm"></i></span>
                        <span class="flex flex-col items-start leading-tight">
                            <span><?= news_h($n['label']) ?></span>
                            <span class="text-[10px] font-normal text-white/70 font-['Cinzel']"><?= news_h($n['en']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ($notice !== ''): ?>
            <?php $isDanger = ($noticeType === 'danger'); ?>
            <div class="p-3.5 rounded-lg border text-xs flex items-center justify-between <?= $isDanger ? 'border-rose-500/30 bg-rose-950/40 text-rose-200' : 'border-emerald-500/30 bg-emerald-950/40 text-emerald-200' ?>">
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid <?= $isDanger ? 'fa-circle-exclamation text-rose-400' : 'fa-circle-check text-emerald-400' ?> text-sm"></i>
                    <span><?= news_h($notice) ?></span>
                </div>
                <span class="text-[11px] font-mono <?= $isDanger ? 'text-rose-400/70' : 'text-emerald-400/70' ?>"><?= date('H:i:s') ?></span>
            </div>
        <?php endif; ?>

<?php if ($section === 'dashboard'): ?>
        <?php
        $cards = [
            ['label' => '全部公告', 'value' => $stats['total'],      'icon' => 'fa-layer-group',  'grad' => 'from-slate-500 to-slate-700',  'sub' => '含草稿與封存'],
            ['label' => '已發布',   'value' => $stats['published'],  'icon' => 'fa-circle-check', 'grad' => 'from-emerald-500 to-emerald-700', 'sub' => '前台可見'],
            ['label' => '草稿',     'value' => $stats['draft'],      'icon' => 'fa-pen-ruler',    'grad' => 'from-amber-500 to-amber-700',  'sub' => '尚未發布'],
            ['label' => '置頂',     'value' => $stats['sticky'],     'icon' => 'fa-thumbtack',    'grad' => 'from-rose-500 to-rose-700',    'sub' => '重點告示'],
            ['label' => '訂閱名單', 'value' => $stats['subs'],       'icon' => 'fa-envelope',     'grad' => 'from-violet-500 to-violet-700', 'sub' => '飛鴿傳書'],
            ['label' => '累計閱覽', 'value' => $stats['views'],      'icon' => 'fa-eye',          'grad' => 'from-sky-500 to-sky-700',      'sub' => '所有公告'],
        ];
        ?>
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
            <?php foreach ($cards as $c): ?>
                <div class="glass-panel corner-accent rounded-xl p-4 text-slate-800">
                    <div class="flex items-center justify-between mb-2">
                        <span class="w-9 h-9 rounded-lg bg-gradient-to-br <?= news_h($c['grad']) ?> text-white flex items-center justify-center shadow"><i class="fa-solid <?= news_h($c['icon']) ?> text-sm"></i></span>
                    </div>
                    <div class="text-2xl font-bold font-mono text-slate-900"><?= number_format((int)$c['value']) ?></div>
                    <div class="text-[11px] font-semibold text-slate-600 mt-0.5"><?= news_h($c['label']) ?></div>
                    <div class="text-[10px] text-slate-400"><?= news_h($c['sub']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700"><i class="fa-solid fa-clock-rotate-left"></i></div>
                        <div>
                            <h2 class="text-base font-bold text-slate-900 tracking-wide">最近更新公告</h2>
                            <p class="text-[11px] text-slate-500">依最後編輯時間排序</p>
                        </div>
                    </div>
                    <a href="news_admin.php?section=articles" class="text-[11px] font-semibold text-sky-700 hover:text-sky-900">查看全部 <i class="fa-solid fa-arrow-right ml-0.5"></i></a>
                </div>
                <div class="overflow-x-auto">
                    <table class="na-table">
                        <thead><tr><th>標題</th><th>分類</th><th>狀態</th><th class="text-center">閱覽</th><th class="text-right">操作</th></tr></thead>
                        <tbody>
                        <?php if (empty($recentArticles)): ?>
                            <tr><td colspan="5" class="text-center text-slate-400 py-6">尚無公告，立即發表第一篇吧！</td></tr>
                        <?php endif; ?>
                        <?php foreach ($recentArticles as $a): $sm = news_status_meta($a['status']); ?>
                            <tr>
                                <td class="max-w-[280px]">
                                    <a href="news_admin.php?section=view&view=<?= (int)$a['id'] ?>" class="font-semibold text-slate-800 hover:text-rose-800">
                                        <?php if ((int)$a['is_sticky'] === 1): ?><i class="fa-solid fa-thumbtack text-rose-600 text-[10px] mr-1"></i><?php endif; ?><?= news_h($a['title']) ?>
                                    </a>
                                </td>
                                <td class="text-slate-500"><?= news_h($a['category_name'] ?: ($catMap[$a['category_code']]['name'] ?? '—')) ?></td>
                                <td><span class="na-badge <?= news_h($sm['badge']) ?>"><span class="w-1.5 h-1.5 rounded-full <?= news_h($sm['dot']) ?>"></span><?= news_h($sm['label']) ?></span></td>
                                <td class="text-center font-mono text-slate-500"><?= number_format((int)$a['view_count']) ?></td>
                                <td class="text-right whitespace-nowrap">
                                    <a href="news_admin.php?section=editor&id=<?= (int)$a['id'] ?>" class="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i>編輯</a>
                                    <a href="news_admin.php?section=view&view=<?= (int)$a['id'] ?>" class="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-800 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-eye"></i>檢視</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="lg:col-span-4 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <h2 class="text-sm font-bold text-slate-900 tracking-wide"><i class="fa-solid fa-envelope-open-text text-violet-600 mr-1.5"></i>最新訂閱</h2>
                        <a href="news_admin.php?section=subscribers" class="text-[11px] font-semibold text-violet-700 hover:text-violet-900">名單</a>
                    </div>
                    <div class="space-y-2">
                        <?php if (empty($recentSubs)): ?><div class="text-center text-slate-400 text-[11px] py-4">尚無訂閱者</div><?php endif; ?>
                        <?php foreach ($recentSubs as $s): ?>
                            <div class="flex items-center justify-between text-[11px] border border-slate-100 rounded-md px-2.5 py-1.5 bg-slate-50">
                                <span class="font-mono text-slate-600 truncate"><?= news_h($s['email']) ?></span>
                                <span class="flex-none ml-2 <?= (int)$s['is_active'] === 1 ? 'text-emerald-600' : 'text-slate-400' ?>"><?= (int)$s['is_active'] === 1 ? '有效' : '停用' ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <h2 class="text-sm font-bold text-slate-900 tracking-wide"><i class="fa-solid fa-list-check text-rose-600 mr-1.5"></i>操作歷程</h2>
                    </div>
                    <div class="space-y-2.5">
                        <?php if (empty($recentLogs)): ?><div class="text-center text-slate-400 text-[11px] py-4">尚無紀錄</div><?php endif; ?>
                        <?php foreach ($recentLogs as $l): ?>
                            <div class="flex items-start gap-2 text-[11px]">
                                <span class="w-1.5 h-1.5 rounded-full bg-rose-500 mt-1.5 flex-none"></span>
                                <div class="min-w-0">
                                    <div class="text-slate-700 truncate"><?= news_h($l['note'] ?: $l['action']) ?></div>
                                    <div class="text-slate-400"><?= news_h($l['operator_name']) ?> · <?= news_h(news_ago($l['created_at'])) ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
<?php elseif ($section === 'articles'): ?>
        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700"><i class="fa-solid fa-scroll"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide">公告管理</h2>
                        <p class="text-[11px] text-slate-500">共 <?= (int)$listTotal ?> 篇 · 支援搜尋、分類與狀態篩選</p>
                    </div>
                </div>
                <a href="news_admin.php?section=editor" class="btn-vermilion inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg self-start">
                    <i class="fa-solid fa-feather-pointed"></i> 發表新公告
                </a>
            </div>

            <form method="GET" action="news_admin.php" class="grid grid-cols-1 md:grid-cols-12 gap-2 mb-4">
                <input type="hidden" name="section" value="articles">
                <div class="md:col-span-5 relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                    <input type="text" name="q" value="<?= news_h($listQ) ?>" placeholder="搜尋公告標題或摘要..." class="na-input pl-9">
                </div>
                <div class="md:col-span-3">
                    <select name="cat" class="na-select">
                        <option value="">全部分類</option>
                        <?php foreach ($categories as $c): ?>
                            <option value="<?= news_h($c['code']) ?>" <?= $listCat === $c['code'] ? 'selected' : '' ?>><?= news_h($c['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="md:col-span-2">
                    <select name="status" class="na-select">
                        <option value="">全部狀態</option>
                        <option value="published" <?= $listStatus === 'published' ? 'selected' : '' ?>>已發布</option>
                        <option value="draft" <?= $listStatus === 'draft' ? 'selected' : '' ?>>草稿</option>
                        <option value="scheduled" <?= $listStatus === 'scheduled' ? 'selected' : '' ?>>預約發布</option>
                        <option value="archived" <?= $listStatus === 'archived' ? 'selected' : '' ?>>已封存</option>
                    </select>
                </div>
                <div class="md:col-span-2 flex gap-2">
                    <button type="submit" class="btn-ice flex-1 px-3 py-2 text-xs font-semibold rounded-lg"><i class="fa-solid fa-filter mr-1"></i>篩選</button>
                    <a href="news_admin.php?section=articles" class="flex-none px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600" title="重設"><i class="fa-solid fa-rotate-left"></i></a>
                </div>
            </form>

            <div class="overflow-x-auto rounded-lg border border-slate-200">
                <table class="na-table">
                    <thead>
                        <tr>
                            <th>公告標題</th>
                            <th>分類</th>
                            <th>狀態</th>
                            <th>發布時間</th>
                            <th class="text-center">閱覽</th>
                            <th class="text-right">操作</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($articles)): ?>
                        <tr><td colspan="6" class="text-center text-slate-400 py-8"><i class="fa-regular fa-face-frown mr-1"></i> 找不到符合條件的公告</td></tr>
                    <?php endif; ?>
                    <?php foreach ($articles as $a): $sm = news_status_meta($a['status']); $pm = news_priority_meta($a['priority']); ?>
                        <tr>
                            <td class="max-w-[340px]">
                                <div class="flex items-start gap-2">
                                    <span class="na-strip <?= news_h($sm['dot']) ?>"></span>
                                    <div class="min-w-0">
                                        <a href="news_admin.php?section=view&view=<?= (int)$a['id'] ?>" class="font-semibold text-slate-800 hover:text-rose-800 block truncate">
                                            <?php if ((int)$a['is_sticky'] === 1): ?><i class="fa-solid fa-thumbtack text-rose-600 text-[10px] mr-1"></i><?php endif; ?><?= news_h($a['title']) ?>
                                        </a>
                                        <div class="text-[10px] text-slate-400 font-mono truncate">/<?= news_h($a['slug']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <span class="na-badge <?= news_h($a['badge_class'] ?: 'bg-slate-100 text-slate-600 border-slate-300') ?>"><?= news_h($a['category_name'] ?: ($catMap[$a['category_code']]['name'] ?? '—')) ?></span>
                            </td>
                            <td>
                                <span class="na-badge <?= news_h($sm['badge']) ?>"><span class="w-1.5 h-1.5 rounded-full <?= news_h($sm['dot']) ?>"></span><?= news_h($sm['label']) ?></span>
                                <?php if ($a['priority'] !== 'normal'): ?>
                                    <span class="na-badge <?= news_h($pm['badge']) ?> ml-1"><?= news_h($pm['label']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td class="text-slate-500 text-[11px] font-mono whitespace-nowrap"><?= $a['published_at'] ? news_h(date('Y-m-d H:i', strtotime($a['published_at']))) : '—' ?></td>
                            <td class="text-center font-mono text-slate-500"><?= number_format((int)$a['view_count']) ?></td>
                            <td class="text-right whitespace-nowrap">
                                <a href="news_admin.php?section=view&view=<?= (int)$a['id'] ?>" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-800 border border-slate-300 text-[11px] font-medium" title="檢視"><i class="fa-solid fa-eye"></i></a>
                                <a href="news_admin.php?section=editor&id=<?= (int)$a['id'] ?>" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium ml-1" title="編輯"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="news_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="toggle_sticky">
                                    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded border text-[11px] font-medium ml-1 <?= (int)$a['is_sticky'] === 1 ? 'bg-rose-100 text-rose-800 border-rose-300' : 'bg-slate-100 hover:bg-rose-100 text-slate-600 border-slate-300' ?>" title="置頂切換"><i class="fa-solid fa-thumbtack"></i></button>
                                </form>
                                <form method="POST" action="news_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="toggle_publish">
                                    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded border text-[11px] font-medium ml-1 <?= $a['status'] === 'published' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-600 border-slate-300' ?>" title="上下架切換"><i class="fa-solid <?= $a['status'] === 'published' ? 'fa-toggle-on' : 'fa-toggle-off' ?>"></i></button>
                                </form>
                                <form method="POST" action="news_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="duplicate_article">
                                    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-violet-100 text-slate-600 hover:text-violet-800 border border-slate-300 text-[11px] font-medium ml-1" title="複製"><i class="fa-solid fa-copy"></i></button>
                                </form>
                                <form method="POST" action="news_admin.php" class="inline" onsubmit="return naConfirmSubmit(this, '確定要刪除公告「<?= news_h($a['title']) ?>」嗎？此動作無法復原。');">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="delete_article">
                                    <input type="hidden" name="id" value="<?= (int)$a['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1" title="刪除"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($listPages > 1): ?>
                <div class="flex items-center justify-between mt-4 text-xs">
                    <span class="text-slate-500">第 <?= $listPage ?> / <?= $listPages ?> 頁</span>
                    <div class="flex items-center gap-1">
                        <?php
                        $baseQ = ['section' => 'articles', 'q' => $listQ, 'cat' => $listCat, 'status' => $listStatus];
                        $mk = function ($pg) use ($baseQ) { $baseQ['page'] = $pg; return 'news_admin.php?' . http_build_query(array_filter($baseQ, function ($v) { return $v !== ''; })); };
                        ?>
                        <?php if ($listPage > 1): ?><a href="<?= news_h($mk($listPage - 1)) ?>" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100"><i class="fa-solid fa-chevron-left"></i> 上一頁</a><?php endif; ?>
                        <?php for ($pg = max(1, $listPage - 2); $pg <= min($listPages, $listPage + 2); $pg++): ?>
                            <a href="<?= news_h($mk($pg)) ?>" class="w-8 h-8 flex items-center justify-center rounded-lg border <?= $pg === $listPage ? 'bg-rose-800 text-white border-rose-800 font-bold' : 'border-slate-300 bg-white text-slate-600 hover:bg-slate-100' ?>"><?= $pg ?></a>
                        <?php endfor; ?>
                        <?php if ($listPage < $listPages): ?><a href="<?= news_h($mk($listPage + 1)) ?>" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100">下一頁 <i class="fa-solid fa-chevron-right"></i></a><?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
<?php elseif ($section === 'editor'): ?>
        <?php
        $isEdit = (bool)$editArticle;
        $f = [
            'id' => $editArticle['id'] ?? 0,
            'category_code' => $editArticle['category_code'] ?? 'update',
            'title' => $editArticle['title'] ?? '',
            'slug' => $editArticle['slug'] ?? '',
            'summary' => $editArticle['summary'] ?? '',
            'content' => $editArticle['content'] ?? '',
            'cover_image' => $editArticle['cover_image'] ?? '',
            'cover_caption' => $editArticle['cover_caption'] ?? '',
            'author' => $editArticle['author'] ?? '官方團隊',
            'priority' => $editArticle['priority'] ?? 'normal',
            'is_sticky' => (int)($editArticle['is_sticky'] ?? 0),
            'is_featured' => (int)($editArticle['is_featured'] ?? 0),
            'status' => $editArticle['status'] ?? 'draft',
            'published_at' => $editArticle['published_at'] ?? '',
            'allow_comments' => (int)($editArticle['allow_comments'] ?? 0),
            'seo_title' => $editArticle['seo_title'] ?? '',
            'seo_keywords' => $editArticle['seo_keywords'] ?? '',
            'seo_description' => $editArticle['seo_description'] ?? '',
        ];
        $pubLocal = '';
        if (!empty($f['published_at'])) {
            $ts = strtotime($f['published_at']);
            if ($ts) { $pubLocal = date('Y-m-d\TH:i', $ts); }
        }
        ?>
        <form method="POST" action="news_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
            <input type="hidden" name="action" value="save_article">
            <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">

            <div class="lg:col-span-8 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                        <div class="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700"><i class="fa-solid fa-feather-pointed"></i></div>
                        <div>
                            <h2 class="text-base font-bold text-slate-900"><?= $isEdit ? '編輯公告' : '發表新公告' ?></h2>
                            <p class="text-[11px] text-slate-500"><?= $isEdit ? '修改後按下儲存即更新前台內容' : '填寫標題與內容即可快速發布江湖快報' ?></p>
                        </div>
                    </div>

                    <div class="space-y-4">
                        <div>
                            <label class="na-label">公告標題 <span class="text-rose-600">*</span></label>
                            <input type="text" name="title" value="<?= news_h($f['title']) ?>" maxlength="200" required class="na-input" placeholder="例：v1.8.5「寒淵破曉」大型版本更新總覽">
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="na-label">網址代稱 (slug)</label>
                                <input type="text" name="slug" value="<?= news_h($f['slug']) ?>" class="na-input font-mono text-xs" placeholder="留空將自動由標題產生">
                                <p class="na-help">僅供網址識別，留空自動生成。</p>
                            </div>
                            <div>
                                <label class="na-label">發布者</label>
                                <input type="text" name="author" value="<?= news_h($f['author']) ?>" maxlength="50" class="na-input" placeholder="官方團隊">
                            </div>
                        </div>
                        <div>
                            <label class="na-label">摘要</label>
                            <textarea name="summary" rows="3" maxlength="500" class="na-textarea" placeholder="一段話說明公告重點，將顯示於列表頁..."><?= news_h($f['summary']) ?></textarea>
                        </div>
                        <div>
                            <div class="flex items-center justify-between mb-2 gap-2 flex-wrap">
                                <label class="na-label mb-0">公告內文</label>
                                <div class="na-mode-switch">
                                    <button type="button" class="na-mode-btn is-active" data-mode="wysiwyg" onclick="naEditorMode('wysiwyg')"><i class="fa-solid fa-eye"></i> 所見即所得</button>
                                    <button type="button" class="na-mode-btn" data-mode="code" onclick="naEditorMode('code')"><i class="fa-solid fa-code"></i> 代碼模式</button>
                                </div>
                            </div>

                            <div class="na-editor" id="na-editor">
                                <!-- 語法工具列 -->
                                <div class="na-editor-toolbar" id="na-toolbar">
                                    <button type="button" class="na-tb-btn" title="復原" onmousedown="event.preventDefault()" onclick="naExec('undo')"><i class="fa-solid fa-rotate-left"></i></button>
                                    <button type="button" class="na-tb-btn" title="重做" onmousedown="event.preventDefault()" onclick="naExec('redo')"><i class="fa-solid fa-rotate-right"></i></button>
                                    <span class="na-tb-sep"></span>

                                    <select class="na-tb-select" title="段落格式" onchange="naBlock(this.value); this.selectedIndex=0;">
                                        <option value="">段落格式</option>
                                        <option value="P">內文</option>
                                        <option value="H2">標題一</option>
                                        <option value="H3">標題二</option>
                                        <option value="H4">標題三</option>
                                        <option value="BLOCKQUOTE">引用區塊</option>
                                        <option value="PRE">程式碼區塊</option>
                                    </select>
                                    <select class="na-tb-select" title="字體" onchange="naInline('fontFamily', this.value); this.selectedIndex=0;">
                                        <option value="">字體</option>
                                        <option value="'Noto Serif TC', serif">思源宋體</option>
                                        <option value="'Manrope', sans-serif">Manrope</option>
                                        <option value="'KaiTi','標楷體', serif">標楷體</option>
                                        <option value="'DFKai-SB', serif">華康楷書</option>
                                        <option value="'Microsoft JhengHei','微軟正黑體', sans-serif">微軟正黑</option>
                                        <option value="Georgia, serif">Georgia</option>
                                        <option value="monospace">等寬字型</option>
                                    </select>
                                    <select class="na-tb-select" title="字級" onchange="naInline('fontSize', this.value); this.selectedIndex=0;">
                                        <option value="">字級</option>
                                        <option value="12px">12</option>
                                        <option value="14px">14</option>
                                        <option value="16px">16</option>
                                        <option value="18px">18</option>
                                        <option value="20px">20</option>
                                        <option value="24px">24</option>
                                        <option value="28px">28</option>
                                        <option value="32px">32</option>
                                    </select>
                                    <span class="na-tb-sep"></span>

                                    <button type="button" class="na-tb-btn" title="粗體 (Ctrl+B)" onmousedown="event.preventDefault()" onclick="naExec('bold')"><i class="fa-solid fa-bold"></i></button>
                                    <button type="button" class="na-tb-btn" title="斜體 (Ctrl+I)" onmousedown="event.preventDefault()" onclick="naExec('italic')"><i class="fa-solid fa-italic"></i></button>
                                    <button type="button" class="na-tb-btn" title="底線 (Ctrl+U)" onmousedown="event.preventDefault()" onclick="naExec('underline')"><i class="fa-solid fa-underline"></i></button>
                                    <button type="button" class="na-tb-btn" title="刪除線" onmousedown="event.preventDefault()" onclick="naExec('strikeThrough')"><i class="fa-solid fa-strikethrough"></i></button>
                                    <button type="button" class="na-tb-btn" title="行內程式碼" onmousedown="event.preventDefault()" onclick="naInlineTag('code')"><i class="fa-solid fa-terminal"></i></button>
                                    <button type="button" class="na-tb-btn" title="上標" onmousedown="event.preventDefault()" onclick="naExec('superscript')"><i class="fa-solid fa-superscript"></i></button>
                                    <button type="button" class="na-tb-btn" title="下標" onmousedown="event.preventDefault()" onclick="naExec('subscript')"><i class="fa-solid fa-subscript"></i></button>
                                    <span class="na-tb-sep"></span>

                                    <label class="na-tb-colorwrap" title="文字顏色">
                                        <i class="fa-solid fa-font na-tb-coloricon"></i>
                                        <input type="color" class="na-tb-color" value="#be123c" onchange="naColor('foreColor', this.value)">
                                    </label>
                                    <label class="na-tb-colorwrap" title="螢光標記">
                                        <i class="fa-solid fa-highlighter na-tb-coloricon"></i>
                                        <input type="color" class="na-tb-color" value="#fef08a" onchange="naColor('hiliteColor', this.value)">
                                    </label>
                                    <span class="na-tb-sep"></span>

                                    <button type="button" class="na-tb-btn" title="靠左" onmousedown="event.preventDefault()" onclick="naExec('justifyLeft')"><i class="fa-solid fa-align-left"></i></button>
                                    <button type="button" class="na-tb-btn" title="置中" onmousedown="event.preventDefault()" onclick="naExec('justifyCenter')"><i class="fa-solid fa-align-center"></i></button>
                                    <button type="button" class="na-tb-btn" title="靠右" onmousedown="event.preventDefault()" onclick="naExec('justifyRight')"><i class="fa-solid fa-align-right"></i></button>
                                    <button type="button" class="na-tb-btn" title="左右對齊" onmousedown="event.preventDefault()" onclick="naExec('justifyFull')"><i class="fa-solid fa-align-justify"></i></button>
                                    <span class="na-tb-sep"></span>

                                    <button type="button" class="na-tb-btn" title="項目符號" onmousedown="event.preventDefault()" onclick="naExec('insertUnorderedList')"><i class="fa-solid fa-list-ul"></i></button>
                                    <button type="button" class="na-tb-btn" title="編號清單" onmousedown="event.preventDefault()" onclick="naExec('insertOrderedList')"><i class="fa-solid fa-list-ol"></i></button>
                                    <button type="button" class="na-tb-btn" title="減少縮排" onmousedown="event.preventDefault()" onclick="naExec('outdent')"><i class="fa-solid fa-outdent"></i></button>
                                    <button type="button" class="na-tb-btn" title="增加縮排" onmousedown="event.preventDefault()" onclick="naExec('indent')"><i class="fa-solid fa-indent"></i></button>
                                    <span class="na-tb-sep"></span>

                                    <button type="button" class="na-tb-btn" title="插入連結" onmousedown="event.preventDefault()" onclick="naOpenMedia('link')"><i class="fa-solid fa-link"></i></button>
                                    <button type="button" class="na-tb-btn" title="插入圖片" onmousedown="event.preventDefault()" onclick="naOpenMedia('image')"><i class="fa-solid fa-image"></i></button>
                                    <button type="button" class="na-tb-btn" title="插入影片" onmousedown="event.preventDefault()" onclick="naOpenMedia('video')"><i class="fa-solid fa-video"></i></button>
                                    <button type="button" class="na-tb-btn" title="插入表格" onmousedown="event.preventDefault()" onclick="naOpenMedia('table')"><i class="fa-solid fa-table"></i></button>
                                    <button type="button" class="na-tb-btn" title="分隔線" onmousedown="event.preventDefault()" onclick="naInsertHtml('<hr>')"><i class="fa-solid fa-minus"></i></button>
                                    <span class="na-tb-sep"></span>

                                    <button type="button" class="na-tb-btn na-tb-danger" title="清除格式" onmousedown="event.preventDefault()" onclick="naClearFormat()"><i class="fa-solid fa-eraser"></i></button>
                                </div>

                                <!-- 所見即所得編輯區 -->
                                <div id="na-content-wysiwyg" class="na-editor-canvas" contenteditable="true" data-placeholder="在此輸入公告內文，或使用上方工具列插入圖片、影片與排版…"></div>
                                <!-- 原始碼（表單實際送出欄位） -->
                                <textarea name="content" id="na-content-code" rows="16" class="na-textarea font-mono text-[12px]" style="display:none;border:0;border-radius:0;" placeholder="<p>內文段落...</p>"><?= news_h($f['content']) ?></textarea>
                            </div>
                            <p class="na-help">支援粗體、斜體、字體、字級、文字／標記顏色、對齊、清單、連結、圖片、影片與表格，並可切換「代碼模式」直接編輯 HTML。</p>
                        </div>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-image text-sky-600 mr-1.5"></i>封面與媒體</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="na-label">封面圖網址</label>
                            <input type="text" name="cover_image" value="<?= news_h($f['cover_image']) ?>" class="na-input font-mono text-[11px]" placeholder="https://...">
                        </div>
                        <div>
                            <label class="na-label">封面標語</label>
                            <input type="text" name="cover_caption" value="<?= news_h($f['cover_caption']) ?>" maxlength="200" class="na-input" placeholder="例：冰宮現世 · 神兵降臨">
                        </div>
                        <?php if (!empty($f['cover_image'])): ?>
                            <div class="border border-slate-200 rounded-lg overflow-hidden">
                                <img src="<?= news_h($f['cover_image']) ?>" alt="封面預覽" class="w-full max-h-52 object-cover">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <details class="glass-panel corner-accent rounded-xl p-5">
                    <summary class="text-sm font-bold text-slate-900 cursor-pointer select-none"><i class="fa-solid fa-magnifying-glass-chart text-emerald-600 mr-1.5"></i>SEO 搜尋最佳化設定</summary>
                    <div class="space-y-4 mt-4">
                        <div>
                            <label class="na-label">SEO 標題</label>
                            <input type="text" name="seo_title" value="<?= news_h($f['seo_title']) ?>" maxlength="200" class="na-input">
                        </div>
                        <div>
                            <label class="na-label">SEO 關鍵字</label>
                            <input type="text" name="seo_keywords" value="<?= news_h($f['seo_keywords']) ?>" maxlength="300" class="na-input" placeholder="以逗號分隔">
                        </div>
                        <div>
                            <label class="na-label">SEO 描述</label>
                            <textarea name="seo_description" rows="2" maxlength="500" class="na-textarea"><?= news_h($f['seo_description']) ?></textarea>
                        </div>
                    </div>
                </details>
            </div>

            <div class="lg:col-span-4 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-paper-plane text-rose-600 mr-1.5"></i>發布設定</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="na-label">分類</label>
                            <select name="category_code" class="na-select">
                                <?php foreach ($categories as $c): ?>
                                    <option value="<?= news_h($c['code']) ?>" <?= $f['category_code'] === $c['code'] ? 'selected' : '' ?>><?= news_h($c['name']) ?><?= (int)$c['enabled'] === 0 ? '（停用）' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="na-label">狀態</label>
                            <select name="status" class="na-select">
                                <option value="draft" <?= $f['status'] === 'draft' ? 'selected' : '' ?>>草稿</option>
                                <option value="published" <?= $f['status'] === 'published' ? 'selected' : '' ?>>已發布</option>
                                <option value="scheduled" <?= $f['status'] === 'scheduled' ? 'selected' : '' ?>>預約發布</option>
                                <option value="archived" <?= $f['status'] === 'archived' ? 'selected' : '' ?>>已封存</option>
                            </select>
                        </div>
                        <div>
                            <label class="na-label">發布時間</label>
                            <input type="datetime-local" name="published_at" value="<?= news_h($pubLocal) ?>" class="na-input">
                            <p class="na-help">設為「已發布」且留空時，將以目前時間發布。</p>
                        </div>
                        <div>
                            <label class="na-label">優先度</label>
                            <select name="priority" class="na-select">
                                <option value="normal" <?= $f['priority'] === 'normal' ? 'selected' : '' ?>>一般</option>
                                <option value="low" <?= $f['priority'] === 'low' ? 'selected' : '' ?>>低</option>
                                <option value="high" <?= $f['priority'] === 'high' ? 'selected' : '' ?>>高</option>
                                <option value="urgent" <?= $f['priority'] === 'urgent' ? 'selected' : '' ?>>緊急</option>
                            </select>
                        </div>
                        <div class="space-y-2 pt-1">
                            <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="is_sticky" value="1" class="w-4 h-4 accent-rose-700" <?= $f['is_sticky'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-thumbtack text-rose-600"></i> 置頂顯示</label>
                            <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="is_featured" value="1" class="w-4 h-4 accent-rose-700" <?= $f['is_featured'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-star text-amber-500"></i> 精選大卡（優先顯示）</label>
                            <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="allow_comments" value="1" class="w-4 h-4 accent-rose-700" <?= $f['allow_comments'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-comments text-sky-600"></i> 開放回應</label>
                        </div>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex flex-col gap-2">
                        <button type="submit" class="btn-vermilion w-full py-2.5 text-sm font-bold rounded-lg flex items-center justify-center gap-2"><i class="fa-solid fa-floppy-disk"></i> <?= $isEdit ? '儲存並更新公告' : '立即發表公告' ?></button>
                        <a href="news_admin.php?section=articles" class="w-full py-2.5 text-sm font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600 text-center">取消返回</a>
                    </div>
                    <?php if ($isEdit): ?>
                        <div class="ink-divider my-4"></div>
                        <div class="text-[11px] text-slate-500 space-y-1">
                            <div><i class="fa-regular fa-clock mr-1"></i>建立：<?= news_h($editArticle['created_at']) ?></div>
                            <div><i class="fa-solid fa-user-pen mr-1"></i>更新：<?= news_h($editArticle['updated_at']) ?>（<?= news_h($editArticle['updated_by']) ?>）</div>
                            <div><i class="fa-solid fa-eye mr-1"></i>閱覽：<?= number_format((int)$editArticle['view_count']) ?> 次</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <!-- 插入媒體 / 連結 / 表格 子視窗 -->
        <div id="na-media-modal" class="na-modal-mask" style="display:none;">
            <div class="na-modal-card">
                <div class="na-modal-head">
                    <span id="na-media-title"><i class="fa-solid fa-image mr-1.5"></i>插入內容</span>
                    <button type="button" class="na-modal-x" onclick="naCloseMedia()"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <div class="na-modal-body" id="na-media-body"></div>
                <div class="na-modal-foot">
                    <button type="button" class="na-modal-btn" onclick="naCloseMedia()">取消</button>
                    <button type="button" class="btn-vermilion na-modal-btn" id="na-media-ok" onclick="naSubmitMedia()"><i class="fa-solid fa-check mr-1"></i>插入</button>
                </div>
            </div>
        </div>
<?php elseif ($section === 'view'): ?>
        <?php if (!$viewArticle): ?>
            <div class="glass-panel corner-accent rounded-xl p-10 text-center text-slate-500">
                <i class="fa-regular fa-face-frown text-3xl mb-3"></i>
                <p>找不到此公告，可能已被刪除。</p>
                <a href="news_admin.php?section=articles" class="btn-ice inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg mt-4"><i class="fa-solid fa-arrow-left"></i> 返回公告列表</a>
            </div>
        <?php else: $sm = news_status_meta($viewArticle['status']); $pm = news_priority_meta($viewArticle['priority']); ?>
            <div class="flex flex-wrap items-center justify-between gap-3">
                <a href="news_admin.php?section=articles" class="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600"><i class="fa-solid fa-arrow-left"></i> 返回列表</a>
                <div class="flex items-center gap-2">
                    <a href="news_admin.php?section=editor&id=<?= (int)$viewArticle['id'] ?>" class="btn-ice inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg"><i class="fa-solid fa-pen"></i> 編輯公告</a>
                    <a href="../swo/news.php?view=<?= (int)$viewArticle['id'] ?>" target="_blank" class="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"><i class="fa-solid fa-eye"></i> 前台預覽</a>
                </div>
            </div>

            <article class="glass-panel corner-accent rounded-xl p-6 sm:p-8">
                <div class="flex flex-wrap items-center gap-2 mb-3">
                    <span class="na-badge <?= news_h($viewArticle['badge_class'] ?: 'bg-rose-100 text-rose-800 border-rose-200') ?>"><?= news_h($viewArticle['category_name'] ?: '公告') ?></span>
                    <span class="na-badge <?= news_h($sm['badge']) ?>"><span class="w-1.5 h-1.5 rounded-full <?= news_h($sm['dot']) ?>"></span><?= news_h($sm['label']) ?></span>
                    <span class="na-badge <?= news_h($pm['badge']) ?>"><?= news_h($pm['label']) ?>優先度</span>
                    <?php if ((int)$viewArticle['is_sticky'] === 1): ?><span class="na-badge bg-rose-100 text-rose-800 border-rose-300"><i class="fa-solid fa-thumbtack"></i> 置頂</span><?php endif; ?>
                    <?php if ((int)$viewArticle['is_featured'] === 1): ?><span class="na-badge bg-amber-100 text-amber-800 border-amber-300"><i class="fa-solid fa-star"></i> 精選</span><?php endif; ?>
                </div>
                <h1 class="text-2xl sm:text-3xl font-bold text-slate-900 tracking-wide leading-snug"><?= news_h($viewArticle['title']) ?></h1>
                <div class="flex flex-wrap items-center gap-4 mt-3 text-[11px] text-slate-500 font-mono">
                    <span><i class="fa-solid fa-user-pen mr-1"></i><?= news_h($viewArticle['author']) ?></span>
                    <span><i class="fa-regular fa-calendar mr-1"></i><?= $viewArticle['published_at'] ? news_h(date('Y-m-d H:i', strtotime($viewArticle['published_at']))) : '未發布' ?></span>
                    <span><i class="fa-solid fa-eye mr-1"></i><?= number_format((int)$viewArticle['view_count']) ?> 閱覽</span>
                    <span><i class="fa-solid fa-link mr-1"></i><?= news_h($viewArticle['slug']) ?></span>
                </div>
                <?php if (!empty($viewArticle['summary'])): ?>
                    <p class="mt-4 p-3 bg-slate-50 border-l-2 border-rose-700 text-sm text-slate-600 leading-relaxed"><?= news_h($viewArticle['summary']) ?></p>
                <?php endif; ?>
                <?php if (!empty($viewArticle['cover_image'])): ?>
                    <div class="mt-5 border border-slate-200 rounded-lg overflow-hidden">
                        <img src="<?= news_h($viewArticle['cover_image']) ?>" alt="<?= news_h($viewArticle['cover_caption'] ?: $viewArticle['title']) ?>" class="w-full max-h-80 object-cover">
                        <?php if (!empty($viewArticle['cover_caption'])): ?><div class="px-3 py-1.5 bg-slate-50 text-[11px] text-slate-500 border-t border-slate-200"><?= news_h($viewArticle['cover_caption']) ?></div><?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="ink-divider my-5"></div>
                <div class="news-content-preview text-sm text-slate-700"><?= $viewArticle['content'] ?></div>

                <?php if (!empty($viewAttachments)): ?>
                    <div class="ink-divider my-5"></div>
                    <h3 class="text-sm font-bold text-slate-900 mb-2"><i class="fa-solid fa-paperclip text-slate-400 mr-1"></i>相關附件</h3>
                    <div class="flex flex-col gap-2">
                        <?php foreach ($viewAttachments as $att): ?>
                            <a href="<?= news_h($att['file_path']) ?>" target="_blank" class="flex items-center justify-between px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg hover:border-sky-300 text-xs">
                                <span class="text-slate-700"><i class="fa-solid fa-file mr-1.5 text-slate-400"></i><?= news_h($att['file_name']) ?></span>
                                <span class="text-slate-400 font-mono"><?= $att['file_size'] > 0 ? number_format($att['file_size'] / 1024, 1) . ' KB' : '連結' ?></span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </article>
        <?php endif; ?>
<?php elseif ($section === 'categories'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700"><i class="fa-solid fa-tags"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">公告分類管理</h2>
                        <p class="text-[11px] text-slate-500">分類代碼欄位（code）為程式識別用，建議沿用既有英文代碼</p>
                    </div>
                </div>
                <div class="overflow-x-auto rounded-lg border border-slate-200">
                    <table class="na-table">
                        <thead><tr><th>分類</th><th>代碼</th><th>樣式</th><th class="text-center">公告數</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($categories as $c): ?>
                            <?php $cnt = 0; $r = $db->query("SELECT COUNT(*) AS n FROM `news_articles` WHERE `category_id` = " . (int)$c['id']); if ($r) { $cnt = (int)$r->fetch_assoc()['n']; } ?>
                            <tr>
                                <td class="font-semibold text-slate-800"><i class="fa-solid <?= $c['icon'] && strpos($c['icon'], 'fa-') === 0 ? news_h($c['icon']) : 'fa-tag' ?> text-slate-400 mr-1.5"></i><?= news_h($c['name']) ?></td>
                                <td class="font-mono text-[11px] text-slate-500"><?= news_h($c['code']) ?></td>
                                <td><span class="na-badge <?= news_h($c['badge_class'] ?: 'bg-slate-100 text-slate-600 border-slate-300') ?>"><?= news_h($c['name_en'] ?: $c['name']) ?></span></td>
                                <td class="text-center font-mono"><?= $cnt ?></td>
                                <td class="text-center">
                                    <form method="POST" action="news_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_category">
                                        <input type="hidden" name="category_id" value="<?= (int)$c['id'] ?>">
                                        <button type="submit" class="na-badge <?= (int)$c['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$c['enabled'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$c['enabled'] === 1 ? '啟用' : '停用' ?></button>
                                    </form>
                                </td>
                                <td class="text-right whitespace-nowrap">
                                    <button type="button" onclick="naEditCategory(<?= htmlspecialchars(json_encode($c, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="news_admin.php" class="inline" onsubmit="return naConfirmSubmit(this, '確定刪除分類「<?= news_h($c['name']) ?>」？');">
                                        <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_category">
                                        <input type="hidden" name="category_id" value="<?= (int)$c['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="lg:col-span-4">
                <form method="POST" action="news_admin.php" id="na-category-form" class="glass-panel corner-accent rounded-xl p-5 sticky top-24">
                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_category">
                    <input type="hidden" name="category_id" id="cat-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="cat-form-title"><i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增分類</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">分類代碼 (code) <span class="text-rose-600">*</span></label><input type="text" name="code" id="cat-code" required class="na-input font-mono text-xs" placeholder="例：maintenance"></div>
                        <div><label class="na-label">分類名稱 <span class="text-rose-600">*</span></label><input type="text" name="name" id="cat-name" required class="na-input" placeholder="例：系統維護"></div>
                        <div><label class="na-label">英文名稱</label><input type="text" name="name_en" id="cat-name-en" class="na-input" placeholder="Maintenance"></div>
                        <div><label class="na-label">FontAwesome 圖示</label><input type="text" name="icon" id="cat-icon" class="na-input font-mono text-xs" placeholder="fa-tag"></div>
                        <div><label class="na-label">徽章樣式 (className)</label><input type="text" name="badge_class" id="cat-badge" class="na-input font-mono text-[11px]" placeholder="bg-rose-100 text-rose-800 border-rose-200"></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">主色系</label>
                                <select name="accent" id="cat-accent" class="na-select">
                                    <option value="rose">rose</option><option value="sky">sky</option><option value="amber">amber</option><option value="slate">slate</option><option value="teal">teal</option>
                                </select>
                            </div>
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="cat-sort" value="0" class="na-input"></div>
                        </div>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="naResetCategory()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <script>
            function naEditCategory(c) {
                document.getElementById('cat-id').value = c.id;
                document.getElementById('cat-code').value = c.code || '';
                document.getElementById('cat-name').value = c.name || '';
                document.getElementById('cat-name-en').value = c.name_en || '';
                document.getElementById('cat-icon').value = c.icon || '';
                document.getElementById('cat-badge').value = c.badge_class || '';
                document.getElementById('cat-accent').value = c.accent || 'rose';
                document.getElementById('cat-sort').value = c.sort_order || 0;
                document.getElementById('cat-form-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-amber-600 mr-1.5"></i>編輯分類 #' + c.id;
                document.getElementById('na-category-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            function naResetCategory() {
                document.getElementById('na-category-form').reset();
                document.getElementById('cat-id').value = 0;
                document.getElementById('cat-form-title').innerHTML = '<i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增分類';
            }
        </script>
<?php elseif ($section === 'settings'): ?>
        <form method="POST" action="news_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
            <input type="hidden" name="action" value="save_settings">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700"><i class="fa-solid fa-sliders"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">公告系統設定</h2>
                        <p class="text-[11px] text-slate-500">這些設定將即時顯示於前台邸報首頁資訊列</p>
                    </div>
                </div>
                <div class="mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide">
                    <i class="fa-solid fa-chess-board text-rose-500"></i>
                    <span>首頁資訊列</span>
                    <span class="font-normal text-slate-400">（版號／維護時間／線路狀態，可分別控制顯示與否）</span>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="na-label">目前江湖版本</label>
                        <input type="text" name="set_site_version" value="<?= news_h($SET['site_version'] ?? '') ?>" class="na-input" placeholder="v1.8.5">
                        <label class="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500 cursor-pointer select-none">
                            <input type="checkbox" name="set_show_version" value="1" class="w-3.5 h-3.5 accent-rose-700" <?= ($SET['show_version'] ?? '1') === '1' ? 'checked' : '' ?>>
                            顯示此區塊
                        </label>
                    </div>
                    <div>
                        <label class="na-label">版本代號</label>
                        <input type="text" name="set_site_codename" value="<?= news_h($SET['site_codename'] ?? '') ?>" class="na-input" placeholder="「寒淵破曉」">
                    </div>
                    <div>
                        <label class="na-label">下次例行維護</label>
                        <input type="text" name="set_maintenance_next" value="<?= news_h($SET['maintenance_next'] ?? '') ?>" class="na-input" placeholder="4月9日 (三) 08:00">
                        <label class="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500 cursor-pointer select-none">
                            <input type="checkbox" name="set_show_maintenance" value="1" class="w-3.5 h-3.5 accent-rose-700" <?= ($SET['show_maintenance'] ?? '1') === '1' ? 'checked' : '' ?>>
                            顯示此區塊
                        </label>
                    </div>
                    <div>
                        <label class="na-label">全服線路狀態</label>
                        <select name="set_server_status" class="na-select">
                            <option value="online" <?= ($SET['server_status'] ?? '') === 'online' ? 'selected' : '' ?>>暢通（綠）</option>
                            <option value="busy" <?= ($SET['server_status'] ?? '') === 'busy' ? 'selected' : '' ?>>繁忙（黃）</option>
                            <option value="offline" <?= ($SET['server_status'] ?? '') === 'offline' ? 'selected' : '' ?>>維護中（紅）</option>
                        </select>
                        <label class="flex items-center gap-1.5 mt-1.5 text-[11px] text-slate-500 cursor-pointer select-none">
                            <input type="checkbox" name="set_show_server_status" value="1" class="w-3.5 h-3.5 accent-rose-700" <?= ($SET['show_server_status'] ?? '1') === '1' ? 'checked' : '' ?>>
                            顯示此區塊
                        </label>
                    </div>
                </div>

                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide">
                    <i class="fa-solid fa-heading text-sky-500"></i>
                    <span>主視覺與其他</span>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2">
                        <label class="na-label">主視覺標題（H1）</label>
                        <input type="text" name="set_hero_title" value="<?= news_h($SET['hero_title'] ?? '') ?>" class="na-input">
                    </div>
                    <div class="md:col-span-2">
                        <label class="na-label">主視覺副標說明</label>
                        <textarea name="set_hero_subtitle" rows="2" class="na-textarea"><?= news_h($SET['hero_subtitle'] ?? '') ?></textarea>
                    </div>
                    <div class="md:col-span-2">
                        <label class="na-label">飛鴿訂閱說明</label>
                        <textarea name="set_subscribe_blurb" rows="2" class="na-textarea"><?= news_h($SET['subscribe_blurb'] ?? '') ?></textarea>
                    </div>
                    <div>
                        <label class="na-label">列表每頁筆數</label>
                        <input type="number" name="set_list_page_size" value="<?= news_h($SET['list_page_size'] ?? '8') ?>" min="1" max="50" class="na-input">
                    </div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200">
                    <button type="submit" class="btn-vermilion px-5 py-2.5 text-sm font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1.5"></i>儲存設定</button>
                </div>
            </div>
            <div class="lg:col-span-4 glass-panel corner-accent rounded-xl p-5">
                <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-circle-info text-sky-600 mr-1.5"></i>設定說明</h2>
                <ul class="text-[11px] text-slate-500 space-y-2 leading-relaxed list-disc pl-4">
                    <li>版本號與維護時間會顯示於前台邸報頁首資訊卡。</li>
                    <li>全服線路狀態支援綠／黃／紅三色提示燈。</li>
                    <li>主視覺標題與副標為邸報首頁主文案。</li>
                    <li>列表每頁筆數影響前台分頁數量，建議 6～12。</li>
                    <li>所有變更即時生效，無需重新部署。</li>
                </ul>
                <div class="ink-divider my-4"></div>
                <div class="text-[11px] text-slate-400 font-mono">DB: <?= news_h(NEWS_DB_NAME) ?></div>
            </div>
        </form>
<?php elseif ($section === 'subscribers'): ?>
        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-violet-50 border border-violet-200 flex items-center justify-center text-violet-700"><i class="fa-solid fa-envelope-open-text"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">飛鴿傳書訂閱名單</h2>
                        <p class="text-[11px] text-slate-500">有效訂閱 <?= (int)$stats['subs'] ?> 筆 · 共 <?= count($subs) ?> 筆顯示</p>
                    </div>
                </div>
                <form method="GET" action="news_admin.php" class="flex gap-2">
                    <input type="hidden" name="section" value="subscribers">
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                        <input type="text" name="subq" value="<?= news_h($subSearch) ?>" placeholder="搜尋信箱..." class="na-input pl-9 w-56">
                    </div>
                    <button type="submit" class="btn-ice px-4 py-2 text-xs font-semibold rounded-lg">搜尋</button>
                </form>
            </div>
            <div class="overflow-x-auto rounded-lg border border-slate-200">
                <table class="na-table">
                    <thead><tr><th>#</th><th>訂閱信箱</th><th>來源</th><th>狀態</th><th>訂閱時間</th><th class="text-right">操作</th></tr></thead>
                    <tbody>
                    <?php if (empty($subs)): ?>
                        <tr><td colspan="6" class="text-center text-slate-400 py-8">尚無訂閱資料</td></tr>
                    <?php endif; ?>
                    <?php foreach ($subs as $s): ?>
                        <tr>
                            <td class="font-mono text-slate-400 text-[11px]">#<?= (int)$s['id'] ?></td>
                            <td class="font-mono text-slate-700"><?= news_h($s['email']) ?></td>
                            <td class="text-slate-500 text-[11px]"><?= news_h($s['source']) ?></td>
                            <td><span class="na-badge <?= (int)$s['is_active'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$s['is_active'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$s['is_active'] === 1 ? '有效' : '已停用' ?></span></td>
                            <td class="text-slate-500 text-[11px] font-mono"><?= news_h($s['created_at']) ?></td>
                            <td class="text-right whitespace-nowrap">
                                <form method="POST" action="news_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="subscriber_toggle">
                                    <input type="hidden" name="subscriber_id" value="<?= (int)$s['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid <?= (int)$s['is_active'] === 1 ? 'fa-toggle-on' : 'fa-toggle-off' ?>"></i></button>
                                </form>
                                <form method="POST" action="news_admin.php" class="inline" onsubmit="return naConfirmSubmit(this, '確定移除此訂閱信箱？');">
                                    <input type="hidden" name="form_token" value="<?= news_h($formToken) ?>">
                                    <input type="hidden" name="action" value="subscriber_delete">
                                    <input type="hidden" name="subscriber_id" value="<?= (int)$s['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php endif; ?>

    </main>

    <script>
        (function initSnow() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = (canvas.width = window.innerWidth);
            let height = (canvas.height = window.innerHeight);
            window.addEventListener('resize', () => { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; });
            const particles = [];
            const count = Math.min(Math.floor(window.innerWidth / 28), 42);
            for (let i = 0; i < count; i++) {
                particles.push({ x: Math.random() * width, y: Math.random() * height, radius: Math.random() * 2.0 + 0.6, speedY: Math.random() * 0.7 + 0.25, speedX: (Math.random() - 0.5) * 0.4, opacity: Math.random() * 0.6 + 0.2 });
            }
            function render() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    p.y += p.speedY; p.x += p.speedX;
                    if (p.y > height) { p.y = -5; p.x = Math.random() * width; }
                    if (p.x < 0) p.x = width; if (p.x > width) p.x = 0;
                    ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255,255,255,${p.opacity})`; ctx.shadowBlur = 4; ctx.shadowColor = 'rgba(255,255,255,0.5)'; ctx.fill();
                }
                requestAnimationFrame(render);
            }
            render();
        })();
        window.naConfirmSubmit = function (form, message) {
            if (!message || window.confirm(message)) { form.submit(); }
            return false;
        };
    </script>

    <script>
        /* ============================================================
         *  公告內文 富文本編輯器（所見即所得 / 代碼模式）
         * ============================================================ */
        (function initNewsEditor() {
            const wysiwyg = document.getElementById('na-content-wysiwyg');
            const code = document.getElementById('na-content-code');
            if (!wysiwyg || !code) return;

            let savedRange = null;
            let currentMode = 'wysiwyg';

            window.naSyncEditor = function () {
                if (currentMode === 'wysiwyg') { code.value = wysiwyg.innerHTML; }
            };
            window.naEditorMode = function (mode) {
                currentMode = mode;
                document.querySelectorAll('.na-mode-btn').forEach(function (b) {
                    b.classList.toggle('is-active', b.getAttribute('data-mode') === mode);
                });
                if (mode === 'code') {
                    code.value = wysiwyg.innerHTML;
                    wysiwyg.style.display = 'none';
                    code.style.display = 'block';
                } else {
                    wysiwyg.innerHTML = code.value;
                    code.style.display = 'none';
                    wysiwyg.style.display = 'block';
                }
            };

            function restoreSel() {
                wysiwyg.focus();
                if (savedRange) {
                    try {
                        const sel = window.getSelection();
                        sel.removeAllRanges();
                        sel.addRange(savedRange);
                    } catch (e) { /* ignore */ }
                }
            }
            function styleWithCss() {
                try { document.execCommand('styleWithCSS', false, true); } catch (e) { /* ignore */ }
            }
            window.naExec = function (cmd) {
                restoreSel();
                styleWithCss();
                document.execCommand(cmd, false, null);
                window.naSyncEditor();
            };
            window.naBlock = function (tag) {
                if (!tag) return;
                restoreSel();
                document.execCommand('formatBlock', false, '<' + tag + '>');
                window.naSyncEditor();
            };
            function wrapSelection(makeNode) {
                restoreSel();
                const sel = window.getSelection();
                if (!sel || !sel.rangeCount) { return false; }
                const range = sel.getRangeAt(0);
                if (range.collapsed) { return false; }
                const node = makeNode();
                try {
                    range.surroundContents(node);
                } catch (e) {
                    const frag = range.extractContents();
                    node.appendChild(frag);
                    range.insertNode(node);
                }
                sel.removeAllRanges();
                const nr = document.createRange();
                nr.selectNodeContents(node);
                sel.addRange(nr);
                window.naSyncEditor();
                return true;
            }
            window.naInline = function (prop, value) {
                if (!value) return;
                wrapSelection(function () {
                    const span = document.createElement('span');
                    span.style[prop] = value;
                    return span;
                });
            };
            window.naInlineTag = function (tag) {
                wrapSelection(function () { return document.createElement(tag); });
            };
            window.naColor = function (cmd, value) {
                restoreSel();
                styleWithCss();
                if (cmd === 'hiliteColor') {
                    if (!document.execCommand('hiliteColor', false, value)) {
                        document.execCommand('backColor', false, value);
                    }
                } else {
                    document.execCommand(cmd, false, value);
                }
                window.naSyncEditor();
            };
            window.naInsertHtml = function (html) {
                restoreSel();
                document.execCommand('insertHTML', false, html);
                window.naSyncEditor();
            };
            window.naClearFormat = function () {
                restoreSel();
                document.execCommand('removeFormat');
                document.execCommand('formatBlock', false, '<p>');
                window.naSyncEditor();
            };

            function esc(s) {
                return String(s == null ? '' : s)
                    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
                    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
            }
            function val(sel) { const el = document.querySelector(sel); return el ? el.value.trim() : ''; }
            function checked(sel) { const el = document.querySelector(sel); return !!(el && el.checked); }

            /* ---------- 圖片上傳 ---------- */
            function uploadFile(file, onDone) {
                const fd = new FormData();
                fd.append('file', file);
                fetch('news_upload.php', { method: 'POST', body: fd, credentials: 'same-origin' })
                    .then(function (r) { return r.json(); })
                    .then(function (d) { onDone(d && d.ok ? d : { ok: false, error: (d && d.error) || '上傳失敗' }); })
                    .catch(function () { onDone({ ok: false, error: '網路錯誤' }); });
            }
            window.naUploadImage = function (file) {
                if (!file) return;
                uploadFile(file, function (d) {
                    if (d.ok) { window.naInsertHtml('<img src="' + esc(d.url) + '" alt="">'); }
                    else { alert('圖片上傳失敗：' + d.error); }
                });
            };

            /* ---------- 貼上 / 拖曳 ---------- */
            wysiwyg.addEventListener('paste', function (e) {
                const items = (e.clipboardData || window.clipboardData).items || [];
                for (let i = 0; i < items.length; i++) {
                    if (items[i].type && items[i].type.indexOf('image') === 0) {
                        e.preventDefault();
                        window.naUploadImage(items[i].getAsFile());
                        return;
                    }
                }
                e.preventDefault();
                const text = (e.clipboardData || window.clipboardData).getData('text/plain');
                document.execCommand('insertText', false, text);
                window.naSyncEditor();
            });
            wysiwyg.addEventListener('dragover', function (e) { e.preventDefault(); wysiwyg.classList.add('is-dragover'); });
            wysiwyg.addEventListener('dragleave', function () { wysiwyg.classList.remove('is-dragover'); });
            wysiwyg.addEventListener('drop', function (e) {
                e.preventDefault();
                wysiwyg.classList.remove('is-dragover');
                const files = e.dataTransfer && e.dataTransfer.files;
                if (files && files.length) {
                    for (let i = 0; i < files.length; i++) {
                        if (files[i].type.indexOf('image') === 0) { window.naUploadImage(files[i]); }
                    }
                }
            });

            /* ---------- 媒體 / 連結 / 表格 子視窗 ---------- */
            let mediaType = null;
            const modal = document.getElementById('na-media-modal');
            const modalBody = document.getElementById('na-media-body');
            const modalTitle = document.getElementById('na-media-title');

            const bodies = {
                link:
                    '<label class="na-label">連結文字</label>' +
                    '<input id="na-link-text" class="na-input" placeholder="未選取文字時顯示的文字">' +
                    '<label class="na-label">連結網址</label>' +
                    '<input id="na-link-url" class="na-input" placeholder="https://...">' +
                    '<label class="flex items-center gap-2 mt-3 text-[11px] text-slate-600"><input type="checkbox" id="na-link-blank" checked> 另開新視窗</label>',
                image:
                    '<label class="na-label">圖片網址</label>' +
                    '<input id="na-img-url" class="na-input" placeholder="https://... 或上傳後自動填入">' +
                    '<div class="na-thumb" id="na-img-thumb"><img id="na-img-preview" src="" alt=""></div>' +
                    '<label class="na-label">或上傳圖片（JPG / PNG / GIF / WEBP，≤ 5MB）</label>' +
                    '<input type="file" id="na-img-file" accept="image/*" class="na-input">' +
                    '<div class="na-help" id="na-img-status"></div>' +
                    '<label class="na-label">替代文字 alt</label>' +
                    '<input id="na-img-alt" class="na-input" placeholder="圖片說明（選填）">' +
                    '<label class="na-label">寬度（選填，如 100%、600px）</label>' +
                    '<input id="na-img-width" class="na-input" placeholder="100%">',
                video:
                    '<label class="na-label">影片網址</label>' +
                    '<input id="na-vid-url" class="na-input" placeholder="YouTube / Vimeo / .mp4 網址">' +
                    '<p class="na-help">支援 YouTube、Vimeo 連結，或直接影片檔（.mp4 / .webm / .ogg）。</p>' +
                    '<label class="na-label">標題（選填）</label>' +
                    '<input id="na-vid-title" class="na-input" placeholder="影片標題">',
                table:
                    '<div class="grid grid-cols-2 gap-3">' +
                    '<div><label class="na-label">列數</label><input type="number" id="na-tb-rows" value="3" min="1" max="30" class="na-input"></div>' +
                    '<div><label class="na-label">欄數</label><input type="number" id="na-tb-cols" value="3" min="1" max="10" class="na-input"></div>' +
                    '</div>' +
                    '<label class="flex items-center gap-2 mt-3 text-[11px] text-slate-600"><input type="checkbox" id="na-tb-head" checked> 首列作為表頭</label>'
            };
            const titles = {
                link: '<i class="fa-solid fa-link mr-1.5"></i>插入連結',
                image: '<i class="fa-solid fa-image mr-1.5"></i>插入圖片',
                video: '<i class="fa-solid fa-video mr-1.5"></i>插入影片',
                table: '<i class="fa-solid fa-table mr-1.5"></i>插入表格'
            };

            window.naOpenMedia = function (type) {
                mediaType = type;
                modalTitle.innerHTML = titles[type] || '插入內容';
                modalBody.innerHTML = bodies[type] || '';
                modal.style.display = 'flex';
                if (type === 'image') {
                    const fileEl = document.getElementById('na-img-file');
                    const urlEl = document.getElementById('na-img-url');
                    const thumb = document.getElementById('na-img-thumb');
                    const preview = document.getElementById('na-img-preview');
                    const status = document.getElementById('na-img-status');
                    urlEl.addEventListener('input', function () {
                        if (urlEl.value.trim()) { preview.src = urlEl.value.trim(); thumb.style.display = 'block'; }
                        else { thumb.style.display = 'none'; }
                    });
                    fileEl.addEventListener('change', function () {
                        const f = fileEl.files && fileEl.files[0];
                        if (!f) return;
                        status.textContent = '上傳中…';
                        uploadFile(f, function (d) {
                            if (d.ok) {
                                urlEl.value = d.url; preview.src = d.url; thumb.style.display = 'block'; status.textContent = '上傳完成。';
                            } else { status.textContent = '上傳失敗：' + d.error; }
                        });
                    });
                }
                const first = modalBody.querySelector('input,select,textarea');
                if (first) { setTimeout(function () { first.focus(); }, 30); }
            };
            window.naCloseMedia = function () { modal.style.display = 'none'; };

            function videoEmbed(url) {
                let m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/))([\w-]{6,})/i);
                if (m) { return '<iframe src="https://www.youtube.com/embed/' + m[1] + '" title="YouTube 影片" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'; }
                m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
                if (m) { return '<iframe src="https://player.vimeo.com/video/' + m[1] + '" title="Vimeo 影片" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe>'; }
                if (/\.(mp4|webm|ogg)(\?.*)?$/i.test(url)) { return '<video controls src="' + esc(url) + '" style="width:100%"></video>'; }
                return '<iframe src="' + esc(url) + '" title="影片" frameborder="0" allowfullscreen></iframe>';
            }

            window.naSubmitMedia = function () {
                let html = '';
                if (mediaType === 'link') {
                    const url = val('#na-link-url');
                    if (!url) { alert('請輸入連結網址。'); return; }
                    const blank = checked('#na-link-blank');
                    const text = val('#na-link-text');
                    const target = blank ? ' target="_blank" rel="noopener"' : '';
                    if (savedRange && !savedRange.collapsed) {
                        restoreSel();
                        document.execCommand('createLink', false, url);
                        if (blank) {
                            try {
                                const nodes = wysiwyg.querySelectorAll('a[href="' + url.replace(/"/g, '\\"') + '"]');
                                nodes.forEach(function (a) { a.target = '_blank'; a.rel = 'noopener'; });
                            } catch (e) { /* ignore */ }
                        }
                        window.naSyncEditor();
                    } else {
                        html = '<a href="' + esc(url) + '"' + target + '>' + esc(text || url) + '</a>';
                    }
                } else if (mediaType === 'image') {
                    const url = val('#na-img-url');
                    if (!url) { alert('請輸入圖片網址或上傳圖片。'); return; }
                    const alt = val('#na-img-alt');
                    const w = val('#na-img-width');
                    html = '<img src="' + esc(url) + '" alt="' + esc(alt) + '"' + (w ? ' style="width:' + esc(w) + '"' : '') + '>';
                } else if (mediaType === 'video') {
                    const url = val('#na-vid-url');
                    if (!url) { alert('請輸入影片網址。'); return; }
                    const title = val('#na-vid-title');
                    html = videoEmbed(url);
                    if (title) { html = '<figure>' + html + '<figcaption style="text-align:center;font-size:13px;color:#64748b;margin-top:.3rem;">' + esc(title) + '</figcaption></figure>'; }
                } else if (mediaType === 'table') {
                    const rows = Math.max(1, Math.min(30, parseInt(val('#na-tb-rows') || '3', 10) || 3));
                    const cols = Math.max(1, Math.min(10, parseInt(val('#na-tb-cols') || '3', 10) || 3));
                    const hasHead = checked('#na-tb-head');
                    html = '<table>';
                    for (let r = 0; r < rows; r++) {
                        html += '<tr>';
                        for (let c = 0; c < cols; c++) {
                            html += (hasHead && r === 0) ? '<th>標題</th>' : '<td>&nbsp;</td>';
                        }
                        html += '</tr>';
                    }
                    html += '</table>';
                }
                if (html) { window.naInsertHtml(html); }
                window.naCloseMedia();
            };

            // 點擊遮罩關閉
            modal.addEventListener('click', function (e) { if (e.target === modal) { window.naCloseMedia(); } });
            document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && modal.style.display === 'flex') { window.naCloseMedia(); } });

            /* ---------- 追蹤選取範圍 ---------- */
            document.addEventListener('selectionchange', function () {
                const sel = window.getSelection();
                if (sel && sel.rangeCount) {
                    const node = sel.anchorNode;
                    if (node && wysiwyg.contains(node)) {
                        try { savedRange = sel.getRangeAt(0).cloneRange(); } catch (e) { /* ignore */ }
                    }
                }
            });

            /* ---------- 初始化 ---------- */
            styleWithCss();
            wysiwyg.innerHTML = code.value;
            wysiwyg.addEventListener('input', window.naSyncEditor);
            const form = wysiwyg.closest('form');
            if (form) { form.addEventListener('submit', function () { window.naSyncEditor(); }); }
        })();
    </script>
</body>
</html>


