<?php
/**
 * =============================================================
 *  踏雪笑傲 · 自動備份工具庫
 *  -------------------------------------------------------------
 *  由 admin/backup_admin.php 載入使用。
 *  功能：資料庫匯出（mysqldump / 純 PHP）、gzip 壓縮、
 *        備份歷程記錄、保留份數清理、備份還原。
 *  備份存放：admin/backups
 * =============================================================
 */

if (!defined('BK_DIR')) {
    define('BK_DIR', __DIR__ . '/backups');
}
if (!defined('BK_INDEX')) {
    define('BK_INDEX', BK_DIR . '/index.json');
}
if (!defined('BK_SETTINGS')) {
    define('BK_SETTINGS', BK_DIR . '/settings.json');
}

function bk_ensure_dir()
{
    if (!is_dir(BK_DIR)) {
        @mkdir(BK_DIR, 0775, true);
    }
    if (!is_dir(BK_DIR)) {
        return false;
    }
    $ht = BK_DIR . '/.htaccess';
    if (!file_exists($ht)) {
        @file_put_contents(
            $ht,
            "Require all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n"
        );
    }
    $ix = BK_DIR . '/index.html';
    if (!file_exists($ix)) {
        @file_put_contents($ix, '');
    }
    return true;
}

function bk_read_json($file, $fallback)
{
    if (!is_file($file)) {
        return $fallback;
    }
    $raw = @file_get_contents($file);
    if ($raw === false || $raw === '') {
        return $fallback;
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $fallback;
}

function bk_write_json($file, $data)
{
    return @file_put_contents(
        $file,
        json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
        LOCK_EX
    ) !== false;
}

function bk_default_settings()
{
    $defaultDb = isset($GLOBALS['DBName']) ? (string)$GLOBALS['DBName'] : '';
    return [
        'enabled'        => 1,
        'interval_value' => 1,
        'interval_unit'  => 'days',
        'retention'      => 10,
        'last_auto_run'  => 0,
        'databases'      => ($defaultDb !== '') ? [$defaultDb] : [],
    ];
}

function bk_settings()
{
    $s = bk_read_json(BK_SETTINGS, []);
    $merged = array_merge(bk_default_settings(), is_array($s) ? $s : []);
    if (!is_array($merged['databases'])) {
        $merged['databases'] = [];
    }
    return $merged;
}

/** 系統資料庫（預設不列入備份清單） */
function bk_system_databases()
{
    return ['information_schema', 'mysql', 'performance_schema', 'sys'];
}

/**
 * 偵測伺服器上所有資料庫（含大小與資料表數量）。
 * @return array<int,array{name:string,charset:string,size:int,tables:int,is_system:bool}>
 */
function bk_list_databases($Link, $includeSystem = false)
{
    $result = [];
    $sql = "SELECT s.SCHEMA_NAME AS name,
                   s.DEFAULT_CHARACTER_SET_NAME AS charset,
                   COALESCE(SUM(t.data_length + t.index_length), 0) AS size,
                   COUNT(t.TABLE_NAME) AS tables
            FROM information_schema.SCHEMATA s
            LEFT JOIN information_schema.TABLES t ON t.TABLE_SCHEMA = s.SCHEMA_NAME
            GROUP BY s.SCHEMA_NAME, s.DEFAULT_CHARACTER_SET_NAME
            ORDER BY s.SCHEMA_NAME";
    $res = $Link->query($sql);
    if (!$res) {
        return $result;
    }
    $system = bk_system_databases();
    while ($row = $res->fetch_assoc()) {
        $name = (string)$row['name'];
        $isSystem = in_array($name, $system, true);
        if ($isSystem && !$includeSystem) {
            continue;
        }
        $result[] = [
            'name'      => $name,
            'charset'   => (string)$row['charset'],
            'size'      => (int)$row['size'],
            'tables'    => (int)$row['tables'],
            'is_system' => $isSystem,
        ];
    }
    return $result;
}

/** 過濾出實際上存在且允許備份的資料庫名稱 */
function bk_normalize_databases($names, $available)
{
    $names = is_array($names) ? $names : [];
    $clean = [];
    foreach ($names as $n) {
        $n = (string)$n;
        if ($n !== '' && !in_array($n, $clean, true)) {
            $clean[] = $n;
        }
    }
    if (empty($available)) {
        return $clean;
    }
    $avail = [];
    foreach ($available as $a) {
        $avail[(string)($a['name'] ?? $a)] = true;
    }
    $out = [];
    foreach ($clean as $n) {
        if (isset($avail[$n])) {
            $out[] = $n;
        }
    }
    return $out;
}

/** 取得資料庫預設字元集與定序 */
function bk_db_charset($Link, $dbName)
{
    $charset = 'utf8mb4';
    $collation = 'utf8mb4_general_ci';
    $stmt = $Link->prepare("SELECT DEFAULT_CHARACTER_SET_NAME AS c, DEFAULT_COLLATION_NAME AS o
                            FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $dbName);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $charset = (string)$row['c'];
            $collation = (string)$row['o'];
        }
    }
    return [$charset, $collation];
}

/** 彙總多個資料庫的大小與資料表數量 */
function bk_databases_info($Link, $databases)
{
    $total = ['size' => 0.0, 'tables' => 0, 'count' => 0];
    foreach ((array)$databases as $db) {
        $info = bk_db_info($Link, $db);
        $total['size'] += $info['size'];
        $total['tables'] += $info['tables'];
        $total['count']++;
    }
    return $total;
}

function bk_save_settings($s)
{
    return bk_write_json(BK_SETTINGS, $s);
}

function bk_interval_seconds($s)
{
    $v = max(1, (int)($s['interval_value'] ?? 1));
    switch ($s['interval_unit'] ?? 'days') {
        case 'minutes':
            return $v * 60;
        case 'hours':
            return $v * 3600;
        case 'days':
        default:
            return $v * 86400;
    }
}

function bk_interval_label($s)
{
    $units = ['minutes' => '分鐘', 'hours' => '小時', 'days' => '天'];
    $v = max(1, (int)($s['interval_value'] ?? 1));
    $u = $units[$s['interval_unit'] ?? 'days'] ?? '天';
    return '每 ' . $v . ' ' . $u;
}

function bk_history()
{
    $h = bk_read_json(BK_INDEX, []);
    return is_array($h) ? $h : [];
}

function bk_save_history($h)
{
    return bk_write_json(BK_INDEX, array_values($h));
}

function bk_find($id)
{
    foreach (bk_history() as $row) {
        if (($row['id'] ?? '') === $id) {
            return $row;
        }
    }
    return null;
}

function bk_format_bytes($bytes, $precision = 2)
{
    $bytes = (float)$bytes;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) {
        $bytes /= 1024;
        $i++;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}

function bk_h($v)
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function bk_format_duration($seconds)
{
    $seconds = (int)$seconds;
    if ($seconds < 0) {
        $seconds = 0;
    }
    if ($seconds < 60) {
        return $seconds . ' 秒';
    }
    if ($seconds < 3600) {
        return floor($seconds / 60) . ' 分 ' . ($seconds % 60) . ' 秒';
    }
    if ($seconds < 86400) {
        return floor($seconds / 3600) . ' 小時 ' . floor(($seconds % 3600) / 60) . ' 分';
    }
    return floor($seconds / 86400) . ' 天 ' . floor(($seconds % 86400) / 3600) . ' 小時';
}

/** 尋找外部工具（mysqldump / mysql） */
function bk_find_binary($kind)
{
    static $cache = [];
    if (array_key_exists($kind, $cache)) {
        return $cache[$kind];
    }
    $isWin = (stripos(PHP_OS, 'WIN') === 0);
    $name = ($kind === 'dump') ? 'mysqldump' : 'mysql';
    $patterns = [];
    if ($isWin) {
        if ($kind === 'dump') {
            $patterns = [
                'C:/ServBay/packages/mysql/*/bin/mysqldump.exe',
                'C:/ServBay/bin/mysqldump.exe',
            ];
        } else {
            $patterns = [
                'C:/ServBay/packages/defaultsqlserver/*/bin/mysql.exe',
                'C:/ServBay/packages/mysql/*/bin/mysql.exe',
                'C:/ServBay/bin/mysql.exe',
            ];
        }
    }
    foreach ($patterns as $p) {
        $found = glob($p);
        if (is_array($found) && count($found) > 0) {
            rsort($found);
            return $cache[$kind] = $found[0];
        }
    }
    $cmd = $isWin ? 'where ' . $name . ' 2>NUL' : 'command -v ' . $name . ' 2>/dev/null';
    $out = @shell_exec($cmd);
    if (is_string($out)) {
        foreach (preg_split('/\r?\n/', trim($out)) as $line) {
            $line = trim($line);
            if ($line !== '' && is_file($line)) {
                return $cache[$kind] = $line;
            }
        }
    }
    return $cache[$kind] = null;
}

function bk_can_exec()
{
    if (!function_exists('exec')) {
        return false;
    }
    $disabled = array_map('trim', explode(',', (string)ini_get('disable_functions')));
    return !in_array('exec', $disabled, true);
}

/** 資料庫大小與資料表數量 */
function bk_db_info($Link, $dbName)
{
    $info = ['size' => 0.0, 'tables' => 0];
    $sql = "SELECT COALESCE(SUM(data_length + index_length), 0) AS s, COUNT(*) AS c
            FROM information_schema.TABLES WHERE table_schema = ?";
    if ($stmt = $Link->prepare($sql)) {
        $stmt->bind_param('s', $dbName);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $info['size'] = (float)$row['s'];
            $info['tables'] = (int)$row['c'];
        }
    }
    return $info;
}

/** 匯出指定資料庫至 SQL 檔（優先 mysqldump，失敗改用純 PHP） */
function bk_export($Link, $sqlFile, $databases)
{
    global $DBHost, $DBUser, $DBPassword, $port;

    $databases = array_values(array_filter(array_map('strval', (array)$databases), 'strlen'));
    if (empty($databases)) {
        return [false, '未選擇任何資料庫'];
    }

    $dump = bk_find_binary('dump');
    if ($dump && bk_can_exec()) {
        $args = [
            '--host=' . $DBHost,
            '--port=' . (int)($port ?? 3306),
            '--user=' . $DBUser,
            '--password=' . $DBPassword,
            '--single-transaction',
            '--quick',
            '--routines',
            '--triggers',
            '--events',
            '--hex-blob',
            '--default-character-set=binary',
            '--result-file=' . $sqlFile,
            '--databases',
        ];
        foreach ($databases as $db) {
            $args[] = $db;
        }
        $cmd = escapeshellarg($dump) . ' ' . implode(' ', array_map('escapeshellarg', $args)) . ' 2>&1';
        $output = [];
        $code = 0;
        @exec($cmd, $output, $code);
        if ($code === 0 && is_file($sqlFile) && filesize($sqlFile) > 0) {
            return [true, 'mysqldump'];
        }
        $msg = trim(implode("\n", $output));
        $fallback = bk_export_php($Link, $sqlFile, $databases);
        if ($fallback[0]) {
            return $fallback;
        }
        return [false, '匯出失敗：' . ($msg !== '' ? $msg : 'mysqldump 執行錯誤')];
    }
    return bk_export_php($Link, $sqlFile, $databases);
}

/** 純 PHP 匯出多個資料庫（無外部工具時使用） */
function bk_export_php($Link, $sqlFile, $databases)
{
    $fh = @fopen($sqlFile, 'wb');
    if (!$fh) {
        return [false, '無法建立備份檔案（目錄權限不足）'];
    }
    $err = '';
    try {
        @$Link->query("SET NAMES binary");
        fwrite($fh, "-- 踏雪笑傲 資料庫備份（PHP 匯出）\n-- 產出時間：" . date('Y-m-d H:i:s') . "\n");
        fwrite($fh, "SET NAMES binary;\nSET FOREIGN_KEY_CHECKS=0;\n\n");

        foreach ((array)$databases as $db) {
            $dbSafe = str_replace('`', '``', (string)$db);
            [$charset, $collation] = bk_db_charset($Link, (string)$db);
            fwrite($fh, "--\n-- 資料庫：`{$dbSafe}`\n--\n");
            fwrite($fh, "CREATE DATABASE IF NOT EXISTS `{$dbSafe}` DEFAULT CHARACTER SET {$charset} COLLATE {$collation};\n");
            fwrite($fh, "USE `{$dbSafe}`;\n\n");

            $res = $Link->query("SHOW TABLES FROM `{$dbSafe}`");
            $list = [];
            if ($res) {
                while ($row = $res->fetch_row()) {
                    $list[] = $row[0];
                }
            }

            foreach ($list as $tbl) {
                $safe = str_replace('`', '``', (string)$tbl);
                $cr = $Link->query("SHOW CREATE TABLE `{$dbSafe}`.`{$safe}`");
                $createRow = $cr ? $cr->fetch_row() : null;
                fwrite($fh, "DROP TABLE IF EXISTS `{$safe}`;\n");
                if ($createRow && isset($createRow[1])) {
                    fwrite($fh, $createRow[1] . ";\n\n");
                }

                $columns = [];
                if ($d = $Link->query("SELECT * FROM `{$dbSafe}`.`{$safe}` LIMIT 0")) {
                    while ($f = $d->fetch_field()) {
                        $columns[] = $f->name;
                    }
                }
                if (empty($columns)) {
                    continue;
                }
                $colSql = '`' . implode('`,`', $columns) . '`';
                $d = $Link->query("SELECT * FROM `{$dbSafe}`.`{$safe}`");
                $buffer = [];
                if ($d) {
                    while ($row = $d->fetch_assoc()) {
                        $vals = [];
                        foreach ($columns as $c) {
                            $v = $row[$c];
                            $vals[] = ($v === null) ? 'NULL' : "'" . $Link->real_escape_string((string)$v) . "'";
                        }
                        $buffer[] = '(' . implode(',', $vals) . ')';
                        if (count($buffer) >= 200) {
                            fwrite($fh, "INSERT INTO `{$safe}` ($colSql) VALUES\n" . implode(",\n", $buffer) . ";\n");
                            $buffer = [];
                        }
                    }
                }
                if ($buffer) {
                    fwrite($fh, "INSERT INTO `{$safe}` ($colSql) VALUES\n" . implode(",\n", $buffer) . ";\n");
                }
                fwrite($fh, "\n");
            }
        }
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
    fclose($fh);
    if ($err !== '') {
        return [false, '匯出失敗：' . $err];
    }
    return [true, 'php'];
}

function bk_gzip($src, $dst)
{
    $in = @fopen($src, 'rb');
    if (!$in) {
        return false;
    }
    $out = @gzopen($dst, 'wb9');
    if (!$out) {
        fclose($in);
        return false;
    }
    while (!feof($in)) {
        $chunk = fread($in, 262144);
        if ($chunk === false) {
            break;
        }
        if ($chunk === '') {
            continue;
        }
        gzwrite($out, $chunk);
    }
    fclose($in);
    gzclose($out);
    return true;
}

function bk_gunzip($src, $dst)
{
    $in = @gzopen($src, 'rb');
    if (!$in) {
        return false;
    }
    $out = @fopen($dst, 'wb');
    if (!$out) {
        gzclose($in);
        return false;
    }
    while (!gzeof($in)) {
        $chunk = gzread($in, 262144);
        if ($chunk === false) {
            break;
        }
        fwrite($out, $chunk);
    }
    gzclose($in);
    fclose($out);
    return true;
}

/** 取得歷程記錄中的所有檔案（相容舊版單檔記錄） */
function bk_record_files($rec)
{
    $files = [];
    if (!empty($rec['files']) && is_array($rec['files'])) {
        $idx = 0;
        foreach ($rec['files'] as $f) {
            if (is_string($f)) {
                $f = ['file' => $f];
            }
            if (!is_array($f)) {
                continue;
            }
            $files[] = [
                'file'    => (string)($f['file'] ?? ''),
                'db'      => (string)($f['db'] ?? ($rec['databases'][$idx] ?? '')),
                'size'    => (int)($f['size'] ?? 0),
                'tables'  => (int)($f['tables'] ?? 0),
                'method'  => (string)($f['method'] ?? ($rec['method'] ?? '')),
                'status'  => (string)($f['status'] ?? 'success'),
                'message' => (string)($f['message'] ?? ''),
            ];
            $idx++;
        }
    } elseif (!empty($rec['file'])) {
        $files[] = [
            'file'    => (string)$rec['file'],
            'db'      => (string)($rec['databases'][0] ?? ''),
            'size'    => (int)($rec['size'] ?? 0),
            'tables'  => (int)($rec['tables'] ?? 0),
            'method'  => (string)($rec['method'] ?? ''),
            'status'  => (($rec['status'] ?? '') === 'success' ? 'success' : 'failed'),
            'message' => (string)($rec['message'] ?? ''),
        ];
    }
    return $files;
}

/** 刪除某筆記錄的所有備份檔 */
function bk_delete_record_files($rec)
{
    foreach (bk_record_files($rec) as $f) {
        $p = BK_DIR . '/' . basename((string)$f['file']);
        if ($f['file'] !== '' && is_file($p)) {
            @unlink($p);
        }
    }
}

/**
 * 執行一次備份：每個資料庫各產生一個獨立的 .sql.gz 檔，
 * 但屬於同一筆歷程記錄。回傳該筆記錄。
 */
function bk_run_backup($Link, $type, $databases = [])
{
    global $DBName;
    bk_ensure_dir();

    $databases = array_values(array_filter(array_map('strval', (array)$databases), 'strlen'));
    if (empty($databases)) {
        $databases = [$DBName];
    }

    $start = microtime(true);
    $batchLabel = (count($databases) === 1) ? $databases[0] : ('multidb' . count($databases));
    $batchLabel = preg_replace('/[^A-Za-z0-9_\-]/', '_', $batchLabel);
    $stamp = date('Ymd_His') . '_' . bin2hex(random_bytes(3));

    $files = [];
    $totalSize = 0;
    $totalTables = 0;
    $methods = [];
    $anySuccess = false;
    $anyFail = false;
    $errors = [];
    $i = 0;

    foreach ($databases as $db) {
        $i++;
        $info = bk_db_info($Link, $db);
        $totalTables += (int)$info['tables'];
        $safeDb = preg_replace('/[^A-Za-z0-9_\-]/', '_', (string)$db);
        $base = $batchLabel . '_' . $stamp . '_' . $i . '_' . $safeDb;
        $sqlFile = BK_DIR . '/' . $base . '.sql';
        $gzFile  = BK_DIR . '/' . $base . '.sql.gz';

        $res = bk_export($Link, $sqlFile, [$db]);
        $entry = [
            'file'    => basename($gzFile),
            'db'      => (string)$db,
            'size'    => 0,
            'tables'  => (int)$info['tables'],
            'method'  => (string)($res[1] ?? ''),
            'status'  => 'failed',
            'message' => '',
        ];

        if ($res[0] && is_file($sqlFile)) {
            if (bk_gzip($sqlFile, $gzFile)) {
                $entry['size'] = (int)filesize($gzFile);
                $entry['status'] = 'success';
                $anySuccess = true;
                $methods[] = (string)$res[1];
                @unlink($sqlFile);
            } else {
                $entry['message'] = '壓縮失敗';
                @unlink($sqlFile);
                @unlink($gzFile);
                $anyFail = true;
                $errors[] = $db . '：壓縮失敗';
            }
        } else {
            $entry['message'] = (string)($res[1] ?? '匯出失敗');
            $anyFail = true;
            $errors[] = $db . '：' . $entry['message'];
        }

        $totalSize += (int)$entry['size'];
        $files[] = $entry;
    }

    if (!$anySuccess) {
        $status = 'failed';
    } elseif ($anyFail) {
        $status = 'partial';
    } else {
        $status = 'success';
    }

    $record = [
        'id'         => bin2hex(random_bytes(8)),
        'type'       => $type,
        'created_at' => date('Y-m-d H:i:s'),
        'created_ts' => time(),
        'size'       => $totalSize,
        'duration'   => round(microtime(true) - $start, 2),
        'databases'  => $databases,
        'db_count'   => count($databases),
        'tables'     => $totalTables,
        'method'     => implode('/', array_values(array_unique($methods))),
        'status'     => $status,
        'message'    => implode('；', $errors),
        'files'      => $files,
    ];

    $history = bk_history();
    array_unshift($history, $record);

    /* 依保留份數清理（成功的備份「筆數」保留 N 筆，超過者刪除其所有檔案） */
    $keep = max(1, (int)bk_settings()['retention']);
    $kept = [];
    $removed = [];
    $failed = [];
    foreach ($history as $h) {
        $st = (string)($h['status'] ?? '');
        if ($st === 'success' || $st === 'partial') {
            if (count($kept) < $keep) {
                $kept[] = $h;
            } else {
                $removed[] = $h;
            }
        } else {
            $failed[] = $h;
        }
    }
    foreach ($removed as $h) {
        bk_delete_record_files($h);
    }
    $final = array_merge($kept, $failed);
    usort($final, function ($a, $b) {
        return ((int)($b['created_ts'] ?? 0)) <=> ((int)($a['created_ts'] ?? 0));
    });
    if (count($final) > 100) {
        $final = array_slice($final, 0, 100);
    }
    bk_save_history($final);

    return $record;
}

/** 還原指定備份檔（優先 mysql 命令列，失敗改用純 PHP） */
function bk_restore($Link, $file)
{
    global $DBHost, $DBUser, $DBPassword, $DBName, $port;

    $path = BK_DIR . '/' . basename((string)$file);
    if (!is_file($path)) {
        return [false, '找不到備份檔案'];
    }
    $tmp = BK_DIR . '/.restore_' . bin2hex(random_bytes(4)) . '.sql';
    if (!bk_gunzip($path, $tmp)) {
        @unlink($tmp);
        return [false, '備份檔解壓縮失敗'];
    }

    $mysql = bk_find_binary('mysql');
    if ($mysql && bk_can_exec()) {
        /* 注意：不可加 --default-character-set=binary，該模式會停用 mysql
           用戶端的 DELIMITER 指令解析，導致預存程序／觸發器還原失敗。
           備份檔開頭已包含 SET NAMES binary，可確保位元組正確還原。 */
        $args = [
            '--host=' . $DBHost,
            '--port=' . (int)($port ?? 3306),
            '--user=' . $DBUser,
            '--password=' . $DBPassword,
            '--force',
            $DBName,
        ];
        $cmd = escapeshellarg($mysql) . ' ' . implode(' ', array_map('escapeshellarg', $args))
             . ' < ' . escapeshellarg($tmp) . ' 2>&1';
        $output = [];
        $code = 0;
        @exec($cmd, $output, $code);
        @unlink($tmp);
        if ($code === 0) {
            return [true, 'mysql'];
        }
        return [false, '還原失敗：' . trim(implode("\n", $output))];
    }

    $res = bk_import_php($Link, $tmp);
    @unlink($tmp);
    return $res;
}

/**
 * 還原一筆備份記錄。
 * @param string|null $onlyFile 僅還原指定檔案（null = 還原全部成功的檔案）
 */
function bk_restore_record($Link, $rec, $onlyFile = null)
{
    $files = bk_record_files($rec);
    if (!empty($onlyFile)) {
        $files = array_values(array_filter($files, function ($f) use ($onlyFile) {
            return (string)$f['file'] === (string)$onlyFile;
        }));
    }
    $files = array_values(array_filter($files, function ($f) {
        return ($f['status'] ?? 'success') === 'success' && $f['file'] !== '';
    }));
    if (empty($files)) {
        return [false, '此備份沒有可還原的檔案'];
    }

    $allOk = true;
    $parts = [];
    foreach ($files as $f) {
        $r = bk_restore($Link, (string)$f['file']);
        $ok = !empty($r[0]);
        if (!$ok) {
            $allOk = false;
        }
        $parts[] = ($ok ? '✓ ' : '✗ ') . ($f['db'] !== '' ? $f['db'] : $f['file']);
    }
    if ($allOk) {
        return [true, 'mysql'];
    }
    return [false, '部分資料庫還原失敗：' . implode('、', $parts)];
}

/** 純 PHP 匯入（解析 SQL 語句逐句執行） */
function bk_import_php($Link, $sqlFile)
{
    $fh = @fopen($sqlFile, 'rb');
    if (!$fh) {
        return [false, '無法讀取備份檔案'];
    }
    @$Link->query("SET NAMES binary");
    $stmt = '';
    $inString = false;
    $quote = '';
    $errors = [];

    while (($line = fgets($fh)) !== false) {
        $trim = ltrim($line);
        if (!$inString && ($trim === '' || strpos($trim, '--') === 0 || strpos($trim, '/*') === 0)) {
            continue;
        }
        $len = strlen($line);
        for ($i = 0; $i < $len; $i++) {
            $ch = $line[$i];
            if ($inString) {
                if ($ch === '\\') {
                    $stmt .= $ch;
                    if ($i + 1 < $len) {
                        $stmt .= $line[++$i];
                    }
                    continue;
                }
                if ($ch === $quote) {
                    $inString = false;
                }
                $stmt .= $ch;
            } else {
                if ($ch === "'" || $ch === '"') {
                    $inString = true;
                    $quote = $ch;
                    $stmt .= $ch;
                } elseif ($ch === ';') {
                    $q = trim($stmt);
                    if ($q !== '' && !$Link->query($q)) {
                        $errors[] = (string)$Link->error;
                    }
                    $stmt = '';
                } else {
                    $stmt .= $ch;
                }
            }
        }
        $stmt .= "\n";
    }
    fclose($fh);

    if (empty($errors)) {
        return [true, 'php'];
    }
    return [false, '還原時發生錯誤：' . implode('；', array_slice($errors, 0, 3))];
}
