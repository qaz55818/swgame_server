<?php
/**
 * ==============================================================
 *  GM 登入紀錄查詢 API（JSON）
 *  提供後台「登入管理」子視窗使用
 *    GET 參數：
 *      status  篩選：all / success / failed / blocked
 *      range   期間：today / 7 / 30 / all
 *      q       關鍵字（帳號 / IP）
 *      page    頁碼（預設 1）
 *      limit   每頁筆數（預設 20，上限 100）
 * ==============================================================
 */
session_start();
@include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../login_security.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['gm_username']) || $_SESSION['gm_username'] === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => '請先登入 GM 控制台。'], JSON_UNESCAPED_UNICODE);
    exit();
}

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => '資料庫連線失敗。'], JSON_UNESCAPED_UNICODE);
    exit();
}
mysqli_set_charset($Link, "utf8");

$status = (string)($_GET['status'] ?? 'all');
if (!in_array($status, ['all', 'success', 'failed', 'blocked'], true)) {
    $status = 'all';
}
$range = (string)($_GET['range'] ?? 'today');
if (!in_array($range, ['today', '7', '30', 'all'], true)) {
    $range = 'today';
}
$q = trim((string)($_GET['q'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1));
$limit = (int)($_GET['limit'] ?? 20);
if ($limit < 1) { $limit = 20; }
if ($limit > 100) { $limit = 100; }
$offset = ($page - 1) * $limit;

// 期間條件
$rangeWhere = '';
$rangeTypes = '';
$rangeParams = [];
if ($range === 'today') {
    $rangeWhere = " AND `created_at` >= CURDATE()";
} elseif ($range === '7') {
    $rangeWhere = " AND `created_at` >= NOW() - INTERVAL 7 DAY";
} elseif ($range === '30') {
    $rangeWhere = " AND `created_at` >= NOW() - INTERVAL 30 DAY";
}

$where = " WHERE 1" . $rangeWhere;
$types = $rangeTypes;
$params = $rangeParams;
if ($status !== 'all') {
    $where .= " AND `status` = ?";
    $types .= "s";
    $params[] = $status;
}
if ($q !== '') {
    $where .= " AND (`username` LIKE ? OR `ip` LIKE ?)";
    $like = '%' . $q . '%';
    $types .= "ss";
    $params[] = $like;
    $params[] = $like;
}

// 總筆數
$countSql = "SELECT COUNT(*) AS c FROM `login_logs`" . $where;
$stmt = $Link->prepare($countSql);
if ($types !== '') { $stmt->bind_param($types, ...$params); }
$stmt->execute();
$total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();
$pages = $total > 0 ? (int)ceil($total / $limit) : 0;
if ($pages > 0 && $page > $pages) {
    $page = $pages;
    $offset = ($page - 1) * $limit;
}

// 列表
$listSql = "SELECT `id`,`username`,`user_id`,`status`,`reason`,`ip`,`ip_forwarded`,`user_agent`,`created_at`
            FROM `login_logs`" . $where . " ORDER BY `id` DESC LIMIT ? OFFSET ?";
$stmt = $Link->prepare($listSql);
$listTypes = $types . "ii";
$listParams = $params;
$listParams[] = $limit;
$listParams[] = $offset;
$stmt->bind_param($listTypes, ...$listParams);
$stmt->execute();
$res = $stmt->get_result();
$logs = [];
while ($row = $res->fetch_assoc()) {
    $logs[] = [
        'id'        => (int)$row['id'],
        'username'  => $row['username'],
        'user_id'   => (int)$row['user_id'],
        'status'    => $row['status'],
        'reason'    => $row['reason'],
        'ip'        => $row['ip'],
        'forwarded' => $row['ip_forwarded'],
        'ua'        => mb_substr((string)$row['user_agent'], 0, 160),
        'created_at' => $row['created_at'],
    ];
}
$stmt->close();

// 統計（今日 / 近 7 日 / 目前鎖定）
$stats = [
    'today_total' => 0, 'today_success' => 0, 'today_failed' => 0, 'today_blocked' => 0,
    'unique_ips_today' => 0, 'week_success' => 0, 'week_failed' => 0,
    'active_blocked_ips' => 0, 'last_fail' => null,
];
$rs = mysqli_query(
    $Link,
    "SELECT
        COUNT(*) AS total,
        SUM(`status`='success') AS success_c,
        SUM(`status`='failed') AS failed_c,
        SUM(`status`='blocked') AS blocked_c,
        COUNT(DISTINCT `ip`) AS ips
     FROM `login_logs` WHERE `created_at` >= CURDATE()"
);
if ($rs && ($row = $rs->fetch_assoc())) {
    $stats['today_total'] = (int)$row['total'];
    $stats['today_success'] = (int)$row['success_c'];
    $stats['today_failed'] = (int)$row['failed_c'];
    $stats['today_blocked'] = (int)$row['blocked_c'];
    $stats['unique_ips_today'] = (int)$row['ips'];
}
$rs = mysqli_query(
    $Link,
    "SELECT
        SUM(`status`='success') AS success_c,
        SUM(`status`='failed') AS failed_c
     FROM `login_logs` WHERE `created_at` >= NOW() - INTERVAL 7 DAY"
);
if ($rs && ($row = $rs->fetch_assoc())) {
    $stats['week_success'] = (int)$row['success_c'];
    $stats['week_failed'] = (int)$row['failed_c'];
}
$rs = mysqli_query(
    $Link,
    "SELECT COUNT(*) AS c FROM (
        SELECT `ip` FROM `login_logs`
         WHERE `status` = 'failed' AND `ip` <> ''
           AND `created_at` >= NOW() - INTERVAL " . (int)LOGIN_WINDOW_MINUTES . " MINUTE
         GROUP BY `ip` HAVING COUNT(*) >= " . (int)LOGIN_MAX_IP_ATTEMPTS . "
     ) t"
);
if ($rs && ($row = $rs->fetch_assoc())) {
    $stats['active_blocked_ips'] = (int)$row['c'];
}
$rs = mysqli_query(
    $Link,
    "SELECT `username`,`ip`,`created_at` FROM `login_logs` WHERE `status` = 'failed' ORDER BY `id` DESC LIMIT 1"
);
if ($rs && ($row = $rs->fetch_assoc())) {
    $stats['last_fail'] = $row;
}

mysqli_close($Link);

echo json_encode([
    'ok'         => true,
    'logs'       => $logs,
    'total'      => $total,
    'page'       => $page,
    'pages'      => $pages,
    'status'     => $status,
    'range'      => $range,
    'q'          => $q,
    'server_now' => time(),
    'thresholds' => [
        'window_minutes'    => LOGIN_WINDOW_MINUTES,
        'max_ip_attempts'   => LOGIN_MAX_IP_ATTEMPTS,
        'max_user_attempts' => LOGIN_MAX_USER_ATTEMPTS,
    ],
    'stats'      => $stats,
], JSON_UNESCAPED_UNICODE);
