<?php
/**
 * =============================================================
 *  踏雪笑傲 · 江湖邸報管理 — 公告內文圖片上傳
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *  回傳 JSON：{ ok: true, url: '...' } 或 { ok: false, error: '...' }
 * =============================================================
 */
session_start();
require_once __DIR__ . '/../config.php';

header('Content-Type: application/json; charset=utf-8');

function na_upload_json(array $payload): void
{
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit();
}

if (!isset($_SESSION['gm_username'])) {
    http_response_code(403);
    na_upload_json(['ok' => false, 'error' => '未授權的操作']);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    na_upload_json(['ok' => false, 'error' => '不支援的請求方法']);
}

if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
    na_upload_json(['ok' => false, 'error' => '未收到檔案']);
}

$file = $_FILES['file'];
if ((int)$file['error'] !== UPLOAD_ERR_OK) {
    na_upload_json(['ok' => false, 'error' => '上傳失敗（錯誤碼 ' . (int)$file['error'] . '）']);
}
if ((int)$file['size'] > 5 * 1024 * 1024) {
    na_upload_json(['ok' => false, 'error' => '檔案超過 5MB 上限']);
}

$allowed = [
    'image/jpeg' => 'jpg',
    'image/png'  => 'png',
    'image/gif'  => 'gif',
    'image/webp' => 'webp',
];

$mime = '';
if (function_exists('finfo_open')) {
    $fi = finfo_open(FILEINFO_MIME_TYPE);
    if ($fi) {
        $mime = (string)finfo_file($fi, $file['tmp_name']);
        finfo_close($fi);
    }
}
if ($mime === '' && function_exists('getimagesize')) {
    $info = @getimagesize($file['tmp_name']);
    if ($info && !empty($info['mime'])) { $mime = (string)$info['mime']; }
}
if (!isset($allowed[$mime])) {
    na_upload_json(['ok' => false, 'error' => '僅允許 JPG / PNG / GIF / WEBP 圖片']);
}

$ext = $allowed[$mime];
$sub = date('Ym');
$baseDir = __DIR__ . '/../swo/assets/uploads/news';
$dir = $baseDir . '/' . $sub;
if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
    na_upload_json(['ok' => false, 'error' => '無法建立上傳目錄']);
}

$name = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
$dest = $dir . '/' . $name;
if (!@move_uploaded_file($file['tmp_name'], $dest)) {
    na_upload_json(['ok' => false, 'error' => '檔案寫入失敗']);
}
@chmod($dest, 0644);

// 相對於 swo/news.php 與 admin/news_admin.php 皆為上一層，故使用 ../swo/...
$url = '../swo/assets/uploads/news/' . $sub . '/' . $name;

na_upload_json(['ok' => true, 'url' => $url]);
