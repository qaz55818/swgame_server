<?php
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../permissions.php';
require_once __DIR__ . '/../account_tiers.php';
require_once __DIR__ . '/../currency.php';

// 需透過 gmlogin.php 以有效的 gm_accounts 登入後才能存取
if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
// 後台閒置逾時（8 小時）
app_session_enforce_timeout(60 * 60 * 8);
$currentGmUsername = $_SESSION['gm_username'];
$currentGmId = $_SESSION['gm_id'];

// 來自 gmopgen.xml 的完整操作類型代碼清單 - 將這些授權寫入 auth 資料表，
// 正是原本 exe 逐筆手動編輯所做的事。
$AllGmOperationTypes = [
    0,1,2,3,4,5,6,7,8,9,10,11,
    100,101,102,103,104,105,
    200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,
    501,502,503,504,505,506,507,508,509,510,511,512,513,514,515,516,517,518
];

if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['form_token'];

$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    http_response_code(500);
    exit('系統暫時無法使用，請稍後再試。');
}
// passwd 是以原始二進位儲存在 utf8 varchar 欄位 - latin1 可原樣傳遞位元組
mysqli_set_charset($Link, "latin1");

// 會員功能權限資料表（首次進入自動建立，並補齊既有會員預設列）
mysqli_set_charset($Link, "utf8mb4");
member_permissions_ensure_table($Link);
// 帳號層級資料表（首次進入自動建立並補上預設層級）
account_tier_ensure_tables($Link);
$allTiers = account_tiers_load_all($Link, false);
mysqli_set_charset($Link, "latin1");

$notice = "";
$noticeType = "success"; // or "danger"
$openRechargeModal = false; // 儲存儲值設定後自動重新開啟子視窗
$supportActionDone = false; // 是否剛執行申訴回報處理（供工單分頁顯示提示）

function refreshToken() {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
    return $_SESSION['form_token'];
}

/** 相對時間（供申訴回報儀表板顯示） */
function gm_ago($dt) {
    if (empty($dt) || $dt === '0000-00-00 00:00:00') { return '—'; }
    $ts = strtotime($dt);
    if ($ts === false) { return '—'; }
    $d = time() - $ts;
    if ($d < 0) { $d = 0; }
    if ($d < 60) { return '剛剛'; }
    if ($d < 3600) { return floor($d / 60) . ' 分鐘前'; }
    if ($d < 86400) { return floor($d / 3600) . ' 小時前'; }
    if ($d < 2592000) { return floor($d / 86400) . ' 天前'; }
    return date('Y-m-d', $ts);
}

/** 申訴回報：狀態對照表 */
function gm_support_status_map() {
    return [
        'open'         => ['label' => '待處理',     'badge' => 'bg-amber-50 text-amber-700 border-amber-200',      'dot' => 'bg-amber-500'],
        'processing'   => ['label' => '處理中',     'badge' => 'bg-sky-50 text-sky-700 border-sky-200',            'dot' => 'bg-sky-500'],
        'pending_user' => ['label' => '待會員回覆', 'badge' => 'bg-violet-50 text-violet-700 border-violet-200',   'dot' => 'bg-violet-500'],
        'resolved'     => ['label' => '已結案',     'badge' => 'bg-emerald-50 text-emerald-700 border-emerald-200','dot' => 'bg-emerald-500'],
        'closed'       => ['label' => '已關閉',     'badge' => 'bg-slate-100 text-slate-600 border-slate-300',     'dot' => 'bg-slate-400'],
    ];
}
/** 申訴回報：優先度對照表 */
function gm_support_priority_map() {
    return [
        'low'    => ['label' => '低',   'badge' => 'bg-slate-100 text-slate-500 border-slate-200'],
        'normal' => ['label' => '一般', 'badge' => 'bg-sky-50 text-sky-700 border-sky-200'],
        'high'   => ['label' => '高',   'badge' => 'bg-orange-50 text-orange-700 border-orange-200'],
        'urgent' => ['label' => '緊急', 'badge' => 'bg-rose-50 text-rose-700 border-rose-200'],
    ];
}
/** 寫入申訴回報管理操作歷程（對應 support_status_log） */
function gm_support_log($Link, $ticketId, $action, $opId, $opName, $oldStatus, $newStatus, $oldPriority, $newPriority, $assignedTo, $note) {
    try {
        $stmt = $Link->prepare(
            "INSERT INTO `support_status_log`
                (`ticket_id`,`action`,`operator_type`,`operator_id`,`operator_name`,`old_status`,`new_status`,`old_priority`,`new_priority`,`assigned_to`,`note`)
             VALUES (?,?, 'gm', ?,?,?,?,?,?,?,?)"
        );
        $stmt->bind_param("isisssssss", $ticketId, $action, $opId, $opName, $oldStatus, $newStatus, $oldPriority, $newPriority, $assignedTo, $note);
        $stmt->execute();
        $stmt->close();
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['form_token']) || $_POST['form_token'] !== $_SESSION['form_token']) {
        $notice = "你的工作階段已過期，請再試一次。";
        $noticeType = "danger";
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'addgm') {
            $newUsername = strtolower(trim($_POST['new_gm_username']));
            $newPassword = trim($_POST['new_gm_password']);

            if (strlen($newPassword) < 8) {
                $notice = "新 GM 密碼至少需 8 個字元。";
                $noticeType = "danger";
            } elseif (!preg_match("/^[a-zA-Z0-9_-]+$/", $newUsername)) {
                $notice = "GM 使用者名稱只能包含英文字母、數字、底線或連字號。";
                $noticeType = "danger";
            } else {
                $hash = password_hash($newPassword, PASSWORD_BCRYPT);
                $stmt = $Link->prepare("INSERT INTO gm_accounts (username, password_hash) VALUES (?, ?)");
                $stmt->bind_param("ss", $newUsername, $hash);
                if ($stmt->execute()) {
                    $notice = "已建立 GM 帳號「$newUsername」。";
                } else {
                    $notice = "建立 GM 帳號失敗（使用者名稱可能已存在）：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'deletegm') {
            $delId = (int)$_POST['gm_account_id'];
            if ($delId === (int)$currentGmId) {
                $notice = "你無法在以此帳號登入時刪除自己的帳號。";
                $noticeType = "danger";
            } else {
                $stmt = $Link->prepare("DELETE FROM gm_accounts WHERE id = ?");
                $stmt->bind_param("i", $delId);
                if ($stmt->execute()) {
                    $notice = "已移除 GM 帳號。";
                } else {
                    $notice = "移除 GM 帳號失敗：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'grantgm') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['gm_zoneid'];

            $stmt = $Link->prepare("INSERT IGNORE INTO auth (userid, zoneid, rid) VALUES (?, ?, ?)");
            $granted = 0;
            $failed = 0;
            foreach ($AllGmOperationTypes as $opType) {
                $stmt->bind_param("iii", $userid, $zoneid, $opType);
                if ($stmt->execute()) {
                    $granted++;
                } else {
                    $failed++;
                }
            }
            $stmt->close();
            if ($failed === 0) {
                $notice = "已將完整 GM 權限組（$granted 個操作類型）授權給區域 $zoneid 上的帳號 #$userid。";
            } else {
                $notice = "已授權 $granted 個操作類型，但有 $failed 個失敗 - 請檢查 zoneid/資料表結構。";
                $noticeType = "danger";
            }

        } elseif ($action === 'revokegm') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['gm_zoneid'];

            $stmt = $Link->prepare("DELETE FROM auth WHERE userid = ? AND zoneid = ?");
            $stmt->bind_param("ii", $userid, $zoneid);
            if ($stmt->execute()) {
                $affected = $stmt->affected_rows;
                $notice = "已撤銷區域 $zoneid 上帳號 #$userid 的 GM 權限（移除了 $affected 筆資料）。";
            } else {
                $notice = "撤銷失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'ban') {
            $userid = (int)$_POST['userid'];
            $type = (int)$_POST['ban_type'];
            $hours = (int)$_POST['ban_hours'];
            $reason = trim($_POST['ban_reason']);
            $forbidSeconds = $hours * 3600;

            $stmt = $Link->prepare("CALL addForbid(?, ?, ?, ?, ?)");
            $gmRoleId = 0;
            $stmt->bind_param("iiisi", $userid, $type, $forbidSeconds, $reason, $gmRoleId);
            if ($stmt->execute()) {
                $notice = "已封鎖帳號 #$userid（類型 $type，{$hours} 小時）。";
            } else {
                $notice = "封鎖失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'unban') {
            $userid = (int)$_POST['userid'];
            $type = (int)$_POST['unban_type'];
            $stmt = $Link->prepare("DELETE FROM forbid WHERE userid = ? AND type = ?");
            $stmt->bind_param("ii", $userid, $type);
            if ($stmt->execute()) {
                $notice = "已解除封鎖帳號 #$userid（類型 $type）。";
            } else {
                $notice = "解除封鎖失敗：";
                $noticeType = "danger";
            }
            $stmt->close();

        } elseif ($action === 'grant') {
            $userid = (int)$_POST['userid'];
            $zoneid = (int)$_POST['zoneid'];
            $aid = (int)$_POST['aid'];
            $points = (int)$_POST['points'];
            $cash = (int)$_POST['cash'];
            $status = 1;
            $sn = time(); // 近似唯一的交易序號

            $usecashQuery = "CALL usecash($userid, $zoneid, $sn, $aid, $points, $cash, $status, @error)";
            if (mysqli_query($Link, $usecashQuery)) {
                $notice = "已授予帳號 #$userid $points 點數 / $cash 現金。";
            } else {
                $notice = "授予失敗：";
                $noticeType = "danger";
            }

        } elseif ($action === 'wallet_adjust') {
            // 目標會員錢包（點數 / 元寶）發放或扣減，寫入 currency_ledger 流水
            $userid = (int)($_POST['userid'] ?? 0);
            $walletCurrency = (($_POST['wallet_currency'] ?? 'points') === 'yuanbao') ? 'yuanbao' : 'points';
            $direction = (($_POST['wallet_direction'] ?? 'grant') === 'deduct') ? 'deduct' : 'grant';
            $amount = abs((int)($_POST['wallet_amount'] ?? 0));
            $reason = trim((string)($_POST['wallet_reason'] ?? ''));
            $label = ($walletCurrency === 'yuanbao') ? '元寶' : '點數';

            if ($userid <= 0 || $amount <= 0) {
                $notice = "請輸入有效的數量（需大於 0）。";
                $noticeType = "danger";
            } else {
                $signed = ($direction === 'deduct') ? -$amount : $amount;
                $type = ($direction === 'deduct') ? 'admin_deduct' : 'admin_grant';
                $desc = ($reason !== '' ? $reason : ($direction === 'deduct' ? '管理員扣減' : '管理員發放')) . '（' . $label . '）';
                mysqli_set_charset($Link, "utf8mb4");
                $res = currency_add($Link, $userid, $walletCurrency, $signed, $type, '', $desc, $currentGmUsername);
                if ($res['ok'] && $walletCurrency === 'yuanbao') {
                    currency_sync_point($Link, $userid, $signed);
                }
                mysqli_set_charset($Link, "latin1");
                if ($res['ok']) {
                    $notice = "已" . ($direction === 'deduct' ? '扣減' : '發放') . " " . number_format($amount) . " $label，帳號 #$userid 目前餘額 " . number_format((int)$res['balance']) . "。";
                } else {
                    $notice = "錢包操作失敗：" . $res['message'];
                    $noticeType = "danger";
                }
            }

        } elseif ($action === 'resetpw') {
            $userid = (int)$_POST['userid'];
            $targetUsername = trim($_POST['target_username']);
            $newPass = trim($_POST['new_passwd']);

            if (strlen($newPass) < 4 || strlen($newPass) > 10) {
                $notice = "新密碼長度必須為 4-10 個字元。";
                $noticeType = "danger";
            } else {
                $newHash = md5($targetUsername . $newPass, true);
                $stmt = $Link->prepare("UPDATE users SET passwd = ? WHERE ID = ?");
                $stmt->bind_param("si", $newHash, $userid);
                if ($stmt->execute()) {
                    $notice = "已重設帳號 #$userid 的密碼。";
                } else {
                    $notice = "密碼重設失敗：";
                    $noticeType = "danger";
                }
                $stmt->close();
            }

        } elseif ($action === 'save_member_perms' || $action === 'save_member_perms_all' || $action === 'save_member_perms_none') {
            $userid = (int)$_POST['userid'];
            if ($userid <= 0) {
                $notice = "缺少目標會員編號，請重新選擇玩家。";
                $noticeType = "danger";
            } else {
                $keys = member_permission_keys();
                $values = [];
                foreach ($keys as $key) {
                    if ($action === 'save_member_perms_all') {
                        $values[$key] = 1;
                    } elseif ($action === 'save_member_perms_none') {
                        $values[$key] = 0;
                    } else {
                        $values[$key] = (isset($_POST['perm'][$key]) && (int)$_POST['perm'][$key] === 1) ? 1 : 0;
                    }
                }
                mysqli_set_charset($Link, "utf8mb4");
                $saved = member_permissions_save($Link, $userid, $values, $currentGmUsername);
                mysqli_set_charset($Link, "latin1");
                if ($saved) {
                    if ($action === 'save_member_perms_all') {
                        $notice = "已將帳號 #$userid 的所有會員功能權限設為「開放」。";
                    } elseif ($action === 'save_member_perms_none') {
                        $notice = "已將帳號 #$userid 的所有會員功能權限設為「停用」。";
                    } else {
                        $off = [];
                        $map = member_permission_map();
                        foreach ($keys as $key) {
                            if (!$values[$key]) {
                                $off[] = $map[$key]['label'] ?? $key;
                            }
                        }
                        $notice = "已更新帳號 #$userid 的會員功能權限設定。";
                        if ($off) {
                            $notice .= " 目前未開放：" . implode('、', $off) . "。";
                        }
                    }
                } else {
                    $notice = "會員功能權限儲存失敗，請稍後再試。";
                    $noticeType = "danger";
                }
            }

        } elseif ($action === 'save_account_data') {
            $userid = (int)$_POST['userid'];
            if ($userid <= 0) {
                $notice = "缺少目標會員編號，請重新選擇玩家。";
                $noticeType = "danger";
            } else {
                // 可編輯欄位白名單（欄位 => [資料庫欄名, 型別, 長度上限]）
                // name / passwd / passwd2 / ID / creatime 不在此編輯，避免破壞遊戲端登入相容性。
                $fieldMap = [
                    'acct_prompt'       => ['Prompt', 's', 32],
                    'acct_answer'       => ['answer', 's', 32],
                    'acct_truename'     => ['truename', 's', 32],
                    'acct_idnumber'     => ['idnumber', 's', 32],
                    'acct_email'        => ['email', 's', 64],
                    'acct_mobilenumber' => ['mobilenumber', 's', 32],
                    'acct_province'     => ['province', 's', 32],
                    'acct_city'         => ['city', 's', 32],
                    'acct_phonenumber'  => ['phonenumber', 's', 32],
                    'acct_address'      => ['address', 's', 64],
                    'acct_postalcode'   => ['postalcode', 's', 8],
                    'acct_gender'       => ['gender', 'i', 0],
                    'acct_birthday'     => ['birthday', 'dt', 0],
                    'acct_qq'           => ['qq', 's', 32],
                ];
                $sets = [];
                $types = '';
                $params = [];
                $invalidDate = '';
                foreach ($fieldMap as $field => [$col, $kind, $maxLen]) {
                    if (!array_key_exists($field, $_POST)) {
                        continue;
                    }
                    $val = trim((string)$_POST[$field]);
                    if ($kind === 'i') {
                        $sets[] = "`$col` = ?";
                        $types .= 'i';
                        $params[] = (int)$val;
                    } elseif ($kind === 'dt') {
                        if ($val === '') {
                            $sets[] = "`$col` = NULL";
                        } else {
                            $ts = strtotime($val);
                            if ($ts === false) {
                                $invalidDate = $col;
                                break;
                            }
                            $sets[] = "`$col` = ?";
                            $types .= 's';
                            $params[] = date('Y-m-d H:i:s', $ts);
                        }
                    } else {
                        if ($maxLen > 0) {
                            $val = mb_substr($val, 0, $maxLen);
                        }
                        $sets[] = "`$col` = ?";
                        $types .= 's';
                        $params[] = $val;
                    }
                }

                if ($invalidDate !== '') {
                    $notice = "「" . $invalidDate . "」日期格式不正確，請使用 YYYY-MM-DD HH:MM:SS。";
                    $noticeType = "danger";
                } elseif (!$sets) {
                    $notice = "沒有可更新的欄位。";
                    $noticeType = "danger";
                } else {
                    $params[] = $userid;
                    $types .= 'i';
                    $sql = "UPDATE `users` SET " . implode(', ', $sets) . " WHERE `ID` = ?";
                    mysqli_set_charset($Link, "utf8mb4");
                    try {
                        $stmt = $Link->prepare($sql);
                        $stmt->bind_param($types, ...$params);
                        $stmt->execute();
                        $stmt->close();
                        $notice = "已更新帳號 #$userid 的詳細資料（" . count($sets) . " 個欄位）。";
                    } catch (Throwable $e) {
                        $notice = "資料更新失敗，請確認輸入格式後再試。";
                        $noticeType = "danger";
                    }
                    mysqli_set_charset($Link, "latin1");
                }
            }

        } elseif ($action === 'support_action') {
            // 處理目標會員的申訴回報工單（狀態／優先度／指派／回覆／內部備註）
            $userid = (int)($_POST['userid'] ?? 0);
            $ticketId = (int)($_POST['ticket_id'] ?? 0);
            $sub = (string)($_POST['sub_action'] ?? '');
            $statusMap = gm_support_status_map();
            $prioMap = gm_support_priority_map();

            mysqli_set_charset($Link, "utf8mb4");
            $ticket = null;
            try {
                $stmt = $Link->prepare("SELECT * FROM `support_tickets` WHERE `id` = ? AND `uid` = ? LIMIT 1");
                $stmt->bind_param("ii", $ticketId, $userid);
                $stmt->execute();
                $ticket = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            } catch (Throwable $e) {
                $ticket = null;
            }

            if (!$ticket) {
                $notice = "找不到指定的回報單，或該工單不屬於此會員。";
                $noticeType = "danger";
            } else {
                $supportActionDone = true;
                try {
                    if ($sub === 'status') {
                        $newStatus = (string)($_POST['new_status'] ?? '');
                        $verdict = mb_substr(trim((string)($_POST['verdict'] ?? '')), 0, 200);
                        if (!isset($statusMap[$newStatus])) {
                            $notice = "無效的回報單狀態。";
                            $noticeType = "danger";
                        } else {
                            $old = (string)$ticket['status'];
                            if ($newStatus === 'resolved') {
                                $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=NOW(), `closed_at`=NULL WHERE `id`=?");
                                $stmt->bind_param("ssi", $newStatus, $verdict, $ticketId);
                            } elseif ($newStatus === 'closed') {
                                $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=IFNULL(`resolved_at`, NOW()), `closed_at`=NOW() WHERE `id`=?");
                                $stmt->bind_param("ssi", $newStatus, $verdict, $ticketId);
                            } else {
                                $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=NULL, `closed_at`=NULL WHERE `id`=?");
                                $stmt->bind_param("ssi", $newStatus, $verdict, $ticketId);
                            }
                            $stmt->execute();
                            $stmt->close();
                            gm_support_log($Link, $ticketId, 'status', $currentGmId, $currentGmUsername, $old, $newStatus, '', '', '', '狀態更新' . ($verdict !== '' ? '：' . $verdict : ''));
                            $notice = "回報單狀態已更新為「" . $statusMap[$newStatus]['label'] . "」。";
                        }
                    } elseif ($sub === 'priority') {
                        $newPriority = (string)($_POST['new_priority'] ?? '');
                        if (!isset($prioMap[$newPriority])) {
                            $notice = "無效的優先度。";
                            $noticeType = "danger";
                        } else {
                            $old = (string)$ticket['priority'];
                            $stmt = $Link->prepare("UPDATE `support_tickets` SET `priority`=? WHERE `id`=?");
                            $stmt->bind_param("si", $newPriority, $ticketId);
                            $stmt->execute();
                            $stmt->close();
                            gm_support_log($Link, $ticketId, 'priority', $currentGmId, $currentGmUsername, '', '', $old, $newPriority, '', '優先度調整');
                            $notice = "優先度已更新為「" . $prioMap[$newPriority]['label'] . "」。";
                        }
                    } elseif ($sub === 'assign_self') {
                        $stmt = $Link->prepare("UPDATE `support_tickets` SET `handler`=? WHERE `id`=?");
                        $stmt->bind_param("si", $currentGmUsername, $ticketId);
                        $stmt->execute();
                        $stmt->close();
                        gm_support_log($Link, $ticketId, 'assign', $currentGmId, $currentGmUsername, '', '', '', '', $currentGmUsername, '指派受理人員');
                        $notice = "已將此工單指派給自己（" . $currentGmUsername . "）。";
                    } elseif ($sub === 'reply') {
                        $content = trim((string)($_POST['content'] ?? ''));
                        $isInternal = ((int)($_POST['is_internal'] ?? 0) === 1) ? 1 : 0;
                        if ($content === '') {
                            $notice = "請輸入回覆或備註內容。";
                            $noticeType = "danger";
                        } else {
                            $stmt = $Link->prepare("INSERT INTO `support_messages` (`ticket_id`,`sender_type`,`sender_id`,`sender_name`,`content`,`is_internal`) VALUES (?, 'gm', ?, ?, ?, ?)");
                            $stmt->bind_param("iissi", $ticketId, $currentGmId, $currentGmUsername, $content, $isInternal);
                            $stmt->execute();
                            $stmt->close();
                            if ($isInternal === 1) {
                                $stmt = $Link->prepare("UPDATE `support_tickets` SET `internal_note` = CONCAT(IFNULL(`internal_note`,''), ?, '[', NOW(), '] ', ?) WHERE `id`=?");
                                $prefix = ($ticket['internal_note'] ? "\n" : '');
                                $noteText = $currentGmUsername . '：' . $content;
                                $stmt->bind_param("ssi", $prefix, $noteText, $ticketId);
                                $stmt->execute();
                                $stmt->close();
                                gm_support_log($Link, $ticketId, 'note', $currentGmId, $currentGmUsername, '', '', '', '', '', '新增內部備註');
                                $notice = "內部備註已新增（會員不可見）。";
                            } else {
                                $oldStatus = (string)$ticket['status'];
                                $newStatus = in_array($oldStatus, ['open', 'processing'], true) ? 'pending_user' : $oldStatus;
                                $stmt = $Link->prepare("UPDATE `support_tickets` SET `reply_count`=`reply_count`+1, `last_reply_by`='gm', `last_reply_at`=NOW(), `status`=? WHERE `id`=?");
                                $stmt->bind_param("si", $newStatus, $ticketId);
                                $stmt->execute();
                                $stmt->close();
                                gm_support_log($Link, $ticketId, 'reply', $currentGmId, $currentGmUsername, $oldStatus, $newStatus, '', '', '', '客服回覆');
                                $notice = "已回覆會員。";
                            }
                        }
                    } else {
                        $notice = "未知的工單操作。";
                        $noticeType = "danger";
                    }
                } catch (Throwable $e) {
                    $notice = "工單處理失敗，請稍後再試。";
                    $noticeType = "danger";
                }
            }
            mysqli_set_charset($Link, "latin1");

        } elseif ($action === 'assign_tier') {
            // 設定目標會員的帳號層級
            $userid = (int)($_POST['userid'] ?? 0);
            $tierId = (int)($_POST['tier_id'] ?? 0);
            if ($userid <= 0) {
                $notice = "缺少目標會員編號，請重新選擇玩家。";
                $noticeType = "danger";
            } else {
                mysqli_set_charset($Link, "utf8mb4");
                if (account_tier_assign($Link, $userid, $tierId, $currentGmUsername)) {
                    $t = account_tier_for_user($Link, $userid);
                    $notice = "已將帳號 #$userid 的層級設為「" . ($t['name'] ?? '預設') . "」。";
                } else {
                    $notice = "層級設定失敗，請稍後再試。";
                    $noticeType = "danger";
                }
                mysqli_set_charset($Link, "latin1");
            }

        } elseif ($action === 'save_recharge') {
            mysqli_set_charset($Link, "utf8");

            // 儲值方式開關
            $baseMethodKeys = ['credit_card', 'bank_transfer', 'cvs', 'crypto'];
            $methodEnabled = $_POST['method_enabled'] ?? [];
            foreach ($baseMethodKeys as $mk) {
                $en = (isset($methodEnabled[$mk]) && (int)$methodEnabled[$mk] === 1) ? 1 : 0;
                $stmt = $Link->prepare("UPDATE recharge_settings SET enabled = ? WHERE setting_type = 'method' AND setting_key = ?");
                $stmt->bind_param("is", $en, $mk);
                $stmt->execute();
                $stmt->close();
            }

            // 既有金額方案更新 / 刪除
            $tiers = $_POST['tier'] ?? [];
            $removeTiers = $_POST['remove_tier'] ?? [];
            foreach ($tiers as $tierId => $fields) {
                $tierId = (int)$tierId;
                if (isset($removeTiers[$tierId])) {
                    $stmt = $Link->prepare("DELETE FROM recharge_settings WHERE id = ? AND setting_type = 'amount'");
                    $stmt->bind_param("i", $tierId);
                    $stmt->execute();
                    $stmt->close();
                    continue;
                }
                $amt = max(1, (int)($fields['amount'] ?? 0));
                $bonus = max(0, min(500, (int)($fields['bonus_percent'] ?? 0)));
                $en = (isset($fields['enabled']) && (int)$fields['enabled'] === 1) ? 1 : 0;
                $sort = $tierId;
                $stmt = $Link->prepare("UPDATE recharge_settings SET amount = ?, bonus_percent = ?, enabled = ?, sort_order = ? WHERE id = ?");
                $stmt->bind_param("iiiii", $amt, $bonus, $en, $sort, $tierId);
                $stmt->execute();
                $stmt->close();
            }

            // 新增金額方案
            $newAmount = (int)($_POST['new_amount'] ?? 0);
            $newBonus = max(0, min(500, (int)($_POST['new_bonus_percent'] ?? 0)));
            if ($newAmount > 0) {
                $seq = $Link->query("SELECT IFNULL(MAX(sort_order), 0) + 1 AS `s` FROM recharge_settings WHERE setting_type = 'amount'");
                $rowS = $seq ? $seq->fetch_assoc() : null;
                $nextSort = isset($rowS['s']) ? (int)$rowS['s'] : 1;
                $ins = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, display_name, icon, description, amount, bonus_percent, enabled, sort_order) VALUES ('amount', '', '', '', '', ?, ?, 1, ?)");
                $ins->bind_param("iii", $newAmount, $newBonus, $nextSort);
                $ins->execute();
                $ins->close();
            }

            // 自訂金額範圍（數值存於 amount）
            $configs = $_POST['config'] ?? [];
            $minAmt = max(1, (int)($configs['min_amount'] ?? 50));
            $maxAmt = max($minAmt, (int)($configs['max_amount'] ?? 100000));
            foreach (['min_amount' => $minAmt, 'max_amount' => $maxAmt] as $cfgKey => $cfgVal) {
                $chk = $Link->prepare("SELECT id FROM recharge_settings WHERE setting_type = 'config' AND setting_key = ? LIMIT 1");
                $chk->bind_param("s", $cfgKey);
                $chk->execute();
                $existRow = $chk->get_result()->fetch_assoc();
                $chk->close();
                if ($existRow) {
                    $stmt = $Link->prepare("UPDATE recharge_settings SET amount = ? WHERE id = ?");
                    $stmt->bind_param("ii", $cfgVal, (int)$existRow['id']);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, amount, enabled, sort_order) VALUES ('config', ?, ?, 1, 0)");
                    $stmt->bind_param("si", $cfgKey, $cfgVal);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            // 金流系統參數（綠界 ECPay；字串存於 description）
            $gatewayKeys = ['ecpay_env', 'ecpay_merchant_id', 'ecpay_hash_key', 'ecpay_hash_iv', 'ecpay_action_url'];
            $gatewayInput = $_POST['gateway'] ?? [];
            foreach ($gatewayKeys as $gk) {
                $gv = trim((string)($gatewayInput[$gk] ?? ''));
                if ($gk === 'ecpay_env') {
                    $gv = ($gv === 'prod') ? 'prod' : 'stage';
                }
                if (strlen($gv) > 200) {
                    $gv = substr($gv, 0, 200);
                }
                $chk = $Link->prepare("SELECT id FROM recharge_settings WHERE setting_type = 'config' AND setting_key = ? LIMIT 1");
                $chk->bind_param("s", $gk);
                $chk->execute();
                $existRow = $chk->get_result()->fetch_assoc();
                $chk->close();
                if ($existRow) {
                    $stmt = $Link->prepare("UPDATE recharge_settings SET description = ?, enabled = 1 WHERE id = ?");
                    $stmt->bind_param("si", $gv, (int)$existRow['id']);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $Link->prepare("INSERT INTO recharge_settings (setting_type, setting_key, amount, description, enabled, sort_order) VALUES ('config', ?, 0, ?, 1, 0)");
                    $stmt->bind_param("ss", $gk, $gv);
                    $stmt->execute();
                    $stmt->close();
                }
            }

            mysqli_set_charset($Link, "latin1");
            $notice = "儲值系統設定已儲存並立即生效。";
            $openRechargeModal = true;
        }

        $formToken = refreshToken();
    }
}

// 帳號搜尋（空白搜尋 = 顯示全部帳號，分頁顯示）
$searchResults = [];
$searchTerm = trim($_GET['q'] ?? '');
$searchPerPage = (int)($_GET['per'] ?? 10);
if (!in_array($searchPerPage, [10, 20, 50], true)) { $searchPerPage = 10; }
$searchPage = max(1, (int)($_GET['page'] ?? 1));
$searchTotal = 0;

$like = '%' . $searchTerm . '%';
if ($searchTerm !== '') {
    $stmt = $Link->prepare("SELECT COUNT(*) AS c FROM users WHERE name LIKE ?");
    $stmt->bind_param("s", $like);
    $stmt->execute();
    $searchTotal = (int)(($stmt->get_result()->fetch_assoc()['c'] ?? 0));
    $stmt->close();
} else {
    $rs = mysqli_query($Link, "SELECT COUNT(*) AS c FROM users");
    if ($rs) { $searchTotal = (int)(($rs->fetch_assoc()['c'] ?? 0)); }
}
$searchTotalPages = max(1, (int)ceil($searchTotal / $searchPerPage));
if ($searchPage > $searchTotalPages) { $searchPage = $searchTotalPages; }
$searchOffset = ($searchPage - 1) * $searchPerPage;

if ($searchTerm !== '') {
    $stmt = $Link->prepare("SELECT ID, name, email, mobilenumber, creatime FROM users WHERE name LIKE ? ORDER BY creatime DESC LIMIT ? OFFSET ?");
    $stmt->bind_param("sii", $like, $searchPerPage, $searchOffset);
    $stmt->execute();
    $searchResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $stmt = $Link->prepare("SELECT ID, name, email, mobilenumber, creatime FROM users ORDER BY creatime DESC LIMIT ? OFFSET ?");
    $stmt->bind_param("ii", $searchPerPage, $searchOffset);
    $stmt->execute();
    $searchResults = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
$searchPageStart = max(1, $searchPage - 2);
$searchPageEnd = min($searchTotalPages, $searchPageStart + 4);
$searchPageStart = max(1, $searchPageEnd - 4);

// 選取帳號詳細資料
$selectedAccount = null;
$selectedAccountFull = null;
$selectedForbids = [];
$selectedPoints = [];
$selectedPerms = member_permission_defaults();
$selectedTier = null;
$selectedRechargeOrders = [];
$selectedExchangeOrders = [];
$selectedWallet = ['points' => 0, 'yuanbao' => 0, 'total_points_in' => 0, 'total_yuanbao_in' => 0];
$selectedWalletLedger = [];
$selectedOrderStats = ['count' => 0, 'paid_count' => 0, 'paid_amount' => 0, 'paid_points' => 0];
$selectedTickets = [];
$selectedSupportStats = ['total' => 0, 'open' => 0, 'processing' => 0, 'pending_user' => 0, 'resolved' => 0, 'closed' => 0];
$supportTicketId = isset($_GET['ticket']) ? (int)$_GET['ticket'] : 0;
$selectedTicket = null;
$ticketMessages = [];
$ticketAttachments = [];
$ticketStatusLogs = [];
$selectedId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($selectedId > 0) {
    $stmt = $Link->prepare("SELECT ID, name, email, mobilenumber, truename, creatime FROM users WHERE ID = ?");
    $stmt->bind_param("i", $selectedId);
    $stmt->execute();
    $selectedAccount = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($selectedAccount) {
        $stmt = $Link->prepare("SELECT type, ctime, forbid_time, reason, gmroleid FROM forbid WHERE userid = ?");
        $stmt->bind_param("i", $selectedId);
        $stmt->execute();
        $selectedForbids = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        $stmt = $Link->prepare("SELECT aid, zoneid, time, lastlogin FROM point WHERE uid = ?");
        $stmt->bind_param("i", $selectedId);
        $stmt->execute();
        $selectedPoints = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // 目標會員的功能權限設定
        mysqli_set_charset($Link, "utf8mb4");
        $selectedPerms = member_permissions_load($Link, (int)$selectedAccount['ID']);
        // 目標會員的帳號層級
        $selectedTier = account_tier_for_user($Link, (int)$selectedAccount['ID']);

        // 目標帳號的完整資料（供「帳號詳細資料」分頁瀏覽／編輯）
        // 明確列出文字欄位，避免讀取 passwd / passwd2 原始二進位欄位。
        $stmt = $Link->prepare("SELECT `ID`,`name`,`Prompt`,`answer`,`truename`,`idnumber`,`email`,`mobilenumber`,`province`,`city`,`phonenumber`,`address`,`postalcode`,`gender`,`birthday`,`creatime`,`qq` FROM `users` WHERE `ID` = ?");
        $stmt->bind_param("i", $selectedId);
        $stmt->execute();
        $selectedAccountFull = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        // 目標會員的歷史訂單：儲值訂單（recharge_orders）
        try {
            $stmt = $Link->prepare("SELECT `order_no`,`method_name`,`choose_payment`,`amount`,`bonus`,`total_points`,`status`,`trade_no`,`paid_at`,`created_at` FROM `recharge_orders` WHERE `uid` = ? ORDER BY `id` DESC LIMIT 50");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $selectedRechargeOrders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } catch (Throwable $e) {
            $selectedRechargeOrders = [];
        }
        try {
            $stmt = $Link->prepare("SELECT COUNT(*) AS c, SUM(`status` = 'paid') AS paid_c,
                    SUM(CASE WHEN `status` = 'paid' THEN `amount` ELSE 0 END) AS paid_amt,
                    SUM(CASE WHEN `status` = 'paid' THEN `total_points` ELSE 0 END) AS paid_pts
                    FROM `recharge_orders` WHERE `uid` = ?");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row) {
                $selectedOrderStats = [
                    'count'       => (int)$row['c'],
                    'paid_count'  => (int)$row['paid_c'],
                    'paid_amount' => (int)$row['paid_amt'],
                    'paid_points' => (int)$row['paid_pts'],
                ];
            }
        } catch (Throwable $e) {
            // 訂單資料表尚未建立時忽略
        }

        // 目標會員的歷史訂單：點數兌換元寶（exchange_orders）
        try {
            $stmt = $Link->prepare("SELECT `exchange_no`,`points_used`,`rate`,`fee_percent`,`yuanbao_gained`,`status`,`note`,`created_at` FROM `exchange_orders` WHERE `uid` = ? ORDER BY `id` DESC LIMIT 50");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $selectedExchangeOrders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } catch (Throwable $e) {
            $selectedExchangeOrders = [];
        }

        // 目標會員的錢包餘額（點數 / 元寶）與交易流水
        mysqli_set_charset($Link, "utf8mb4");
        $selectedWallet = currency_get_wallet($Link, (int)$selectedId);
        try {
            $stmt = $Link->prepare("SELECT `currency`,`change_amount`,`balance_after`,`type`,`ref_no`,`description`,`operator`,`created_at` FROM `currency_ledger` WHERE `uid` = ? ORDER BY `id` DESC LIMIT 30");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $selectedWalletLedger = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } catch (Throwable $e) {
            $selectedWalletLedger = [];
        }
        mysqli_set_charset($Link, "latin1");

        // 目標會員的申訴回報工單（support_tickets）
        try {
            $stmt = $Link->prepare("SELECT t.`id`,t.`ticket_no`,t.`subject`,t.`priority`,t.`status`,t.`handler`,t.`reply_count`,t.`last_reply_by`,t.`last_reply_at`,t.`created_at`,t.`updated_at`,c.`name` AS category_name,c.`icon` AS category_icon FROM `support_tickets` t LEFT JOIN `support_categories` c ON c.`id`=t.`category_id` WHERE t.`uid` = ? ORDER BY t.`id` DESC LIMIT 100");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $selectedTickets = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        } catch (Throwable $e) {
            $selectedTickets = [];
        }
        try {
            $stmt = $Link->prepare("SELECT COUNT(*) AS total,
                    SUM(`status`='open') AS open_c,
                    SUM(`status`='processing') AS processing_c,
                    SUM(`status`='pending_user') AS pending_c,
                    SUM(`status`='resolved') AS resolved_c,
                    SUM(`status`='closed') AS closed_c
                FROM `support_tickets` WHERE `uid` = ?");
            $stmt->bind_param("i", $selectedId);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row) {
                $selectedSupportStats = [
                    'total'        => (int)$row['total'],
                    'open'         => (int)$row['open_c'],
                    'processing'   => (int)$row['processing_c'],
                    'pending_user' => (int)$row['pending_c'],
                    'resolved'     => (int)$row['resolved_c'],
                    'closed'       => (int)$row['closed_c'],
                ];
            }
        } catch (Throwable $e) {
            // 工單資料表尚未建立時忽略
        }

        // 指定工單詳細資料（限本會員）
        if ($supportTicketId > 0) {
            try {
                $stmt = $Link->prepare("SELECT t.*, c.`name` AS category_name, c.`icon` AS category_icon FROM `support_tickets` t LEFT JOIN `support_categories` c ON c.`id`=t.`category_id` WHERE t.`id` = ? AND t.`uid` = ? LIMIT 1");
                $stmt->bind_param("ii", $supportTicketId, $selectedId);
                $stmt->execute();
                $selectedTicket = $stmt->get_result()->fetch_assoc();
                $stmt->close();
            } catch (Throwable $e) {
                $selectedTicket = null;
            }
            if ($selectedTicket) {
                try {
                    $stmt = $Link->prepare("SELECT `id`,`sender_type`,`sender_name`,`sender_id`,`content`,`is_internal`,`created_at` FROM `support_messages` WHERE `ticket_id` = ? ORDER BY `id` ASC");
                    $stmt->bind_param("i", $supportTicketId);
                    $stmt->execute();
                    $ticketMessages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    $stmt->close();
                } catch (Throwable $e) {
                    $ticketMessages = [];
                }
                try {
                    $stmt = $Link->prepare("SELECT `message_id`,`file_name`,`file_path`,`file_size`,`uploader_type` FROM `support_attachments` WHERE `ticket_id` = ? ORDER BY `id` ASC");
                    $stmt->bind_param("i", $supportTicketId);
                    $stmt->execute();
                    $res = $stmt->get_result();
                    while ($att = $res->fetch_assoc()) {
                        $mid = (int)$att['message_id'];
                        if (!isset($ticketAttachments[$mid])) { $ticketAttachments[$mid] = []; }
                        $ticketAttachments[$mid][] = $att;
                    }
                    $stmt->close();
                } catch (Throwable $e) {
                    $ticketAttachments = [];
                }
                try {
                    $stmt = $Link->prepare("SELECT `action`,`operator_type`,`operator_name`,`old_status`,`new_status`,`old_priority`,`new_priority`,`assigned_to`,`note`,`created_at` FROM `support_status_log` WHERE `ticket_id` = ? ORDER BY `id` ASC");
                    $stmt->bind_param("i", $supportTicketId);
                    $stmt->execute();
                    $ticketStatusLogs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                    $stmt->close();
                } catch (Throwable $e) {
                    $ticketStatusLogs = [];
                }
            }
        }

        mysqli_set_charset($Link, "latin1");
    }
}

// 線上人數
$onlineStmt = mysqli_query($Link, "SELECT online.ID, users.name FROM online JOIN users ON online.ID = users.ID");
$onlineList = $onlineStmt ? $onlineStmt->fetch_all(MYSQLI_ASSOC) : [];

$gmAccountsList = mysqli_query($Link, "SELECT id, username, created_at FROM gm_accounts ORDER BY created_at ASC");
$gmAccountsList = $gmAccountsList ? $gmAccountsList->fetch_all(MYSQLI_ASSOC) : [];

// 保留查詢關鍵字，讓進入管理與操作後不遺失搜尋結果。
// modal=1 為「子視窗內發起」的標記：只有帶此標記的請求才會自動重新開啟子視窗。
$modalFlag = (isset($_GET['modal']) && (string)$_GET['modal'] === '1');
// GM 帳號管理子視窗：於子視窗內新增／移除帳號後，自動重新開啟以顯示最新結果。
$openGmAccountsModal = ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array((string)($_POST['action'] ?? ''), ['addgm', 'deletegm'], true));
$searchQuery = 'modal=1' . (($searchTerm !== '') ? '&q=' . urlencode($searchTerm) : '');
$preserveQHtml = htmlspecialchars('&' . $searchQuery, ENT_QUOTES);
$backUrl = htmlspecialchars(($searchTerm !== '') ? '?' . $searchQuery : 'gmpanel.php', ENT_QUOTES);
$backLabel = ($searchQuery !== '') ? '返回查詢列表' : '返回控制台首頁';

// 讀取儲值系統設定（以 utf8 正確讀取中文）
mysqli_set_charset($Link, "utf8");
$rechargeCfg = loadRechargeSettings($Link);
$rcMethods = $rechargeCfg['methods'];
$rcTiers = $rechargeCfg['tiers'];
$rcConfig = $rechargeCfg['config'];
$rcGateway = $rechargeCfg['gateway'];
mysqli_set_charset($Link, "latin1");

// 貨幣顯示名稱（點數 / 元寶），供錢包管理分頁使用
mysqli_set_charset($Link, "utf8");
$currencySettings = currency_load_settings($Link);
$pointsName = ($currencySettings['points_name'] !== '') ? $currencySettings['points_name'] : '點數';
$yuanbaoName = ($currencySettings['yuanbao_name'] !== '') ? $currencySettings['yuanbao_name'] : '元寶';
mysqli_set_charset($Link, "latin1");

// ------------------------------------------------------------
// 申訴回報統計（後台首頁儀表板）
// ------------------------------------------------------------
mysqli_set_charset($Link, "utf8");
$supportStats = ['total' => 0, 'open' => 0, 'processing' => 0, 'pending_user' => 0, 'resolved' => 0, 'closed' => 0, 'awaiting' => 0, 'stale' => 0];
$recentTickets = [];
try {
    $rs = mysqli_query(
        $Link,
        "SELECT COUNT(*) AS total,
                SUM(`status` = 'open') AS open_c,
                SUM(`status` = 'processing') AS processing_c,
                SUM(`status` = 'pending_user') AS pending_c,
                SUM(`status` = 'resolved') AS resolved_c,
                SUM(`status` = 'closed') AS closed_c,
                SUM(`last_reply_by` = 'user' AND `status` IN ('open','processing')) AS awaiting_c,
                SUM(`status` IN ('open','processing','pending_user')
                    AND TIMESTAMPDIFF(HOUR, IFNULL(`last_reply_at`, `created_at`), NOW()) > 24) AS stale_c
           FROM `support_tickets`"
    );
    if ($rs && ($row = $rs->fetch_assoc())) {
        $supportStats['total'] = (int)$row['total'];
        $supportStats['open'] = (int)$row['open_c'];
        $supportStats['processing'] = (int)$row['processing_c'];
        $supportStats['pending_user'] = (int)$row['pending_c'];
        $supportStats['resolved'] = (int)$row['resolved_c'];
        $supportStats['closed'] = (int)$row['closed_c'];
        $supportStats['awaiting'] = (int)$row['awaiting_c'];
        $supportStats['stale'] = (int)$row['stale_c'];
    }
    $rs = mysqli_query(
        $Link,
        "SELECT t.`id`, t.`ticket_no`, t.`subject`, t.`username`, t.`priority`, t.`status`,
                t.`last_reply_by`, t.`last_reply_at`, t.`created_at`, c.`name` AS category_name
           FROM `support_tickets` t
           LEFT JOIN `support_categories` c ON c.`id` = t.`category_id`
          WHERE t.`status` IN ('open','processing','pending_user')
          ORDER BY FIELD(t.`priority`, 'urgent', 'high', 'normal', 'low'), t.`id` DESC
          LIMIT 4"
    );
    if ($rs) {
        while ($row = $rs->fetch_assoc()) { $recentTickets[] = $row; }
    }
} catch (Throwable $e) {
    // support 資料表尚未建立時忽略，不影響後台運作
}
mysqli_set_charset($Link, "latin1");

// 申訴狀態 / 優先度顯示對照
$supStatusMap = [
    'open'         => ['label' => '待處理',     'badge' => 'bg-amber-50 text-amber-700 border-amber-200',   'dot' => 'bg-amber-500'],
    'processing'   => ['label' => '處理中',     'badge' => 'bg-sky-50 text-sky-700 border-sky-200',         'dot' => 'bg-sky-500'],
    'pending_user' => ['label' => '待會員回覆', 'badge' => 'bg-violet-50 text-violet-700 border-violet-200', 'dot' => 'bg-violet-500'],
    'resolved'     => ['label' => '已結案',     'badge' => 'bg-emerald-50 text-emerald-700 border-emerald-200', 'dot' => 'bg-emerald-500'],
    'closed'       => ['label' => '已關閉',     'badge' => 'bg-slate-100 text-slate-600 border-slate-300',  'dot' => 'bg-slate-400'],
];
$supPrioMap = [
    'urgent' => ['label' => '緊急', 'badge' => 'bg-rose-50 text-rose-700 border-rose-200'],
    'high'   => ['label' => '高',   'badge' => 'bg-orange-50 text-orange-700 border-orange-200'],
    'normal' => ['label' => '一般', 'badge' => 'bg-slate-100 text-slate-600 border-slate-200'],
    'low'    => ['label' => '低',   'badge' => 'bg-slate-100 text-slate-500 border-slate-200'],
];

// ------------------------------------------------------------
// 後台管理工具選單設定
// ------------------------------------------------------------
// 以資料驅動方式集中管理上方工具列，未來新增功能只要在此陣列加入一筆即可，
// 無須再手動複製整段 HTML。每個項目的欄位說明：
//   label   : 主標題（中文）
//   sub     : 副標題（英文，顯示於主標題下方）
//   icon    : Font Awesome 圖示 class
//   theme   : 配色主題（t-amber / t-sky / t-rose / t-emerald / t-violet /
//             t-fuchsia / t-cyan / t-indigo / t-orange）
//   href    : 直接連結頁面（與 onclick 二擇一）
//   onclick : 開啟子視窗的 JS 函式，例如 openRechargeModal()
$adminMenuGroups = [
    [
        'label' => '營運與金流',
        'sub'   => 'Operations & Payment',
        'icon'  => 'fa-solid fa-sack-dollar',
        'theme' => 't-amber',
        'items' => [
            ['label' => '儲值系統設定', 'sub' => 'Recharge Settings', 'icon' => 'fa-solid fa-sliders',      'theme' => 't-amber', 'onclick' => 'openRechargeModal()'],
            ['label' => '訂單管理',     'sub' => 'Order Center',      'icon' => 'fa-solid fa-receipt',      'theme' => 't-sky',   'onclick' => 'openOrderModal()'],
        ],
    ],
    [
        'label' => '會員與安全',
        'sub'   => 'Members & Security',
        'icon'  => 'fa-solid fa-shield-halved',
        'theme' => 't-rose',
        'items' => [
            ['label' => '登入管理', 'sub' => 'Login Audit',          'icon' => 'fa-solid fa-shield-halved', 'theme' => 't-rose',    'onclick' => 'openLoginModal()'],
            ['label' => '權限防護', 'sub' => 'Access Guard',         'icon' => 'fa-solid fa-user-lock',     'theme' => 't-emerald', 'href'    => 'member_admin.php'],
            ['label' => '註冊管理', 'sub' => 'Registration Center',  'icon' => 'fa-solid fa-user-plus',     'theme' => 't-emerald', 'href'    => 'registration_admin.php'],
            ['label' => '信用管理', 'sub' => 'Credit Center',        'icon' => 'fa-solid fa-gauge-high',    'theme' => 't-emerald', 'onclick' => 'openCreditModal()'],
            ['label' => '帳號層級管理', 'sub' => 'Account Tiers',    'icon' => 'fa-solid fa-layer-group',   'theme' => 't-violet',  'onclick' => 'openTierModal()'],
        ],
    ],
    [
        'label' => '內容與站務',
        'sub'   => 'Content & Site',
        'icon'  => 'fa-solid fa-newspaper',
        'theme' => 't-violet',
        'items' => [
            ['label' => '公告管理', 'sub' => 'News Center',      'icon' => 'fa-solid fa-bullhorn',              'theme' => 't-violet',  'href' => 'news_admin.php'],
            ['label' => '活動管理', 'sub' => 'Events Center',    'icon' => 'fa-solid fa-calendar-check',         'theme' => 't-fuchsia', 'href' => 'events_admin.php'],
            ['label' => '下載管理', 'sub' => 'Download Center',  'icon' => 'fa-solid fa-cloud-arrow-down',      'theme' => 't-cyan',    'href' => 'download_admin.php'],
            ['label' => '首頁管理', 'sub' => 'Landing Page',     'icon' => 'fa-solid fa-house-chimney-window',  'theme' => 't-orange',  'href' => 'site_admin.php'],
        ],
    ],
    [
        'label' => '系統維護',
        'sub'   => 'System Maintenance',
        'icon'  => 'fa-solid fa-screwdriver-wrench',
        'theme' => 't-indigo',
        'items' => [
            ['label' => '系統備份', 'sub' => 'Auto Backup', 'icon' => 'fa-solid fa-database', 'theme' => 't-indigo', 'href' => 'backup_admin.php'],
        ],
    ],
];
// 每個主題的雙色漸層（起色／終色），供華麗按鈕的邊框、光暈與圖示磚使用
$themePair = [
    't-amber'   => ['#fbbf24', '#d97706'],
    't-sky'     => ['#38bdf8', '#0369a1'],
    't-rose'    => ['#fb7185', '#be123c'],
    't-emerald' => ['#34d399', '#059669'],
    't-violet'  => ['#a78bfa', '#7c3aed'],
    't-fuchsia' => ['#e879f9', '#c026d3'],
    't-cyan'    => ['#22d3ee', '#0891b2'],
    't-indigo'  => ['#818cf8', '#4f46e5'],
    't-orange'  => ['#fb923c', '#ea580c'],
];
$adminMenuCount = 0;
foreach ($adminMenuGroups as $grp) { $adminMenuCount += count($grp['items']); }

mysqli_close($Link);
?>
<!DOCTYPE html>
<html class="dark" lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · GM 掌門指揮中樞</title>
    <!-- Tailwind 樣式：編譯後靜態檔（不使用 CDN） -->
    <link rel="stylesheet" href="assets/tailwind.css">
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="stylesheet" href="assets/gmpanel-v2-tailwind.css?v=20260921">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Be+Vietnam+Pro:wght@300;400;500;600;700&family=Bodoni+Moda:ital,opsz,wght@0,6..96,400;0,6..96,700;1,6..96,400&display=swap" rel="stylesheet">
    <!-- FontAwesome 6.5.1 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <?php
    $onlineCount = count($onlineList);
    $gmCount = count($gmAccountsList);
    $supportActive = (int)($supportStats['open'] + $supportStats['processing'] + $supportStats['pending_user']);
    $selectedName = $selectedAccount ? (string)$selectedAccount['name'] : '';
    $selectedInitial = ($selectedName !== '') ? mb_substr($selectedName, 0, 1, 'UTF-8') : '?';
    ?>
    <style>
        :root {
            --vermilion: #be123c;
            --ice-blue: #0284c7;
            --ink-black: #06090f;
        }
        body {
            background-color: #06090f;
            color: #e2e8f0;
            font-family: 'Be Vietnam Pro', system-ui, sans-serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% -10%, rgba(190, 18, 60, 0.18) 0%, transparent 65%),
                radial-gradient(ellipse at 88% 92%, rgba(2, 132, 199, 0.15) 0%, transparent 60%),
                radial-gradient(ellipse at 10% 45%, rgba(15, 23, 42, 0.85) 0%, transparent 70%);
        }
        #snow-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 1;
            transform: translateZ(0);
            will-change: transform;
        }
        .glass-jade {
            background: rgba(255, 255, 255, 0.96);
            border: 1px solid rgba(255, 255, 255, 0.9);
            box-shadow: 0 16px 40px -8px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.6) inset;
            backdrop-filter: blur(16px);
        }
        .glass-dark {
            background: rgba(13, 19, 32, 0.82);
            border: 1px solid rgba(255, 255, 255, 0.08);
            box-shadow: 0 14px 36px -8px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.04) inset;
            backdrop-filter: blur(20px);
        }
        .corner-accent { position: relative; }
        .corner-accent::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 14px;
            height: 14px;
            border-top: 2.5px solid var(--vermilion);
            border-left: 2.5px solid var(--vermilion);
            pointer-events: none;
            border-top-left-radius: 4px;
        }
        .corner-accent::after {
            content: '';
            position: absolute;
            bottom: 0;
            right: 0;
            width: 14px;
            height: 14px;
            border-bottom: 2.5px solid var(--ice-blue);
            border-right: 2.5px solid var(--ice-blue);
            pointer-events: none;
            border-bottom-right-radius: 4px;
        }
        .btn-vermilion {
            background: linear-gradient(135deg, #be123c 0%, #95002a 100%);
            box-shadow: 0 4px 16px rgba(190, 18, 60, 0.35);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-vermilion:hover {
            background: linear-gradient(135deg, #e11d48 0%, #be123c 100%);
            box-shadow: 0 6px 22px rgba(190, 18, 60, 0.5);
            transform: translateY(-1px);
        }
        .btn-ice {
            background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%);
            box-shadow: 0 4px 16px rgba(2, 132, 199, 0.35);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-ice:hover {
            background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
            box-shadow: 0 6px 22px rgba(2, 132, 199, 0.5);
            transform: translateY(-1px);
        }
        .btn-amber {
            background: linear-gradient(135deg, #d97706 0%, #b45309 100%);
            box-shadow: 0 4px 16px rgba(217, 119, 6, 0.35);
            transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .btn-amber:hover {
            background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
            box-shadow: 0 6px 22px rgba(217, 119, 6, 0.5);
            transform: translateY(-1px);
        }
        .cmd-pill {
            background: rgba(18, 26, 43, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .cmd-pill:hover {
            background: rgba(30, 41, 59, 0.95);
            border-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px -4px rgba(0, 0, 0, 0.4);
        }
        /* ===== 帳號操作管理：美化分頁選單 ===== */
        .action-tabs {
            position: relative;
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 5px;
            padding: 5px;
            border-radius: 16px;
            background: linear-gradient(145deg, #f1f5f9 0%, #e2e8f0 100%);
            border: 1px solid rgba(203, 213, 225, 0.9);
            box-shadow: inset 0 1px 2px rgba(255, 255, 255, 0.95), inset 0 -3px 8px rgba(148, 163, 184, 0.16);
            width: 100%;
            min-width: 0;
        }
        @media (min-width: 640px) {
            .action-tabs {
                grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
                width: auto;
                flex: 1 1 auto;
            }
        }
        .tab-btn {
            position: relative;
            overflow: hidden;
            display: inline-flex;
            align-items: center;
            justify-content: flex-start;
            gap: 8px;
            width: 100%;
            min-width: 0;
            padding: 8px 14px;
            border-radius: 12px;
            color: #475569;
            font-weight: 600;
            letter-spacing: 0.01em;
            white-space: nowrap;
            text-align: left;
            cursor: pointer;
            transition: color .25s ease, transform .28s cubic-bezier(.34, 1.56, .64, 1), box-shadow .3s ease;
        }
        .tab-btn .tab-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        /* 底色漸層洗色（hover / active 共用） */
        .tab-btn::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, var(--tab-accent) 0%, var(--tab-accent-2) 100%);
            opacity: 0;
            transition: opacity .3s ease;
            z-index: 0;
        }
        .tab-btn > * { position: relative; z-index: 1; }
        .tab-btn:hover { transform: translateY(-2px); color: #1e293b; }
        .tab-btn:hover::before { opacity: .10; }
        .tab-btn:active { transform: translateY(0) scale(.98); }
        .tab-btn:focus-visible { outline: none; box-shadow: 0 0 0 3px rgba(2, 132, 199, .25); }
        /* 圖示晶片 */
        .tab-btn .tab-ico {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex: 0 0 auto;
            width: 26px;
            height: 26px;
            border-radius: 9px;
            font-size: 12px;
            background: #ffffff;
            color: var(--tab-accent);
            box-shadow: 0 2px 6px rgba(15, 23, 42, .08);
            transition: transform .35s cubic-bezier(.34, 1.56, .64, 1), background .3s ease, color .3s ease, box-shadow .3s ease;
        }
        .tab-btn:hover .tab-ico { transform: translateY(-2px) rotate(-6deg) scale(1.08); }
        /* 底部指示燈 */
        .tab-btn::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: 4px;
            height: 3px;
            width: 0;
            border-radius: 9999px;
            background: rgba(255, 255, 255, .95);
            transform: translateX(-50%);
            transition: width .3s cubic-bezier(.22, 1, .36, 1);
            z-index: 1;
        }
        .tab-btn.active {
            color: #ffffff;
            box-shadow: 0 12px 24px -10px var(--tab-accent), 0 3px 8px rgba(15, 23, 42, .14);
        }
        .tab-btn.active::before { opacity: 1; }
        .tab-btn.active .tab-ico {
            background: rgba(255, 255, 255, .22);
            color: #ffffff;
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, .35);
            transform: scale(1.06);
            animation: tabIcoPop .42s cubic-bezier(.34, 1.56, .64, 1);
        }
        .tab-btn.active::after { width: 24px; }
        @keyframes tabIcoPop {
            0%   { transform: scale(.78) rotate(-8deg); }
            60%  { transform: scale(1.14) rotate(3deg); }
            100% { transform: scale(1.06) rotate(0); }
        }
        .tab-pane { display: none; }
        .tab-pane.active {
            display: block;
            animation: tabFade .38s cubic-bezier(.22, 1, .36, 1);
        }
        @keyframes tabFade {
            from { opacity: 0; transform: translateY(10px); }
            to   { opacity: 1; transform: translateY(0); }
        }
        @media (prefers-reduced-motion: reduce) {
            .tab-btn, .tab-btn .tab-ico, .tab-btn::before, .tab-btn::after { transition: none; }
            .tab-btn.active .tab-ico { animation: none; }
            .tab-pane.active { animation: none; }
        }
        .modal-backdrop {
            background-color: rgba(3, 6, 12, 0.82);
            backdrop-filter: blur(14px);
        }
        ::-webkit-scrollbar { width: 5px; height: 5px; }
        ::-webkit-scrollbar-track { background: rgba(15, 23, 42, 0.2); }
        ::-webkit-scrollbar-thumb { background: rgba(100, 116, 139, 0.4); border-radius: 9999px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(148, 163, 184, 0.7); }

        /* ===== 既有子視窗沿用的元件樣式 ===== */
        .glass-panel {
            background: rgba(255, 255, 255, 0.94);
            border: 1px solid rgba(226, 232, 240, 0.85);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.7) inset;
            position: relative;
            transform: translateZ(0);
        }
        .ink-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent 0%, rgba(190, 18, 60, 0.3) 25%, rgba(2, 132, 199, 0.3) 75%, transparent 100%);
        }
        .form-input-focus:focus {
            outline: none;
            border-color: #0284c7;
            box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.15);
        }
        /* 子視窗（白玉面板）內的表單控制項：強制深色文字，避免繼承深色主題的淺色文字而看不清 */
        .glass-panel input:not([type="checkbox"]):not([type="radio"]),
        .glass-panel select,
        .glass-panel textarea {
            color: #1e293b;
        }
        .glass-panel input::placeholder,
        .glass-panel textarea::placeholder {
            color: #94a3b8;
            opacity: 1;
        }
        .glass-panel select option {
            color: #1e293b;
            background-color: #ffffff;
        }
        .order-filter-btn { transition: all 0.2s ease; }
        .order-filter-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            box-shadow: 0 8px 18px -6px rgba(0, 0, 0, 0.45);
            transform: translateY(-1px);
        }
        .order-filter-btn.active [data-count] {
            background: rgba(255, 255, 255, 0.25) !important;
            color: #ffffff;
        }
        .order-filter-btn[data-status="all"].active { background: linear-gradient(135deg, #334155, #0f172a); }
        .order-filter-btn[data-status="pending"].active { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .order-filter-btn[data-status="paid"].active { background: linear-gradient(135deg, #10b981, #047857); }
        .order-filter-btn[data-status="failed"].active { background: linear-gradient(135deg, #f43f5e, #be123c); }
        .order-filter-btn[data-status="expired"].active { background: linear-gradient(135deg, #64748b, #334155); }
        .order-filter-btn[data-status="cancelled"].active { background: linear-gradient(135deg, #94a3b8, #475569); }
        .order-period-btn { transition: all 0.2s ease; }
        .order-period-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            background: linear-gradient(135deg, #6366f1, #4338ca);
            box-shadow: 0 8px 18px -6px rgba(67, 56, 202, 0.6);
            transform: translateY(-1px);
        }
        .order-row-check { transition: box-shadow 0.15s ease; }
        .order-row-check:checked { box-shadow: 0 0 0 3px rgba(2, 132, 199, 0.18); }
        .py-0\.2 { padding-top: 0.05rem; padding-bottom: 0.05rem; }
        .login-filter-btn { transition: all 0.2s ease; }
        .login-filter-btn.active {
            color: #ffffff;
            border-color: transparent !important;
            background: linear-gradient(135deg, #be123c, #7f1d3a);
            box-shadow: 0 8px 18px -6px rgba(190, 18, 60, 0.55);
            transform: translateY(-1px);
        }

        /* ===== 補齊已編譯 Tailwind CSS 遺漏的類別（前台首頁按鈕顯示修正） =====
           下列類別在頁面中被使用，但未收錄於已編譯的 *.css 檔（編譯後才新增所致）。
           尤其 .-top-1 缺失會讓絕對定位的通知圓點失去 top 位移而與圖示／文字重疊。
           此處以 Tailwind 相同的 CSS 變數寫法補上，維持原有漸層與陰影效果。 */
        .-top-1 { top: -0.25rem; }
        .opacity-80 { opacity: 0.8; }
        .text-teal-400 { color: #2dd4bf; }
        .bg-amber-200 { background-color: #fde68a; }
        .bg-amber-300 { background-color: #fcd34d; }
        .border-orange-500 { border-color: #f97316; }
        .via-orange-500 {
            --tw-gradient-to: rgba(249, 115, 22, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), #f97316 var(--tw-gradient-via-position), var(--tw-gradient-to);
        }
        .hover\:from-amber-400:hover {
            --tw-gradient-from: #fbbf24 var(--tw-gradient-from-position);
            --tw-gradient-to: rgba(251, 191, 36, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to);
        }
        .hover\:via-orange-400:hover {
            --tw-gradient-to: rgba(251, 146, 60, 0) var(--tw-gradient-to-position);
            --tw-gradient-stops: var(--tw-gradient-from), #fb923c var(--tw-gradient-via-position), var(--tw-gradient-to);
        }
        .hover\:to-rose-400:hover { --tw-gradient-to: #fb7185 var(--tw-gradient-to-position); }
        .shadow-amber-900\/40 {
            --tw-shadow-color: rgba(120, 53, 15, 0.4);
            --tw-shadow: var(--tw-shadow-colored);
        }
        .hover\:shadow-orange-900\/50:hover {
            --tw-shadow-color: rgba(124, 45, 18, 0.5);
            --tw-shadow: var(--tw-shadow-colored);
        }

        /* ===== 左下方浮動多功能選單（玩家帳號查詢 + GM 管理員帳號） ===== */
        .account-fab-wrap {
            position: fixed;
            left: 1.5rem;
            bottom: 1.5rem;
            z-index: 45;
            display: flex;
            align-items: flex-end;
        }
        .account-fab-menu {
            position: absolute;
            left: calc(100% + 0.85rem);
            bottom: 0;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            width: 15rem;
            max-width: calc(100vw - 6.5rem);
            transform-origin: bottom left;
            opacity: 0;
            visibility: hidden;
            transform: translateX(-10px) scale(0.96);
            transition: opacity 0.22s ease, transform 0.22s cubic-bezier(0.4, 0, 0.2, 1), visibility 0.22s;
            pointer-events: none;
        }
        .account-fab-menu.is-open {
            opacity: 1;
            visibility: visible;
            transform: none;
            pointer-events: auto;
        }
        .account-fab-menu__item {
            display: flex;
            align-items: center;
            gap: 0.7rem;
            width: 100%;
            padding: 0.6rem 0.7rem;
            border: 1px solid rgba(255, 255, 255, 0.12);
            border-radius: 0.9rem;
            background: rgba(15, 23, 42, 0.95);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            box-shadow: 0 14px 30px -12px rgba(0, 0, 0, 0.7);
            color: #e2e8f0;
            cursor: pointer;
            text-align: left;
            transition: border-color 0.2s ease, background 0.2s ease, transform 0.2s ease;
        }
        .account-fab-menu__item:hover {
            background: rgba(30, 41, 59, 0.98);
            border-color: rgba(244, 63, 94, 0.5);
            transform: translateX(3px);
        }
        .account-fab-menu__ico {
            width: 2.1rem;
            height: 2.1rem;
            border-radius: 0.7rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.85rem;
            flex-shrink: 0;
            border: 1px solid rgba(255, 255, 255, 0.12);
        }
        .account-fab-menu__ico.t-sky { background: rgba(2, 132, 199, 0.22); color: #7dd3fc; }
        .account-fab-menu__ico.t-amber { background: rgba(217, 119, 6, 0.22); color: #fcd34d; }
        .account-fab-menu__txt { display: flex; flex-direction: column; line-height: 1.25; min-width: 0; }
        .account-fab-menu__txt strong { font-family: 'Noto Serif TC', serif; font-size: 0.8rem; font-weight: 700; color: #f8fafc; white-space: nowrap; }
        .account-fab-menu__txt small { font-size: 0.65rem; color: #94a3b8; white-space: nowrap; }
        .account-fab-menu__go { margin-left: auto; font-size: 0.65rem; color: #64748b; }
        .account-fab-wrap.is-open .account-fab__tip { opacity: 0; visibility: hidden; }

        .account-fab {
            position: relative;
            width: 3.6rem;
            height: 3.6rem;
            border: 0;
            border-radius: 9999px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #ffffff;
            cursor: pointer;
            background: linear-gradient(135deg, #be123c 0%, #7c3aed 55%, #0284c7 100%);
            box-shadow: 0 14px 34px -8px rgba(124, 58, 237, 0.65), 0 0 0 1px rgba(255, 255, 255, 0.15) inset;
            transition: transform 0.28s cubic-bezier(0.4, 0, 0.2, 1), box-shadow 0.28s ease;
        }
        .account-fab:hover {
            transform: translateY(-3px) scale(1.06);
            box-shadow: 0 20px 46px -10px rgba(124, 58, 237, 0.8), 0 0 0 1px rgba(255, 255, 255, 0.2) inset;
        }
        .account-fab:active { transform: translateY(-1px) scale(1.01); }
        .account-fab__ring {
            position: absolute;
            inset: 0;
            border-radius: 9999px;
            border: 2px solid rgba(244, 63, 94, 0.55);
            animation: accountFabPulse 2.6s ease-out infinite;
            pointer-events: none;
        }
        .account-fab__ring--delay {
            animation-delay: 1.3s;
            border-color: rgba(14, 165, 233, 0.5);
        }
        @keyframes accountFabPulse {
            0% { transform: scale(1); opacity: 0.85; }
            70% { transform: scale(1.75); opacity: 0; }
            100% { transform: scale(1.75); opacity: 0; }
        }
        .account-fab__tip {
            position: absolute;
            left: calc(100% + 0.75rem);
            top: 50%;
            transform: translateY(-50%) translateX(-8px);
            white-space: nowrap;
            font-family: 'Noto Serif TC', serif;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.06em;
            color: #f8fafc;
            background: rgba(15, 23, 42, 0.92);
            border: 1px solid rgba(255, 255, 255, 0.12);
            padding: 0.4rem 0.75rem;
            border-radius: 0.65rem;
            box-shadow: 0 10px 24px -8px rgba(0, 0, 0, 0.6);
            opacity: 0;
            visibility: hidden;
            transition: all 0.25s ease;
            pointer-events: none;
        }
        .account-fab:hover .account-fab__tip {
            opacity: 1;
            visibility: visible;
            transform: translateY(-50%) translateX(0);
        }
        /* 子視窗內容底襯，讓白玉卡片層次分明 */
        .account-modal-body { background: #eef2f7; }

        /* ===== 帳號查詢子視窗：欄寬與版面（編譯版 CSS 未含這些工具類，改以本頁樣式定義）===== */
        @media (min-width: 1024px) {
            .acct-col-left  { grid-column: span 3 / span 3; }
            .acct-col-right { grid-column: span 9 / span 9; }
        }
        /* 歷史訂單表格：固定欄寬，過長欄位以水平捲動呈現 */
        .acct-orders-table { table-layout: fixed; width: 100%; min-width: 940px; }
        /* 最後一欄（操作／編輯）固定在右側，無需水平拖拉即可點選 */
        .acct-orders-actions thead th:last-child,
        .acct-orders-actions tbody td:last-child {
            position: sticky;
            right: 0;
            background: #ffffff;
            box-shadow: -10px 0 14px -10px rgba(15, 23, 42, .18);
        }
        .acct-orders-actions thead th:last-child { background: #f8fafc; }
        .acct-orders-actions tbody tr:hover td:last-child { background: #f8fafc; }
        /* 訂單管理子視窗必須高於帳號查詢子視窗（z-index:65） */
        #order-modal { z-index: 80; }
        /* 分頁列在需要時可換行，避免撐破標題列 */
        @media (min-width: 640px) {
            .acct-tabbar-head { flex-wrap: wrap; }
        }
        /* 補齊編譯版 CSS 缺少的工具類（本頁新增的靛藍／藍綠配色與版面小工具） */
        .bg-indigo-50 { background-color: #eef2ff; }
        .bg-indigo-100 { background-color: #e0e7ff; }
        .border-indigo-200 { border-color: #c7d2fe; }
        .text-indigo-600 { color: #4f46e5; }
        .text-indigo-700 { color: #4338ca; }
        .text-indigo-800 { color: #3730a3; }
        .text-indigo-950 { color: #1e1b4b; }
        .bg-teal-50 { background-color: #f0fdfa; }
        .border-teal-200 { border-color: #99f6e4; }
        .border-teal-300 { border-color: #5eead4; }
        .text-teal-600 { color: #0d9488; }
        .text-teal-700 { color: #0f766e; }
        .text-teal-950 { color: #042f2e; }
        .hover\:bg-teal-100:hover { background-color: #ccfbf1; }
        .hover\:border-emerald-300:hover { border-color: #6ee7b7; }
        .hover\:bg-emerald-50:hover { background-color: #ecfdf5; }
        .accent-emerald-600 { accent-color: #059669; }
        .bg-white\/70 { background-color: rgba(255, 255, 255, .7); }
        .mr-0\.5 { margin-right: .125rem; }
        .acct-btn-teal { background-image: linear-gradient(to right, #0d9488, #0f766e); }
        .acct-btn-teal:hover { background-image: linear-gradient(to right, #14b8a6, #0d9488); }
        @media (min-width: 640px) {
            .sm\:text-xl { font-size: 1.25rem; line-height: 1.75rem; }
            .sm\:col-span-2 { grid-column: span 2 / span 2; }
        }
        @media (min-width: 1024px) {
            .lg\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
            .lg\:col-span-2 { grid-column: span 2 / span 2; }
            .lg\:self-auto { align-self: auto; }
        }
        /* 工單回報分頁所需工具類 */
        .grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        .bg-violet-400 { background-color: #a78bfa; }
        .text-violet-600 { color: #7c3aed; }
        .text-orange-600 { color: #ea580c; }
        .text-orange-950 { color: #431407; }
        .border-orange-300 { border-color: #fdba74; }
        .hover\:bg-orange-100:hover { background-color: #ffedd5; }
        .hover\:border-orange-300:hover { border-color: #fdba74; }
        .hover\:text-orange-700:hover { color: #c2410c; }
        .break-words { overflow-wrap: break-word; word-break: break-word; }
        .whitespace-pre-wrap { white-space: pre-wrap; }
        .max-h-80 { max-height: 20rem; }
        .max-w-\[85\%\] { max-width: 85%; }
        .last\:border-0:last-child { border-width: 0; }
        .acct-support-table { min-width: 1100px; }
        /* 玩家帳號查詢：精簡結果列與分頁按鈕 */
        .acct-search-item { transition: border-color .15s ease, background .15s ease, box-shadow .15s ease; }
        .acct-pager-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 1.75rem;
            height: 1.75rem;
            padding: 0 .45rem;
            border-radius: .55rem;
            border: 1px solid #e2e8f0;
            background: #ffffff;
            color: #475569;
            font-size: .7rem;
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            text-decoration: none;
            transition: all .15s ease;
        }
        .acct-pager-btn:hover { border-color: #fda4af; color: #be123c; background: #fff1f2; }
        .acct-pager-btn.is-active {
            background: linear-gradient(135deg, #be123c, #9f1239);
            border-color: #be123c;
            color: #ffffff;
            box-shadow: 0 4px 10px -4px rgba(190, 18, 60, .6);
        }
        .acct-pager-btn.is-disabled { opacity: .35; pointer-events: none; }

        /* 玩家帳號查詢：每頁筆數控制項（自帶樣式，避免依賴未編譯的 Tailwind 工具類） */
        .acct-per {
            display: inline-flex;
            align-items: center;
            gap: .35rem;
            white-space: nowrap;
            flex: 0 0 auto;
        }
        .acct-per__label { font-size: .68rem; line-height: 1; color: #64748b; }
        .acct-per__select {
            display: inline-block;
            width: auto;
            min-width: 3.1rem;
            height: 1.6rem;
            padding: 0 1.3rem 0 .5rem;
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            font-size: .68rem;
            line-height: 1.6rem;
            color: #475569;
            background-color: #ffffff;
            background-image: url("data:image/svg+xml;charset=utf-8,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3E%3Cpath stroke='%2364748b' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right .35rem center;
            background-size: .8rem .8rem;
            border: 1px solid #cbd5e1;
            border-radius: .45rem;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            cursor: pointer;
            vertical-align: middle;
        }
        .acct-per__select:focus { outline: none; border-color: #be123c; box-shadow: 0 0 0 2px rgba(190, 18, 60, .15); }

        /* 補齊本頁新增、但未收錄於編譯版 CSS 的工具類 */
        .text-\[11px\] { font-size: 11px; line-height: 1.45; }
        .text-\[10px\] { font-size: 10px; line-height: 1.4; }
        .mt-0\.5 { margin-top: .125rem; }
        .px-1\.5 { padding-left: .375rem; padding-right: .375rem; }
        .py-0\.5 { padding-top: .125rem; padding-bottom: .125rem; }
        .bg-rose-50\/70 { background-color: rgba(255, 241, 242, .7); }
        .ring-1 { box-shadow: 0 0 0 1px var(--tw-ring-color, rgba(148, 163, 184, .5)); }
        .ring-rose-300 { --tw-ring-color: #fda4af; }
        .hover\:bg-slate-50:hover { background-color: #f8fafc; }
        .hover\:border-slate-300:hover { border-color: #cbd5e1; }
        /* 帳號層級管理子視窗所需工具類 */
        .bg-violet-600 { background-color: #7c3aed; }
        .hover\:bg-violet-700:hover { background-color: #6d28d9; }
        .hover\:bg-violet-50:hover { background-color: #f5f3ff; }
        .hover\:border-violet-400:hover { border-color: #a78bfa; }
        .text-violet-500 { color: #8b5cf6; }
        .border-violet-400 { border-color: #a78bfa; }
        .hover\:bg-white:hover { background-color: #ffffff; }
        .min-h-\[160px\] { min-height: 160px; }
        .py-10 { padding-top: 2.5rem; padding-bottom: 2.5rem; }
        /* 圖示選擇器 */
        .acct-icon-scroll { max-height: 46vh; }
        .acct-icon-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(56px, 1fr)); gap: 6px; }
        .acct-icon-cell { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; padding: 6px 2px; border-radius: 10px; border: 1px solid #e2e8f0; background: #fff; cursor: pointer; min-height: 52px; transition: transform .15s ease, border-color .15s ease, background .15s ease, box-shadow .15s ease; }
        .acct-icon-cell:hover { border-color: #a78bfa; background: #f5f3ff; transform: translateY(-1px); }
        .acct-icon-cell i { font-size: 16px; color: #475569; }
        .acct-icon-cell span { font-size: 8px; color: #94a3b8; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .acct-icon-cell.is-active { border-color: #7c3aed; background: #f5f3ff; box-shadow: 0 0 0 2px rgba(124,58,237,.15); }
        .acct-icon-cell.is-active i { color: #7c3aed; }
        @media (min-width: 1024px) {
            .lg\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        }
        @media (max-width: 640px) {
            .account-fab-wrap { left: 1rem; bottom: 1rem; }
            .account-fab { width: 3.2rem; height: 3.2rem; }
            .account-fab__tip { display: none; }
            .account-fab-menu { width: 13rem; max-width: calc(100vw - 5.5rem); }
        }

        /* ==================================================================
           管理工具捷徑 · 華麗特效按鈕選單
           依模組分組，卡片式捷徑具備：掃光、光暈、上緣漸層、圖示彈跳、
           浮起陰影與錯位進場動畫。
           ================================================================== */
        .admin-hub { position: relative; overflow: hidden; }
        .admin-hub::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, #be123c, #0284c7, transparent);
            background-size: 200% 100%;
            animation: adminHubScan 7s linear infinite;
            opacity: .75;
            pointer-events: none;
        }
        @keyframes adminHubScan {
            0%   { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }
        .admin-hub__badge { animation: adminBadgeGlow 3.4s ease-in-out infinite; }
        @keyframes adminBadgeGlow {
            0%, 100% { box-shadow: inset 0 0 6px rgba(244, 63, 94, .2); }
            50%      { box-shadow: inset 0 0 6px rgba(244, 63, 94, .25), 0 0 16px rgba(244, 63, 94, .45); }
        }

        /* 攤平捷徑：桌機固定 6 欄 → 11 項排成兩列 */
        .admin-flat-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: .6rem;
        }
        @media (min-width: 560px) {
            .admin-flat-grid { grid-template-columns: repeat(3, minmax(0, 1fr)); }
        }
        @media (min-width: 768px) {
            .admin-flat-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); }
        }
        @media (min-width: 1024px) {
            .admin-flat-grid { grid-template-columns: repeat(6, minmax(0, 1fr)); }
        }

        /* 單一捷徑卡片 */
        .nav-card {
            position: relative;
            display: flex;
            align-items: center;
            gap: .7rem;
            padding: .7rem .8rem;
            border-radius: 14px;
            overflow: hidden;
            isolation: isolate;
            cursor: pointer;
            text-align: left;
            text-decoration: none;
            color: inherit;
            background: linear-gradient(145deg, rgba(30, 41, 59, .72), rgba(15, 23, 42, .88));
            border: 1px solid rgba(148, 163, 184, .14);
            box-shadow: 0 4px 14px -6px rgba(0, 0, 0, .55), inset 0 1px 0 rgba(255, 255, 255, .05);
            transition: transform .38s cubic-bezier(.22, 1, .36, 1), box-shadow .38s ease, border-color .38s ease, background .38s ease;
            animation: navCardIn .55s cubic-bezier(.22, 1, .36, 1) both;
            animation-delay: var(--nav-delay, 0ms);
        }
        @keyframes navCardIn {
            from { opacity: 0; transform: translateY(14px) scale(.95); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }
        /* 主體光暈 */
        .nav-card__glow {
            position: absolute;
            inset: -35%;
            background: radial-gradient(circle at 28% 18%, var(--accent) 0%, transparent 58%);
            opacity: .12;
            transition: opacity .4s ease, transform .5s ease;
            z-index: 0;
            pointer-events: none;
        }
        /* 斜向掃光 */
        .nav-card__sheen {
            position: absolute;
            top: -20%;
            bottom: -20%;
            left: -70%;
            width: 50%;
            background: linear-gradient(105deg, transparent, rgba(255, 255, 255, .24), transparent);
            transform: skewX(-18deg) translateX(0);
            transition: transform .85s cubic-bezier(.22, 1, .36, 1);
            z-index: 1;
            pointer-events: none;
        }
        /* 上緣漸層指示條 */
        .nav-card__bar {
            position: absolute;
            top: 0;
            left: 0;
            height: 2px;
            width: 0;
            background: linear-gradient(90deg, var(--accent), var(--accent-2));
            box-shadow: 0 0 12px var(--accent);
            transition: width .45s cubic-bezier(.22, 1, .36, 1);
            z-index: 2;
            pointer-events: none;
        }
        .nav-card__ico {
            position: relative;
            z-index: 2;
            flex: 0 0 auto;
            width: 2.3rem;
            height: 2.3rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 11px;
            color: #fff;
            background: linear-gradient(140deg, var(--accent), var(--accent-2));
            box-shadow: 0 6px 16px -6px var(--accent), inset 0 1px 0 rgba(255, 255, 255, .45);
            transition: transform .45s cubic-bezier(.34, 1.56, .64, 1), box-shadow .4s ease, filter .4s ease;
        }
        .nav-card__ico i { font-size: .95rem; }
        .nav-card__text {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            min-width: 0;
        }
        .nav-card__title {
            font-weight: 700;
            font-size: .8rem;
            color: #e2e8f0;
            letter-spacing: .01em;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: color .3s ease;
        }
        .nav-card__sub {
            font-size: .62rem;
            color: #64748b;
            font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
            letter-spacing: .03em;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            transition: color .3s ease;
        }
        .nav-card__go {
            position: relative;
            z-index: 2;
            margin-left: auto;
            font-size: .7rem;
            color: var(--accent);
            opacity: 0;
            transform: translateX(-6px);
            transition: opacity .35s ease, transform .35s cubic-bezier(.22, 1, .36, 1);
        }
        /* hover / focus 狀態 */
        .nav-card:hover {
            transform: translateY(-4px);
            border-color: var(--accent);
            background: linear-gradient(145deg, rgba(30, 41, 59, .95), rgba(15, 23, 42, .97));
            box-shadow: 0 18px 36px -14px var(--accent), 0 4px 16px -6px rgba(0, 0, 0, .6);
        }
        .nav-card:hover .nav-card__glow { opacity: .28; transform: scale(1.08); }
        .nav-card:hover .nav-card__sheen { transform: skewX(-18deg) translateX(380%); }
        .nav-card:hover .nav-card__bar { width: 100%; }
        .nav-card:hover .nav-card__ico {
            transform: translateY(-2px) rotate(-6deg) scale(1.08);
            box-shadow: 0 10px 24px -6px var(--accent), inset 0 1px 0 rgba(255, 255, 255, .55);
            filter: saturate(1.15);
        }
        .nav-card:hover .nav-card__title { color: #ffffff; }
        .nav-card:hover .nav-card__sub { color: var(--accent); }
        .nav-card:hover .nav-card__go { opacity: 1; transform: translateX(0); }
        .nav-card:active { transform: translateY(-1px) scale(.985); }
        .nav-card:active .nav-card__ico { transform: scale(.94) rotate(0); }
        .nav-card:focus-visible {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(56, 189, 248, .3), 0 18px 36px -14px var(--accent);
        }

        @media (max-width: 640px) {
            .nav-card__ico { width: 2rem; height: 2rem; border-radius: 10px; }
            .nav-card__title { font-size: .74rem; }
        }
        @media (prefers-reduced-motion: reduce) {
            .admin-hub::before,
            .admin-hub__badge { animation: none; }
            .nav-card { animation: none; }
            .nav-card,
            .nav-card__glow,
            .nav-card__sheen,
            .nav-card__bar,
            .nav-card__ico,
            .nav-card__go,
            .nav-card__title,
            .nav-card__sub { transition: none; }
        }
    </style>
</head>
<body class="relative min-h-screen flex flex-col justify-between selection:bg-rose-900 selection:text-white antialiased text-slate-100">
<!-- GPU 飄雪動效畫布 -->
<canvas id="snow-canvas"></canvas>
<!-- 帳號管理：左下方浮動多功能選單（玩家帳號查詢 + GM 管理員帳號） -->
<div class="account-fab-wrap" id="account-fab-wrap">
    <div class="account-fab-menu" id="account-fab-menu" role="menu" aria-label="帳號管理選單">
        <button type="button" class="account-fab-menu__item" role="menuitem" onclick="openAccountModal()">
            <span class="account-fab-menu__ico t-sky"><i class="fa-solid fa-magnifying-glass"></i></span>
            <span class="account-fab-menu__txt">
                <strong>玩家帳號查詢</strong>
                <small>完整帳號管理面板</small>
            </span>
            <i class="fa-solid fa-chevron-right account-fab-menu__go"></i>
        </button>
        <button type="button" class="account-fab-menu__item" role="menuitem" onclick="openGmAccountsModal()">
            <span class="account-fab-menu__ico t-amber"><i class="fa-solid fa-user-gear"></i></span>
            <span class="account-fab-menu__txt">
                <strong>GM 管理員帳號</strong>
                <small>新增 / 移除後台帳號</small>
            </span>
            <i class="fa-solid fa-chevron-right account-fab-menu__go"></i>
        </button>
    </div>
    <button type="button" id="account-fab" class="account-fab" onclick="toggleAccountFab()" title="帳號管理選單" aria-label="開啟帳號管理選單" aria-haspopup="true" aria-expanded="false">
        <span class="account-fab__ring"></span>
        <span class="account-fab__ring account-fab__ring--delay"></span>
        <i class="fa-solid fa-user-shield text-xl relative z-10"></i>
        <span class="account-fab__tip">帳號管理選單</span>
    </button>
</div>


<!-- 頂部現代仙俠中樞導航 -->
<header class="relative z-30 border-b border-slate-800/90 bg-[#070b14]/90 backdrop-blur-xl sticky top-0 shadow-2xl">
    <div class="h-[2px] w-full bg-gradient-to-r from-transparent via-rose-600/70 to-transparent"></div>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between gap-4 h-16 w-full flex-nowrap">
            <div class="flex items-center space-x-4 shrink-0">
                <a class="flex items-center space-x-3 group no-underline shrink-0" href="gmpanel.php">
                    <div class="relative shrink-0">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-rose-950/80 via-slate-900 to-black p-0.5 border border-rose-500/40 shadow-xl group-hover:border-rose-400 transition-all flex items-center justify-center overflow-hidden">
                            <img alt="踏雪笑傲" class="w-full h-full object-cover rounded-lg group-hover:scale-105 transition-transform duration-300" src="../assets/logo.svg">
                        </div>
                        <span class="absolute -bottom-0.5 -right-0.5 flex h-3 w-3 items-center justify-center">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500 border-2 border-[#070b14]"></span>
                        </span>
                    </div>
                    <div class="flex flex-col justify-center space-y-0.5 whitespace-nowrap">
                        <div class="flex items-center space-x-2">
                            <span class="text-lg font-bold tracking-[0.18em] text-white font-serif drop-shadow-md whitespace-nowrap">踏雪笑傲</span>
                            <span class="text-[10px] tracking-wider px-2 py-0.5 rounded bg-gradient-to-r from-rose-950/90 to-rose-900/60 text-rose-300 border border-rose-500/50 font-serif font-bold uppercase shadow-sm flex items-center gap-1 whitespace-nowrap"><i class="fa-solid fa-scroll text-[9px] text-rose-400"></i> GM 管理後台</span>
                        </div>
                        <p class="text-[9px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel'] font-medium flex items-center gap-1 whitespace-nowrap">
                            <span>SNOW WANDERER ONLINE</span>
                            <span class="text-rose-500/60">•</span>
                            <span class="text-slate-500">CENTRAL CORE</span>
                        </p>
                    </div>
                </a>
            </div>
            <nav class="hidden lg:flex items-center flex-nowrap shrink-0 gap-1.5 text-xs font-serif">
                <a class="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition-all flex items-center gap-1.5 font-medium border border-transparent hover:border-slate-700/60 whitespace-nowrap" href="gmpanel.php">
                    <div class="w-5 h-5 rounded bg-slate-800/80 flex items-center justify-center text-slate-400"><i class="fa-solid fa-compass text-xs"></i></div>
                    <span>總覽儀表</span>
                </a>
                <a class="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition-all flex items-center gap-1.5 font-medium border border-transparent hover:border-slate-700/60 relative whitespace-nowrap" href="support_admin.php">
                    <div class="w-5 h-5 rounded bg-slate-800/80 flex items-center justify-center text-sky-400"><i class="fa-solid fa-headset text-xs"></i></div>
                    <span>客服工單</span>
                    <?php if ((int)$supportStats['awaiting'] > 0): ?><span class="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse ring-2 ring-rose-950"></span><?php endif; ?>
                </a>
                <button type="button" class="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition-all flex items-center gap-1.5 font-medium border border-transparent hover:border-slate-700/60 whitespace-nowrap cursor-pointer" onclick="openCreditModal()">
                    <div class="w-5 h-5 rounded bg-slate-800/80 flex items-center justify-center text-teal-400"><i class="fa-solid fa-gauge-high text-xs"></i></div>
                    <span>信用管理</span>
                </button>
                <a class="px-3 py-1.5 text-slate-400 hover:text-white hover:bg-slate-800/60 rounded-xl transition-all flex items-center gap-1.5 font-medium border border-transparent hover:border-slate-700/60 whitespace-nowrap" href="wallet_admin.php">
                    <div class="w-5 h-5 rounded bg-slate-800/80 flex items-center justify-center text-amber-400"><i class="fa-solid fa-wallet text-xs"></i></div>
                    <span>錢包管理</span>
                </a>
            </nav>
            <div class="flex items-center flex-nowrap gap-2.5 shrink-0">
                <a class="relative px-3.5 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:from-amber-400 hover:via-orange-400 hover:to-rose-400 border border-amber-300/60 rounded-xl shadow-lg shadow-amber-900/40 hover:shadow-orange-900/50 transition-all flex items-center gap-1.5 whitespace-nowrap shrink-0 group" href="../home.php" target="_blank" rel="noopener" title="開啟前台會員中心首頁">
                    <span class="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-300 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-200 border border-orange-500"></span>
                    </span>
                    <i class="fa-solid fa-house-chimney text-[11px] group-hover:scale-110 transition-transform"></i>
                    <span class="font-serif tracking-wide hidden sm:inline">前往前台首頁</span>
                    <i class="fa-solid fa-arrow-up-right-from-square text-[9px] opacity-80 hidden sm:inline"></i>
                </a>
                <div class="hidden sm:flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 px-3 py-1.5 rounded-xl text-xs shadow-inner whitespace-nowrap">
                    <span class="flex h-2 w-2 relative shrink-0">
                        <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span class="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                    </span>
                    <span class="text-slate-400 font-serif text-[11px] whitespace-nowrap">全服在線:</span>
                    <span class="font-mono text-emerald-400 font-bold text-xs tabular-nums tracking-wide whitespace-nowrap"><?php echo $onlineCount; ?> 人</span>
                </div>
                <div class="flex items-center space-x-2 bg-slate-900/90 border border-slate-800/90 px-2.5 py-1 rounded-xl shadow-md whitespace-nowrap">
                    <div class="w-6 h-6 rounded-lg bg-gradient-to-br from-rose-900 to-slate-800 flex items-center justify-center border border-rose-500/40 text-rose-300 text-xs shadow-sm shrink-0">
                        <i class="fa-solid fa-user-ninja"></i>
                    </div>
                    <div class="hidden md:flex flex-col text-left whitespace-nowrap">
                        <span class="font-bold text-slate-200 font-mono text-xs leading-none whitespace-nowrap"><?php echo htmlspecialchars($currentGmUsername); ?></span>
                        <span class="text-[9px] text-amber-400/90 font-serif leading-none mt-1 whitespace-nowrap">最高管理員</span>
                    </div>
                </div>
                <a class="px-3 py-1.5 text-xs text-rose-300 hover:text-white bg-rose-950/40 hover:bg-rose-950/80 border border-rose-800/50 hover:border-rose-600 rounded-xl transition-all flex items-center gap-1.5 font-serif shadow-sm whitespace-nowrap shrink-0" href="gmlogout.php">
                    <i class="fa-solid fa-arrow-right-from-bracket text-rose-400 text-xs"></i>
                    <span class="hidden sm:inline font-semibold whitespace-nowrap">登出系統</span>
                </a>
            </div>
        </div>
    </div>
</header>

<!-- 主作業區 -->
<main class="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full space-y-6">

    <!-- 1. 頂部核心狀態指標群 (KPI HUD) -->
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <!-- 指標 1: 即時在線玩家 -->
        <div class="glass-dark rounded-2xl p-5 border border-slate-800/90 relative overflow-hidden hover:border-emerald-500/40 transition-all flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2 text-sm font-serif text-slate-300">
                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
                    <span class="font-medium">即時在線玩家</span>
                </div>
                <span class="text-xs text-emerald-400 font-mono bg-emerald-950/50 px-2.5 py-0.5 rounded border border-emerald-800/40 font-semibold">即時</span>
            </div>
            <div class="flex items-baseline justify-between mt-2">
                <div class="text-3xl font-extrabold font-mono text-white tracking-tight tabular-nums"><?php echo $onlineCount; ?> <span class="text-sm font-serif text-slate-400 font-normal">位玩家</span></div>
                <div class="flex items-end gap-1.5 h-9">
                    <span class="w-2 bg-emerald-500/40 rounded-t h-3.5"></span>
                    <span class="w-2 bg-emerald-500/60 rounded-t h-6"></span>
                    <span class="w-2 bg-emerald-500/40 rounded-t h-4"></span>
                    <span class="w-2 bg-emerald-500/80 rounded-t h-8"></span>
                    <span class="w-2 bg-emerald-400 rounded-t h-9"></span>
                </div>
            </div>
            <p class="text-xs text-slate-400 mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-2"><i class="fa-solid fa-server text-xs text-emerald-400"></i><span>主伺服器連線正常 · 玩家名冊即時同步</span></p>
        </div>
        <!-- 指標 2: GM 管理人員 -->
        <div class="glass-dark rounded-2xl p-5 border border-slate-800/90 relative overflow-hidden hover:border-amber-500/40 transition-all flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2 text-sm font-serif text-slate-300">
                    <i class="fa-solid fa-user-shield text-amber-400 text-sm"></i>
                    <span class="font-medium">GM 管理人員</span>
                </div>
                <button type="button" class="text-xs text-amber-400 font-mono bg-amber-950/50 px-2.5 py-0.5 rounded border border-amber-800/40 hover:bg-amber-900/50 transition-colors font-semibold cursor-pointer" onclick="openLoginModal()">登入稽核</button>
            </div>
            <div class="flex items-baseline justify-between mt-2">
                <div class="text-3xl font-extrabold font-mono text-white tracking-tight tabular-nums"><?php echo $gmCount; ?> <span class="text-sm font-serif text-slate-400 font-normal">組帳號</span></div>
                <span class="text-xs font-serif text-amber-300 font-semibold">當值：<?php echo htmlspecialchars($currentGmUsername); ?></span>
            </div>
            <p class="text-xs text-slate-400 mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-2"><i class="fa-solid fa-key text-xs text-amber-400"></i><span>後台登入憑證與權限集中管理</span></p>
        </div>
        <!-- 指標 3: 申訴回報統計 -->
        <div class="glass-dark rounded-2xl p-5 border border-slate-800/90 relative overflow-hidden hover:border-rose-500/40 transition-all flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2 text-sm font-serif text-slate-300">
                    <i class="fa-solid fa-bell text-rose-400 animate-pulse text-sm"></i>
                    <span class="font-medium">申訴回報統計</span>
                </div>
                <span class="text-xs text-rose-400 font-mono bg-rose-950/50 px-2.5 py-0.5 rounded border border-rose-800/40 font-semibold"><?php echo (int)$supportStats['stale']; ?> 筆逾期</span>
            </div>
            <div class="flex items-baseline justify-between mt-2">
                <div class="text-3xl font-extrabold font-mono text-rose-400 tracking-tight tabular-nums"><?php echo (int)$supportStats['awaiting']; ?> <span class="text-sm font-serif text-slate-400 font-normal">待回覆</span></div>
                <span class="text-xs text-slate-400 font-serif">進行中：<?php echo $supportActive; ?> 件</span>
            </div>
            <p class="text-xs text-slate-400 mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-2"><i class="fa-solid fa-clock-rotate-left text-xs text-rose-400"></i><span>累計工單 <?php echo (int)$supportStats['total']; ?> 件 · 已結案 <?php echo (int)$supportStats['resolved']; ?> 件</span></p>
        </div>
        <!-- 指標 4: 系統狀態 -->
        <div class="glass-dark rounded-2xl p-5 border border-slate-800/90 relative overflow-hidden hover:border-sky-500/40 transition-all flex flex-col justify-between">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2 text-sm font-serif text-slate-300">
                    <i class="fa-solid fa-gauge-high text-sky-400 text-sm"></i>
                    <span class="font-medium">伺服器系統狀態</span>
                </div>
                <span class="text-xs text-sky-400 font-mono bg-sky-950/50 px-2.5 py-0.5 rounded border border-sky-800/40 font-semibold">極佳</span>
            </div>
            <div class="flex items-baseline justify-between mt-2">
                <div class="text-3xl font-extrabold font-mono text-sky-400 tracking-tight tabular-nums">ONLINE</div>
                <span class="text-xs font-mono text-slate-300 font-medium">資料庫已連線</span>
            </div>
            <p class="text-xs text-slate-400 mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-2"><i class="fa-solid fa-shield-halved text-xs text-sky-400"></i><span>指令集、玩家資料與預存程序運作正常</span></p>
        </div>
    </section>

    <!-- 2. 管理工具捷徑 · 系統功能列表 -->
    <section class="admin-hub glass-dark rounded-2xl p-4 sm:p-5 border border-slate-800 shadow-xl">
        <div class="admin-hub__head flex flex-col sm:flex-row sm:items-center justify-between pb-3 mb-4 gap-2">
            <div class="flex items-center gap-2.5">
                <div class="admin-hub__badge w-7 h-7 rounded-lg bg-rose-950/80 border border-rose-600/40 flex items-center justify-center text-rose-400 text-xs shadow-inner">
                    <i class="fa-solid fa-cube"></i>
                </div>
                <div class="leading-tight">
                    <span class="block text-xs font-bold text-slate-200 font-serif tracking-widest uppercase">管理工具捷徑 · 系統功能列表</span>
                    <span class="block text-[10px] text-slate-500 font-mono tracking-wider">MISSION CONTROL</span>
                </div>
            </div>
            <div class="flex items-center gap-3 text-[11px] text-slate-400">
                <span class="inline-flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>共 <?php echo (int)$adminMenuCount; ?> 項功能</span>
                <span class="font-mono text-slate-500">2-ROW GRID</span>
            </div>
        </div>
        <div class="admin-flat-grid">
            <?php $navIndex = 0; foreach ($adminMenuGroups as $group): ?>
                <?php foreach ($group['items'] as $item):
                    $pair = $themePair[$item['theme']] ?? ['#94a3b8', '#475569'];
                    $isButton = isset($item['onclick']);
                    $tag = $isButton ? 'button' : 'a';
                    $attr = $isButton
                        ? 'type="button" onclick="' . htmlspecialchars($item['onclick'], ENT_QUOTES) . '"'
                        : 'href="' . htmlspecialchars($item['href'], ENT_QUOTES) . '"';
                    $navIndex++;
                ?>
                <<?php echo $tag; ?> <?php echo $attr; ?>
                    class="nav-card"
                    style="--accent: <?php echo $pair[0]; ?>; --accent-2: <?php echo $pair[1]; ?>; --nav-delay: <?php echo ($navIndex * 45); ?>ms;">
                    <span class="nav-card__glow" aria-hidden="true"></span>
                    <span class="nav-card__sheen" aria-hidden="true"></span>
                    <span class="nav-card__bar" aria-hidden="true"></span>
                    <span class="nav-card__ico">
                        <i class="<?php echo htmlspecialchars($item['icon']); ?>"></i>
                    </span>
                    <span class="nav-card__text">
                        <span class="nav-card__title"><?php echo htmlspecialchars($item['label']); ?></span>
                        <span class="nav-card__sub"><?php echo htmlspecialchars($item['sub']); ?></span>
                    </span>
                    <span class="nav-card__go" aria-hidden="true"><i class="fa-solid fa-arrow-right"></i></span>
                </<?php echo $tag; ?>>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </section>


    <!-- 系統操作結果提示橫幅 -->
    <?php if ($notice !== ""): ?>
        <?php $isDanger = ($noticeType === 'danger'); ?>
        <div class="p-3.5 rounded-2xl border text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-lg backdrop-blur-md <?php echo $isDanger ? 'border-rose-500/30 bg-rose-950/30 text-rose-200' : 'border-emerald-500/30 bg-emerald-950/30 text-emerald-200'; ?>">
            <div class="flex items-center gap-2.5">
                <i class="fa-solid <?php echo $isDanger ? 'fa-circle-exclamation text-rose-400' : 'fa-circle-check text-emerald-400'; ?> text-base"></i>
                <span class="font-serif"><?php echo htmlspecialchars($notice); ?></span>
            </div>
            <span class="text-[11px] font-mono px-2.5 py-0.5 rounded border shrink-0 self-start sm:self-auto <?php echo $isDanger ? 'text-rose-400 bg-rose-900/40 border-rose-700/40' : 'text-emerald-400 bg-emerald-900/40 border-emerald-700/40'; ?>">CSRF Token 驗證正常</span>
        </div>
    <?php else: ?>
        <div class="p-3.5 rounded-2xl border border-emerald-500/30 bg-emerald-950/30 text-emerald-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-lg backdrop-blur-md">
            <div class="flex items-center gap-2.5">
                <i class="fa-solid fa-circle-check text-emerald-400 text-base"></i>
                <span class="font-serif">已成功連線主伺服器資料庫。指令集、玩家資料與預存程序運作正常。</span>
            </div>
            <span class="text-[11px] text-emerald-400 font-mono bg-emerald-900/40 px-2.5 py-0.5 rounded border border-emerald-700/40 shrink-0 self-start sm:self-auto">CSRF Token 驗證正常</span>
        </div>
    <?php endif; ?>

    <!-- 3. 主作業區：營運名冊與客服看板 -->
    <section class="grid grid-cols-1 gap-6 items-start">
        <!-- 即時線上名冊與申訴工單 -->
        <div class="space-y-6">


            <!-- 即時線上名冊與申訴工單並聯區 -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- 即時在線玩家 -->
                <div class="glass-jade corner-accent rounded-2xl p-6 text-slate-800 shadow-xl space-y-3.5">
                    <div class="flex items-center justify-between pb-3 border-b border-slate-200">
                        <div class="flex items-center gap-2.5">
                            <div class="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-sm shadow-sm"><i class="fa-solid fa-users"></i></div>
                            <h3 class="text-base font-bold text-slate-900 font-serif">即時在線玩家</h3>
                        </div>
                        <span class="text-xs text-emerald-800 bg-emerald-100 font-bold px-2.5 py-0.5 rounded-full border border-emerald-300"><?php echo $onlineCount; ?> 人在線</span>
                    </div>
                    <div class="space-y-2 max-h-72 overflow-y-auto pr-1 text-xs">
                        <?php foreach ($onlineList as $o): ?>
                            <div class="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 border border-slate-200 hover:bg-slate-100 transition-colors shadow-sm">
                                <div class="flex items-center gap-2.5 min-w-0">
                                    <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
                                    <span class="font-medium text-slate-800 font-serif text-sm truncate"><?php echo htmlspecialchars($o['name']); ?></span>
                                    <span class="text-xs text-slate-400 font-mono shrink-0">#<?php echo (int)$o['ID']; ?></span>
                                </div>
                                <a class="text-sky-600 hover:text-sky-800 font-serif text-xs font-bold transition-colors shrink-0" href="?id=<?php echo (int)$o['ID'] . $preserveQHtml; ?>">查看</a>
                            </div>
                        <?php endforeach; ?>
                        <?php if (empty($onlineList)): ?>
                            <div class="py-8 text-center text-slate-400 text-xs"><i class="fa-regular fa-moon mr-1"></i> 目前無人在線</div>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- 申訴回報看板 -->
                <div class="glass-jade corner-accent rounded-2xl p-6 text-slate-800 shadow-xl space-y-3.5 flex flex-col justify-between">
                    <div>
                        <div class="flex items-center justify-between pb-3 border-b border-slate-200 mb-3">
                            <div class="flex items-center gap-2.5">
                                <div class="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center text-sm shadow-sm"><i class="fa-solid fa-headset"></i></div>
                                <h3 class="text-base font-bold text-slate-900 font-serif">客服申訴工單</h3>
                            </div>
                            <a class="text-xs text-rose-700 hover:text-rose-800 font-serif font-bold flex items-center gap-1.5 transition-colors" href="support_admin.php"><span>工單管理</span><i class="fa-solid fa-chevron-right text-xs"></i></a>
                        </div>
                        <div class="grid grid-cols-4 gap-2 text-center text-xs">
                            <div class="bg-rose-50 p-2 rounded-xl border border-rose-200 shadow-sm"><span class="text-rose-700 block font-medium">待回覆</span><span class="font-bold text-rose-800 font-mono text-base"><?php echo (int)$supportStats['awaiting']; ?></span></div>
                            <div class="bg-amber-50 p-2 rounded-xl border border-amber-200 shadow-sm"><span class="text-amber-700 block font-medium">處理中</span><span class="font-bold text-amber-800 font-mono text-base"><?php echo (int)$supportStats['processing']; ?></span></div>
                            <div class="bg-red-50 p-2 rounded-xl border border-red-200 shadow-sm"><span class="text-red-700 block font-medium">逾期&gt;24h</span><span class="font-bold text-red-800 font-mono text-base"><?php echo (int)$supportStats['stale']; ?></span></div>
                            <div class="bg-emerald-50 p-2 rounded-xl border border-emerald-200 shadow-sm"><span class="text-emerald-700 block font-medium">已結案</span><span class="font-bold text-emerald-800 font-mono text-base"><?php echo (int)$supportStats['resolved']; ?></span></div>
                        </div>
                    </div>
                    <div class="space-y-2 mt-3">
                        <?php if (empty($recentTickets)): ?>
                            <div class="py-6 text-center text-slate-400 text-xs"><i class="fa-regular fa-circle-check mr-1"></i> 目前無待處理申訴</div>
                        <?php else: ?>
                            <?php foreach (array_slice($recentTickets, 0, 3) as $rt):
                                $pMeta = $supPrioMap[$rt['priority']] ?? ['label' => '一般'];
                                $sMeta = $supStatusMap[$rt['status']] ?? ['label' => $rt['status']];
                            ?>
                                <a href="support_admin.php?ticket=<?php echo (int)$rt['id']; ?>" class="block p-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 transition-colors shadow-sm no-underline">
                                    <div class="flex items-center justify-between">
                                        <span class="px-2 py-0.5 rounded text-xs font-bold <?php echo $pMeta['badge']; ?> border"><?php echo htmlspecialchars($pMeta['label']); ?></span>
                                        <span class="text-xs text-slate-500 font-mono font-medium"><?php echo htmlspecialchars($rt['ticket_no']); ?></span>
                                    </div>
                                    <p class="font-bold text-slate-900 truncate font-serif text-sm mt-1.5"><?php echo htmlspecialchars($rt['subject']); ?></p>
                                    <div class="flex items-center justify-between text-xs text-slate-600 pt-1.5 border-t border-slate-200 mt-1.5">
                                        <span class="font-medium"><?php echo htmlspecialchars($rt['username']); ?></span>
                                        <span class="text-rose-700 font-bold"><?php echo htmlspecialchars(gm_ago($rt['last_reply_at'] ?: $rt['created_at'])); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

    <!-- GM 管理員帳號 子視窗 -->
    <div class="fixed inset-0 flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="gm-accounts-modal" style="margin:0; z-index:70;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-2xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="gm-accounts-modal-card" style="max-height:90vh;">
            <div class="flex items-start justify-between gap-4 p-4 sm:p-5 border-b border-slate-200 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700 text-lg shrink-0">
                        <i class="fa-solid fa-user-gear"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            GM 管理員帳號
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">gm_accounts</span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-semibold">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> <?php echo count($gmAccountsList); ?> 組帳號
                            </span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">新增或移除可登入 GM 後台的管理員帳號，密碼以 bcrypt 雜湊儲存。</p>
                    </div>
                </div>
                <button type="button" onclick="closeGmAccountsModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
            <div class="p-4 sm:p-5 overflow-y-auto" style="min-height:0;">
                <div class="space-y-2 text-xs">
                    <?php foreach ($gmAccountsList as $g): $isSelf = ((int)$g['id'] === (int)$currentGmId); ?>
                        <div class="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3 shadow-sm">
                            <div class="flex items-center gap-2.5 min-w-0">
                                <span class="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center text-xs shrink-0"><i class="fa-solid fa-user-shield"></i></span>
                                <span class="font-mono text-slate-400 text-xs font-medium shrink-0">#<?php echo (int)$g['id']; ?></span>
                                <span class="font-bold text-slate-900 font-mono text-sm truncate"><?php echo htmlspecialchars($g['username']); ?></span>
                                <?php if ($isSelf): ?><span class="text-xs bg-rose-100 text-rose-700 px-2 py-0.5 rounded font-serif font-bold shrink-0">您</span><?php endif; ?>
                            </div>
                            <?php if ($isSelf): ?>
                                <span class="text-xs text-emerald-700 font-serif font-bold shrink-0">當值中</span>
                            <?php else: ?>
                                <form action="gmpanel.php" method="POST" onsubmit="return confirm('確認要移除此 GM 帳號嗎？');" class="shrink-0">
                                    <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                                    <input name="action" type="hidden" value="deletegm">
                                    <input name="gm_account_id" type="hidden" value="<?php echo (int)$g['id']; ?>">
                                    <button class="px-3 py-1.5 rounded-lg border border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100 text-xs font-bold transition-colors cursor-pointer" type="submit"><i class="fa-solid fa-user-minus mr-1"></i>移除</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                    <?php if (empty($gmAccountsList)): ?>
                        <div class="py-6 text-center text-slate-400 text-xs">尚無 GM 帳號</div>
                    <?php endif; ?>
                </div>
                <form action="gmpanel.php" class="mt-4 pt-4 border-t border-slate-200 space-y-3 text-xs" method="POST">
                    <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                    <input name="action" type="hidden" value="addgm">
                    <div class="flex items-center gap-2 text-slate-700 font-serif font-bold">
                        <i class="fa-solid fa-user-plus text-sky-600"></i><span>建立新的 GM 帳號</span>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:border-sky-600" name="new_gm_username" placeholder="帳號名稱（英數、_、-）" required type="text" autocomplete="off">
                        <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-sm text-slate-800 focus:outline-none focus:border-sky-600" name="new_gm_password" placeholder="密碼（至少 8 碼）" required type="password" autocomplete="new-password">
                    </div>
                    <button class="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-serif text-sm font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors cursor-pointer" type="submit"><i class="fa-solid fa-user-plus text-xs"></i><span>建立 GM 帳號</span></button>
                </form>
            </div>
        </div>
    </div>

    <!-- 玩家帳號查詢 / 完整帳號管理 子視窗 -->
    <div class="fixed inset-0 flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="account-modal" style="margin:0; z-index:65;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-7xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="account-modal-card" style="max-height:92vh;">
            <div class="flex items-start justify-between gap-4 p-4 sm:p-5 border-b border-slate-200">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700 text-lg shrink-0">
                        <i class="fa-solid fa-users-gear"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            玩家帳號查詢 · 完整帳號管理面板
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">users</span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">輸入角色名稱查詢玩家（留空則列出全部帳號），選取後即可於右側執行停權、補點、重設密碼與 GM 權限管理。</p>
                    </div>
                </div>
                <button type="button" onclick="closeAccountModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
            <div class="account-modal-body" style="flex:1 1 auto; min-height:0; overflow-y:auto; overflow-x:hidden;">
                <div class="p-4 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                    <div class="acct-col-left min-w-0 space-y-4">
            <!-- 玩家帳號查詢 -->
            <div class="glass-jade corner-accent rounded-2xl p-6 text-slate-800 shadow-2xl space-y-4">
                <div class="flex items-center justify-between pb-3 border-b border-slate-200">
                    <div class="flex items-center gap-2.5">
                        <div class="w-8 h-8 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center text-sm shadow-sm"><i class="fa-solid fa-magnifying-glass"></i></div>
                        <h3 class="text-base font-bold text-slate-900 font-serif tracking-wide">玩家帳號查詢</h3>
                    </div>
                    <span class="text-xs text-slate-500 font-mono bg-slate-100 px-2.5 py-0.5 rounded-md font-medium border border-slate-200">users</span>
                </div>
                <form action="" class="space-y-3.5" method="GET">
                    <input type="hidden" name="modal" value="1">
                    <input type="hidden" name="per" value="<?php echo (int)$searchPerPage; ?>">
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-slate-400"><i class="fa-solid fa-user-ninja text-sm"></i></span>
                        <input class="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-slate-300 bg-white text-slate-800 focus:outline-none focus:border-rose-600 focus:ring-2 focus:ring-rose-200 transition-all font-sans shadow-inner" id="account-search-input" name="q" placeholder="輸入角色名稱搜尋，留空顯示全部帳號..." type="text" value="<?php echo htmlspecialchars($searchTerm); ?>">
                    </div>
                    <div class="flex gap-2.5">
                        <button class="w-full btn-vermilion py-2.5 px-4 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-search text-xs"></i><span>查詢帳號</span></button>
                        <a class="px-3.5 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-sm font-serif transition-colors flex items-center justify-center shrink-0 border border-slate-200 shadow-sm" href="?modal=1" title="重置搜尋"><i class="fa-solid fa-rotate-left"></i></a>
                    </div>
                </form>
                <?php $pageExtra = $preserveQHtml . ($selectedId > 0 ? '&id=' . (int)$selectedId : ''); ?>
                <div class="mt-4 pt-3.5 border-t border-slate-200 space-y-2.5">
                    <div class="flex items-center justify-between text-xs text-slate-500 px-1 font-serif gap-2">
                        <span class="font-medium truncate">
                            <?php echo $searchTerm === '' ? '全部帳號' : '查詢結果'; ?>
                            <span class="font-mono text-slate-700">(<?php echo number_format($searchTotal); ?>)</span>
                        </span>
                        <?php if ($searchTotal > 0): ?>
                        <div class="acct-per">
                            <span class="acct-per__label">每頁</span>
                            <select class="acct-per__select" onchange="location.href='?page=1<?php echo $pageExtra; ?>&per='+this.value;">
                                <?php foreach ([10, 20, 50] as $pp): ?><option value="<?php echo $pp; ?>" <?php echo $searchPerPage === $pp ? 'selected' : ''; ?>><?php echo $pp; ?></option><?php endforeach; ?>
                            </select>
                        </div>
                        <?php else: ?>
                        <span class="shrink-0">按最近活躍排序</span>
                        <?php endif; ?>
                    </div>
                    <?php if ($searchTotal === 0): ?>
                        <div class="py-6 text-center text-slate-400 text-xs"><i class="fa-regular fa-face-frown mr-1"></i> <?php echo $searchTerm === '' ? '目前尚無帳號資料' : '找不到符合條件的帳號'; ?></div>
                    <?php else: ?>
                        <?php foreach ($searchResults as $r): $isCurrent = ((int)$r['ID'] === $selectedId); ?>
                            <a class="acct-search-item block px-3 py-2 rounded-lg border <?php echo $isCurrent ? 'border-rose-500 bg-rose-50/70 ring-1 ring-rose-300' : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'; ?>" href="?id=<?php echo (int)$r['ID'] . $preserveQHtml; ?>&page=<?php echo $searchPage; ?>&per=<?php echo $searchPerPage; ?>">
                                <div class="flex items-center justify-between gap-2">
                                    <span class="font-bold text-slate-900 font-serif text-xs truncate"><?php echo htmlspecialchars($r['name']); ?></span>
                                    <span class="text-[10px] font-mono text-slate-400 shrink-0">UID #<?php echo (int)$r['ID']; ?></span>
                                </div>
                                <div class="text-[11px] text-slate-500 font-mono truncate mt-0.5"><?php echo htmlspecialchars($r['email'] !== '' ? $r['email'] : '—'); ?></div>
                            </a>
                        <?php endforeach; ?>
                        <?php if ($searchTotalPages > 1): ?>
                            <div class="flex items-center justify-center gap-1 flex-wrap pt-1">
                                <a class="acct-pager-btn <?php echo $searchPage <= 1 ? 'is-disabled' : ''; ?>" href="?page=<?php echo max(1, $searchPage - 1) . $pageExtra; ?>&per=<?php echo $searchPerPage; ?>" title="上一頁"><i class="fa-solid fa-chevron-left"></i></a>
                                <?php for ($p = $searchPageStart; $p <= $searchPageEnd; $p++): ?>
                                    <a class="acct-pager-btn <?php echo $p === $searchPage ? 'is-active' : ''; ?>" href="?page=<?php echo $p . $pageExtra; ?>&per=<?php echo $searchPerPage; ?>"><?php echo $p; ?></a>
                                <?php endfor; ?>
                                <a class="acct-pager-btn <?php echo $searchPage >= $searchTotalPages ? 'is-disabled' : ''; ?>" href="?page=<?php echo min($searchTotalPages, $searchPage + 1) . $pageExtra; ?>&per=<?php echo $searchPerPage; ?>" title="下一頁"><i class="fa-solid fa-chevron-right"></i></a>
                            </div>
                            <div class="text-center text-[10px] text-slate-400 font-mono">第 <?php echo $searchPage; ?> / <?php echo $searchTotalPages; ?> 頁</div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
                    </div>
                    <div class="acct-col-right min-w-0 space-y-5">
            <?php if ($selectedAccount): ?>
            <!-- 檔案畫卷看板 -->
            <div class="glass-jade corner-accent rounded-2xl p-6 text-slate-800 shadow-2xl relative overflow-hidden space-y-5">
                <div class="absolute -right-8 -bottom-8 w-44 h-44 rounded-full border-8 border-rose-900/5 pointer-events-none flex items-center justify-center font-serif text-rose-900/5 text-6xl font-black rotate-12 select-none">踏雪</div>
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-200">
                    <div class="flex items-start sm:items-center gap-4">
                        <div class="relative">
                            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-rose-800 to-slate-900 text-white flex items-center justify-center text-3xl font-serif font-black shadow-xl border-2 border-rose-200 shrink-0"><?php echo htmlspecialchars($selectedInitial); ?></div>
                            <?php if (!empty($selectedForbids)): ?>
                                <span class="absolute -bottom-1 -right-1 bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-white shadow">受限</span>
                            <?php else: ?>
                                <span class="absolute -bottom-1 -right-1 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full border-2 border-white shadow">正常</span>
                            <?php endif; ?>
                        </div>
                        <div>
                            <div class="flex items-center gap-2.5 mb-1.5 flex-wrap">
                                <span class="px-3 py-0.5 rounded-md text-xs font-bold bg-rose-100 text-rose-800 border border-rose-300 font-serif">UID #<?php echo (int)$selectedAccount['ID']; ?></span>
                                <span class="text-xs text-slate-600 font-mono font-medium">註冊：<?php echo htmlspecialchars($selectedAccount['creatime']); ?></span>
                                <span class="inline-flex items-center gap-1.5 text-xs font-bold px-2.5 py-0.5 rounded-full <?php echo empty($selectedForbids) ? 'text-emerald-700 bg-emerald-50 border border-emerald-200' : 'text-rose-700 bg-rose-50 border border-rose-200'; ?>"><span class="w-2 h-2 rounded-full <?php echo empty($selectedForbids) ? 'bg-emerald-500' : 'bg-rose-500'; ?> animate-pulse"></span><?php echo empty($selectedForbids) ? '帳號狀態正常' : '帳號受限中'; ?></span>
                                <?php echo account_tier_badge_html($selectedTier, ['size' => 'lg', 'title' => '帳號層級']); ?>
                            </div>
                            <h2 class="text-2xl sm:text-3xl font-bold text-slate-900 font-serif flex items-center gap-2.5 flex-wrap">
                                <span><?php echo htmlspecialchars($selectedAccount['name']); ?></span>
                                <?php if (!empty($selectedAccount['truename'])): ?><span class="text-sm font-normal text-slate-500 font-mono">(<?php echo htmlspecialchars($selectedAccount['truename']); ?>)</span><?php endif; ?>
                            </h2>
                            <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" method="POST" class="flex flex-wrap items-center gap-2 mt-2">
                                <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                                <input name="action" type="hidden" value="assign_tier">
                                <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                <label class="text-[11px] text-slate-500 font-serif"><i class="fa-solid fa-layer-group text-violet-500 mr-1"></i>帳號層級</label>
                                <select name="tier_id" class="appearance-none px-2.5 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                                    <option value="0">（回復預設）</option>
                                    <?php foreach ($allTiers as $t): ?>
                                        <option value="<?php echo (int)$t['id']; ?>" <?php echo ((int)($selectedTier['id'] ?? 0) === (int)$t['id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($t['name']); ?><?php echo ((int)$t['enabled'] === 1) ? '' : '（停用）'; ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" class="px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-700 text-white text-xs font-semibold transition-colors">儲存層級</button>
                            </form>
                        </div>
                    </div>
                    <a href="<?php echo $backUrl; ?>" class="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-serif text-xs font-semibold shadow-sm transition-colors shrink-0">
                        <i class="fa-solid fa-arrow-left text-[10px]"></i><span><?php echo $backLabel; ?></span>
                    </a>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                    <div class="p-4 rounded-xl bg-slate-50/80 border border-slate-200/90 space-y-3 text-xs shadow-sm">
                        <div class="font-bold text-slate-900 font-serif flex items-center gap-2 pb-2 border-b border-slate-200 text-sm"><i class="fa-solid fa-address-card text-sky-600"></i><span>會員基本資料</span></div>
                        <div class="grid grid-cols-2 gap-3 text-xs pt-1">
                            <div><span class="text-slate-500 block font-medium mb-0.5">電子信箱</span><span class="font-mono text-slate-800 font-medium truncate block"><?php echo htmlspecialchars($selectedAccount['email']); ?></span></div>
                            <div><span class="text-slate-500 block font-medium mb-0.5">手機號碼</span><span class="font-mono text-slate-800 font-medium"><?php echo htmlspecialchars((string)$selectedAccount['mobilenumber']); ?></span></div>
                            <div><span class="text-slate-500 block font-medium mb-0.5">真實姓名</span><span class="font-mono text-slate-700"><?php echo !empty($selectedAccount['truename']) ? htmlspecialchars((string)$selectedAccount['truename']) : '—'; ?></span></div>
                            <div><span class="text-slate-500 block font-medium mb-0.5">註冊時間</span><span class="font-mono text-slate-700"><?php echo htmlspecialchars($selectedAccount['creatime']); ?></span></div>
                        </div>
                    </div>
                    <div class="p-4 rounded-xl bg-slate-50/80 border border-slate-200/90 space-y-3 text-xs shadow-sm">
                        <div class="flex items-center justify-between pb-2 border-b border-slate-200">
                            <div class="font-bold text-slate-900 font-serif flex items-center gap-2 text-sm"><i class="fa-solid fa-coins text-amber-500"></i><span>點數餘額與分區</span></div>
                            <span class="text-xs text-slate-500 font-mono bg-white px-2 py-0.5 rounded border border-slate-200 font-medium">point</span>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left text-xs">
                                <thead class="text-slate-500 text-xs font-serif border-b border-slate-200">
                                    <tr><th class="py-1.5">分區</th><th class="py-1.5">Aid</th><th class="py-1.5">持有點數</th><th class="py-1.5 text-right">最後登入</th></tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 font-mono text-xs">
                                    <?php foreach ($selectedPoints as $p): ?>
                                        <tr>
                                            <td class="py-2 font-medium text-slate-800"><?php echo (int)$p['zoneid']; ?> 區</td>
                                            <td class="py-2 text-slate-600"><?php echo (int)$p['aid']; ?></td>
                                            <td class="py-2 font-bold text-emerald-600 text-sm"><?php echo (int)$p['time']; ?> 點</td>
                                            <td class="py-2 text-slate-500 text-right"><?php echo htmlspecialchars($p['lastlogin']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($selectedPoints)): ?>
                                        <tr><td colspan="4" class="py-3 text-center text-slate-400 text-xs">沒有點數記錄</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- 處分紀錄 -->
                <?php if (empty($selectedForbids)): ?>
                    <div class="p-3.5 rounded-xl border border-emerald-200 bg-emerald-50/50 text-xs sm:text-sm flex items-center justify-between shadow-sm">
                        <div class="flex items-center gap-2.5"><i class="fa-regular fa-circle-check text-emerald-600 text-base shrink-0"></i><span class="font-serif text-slate-800 font-medium">處分紀錄 (forbid)：目前無任何停權、禁言或交易限制紀錄。</span></div>
                        <span class="text-xs text-emerald-700 font-mono bg-emerald-100 px-2.5 py-1 rounded font-bold border border-emerald-200 shrink-0">狀態良好</span>
                    </div>
                <?php else: ?>
                    <div class="rounded-xl border border-rose-200 bg-rose-50/40 overflow-hidden shadow-sm">
                        <div class="px-3.5 py-2 border-b border-rose-200 flex items-center justify-between">
                            <span class="text-xs font-bold text-rose-900 font-serif flex items-center gap-1.5"><i class="fa-solid fa-ban"></i> 目前封鎖紀錄 (forbid)</span>
                            <span class="text-[10px] text-rose-700 font-mono"><?php echo count($selectedForbids); ?> 筆</span>
                        </div>
                        <table class="w-full text-left text-xs">
                            <thead class="bg-rose-50 text-rose-700 text-[11px]">
                                <tr><th class="py-1.5 px-3">類型</th><th class="py-1.5 px-3">開始時間</th><th class="py-1.5 px-3">時長(秒)</th><th class="py-1.5 px-3">原因</th><th class="py-1.5 px-3 text-right">操作</th></tr>
                            </thead>
                            <tbody class="divide-y divide-rose-100">
                                <?php foreach ($selectedForbids as $f): ?>
                                    <tr>
                                        <td class="py-2 px-3 font-mono"><?php echo (int)$f['type']; ?></td>
                                        <td class="py-2 px-3 text-slate-500 font-mono text-[11px]"><?php echo htmlspecialchars($f['ctime']); ?></td>
                                        <td class="py-2 px-3 font-mono text-[11px]"><?php echo (int)$f['forbid_time']; ?></td>
                                        <td class="py-2 px-3 text-slate-600"><?php echo htmlspecialchars($f['reason']); ?></td>
                                        <td class="py-2 px-3 text-right">
                                            <form method="POST" action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="inline">
                                                <input type="hidden" name="form_token" value="<?php echo htmlspecialchars($formToken); ?>">
                                                <input type="hidden" name="action" value="unban">
                                                <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                                <input type="hidden" name="unban_type" value="<?php echo (int)$f['type']; ?>">
                                                <button type="submit" class="text-sky-600 hover:text-sky-800 text-[11px] font-bold transition-colors cursor-pointer">解除</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>

            <!-- 一體化操作台 (Tabs) -->
            <div class="glass-jade corner-accent rounded-2xl p-6 text-slate-800 shadow-2xl space-y-5 min-w-0 overflow-hidden">
                <div class="acct-tabbar-head flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-3">
                    <div class="min-w-0">
                        <h3 class="text-lg font-bold text-slate-900 font-serif flex items-center gap-2"><i class="fa-solid fa-scroll text-rose-700"></i><span>帳號操作管理</span></h3>
                        <p class="text-xs text-slate-500 mt-0.5">針對目標玩家 UID #<?php echo (int)$selectedAccount['ID']; ?> 執行系統管理指令</p>
                    </div>
                    <div class="action-tabs text-xs font-serif min-w-0" role="tablist" aria-label="帳號操作選單">
                        <button type="button" role="tab" aria-selected="true" class="tab-btn active" id="btn-tab-ban" onclick="switchActionTab('tab-ban')" style="--tab-accent:#e11d48; --tab-accent-2:#9f1239;">
                            <span class="tab-ico"><i class="fa-solid fa-gavel"></i></span><span class="tab-label">帳號停權處分</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-grant" onclick="switchActionTab('tab-grant')" style="--tab-accent:#f59e0b; --tab-accent-2:#d97706;">
                            <span class="tab-ico"><i class="fa-solid fa-circle-dollar-to-slot"></i></span><span class="tab-label">補發點數/元寶</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-pwd" onclick="switchActionTab('tab-pwd')" style="--tab-accent:#0ea5e9; --tab-accent-2:#0369a1;">
                            <span class="tab-ico"><i class="fa-solid fa-key"></i></span><span class="tab-label">重設密碼</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-gm" onclick="switchActionTab('tab-gm')" style="--tab-accent:#8b5cf6; --tab-accent-2:#6d28d9;">
                            <span class="tab-ico"><i class="fa-solid fa-shield-halved"></i></span><span class="tab-label">GM 權限管理</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-perm" onclick="switchActionTab('tab-perm')" style="--tab-accent:#10b981; --tab-accent-2:#047857;">
                            <span class="tab-ico"><i class="fa-solid fa-user-lock"></i></span><span class="tab-label">會員功能權限</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-data" onclick="switchActionTab('tab-data')" style="--tab-accent:#6366f1; --tab-accent-2:#4338ca;">
                            <span class="tab-ico"><i class="fa-solid fa-database"></i></span><span class="tab-label">帳號詳細資料</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-orders" onclick="switchActionTab('tab-orders')" style="--tab-accent:#0d9488; --tab-accent-2:#0f766e;">
                            <span class="tab-ico"><i class="fa-solid fa-receipt"></i></span><span class="tab-label">歷史訂單</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-wallet" onclick="switchActionTab('tab-wallet')" style="--tab-accent:#d97706; --tab-accent-2:#b45309;">
                            <span class="tab-ico"><i class="fa-solid fa-wallet"></i></span><span class="tab-label">錢包管理</span>
                        </button>
                        <button type="button" role="tab" aria-selected="false" class="tab-btn" id="btn-tab-support" onclick="switchActionTab('tab-support')" style="--tab-accent:#f97316; --tab-accent-2:#c2410c;">
                            <span class="tab-ico"><i class="fa-solid fa-headset"></i></span><span class="tab-label">工單回報</span>
                        </button>
                    </div>
                </div>

                <!-- Tab 1: 停權處分 -->
                <div class="tab-pane active" id="tab-ban">
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="action" type="hidden" value="ban">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">處分類型 (寫入 forbid 稽核紀錄)</label>
                                <select class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-rose-200 focus:border-rose-600 font-sans shadow-inner" name="ban_type">
                                    <option value="1">1 - 全服登入凍結 (封鎖帳號)</option>
                                    <option value="2">2 - 遊戲內全頻道禁言處分 (禁言)</option>
                                    <option value="3">3 - 拍賣行與擺攤交易限制 (限交)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">持續時間（小時，0 為永久）</label>
                                <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-rose-200 focus:border-rose-600 shadow-inner" name="ban_hours" type="number" value="24">
                            </div>
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">處分原因說明</label>
                            <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-rose-200 focus:border-rose-600 shadow-inner" name="ban_reason" maxlength="255" placeholder="請詳細輸入處分原因，例如：散布不當廣告、使用非法外掛程式..." type="text">
                        </div>
                        <div class="pt-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <span class="text-xs text-slate-500 font-serif">執行後將強制中斷玩家連線並記錄於系統日誌</span>
                            <button class="btn-vermilion px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-gavel text-xs"></i><span>確認執行停權處分</span></button>
                        </div>
                    </form>
                </div>

                <!-- Tab 2: 發放點數 -->
                <div class="tab-pane" id="tab-grant">
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="action" type="hidden" value="grant">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                            <div><label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">分區 (zoneid)</label><input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-xs sm:text-sm" name="zoneid" type="number" value="1"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">Aid 標識</label><input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-xs sm:text-sm" name="aid" type="number" value="1"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">增補點數 (Points)</label><input class="w-full px-3.5 py-2.5 rounded-xl border border-amber-300 bg-amber-50/50 font-mono font-bold text-amber-700 text-xs sm:text-sm" name="points" type="number" value="100"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">增補元寶/現金 (Cash)</label><input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-xs sm:text-sm" name="cash" type="number" value="0"></div>
                        </div>
                        <div class="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <span class="flex items-center gap-2 font-serif"><i class="fa-solid fa-wand-magic-sparkles text-amber-600 text-sm"></i>呼叫 usecash 預存程序將自動生成唯一交易 sn，無需人工對帳。</span>
                            <span class="font-mono text-amber-800 text-xs font-semibold">EXEC usecash(@uid, @zoneid, @aid, @points, @cash)</span>
                        </div>
                        <div class="pt-2.5 flex items-center justify-end">
                            <button class="btn-amber px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-gift text-xs"></i><span>確認撥付點數</span></button>
                        </div>
                    </form>
                </div>

                <!-- Tab 3: 重設密碼 -->
                <div class="tab-pane" id="tab-pwd">
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="action" type="hidden" value="resetpw">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                        <input name="target_username" type="hidden" value="<?php echo htmlspecialchars($selectedAccount['name']); ?>">
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">目標角色名稱 (不可更改)</label>
                                <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-100 text-slate-600 font-serif text-xs sm:text-sm" readonly type="text" value="<?php echo htmlspecialchars($selectedAccount['name']); ?>">
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">新設定密碼 (4-10 個字元)</label>
                                <div class="relative">
                                    <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white pr-10 text-xs sm:text-sm focus:ring-2 focus:ring-sky-200 focus:border-sky-600 shadow-inner" id="user_new_pw" name="new_passwd" placeholder="請輸入全新安全密碼..." type="password">
                                    <button class="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer" onclick="togglePasswordVisibility('user_new_pw')" type="button"><i class="fa-regular fa-eye text-sm"></i></button>
                                </div>
                            </div>
                        </div>
                        <p class="text-xs text-slate-500 font-serif">系統將以標準 <code class="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-700 font-bold border border-slate-200">MD5(帳號 + 密碼)</code> 二進位雜湊直寫 users 資料表，完成後建議通知玩家重新登入。</p>
                        <div class="pt-2.5 flex items-center justify-end">
                            <button class="btn-ice px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-key text-xs"></i><span>確認重設密碼</span></button>
                        </div>
                    </form>
                </div>

                <!-- Tab 4: GM 特權 -->
                <div class="tab-pane" id="tab-gm">
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                        <div class="p-4 rounded-xl bg-sky-50 border border-sky-200 space-y-1.5">
                            <div class="flex items-center justify-between mb-1">
                                <span class="font-serif font-bold text-sky-950 text-sm flex items-center gap-2"><i class="fa-solid fa-shield-halved text-sky-600"></i>分區 GM 特權清單授權 (auth 表)</span>
                                <span class="text-xs text-sky-800 bg-sky-100 px-2.5 py-0.5 rounded font-mono font-bold border border-sky-200"><?php echo count($AllGmOperationTypes); ?> 項全權限</span>
                            </div>
                            <p class="text-xs text-slate-600 leading-relaxed">在指定遊戲分區為該玩家寫入或清除全套操作權限清單（包含 gmopgen 代碼集：廣播、踢除、瞬移、召喚、造物等全權限）。</p>
                        </div>
                        <div class="flex flex-col sm:flex-row items-end gap-3 pt-1">
                            <div class="w-full sm:w-56">
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">分區代碼 (zoneid)</label>
                                <input class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white font-mono text-xs sm:text-sm" name="gm_zoneid" type="number" value="20586">
                            </div>
                            <div class="flex items-center gap-2.5 w-full sm:w-auto">
                                <button class="btn-ice flex-1 sm:flex-none px-5 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" name="action" type="submit" value="grantgm"><i class="fa-solid fa-circle-check text-xs"></i><span>授予完整 GM 權限</span></button>
                                <button class="flex-1 sm:flex-none px-5 py-2.5 rounded-xl bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-serif font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer" name="action" type="submit" value="revokegm"><i class="fa-solid fa-circle-xmark text-xs"></i><span>撤銷 GM 特權</span></button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Tab 5: 會員功能權限 -->
                <div class="tab-pane" id="tab-perm">
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">
                        <div class="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1.5">
                            <div class="flex items-center justify-between mb-1">
                                <span class="font-serif font-bold text-emerald-950 text-sm flex items-center gap-2"><i class="fa-solid fa-user-lock text-emerald-600"></i>會員前台功能權限（user_permissions）</span>
                                <span class="text-xs text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded font-mono font-bold border border-emerald-200"><?php echo count(member_permission_keys()); ?> 項功能</span>
                            </div>
                            <p class="text-xs text-slate-600 leading-relaxed">逐項設定目標會員可使用的網站功能；取消勾選即關閉該功能，前台將顯示權限不足提示。未設定的會員預設為全部開放。</p>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <?php $permMap = member_permission_map(); foreach (member_permission_keys() as $pk): $pm = $permMap[$pk] ?? ['label' => $pk, 'desc' => '', 'icon' => 'fa-circle', 'page' => '']; $pOn = !empty($selectedPerms[$pk]); ?>
                            <label class="flex items-start gap-3 p-3.5 rounded-xl border <?php echo $pOn ? 'border-emerald-200 bg-emerald-50/60' : 'border-slate-200 bg-white'; ?> cursor-pointer transition-colors hover:border-emerald-300">
                                <input type="checkbox" name="perm[<?php echo htmlspecialchars($pk); ?>]" value="1" class="mt-0.5 w-4 h-4 accent-emerald-600" <?php echo $pOn ? 'checked' : ''; ?>>
                                <span class="flex-1">
                                    <span class="flex items-center gap-2 font-bold text-slate-800 font-serif"><i class="fa-solid <?php echo htmlspecialchars($pm['icon']); ?> text-emerald-600"></i><?php echo htmlspecialchars($pm['label']); ?></span>
                                    <span class="block text-[11px] text-slate-500 mt-1 leading-relaxed"><?php echo htmlspecialchars($pm['desc']); ?></span>
                                    <?php if (!empty($pm['page'])): ?><span class="inline-block mt-1 text-[10px] font-mono text-slate-400 border border-slate-200 rounded px-1.5 py-0.5"><?php echo htmlspecialchars($pm['page']); ?></span><?php endif; ?>
                                </span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                        <div class="pt-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <span class="text-xs text-slate-500 font-serif">異動將立即生效，玩家下次進入對應功能頁面即套用。</span>
                            <div class="flex items-center gap-2.5">
                                <button class="px-4 py-2.5 rounded-xl bg-white hover:bg-emerald-50 text-emerald-700 border border-emerald-300 font-serif font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer" name="action" type="submit" value="save_member_perms_all"><i class="fa-solid fa-toggle-on text-xs"></i><span>全部開放</span></button>
                                <button class="px-4 py-2.5 rounded-xl bg-white hover:bg-rose-50 text-rose-700 border border-rose-300 font-serif font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 shadow-sm cursor-pointer" name="action" type="submit" value="save_member_perms_none"><i class="fa-solid fa-toggle-off text-xs"></i><span>全部停用</span></button>
                                <button class="btn-ice px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" name="action" type="submit" value="save_member_perms"><i class="fa-solid fa-floppy-disk text-xs"></i><span>儲存權限設定</span></button>
                            </div>
                        </div>
                    </form>
                </div>

                <!-- Tab 6: 帳號詳細資料（SQL 詳細數據瀏覽與編輯） -->
                <div class="tab-pane" id="tab-data">
                    <?php
                        $accData = $selectedAccountFull ?: [];
                        $dv = function ($k) use ($accData) {
                            return htmlspecialchars((string)($accData[$k] ?? ''), ENT_QUOTES, 'UTF-8');
                        };
                        $inpCls = 'mt-1 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-indigo-200 focus:border-indigo-600 shadow-inner';
                        $roCls  = 'mt-1 w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-100 text-slate-500 font-mono text-xs sm:text-sm';
                    ?>
                    <form action="?id=<?php echo (int)$selectedAccount['ID'] . $preserveQHtml; ?>" class="space-y-4 text-xs" method="POST">
                        <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                        <input name="action" type="hidden" value="save_account_data">
                        <input name="userid" type="hidden" value="<?php echo (int)$selectedAccount['ID']; ?>">

                        <div class="p-4 rounded-xl bg-indigo-50 border border-indigo-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div class="space-y-1.5">
                                <span class="font-serif font-bold text-indigo-950 text-sm flex items-center gap-2"><i class="fa-solid fa-database text-indigo-600"></i>目標帳號 SQL 詳細資料</span>
                                <p class="text-xs text-slate-600 leading-relaxed">檢視並編輯 <code class="bg-white/70 px-1.5 py-0.5 rounded font-mono text-indigo-700 border border-indigo-200">users</code> 資料表的會員欄位。基於遊戲端登入相容性，帳號（name）與密碼欄位不在此編輯，請改用「重設密碼」分頁。</p>
                            </div>
                            <span class="text-xs text-indigo-800 bg-indigo-100 px-2.5 py-0.5 rounded font-mono font-bold border border-indigo-200 self-start whitespace-nowrap">users #<?php echo (int)$selectedAccount['ID']; ?></span>
                        </div>

                        <!-- 唯讀識別欄位 -->
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <div><label class="block text-xs font-bold text-slate-500 mb-0.5 font-serif">會員編號 (ID)</label><input class="<?php echo $roCls; ?>" type="text" value="<?php echo $dv('ID'); ?>" readonly></div>
                            <div><label class="block text-xs font-bold text-slate-500 mb-0.5 font-serif">遊戲帳號 (name)</label><input class="<?php echo $roCls; ?>" type="text" value="<?php echo $dv('name'); ?>" readonly></div>
                            <div><label class="block text-xs font-bold text-slate-500 mb-0.5 font-serif">建立時間 (creatime)</label><input class="<?php echo $roCls; ?>" type="text" value="<?php echo $dv('creatime'); ?>" readonly></div>
                        </div>

                        <!-- 可編輯欄位 -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">密碼提示 (Prompt)</label><input class="<?php echo $inpCls; ?>" name="acct_prompt" type="text" maxlength="32" value="<?php echo $dv('Prompt'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">提示答案 (answer)</label><input class="<?php echo $inpCls; ?>" name="acct_answer" type="text" maxlength="32" value="<?php echo $dv('answer'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">真實姓名 (truename)</label><input class="<?php echo $inpCls; ?>" name="acct_truename" type="text" maxlength="32" value="<?php echo $dv('truename'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">身分證號 (idnumber)</label><input class="<?php echo $inpCls; ?>" name="acct_idnumber" type="text" maxlength="32" value="<?php echo $dv('idnumber'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">電子郵件 (email)</label><input class="<?php echo $inpCls; ?>" name="acct_email" type="text" maxlength="64" value="<?php echo $dv('email'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">行動電話 (mobilenumber)</label><input class="<?php echo $inpCls; ?>" name="acct_mobilenumber" type="text" maxlength="32" value="<?php echo $dv('mobilenumber'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">市內電話 (phonenumber)</label><input class="<?php echo $inpCls; ?>" name="acct_phonenumber" type="text" maxlength="32" value="<?php echo $dv('phonenumber'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">郵遞區號 (postalcode)</label><input class="<?php echo $inpCls; ?>" name="acct_postalcode" type="text" maxlength="8" value="<?php echo $dv('postalcode'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">QQ 號碼 (qq)</label><input class="<?php echo $inpCls; ?>" name="acct_qq" type="text" maxlength="32" value="<?php echo $dv('qq'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">省份 (province)</label><input class="<?php echo $inpCls; ?>" name="acct_province" type="text" maxlength="32" value="<?php echo $dv('province'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">城市 (city)</label><input class="<?php echo $inpCls; ?>" name="acct_city" type="text" maxlength="32" value="<?php echo $dv('city'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">性別 (gender)</label><input class="<?php echo $inpCls; ?>" name="acct_gender" type="number" min="0" max="9" value="<?php echo $dv('gender'); ?>"></div>
                            <div class="sm:col-span-2"><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">通訊地址 (address)</label><input class="<?php echo $inpCls; ?>" name="acct_address" type="text" maxlength="64" value="<?php echo $dv('address'); ?>"></div>
                            <div><label class="block text-xs font-bold text-slate-700 mb-0.5 font-serif">生日 (birthday)</label><input class="<?php echo $inpCls; ?>" name="acct_birthday" type="text" placeholder="YYYY-MM-DD HH:MM:SS" value="<?php echo $dv('birthday'); ?>"></div>
                        </div>

                        <div class="pt-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                            <span class="text-xs text-slate-500 font-serif flex items-center gap-1.5"><i class="fa-solid fa-triangle-exclamation text-amber-500"></i>此操作直接寫入資料庫，請確認內容無誤再儲存；生日留空將寫入 NULL。</span>
                            <button class="btn-ice px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-floppy-disk text-xs"></i><span>儲存帳號資料</span></button>
                        </div>
                    </form>
                </div>

                <!-- Tab 7: 歷史訂單（目標會員訂單瀏覽、編輯、管理） -->
                <div class="tab-pane" id="tab-orders">
                    <?php
                        $uidForOrders = (int)$selectedAccount['ID'];
                        $rcStatusMeta = [
                            'paid'      => ['已付款',  'bg-emerald-50 text-emerald-700 border-emerald-200', 'bg-emerald-500'],
                            'pending'   => ['待付款',  'bg-amber-50 text-amber-700 border-amber-200',       'bg-amber-500'],
                            'failed'    => ['付款失敗','bg-rose-50 text-rose-700 border-rose-200',          'bg-rose-500'],
                            'expired'   => ['已逾期',  'bg-slate-100 text-slate-600 border-slate-300',      'bg-slate-400'],
                            'cancelled' => ['已取消',  'bg-slate-100 text-slate-600 border-slate-300',      'bg-slate-400'],
                        ];
                        $exStatusMeta = [
                            'completed' => ['已完成', 'bg-emerald-50 text-emerald-700 border-emerald-200', 'bg-emerald-500'],
                            'failed'    => ['失敗',   'bg-rose-50 text-rose-700 border-rose-200',          'bg-rose-500'],
                        ];
                    ?>
                    <div class="space-y-4 text-xs">
                        <div class="p-4 rounded-xl bg-teal-50 border border-teal-200 flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                            <div class="space-y-1.5">
                                <span class="font-serif font-bold text-teal-950 text-sm flex items-center gap-2"><i class="fa-solid fa-receipt text-teal-600"></i>目標會員歷史訂單</span>
                                <p class="text-xs text-slate-600 leading-relaxed">瀏覽、編輯與管理會員 #<?php echo $uidForOrders; ?> 的儲值訂單與點數兌換紀錄。點擊「編輯」可直接調整訂單狀態、金額與點數入帳。</p>
                            </div>
                            <button type="button" onclick="openOrderModal(<?php echo $uidForOrders; ?>)" class="self-start lg:self-auto px-5 py-2.5 rounded-xl acct-btn-teal text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer transition-all">
                                <i class="fa-solid fa-up-right-and-down-left-from-center text-xs"></i><span>開啟完整訂單管理</span>
                            </button>
                        </div>

                        <!-- 訂單統計 -->
                        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                            <div class="rounded-xl border border-slate-200 bg-white p-3.5"><div class="text-[11px] text-slate-500 whitespace-nowrap">訂單總數</div><div class="text-lg sm:text-xl font-extrabold text-slate-800 font-mono whitespace-nowrap leading-tight"><?php echo number_format($selectedOrderStats['count']); ?></div></div>
                            <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5"><div class="text-[11px] text-emerald-700 whitespace-nowrap">已付款訂單</div><div class="text-lg sm:text-xl font-extrabold text-emerald-700 font-mono whitespace-nowrap leading-tight"><?php echo number_format($selectedOrderStats['paid_count']); ?></div></div>
                            <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5"><div class="text-[11px] text-amber-700 whitespace-nowrap">已付金額</div><div class="text-lg sm:text-xl font-extrabold text-amber-700 font-mono whitespace-nowrap leading-tight">NT$ <?php echo number_format($selectedOrderStats['paid_amount']); ?></div></div>
                            <div class="rounded-xl border border-sky-200 bg-sky-50 p-3.5"><div class="text-[11px] text-sky-700 whitespace-nowrap">已入帳點數</div><div class="text-lg sm:text-xl font-extrabold text-sky-700 font-mono whitespace-nowrap leading-tight"><?php echo number_format($selectedOrderStats['paid_points']); ?></div></div>
                        </div>

                        <!-- 儲值訂單 -->
                        <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                            <div class="px-3.5 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                                <span class="text-xs font-bold text-slate-700 font-serif flex items-center gap-1.5"><i class="fa-solid fa-coins text-amber-600"></i>儲值訂單 (recharge_orders)</span>
                                <span class="text-[10px] text-slate-500 font-mono">顯示最近 <?php echo count($selectedRechargeOrders); ?> 筆</span>
                            </div>
                            <?php if (empty($selectedRechargeOrders)): ?>
                                <div class="py-8 text-center text-slate-400 text-xs"><i class="fa-regular fa-folder-open text-xl block mb-2"></i>尚無儲值訂單紀錄</div>
                            <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="text-left text-xs acct-orders-table acct-orders-actions">
                                    <colgroup>
                                        <col style="width:170px;"><col style="width:130px;"><col style="width:100px;"><col style="width:100px;">
                                        <col style="width:88px;"><col style="width:130px;"><col style="width:140px;"><col style="width:80px;">
                                    </colgroup>
                                    <thead class="bg-slate-50 text-slate-500 border-b border-slate-200 text-[11px]">
                                        <tr>
                                            <th class="py-2 px-3 whitespace-nowrap">訂單編號</th>
                                            <th class="py-2 px-3 whitespace-nowrap">儲值方式</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">金額</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">點數</th>
                                            <th class="py-2 px-3 whitespace-nowrap">狀態</th>
                                            <th class="py-2 px-3 whitespace-nowrap">交易編號</th>
                                            <th class="py-2 px-3 whitespace-nowrap">建立時間</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        <?php foreach ($selectedRechargeOrders as $o): $m = $rcStatusMeta[$o['status']] ?? ['未確認', 'bg-slate-100 text-slate-600 border-slate-300', 'bg-slate-400']; $mName = $o['method_name'] !== '' ? $o['method_name'] : ($o['choose_payment'] !== '' ? $o['choose_payment'] : '—'); ?>
                                        <tr class="hover:bg-slate-50/80">
                                            <td class="py-2 px-3 font-mono font-semibold text-slate-700 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($o['order_no'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($o['order_no'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-slate-600 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($mName, ENT_QUOTES); ?>"><?php echo htmlspecialchars($mName, ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-slate-700 whitespace-nowrap">NT$ <?php echo number_format((int)$o['amount']); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-amber-600 whitespace-nowrap">+<?php echo number_format((int)$o['total_points']); ?></td>
                                            <td class="py-2 px-3 whitespace-nowrap"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium <?php echo $m[1]; ?>"><span class="w-1.5 h-1.5 rounded-full <?php echo $m[2]; ?>"></span><?php echo $m[0]; ?></span></td>
                                            <td class="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($o['trade_no'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($o['trade_no'] !== '' ? $o['trade_no'] : '—', ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap"><?php echo htmlspecialchars($o['created_at'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-right whitespace-nowrap"><button type="button" onclick="openOrderModal(<?php echo $uidForOrders; ?>, <?php echo htmlspecialchars(json_encode($o['order_no']), ENT_QUOTES); ?>)" class="px-2.5 py-1 rounded-lg border border-teal-300 bg-teal-50 text-teal-700 hover:bg-teal-100 text-[11px] font-semibold transition-colors"><i class="fa-solid fa-pen-to-square text-[10px] mr-0.5"></i>編輯</button></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- 兌換訂單 -->
                        <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                            <div class="px-3.5 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                                <span class="text-xs font-bold text-slate-700 font-serif flex items-center gap-1.5"><i class="fa-solid fa-right-left text-sky-600"></i>點數兌換紀錄 (exchange_orders)</span>
                                <span class="text-[10px] text-slate-500 font-mono">顯示最近 <?php echo count($selectedExchangeOrders); ?> 筆</span>
                            </div>
                            <?php if (empty($selectedExchangeOrders)): ?>
                                <div class="py-8 text-center text-slate-400 text-xs"><i class="fa-regular fa-folder-open text-xl block mb-2"></i>尚無點數兌換紀錄</div>
                            <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="text-left text-xs acct-orders-table">
                                    <colgroup>
                                        <col style="width:170px;"><col style="width:100px;"><col style="width:80px;"><col style="width:76px;">
                                        <col style="width:100px;"><col style="width:88px;"><col style="width:180px;"><col style="width:140px;">
                                    </colgroup>
                                    <thead class="bg-slate-50 text-slate-500 border-b border-slate-200 text-[11px]">
                                        <tr>
                                            <th class="py-2 px-3 whitespace-nowrap">兌換編號</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">使用點數</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">匯率</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">手續費</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">獲得元寶</th>
                                            <th class="py-2 px-3 whitespace-nowrap">狀態</th>
                                            <th class="py-2 px-3 whitespace-nowrap">備註</th>
                                            <th class="py-2 px-3 whitespace-nowrap">建立時間</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        <?php foreach ($selectedExchangeOrders as $x): $xm = $exStatusMeta[$x['status']] ?? ['未確認', 'bg-slate-100 text-slate-600 border-slate-300', 'bg-slate-400']; ?>
                                        <tr class="hover:bg-slate-50/80">
                                            <td class="py-2 px-3 font-mono font-semibold text-slate-700 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($x['exchange_no'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($x['exchange_no'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-rose-600 whitespace-nowrap">-<?php echo number_format((int)$x['points_used']); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-slate-600 whitespace-nowrap"><?php echo htmlspecialchars((string)$x['rate'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-slate-600 whitespace-nowrap"><?php echo (int)$x['fee_percent']; ?>%</td>
                                            <td class="py-2 px-3 text-right font-mono text-sky-600 whitespace-nowrap">+<?php echo number_format((int)$x['yuanbao_gained']); ?></td>
                                            <td class="py-2 px-3 whitespace-nowrap"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium <?php echo $xm[1]; ?>"><span class="w-1.5 h-1.5 rounded-full <?php echo $xm[2]; ?>"></span><?php echo $xm[0]; ?></span></td>
                                            <td class="py-2 px-3 text-slate-600 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($x['note'] !== '' ? $x['note'] : '—', ENT_QUOTES); ?>"><?php echo htmlspecialchars($x['note'] !== '' ? $x['note'] : '—', ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap"><?php echo htmlspecialchars($x['created_at'], ENT_QUOTES); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Tab 8: 錢包管理（點數 / 元寶） -->
                <div class="tab-pane" id="tab-wallet">
                    <?php
                        $wUid = (int)$selectedAccount['ID'];
                        $wBase = '?id=' . $wUid . $preserveQHtml;
                        $ledgerTypeMap = [
                            'recharge'       => '儲值入帳',
                            'exchange_in'    => '兌換取得',
                            'exchange_out'   => '兌換扣點',
                            'admin_grant'    => '管理發放',
                            'admin_deduct'   => '管理扣減',
                            'consume'        => '消費',
                            'refund'         => '退款退回',
                            'adjust'         => '調整',
                            'register_bonus' => '註冊獎勵',
                        ];
                    ?>
                    <div class="space-y-4 text-xs">
                        <!-- 餘額總覽 -->
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div class="rounded-xl border border-amber-200 bg-gradient-to-br from-amber-50 via-white to-amber-50 p-4">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs font-bold text-amber-800 font-serif flex items-center gap-2"><i class="fa-solid fa-coins text-amber-500"></i><?php echo htmlspecialchars($pointsName, ENT_QUOTES); ?>餘額</span>
                                    <span class="text-[10px] text-amber-700 bg-amber-100 border border-amber-200 rounded px-1.5 py-0.5 font-mono">points</span>
                                </div>
                                <div class="text-3xl font-extrabold text-amber-700 font-mono mt-2 tabular-nums leading-none"><?php echo number_format((int)$selectedWallet['points']); ?></div>
                                <div class="text-[11px] text-slate-500 mt-2">累計存入 <span class="font-mono font-semibold text-slate-600"><?php echo number_format((int)$selectedWallet['total_points_in']); ?></span></div>
                            </div>
                            <div class="rounded-xl border border-sky-200 bg-gradient-to-br from-sky-50 via-white to-sky-50 p-4">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs font-bold text-sky-800 font-serif flex items-center gap-2"><i class="fa-solid fa-gem text-sky-500"></i><?php echo htmlspecialchars($yuanbaoName, ENT_QUOTES); ?>餘額</span>
                                    <span class="text-[10px] text-sky-700 bg-sky-100 border border-sky-200 rounded px-1.5 py-0.5 font-mono">yuanbao</span>
                                </div>
                                <div class="text-3xl font-extrabold text-sky-700 font-mono mt-2 tabular-nums leading-none"><?php echo number_format((int)$selectedWallet['yuanbao']); ?></div>
                                <div class="text-[11px] text-slate-500 mt-2">累計存入 <span class="font-mono font-semibold text-slate-600"><?php echo number_format((int)$selectedWallet['total_yuanbao_in']); ?></span></div>
                            </div>
                        </div>

                        <!-- 發放 / 扣減 -->
                        <form action="<?php echo $wBase; ?>" method="POST" class="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                            <input name="form_token" type="hidden" value="<?php echo htmlspecialchars($formToken); ?>">
                            <input name="action" type="hidden" value="wallet_adjust">
                            <input name="userid" type="hidden" value="<?php echo $wUid; ?>">
                            <div class="flex items-center justify-between pb-2 border-b border-slate-200">
                                <span class="font-serif font-bold text-amber-950 text-sm flex items-center gap-2"><i class="fa-solid fa-hand-holding-dollar text-amber-600"></i>錢包發放 / 扣減</span>
                                <span class="text-[10px] text-slate-400 font-mono">currency_ledger</span>
                            </div>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">貨幣種類</label>
                                    <select name="wallet_currency" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-amber-200 focus:border-amber-600">
                                        <option value="points"><?php echo htmlspecialchars($pointsName, ENT_QUOTES); ?>（points）</option>
                                        <option value="yuanbao"><?php echo htmlspecialchars($yuanbaoName, ENT_QUOTES); ?>（yuanbao）</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">操作方向</label>
                                    <select name="wallet_direction" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-amber-200 focus:border-amber-600">
                                        <option value="grant">發放（增加餘額）</option>
                                        <option value="deduct">扣減（減少餘額）</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">數量</label>
                                    <input name="wallet_amount" type="number" min="1" value="100" class="w-full px-3.5 py-2.5 rounded-xl border border-amber-300 bg-amber-50/50 font-mono font-bold text-amber-700 text-xs sm:text-sm focus:ring-2 focus:ring-amber-200 focus:border-amber-600">
                                </div>
                            </div>
                            <div>
                                <label class="block text-xs font-bold text-slate-700 mb-1.5 font-serif">原因說明（選填）</label>
                                <input name="wallet_reason" type="text" maxlength="120" placeholder="例如：活動補償、客服補發…" class="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white text-xs sm:text-sm text-slate-800 focus:ring-2 focus:ring-amber-200 focus:border-amber-600 shadow-inner">
                            </div>
                            <div class="p-3 rounded-xl bg-amber-50 border border-amber-200 text-[11px] text-amber-900 flex items-start gap-2">
                                <i class="fa-solid fa-circle-info text-amber-600 mt-0.5"></i>
                                <span class="leading-relaxed">每次異動皆寫入 <code class="bg-white/70 px-1 rounded font-mono border border-amber-200">currency_ledger</code> 交易流水可供稽核；調整<?php echo htmlspecialchars($yuanbaoName, ENT_QUOTES); ?>時會同步遊戲端 <code class="bg-white/70 px-1 rounded font-mono border border-amber-200">point</code> 表（aid=23）。</span>
                            </div>
                            <div class="pt-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                <span class="text-xs text-slate-500 font-serif">扣減後餘額不得為負，餘額不足將自動拒絕。</span>
                                <button class="btn-amber px-6 py-2.5 rounded-xl text-white font-serif font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md cursor-pointer" type="submit"><i class="fa-solid fa-wallet text-xs"></i><span>確認執行錢包操作</span></button>
                            </div>
                        </form>

                        <!-- 交易流水 -->
                        <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                            <div class="px-3.5 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                                <span class="text-xs font-bold text-slate-700 font-serif flex items-center gap-1.5"><i class="fa-solid fa-list-ul text-amber-600"></i>錢包交易流水 (currency_ledger)</span>
                                <span class="text-[10px] text-slate-500 font-mono">顯示最近 <?php echo count($selectedWalletLedger); ?> 筆</span>
                            </div>
                            <?php if (empty($selectedWalletLedger)): ?>
                                <div class="py-8 text-center text-slate-400 text-xs"><i class="fa-regular fa-folder-open text-xl block mb-2"></i>尚無錢包交易紀錄</div>
                            <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="w-full text-left text-xs" style="min-width:860px;">
                                    <thead class="bg-slate-50 text-slate-500 border-b border-slate-200 text-[11px]">
                                        <tr>
                                            <th class="py-2 px-3 whitespace-nowrap">時間</th>
                                            <th class="py-2 px-3 whitespace-nowrap">貨幣</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">異動</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">餘額</th>
                                            <th class="py-2 px-3 whitespace-nowrap">類型</th>
                                            <th class="py-2 px-3 whitespace-nowrap">說明</th>
                                            <th class="py-2 px-3 whitespace-nowrap">操作人</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        <?php foreach ($selectedWalletLedger as $lg):
                                            $isYb = ((string)$lg['currency'] === 'yuanbao');
                                            $curLabel = $isYb ? $yuanbaoName : $pointsName;
                                            $chg = (int)$lg['change_amount'];
                                            $chgCls = $chg >= 0 ? ($isYb ? 'text-sky-600' : 'text-emerald-600') : 'text-rose-600';
                                            $typeLabel = $ledgerTypeMap[$lg['type']] ?? (string)$lg['type'];
                                        ?>
                                        <tr class="hover:bg-slate-50/80">
                                            <td class="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap"><?php echo htmlspecialchars((string)$lg['created_at'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 whitespace-nowrap"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium <?php echo $isYb ? 'bg-sky-50 text-sky-700 border-sky-200' : 'bg-amber-50 text-amber-700 border-amber-200'; ?>"><?php echo htmlspecialchars($curLabel, ENT_QUOTES); ?></span></td>
                                            <td class="py-2 px-3 text-right font-mono font-bold whitespace-nowrap <?php echo $chgCls; ?>"><?php echo ($chg >= 0 ? '+' : '') . number_format($chg); ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-slate-700 whitespace-nowrap"><?php echo number_format((int)$lg['balance_after']); ?></td>
                                            <td class="py-2 px-3 text-slate-600 whitespace-nowrap"><?php echo htmlspecialchars($typeLabel, ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-slate-600 truncate" style="max-width:240px;" title="<?php echo htmlspecialchars((string)$lg['description'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($lg['description'] !== '' ? (string)$lg['description'] : '—', ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-slate-500 whitespace-nowrap"><?php echo htmlspecialchars($lg['operator'] !== '' ? (string)$lg['operator'] : '—', ENT_QUOTES); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Tab 9: 工單回報 -->
                <div class="tab-pane" id="tab-support">
                    <?php
                        $supStatusMap = gm_support_status_map();
                        $supPrioMap = gm_support_priority_map();
                        $supportListUrl = '?id=' . (int)$selectedAccount['ID'] . $preserveQHtml;
                    ?>
                    <?php if ($supportActionDone && $notice !== ''): ?>
                        <div class="mb-3 p-3 rounded-xl border text-xs flex items-center gap-2 <?php echo $noticeType === 'danger' ? 'border-rose-200 bg-rose-50 text-rose-700' : 'border-emerald-200 bg-emerald-50 text-emerald-700'; ?>">
                            <i class="fa-solid <?php echo $noticeType === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-check'; ?>"></i><span><?php echo htmlspecialchars($notice, ENT_QUOTES, 'UTF-8'); ?></span>
                        </div>
                    <?php endif; ?>

                    <?php if ($selectedTicket): $tkStatus = $supStatusMap[$selectedTicket['status']] ?? ['label' => $selectedTicket['status'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-300', 'dot' => 'bg-slate-400']; $tkPrio = $supPrioMap[$selectedTicket['priority']] ?? ['label' => $selectedTicket['priority'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-300']; $tkBase = $supportListUrl . '&amp;ticket=' . (int)$selectedTicket['id']; ?>
                    <!-- 工單詳細與處理 -->
                    <div class="space-y-4 text-xs">
                        <div class="flex flex-wrap items-center justify-between gap-2">
                            <a href="<?php echo $supportListUrl; ?>" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-slate-300 text-slate-600 hover:bg-slate-50 font-semibold transition-colors"><i class="fa-solid fa-arrow-left text-[10px]"></i>返回工單列表</a>
                            <span class="text-[11px] text-slate-500 font-mono">單號：<?php echo htmlspecialchars($selectedTicket['ticket_no'], ENT_QUOTES); ?></span>
                        </div>

                        <div class="p-4 rounded-xl bg-orange-50 border border-orange-200 space-y-2.5">
                            <div class="flex flex-wrap items-center gap-2">
                                <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-bold <?php echo $tkStatus['badge']; ?>"><span class="w-1.5 h-1.5 rounded-full <?php echo $tkStatus['dot']; ?>"></span><?php echo htmlspecialchars($tkStatus['label'], ENT_QUOTES); ?></span>
                                <span class="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full border text-[11px] font-bold <?php echo $tkPrio['badge']; ?>">優先度：<?php echo htmlspecialchars($tkPrio['label'], ENT_QUOTES); ?></span>
                                <span class="text-[11px] text-slate-600 inline-flex items-center gap-1"><i class="fa-solid <?php echo htmlspecialchars($selectedTicket['category_icon'] !== '' ? $selectedTicket['category_icon'] : 'fa-circle', ENT_QUOTES); ?> text-orange-600"></i><?php echo htmlspecialchars($selectedTicket['category_name'] !== '' ? $selectedTicket['category_name'] : '未分類', ENT_QUOTES); ?></span>
                            </div>
                            <h3 class="text-base font-bold text-slate-900 font-serif"><?php echo htmlspecialchars($selectedTicket['subject'], ENT_QUOTES); ?></h3>
                            <div class="flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-500 font-mono">
                                <span>受理 GM：<?php echo $selectedTicket['handler'] !== '' ? htmlspecialchars($selectedTicket['handler'], ENT_QUOTES) : '未指派'; ?></span>
                                <span>回覆數：<?php echo (int)$selectedTicket['reply_count']; ?></span>
                                <span>建立：<?php echo htmlspecialchars($selectedTicket['created_at'], ENT_QUOTES); ?></span>
                                <span>更新：<?php echo htmlspecialchars((string)$selectedTicket['updated_at'], ENT_QUOTES); ?></span>
                            </div>
                        </div>

                        <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
                            <div class="lg:col-span-2 space-y-4">
                                <!-- 工單內容 -->
                                <div class="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                                    <div class="font-bold text-slate-700 font-serif pb-2 border-b border-slate-200 flex items-center gap-2"><i class="fa-solid fa-file-lines text-orange-600"></i>工單內容</div>
                                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                                        <div><span class="text-slate-400 block">伺服器/區域</span><span class="text-slate-700"><?php echo $selectedTicket['server_zone'] !== '' ? htmlspecialchars($selectedTicket['server_zone'], ENT_QUOTES) : '—'; ?></span></div>
                                        <div><span class="text-slate-400 block">角色名稱</span><span class="text-slate-700"><?php echo $selectedTicket['role_name'] !== '' ? htmlspecialchars($selectedTicket['role_name'], ENT_QUOTES) : '—'; ?></span></div>
                                        <div><span class="text-slate-400 block">聯絡信箱</span><span class="text-slate-700 truncate block"><?php echo $selectedTicket['contact_email'] !== '' ? htmlspecialchars($selectedTicket['contact_email'], ENT_QUOTES) : '—'; ?></span></div>
                                        <div><span class="text-slate-400 block">聯絡手機</span><span class="text-slate-700"><?php echo $selectedTicket['contact_mobile'] !== '' ? htmlspecialchars($selectedTicket['contact_mobile'], ENT_QUOTES) : '—'; ?></span></div>
                                    </div>
                                    <div class="text-slate-700 leading-relaxed whitespace-pre-wrap break-words bg-slate-50 rounded-lg p-3 border border-slate-100"><?php echo htmlspecialchars((string)$selectedTicket['content'], ENT_QUOTES); ?></div>
                                    <?php if (!empty($ticketAttachments[0])): ?>
                                        <div class="flex flex-wrap gap-2">
                                            <?php foreach ($ticketAttachments[0] as $att): ?>
                                                <a href="../<?php echo htmlspecialchars($att['file_path'], ENT_QUOTES); ?>" target="_blank" class="inline-flex items-center gap-1.5 text-[11px] bg-white border border-slate-200 hover:border-orange-300 hover:text-orange-700 text-slate-600 rounded-lg px-2.5 py-1.5 transition-colors"><i class="fa-solid fa-paperclip"></i><?php echo htmlspecialchars($att['file_name'], ENT_QUOTES); ?></a>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($selectedTicket['verdict'] !== ''): ?>
                                        <div class="text-[11px] text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg p-2.5"><i class="fa-solid fa-gavel mr-1"></i>處理結論：<?php echo htmlspecialchars($selectedTicket['verdict'], ENT_QUOTES); ?></div>
                                    <?php endif; ?>
                                </div>

                                <!-- 對話紀錄 -->
                                <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                                    <div class="px-4 py-2.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                                        <span class="font-bold text-slate-700 font-serif flex items-center gap-2"><i class="fa-solid fa-comments text-sky-600"></i>對話紀錄</span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?php echo count($ticketMessages); ?> 則</span>
                                    </div>
                                    <div class="p-4 space-y-3">
                                        <?php if (empty($ticketMessages)): ?>
                                            <div class="py-6 text-center text-slate-400 text-xs">尚無對話訊息</div>
                                        <?php else: ?>
                                            <?php foreach ($ticketMessages as $msg): $isGm = ($msg['sender_type'] === 'gm'); $isInternal = ((int)$msg['is_internal'] === 1); ?>
                                                <div class="flex <?php echo $isGm ? 'justify-end' : 'justify-start'; ?>">
                                                    <div class="max-w-[85%] rounded-xl border p-3 <?php echo $isInternal ? 'border-amber-200 bg-amber-50' : ($isGm ? 'border-sky-200 bg-sky-50' : 'border-slate-200 bg-slate-50'); ?>">
                                                        <div class="flex items-center gap-2 mb-1 text-[10px]">
                                                            <span class="font-bold <?php echo $isGm ? 'text-sky-700' : 'text-slate-700'; ?>"><?php echo htmlspecialchars($msg['sender_name'] !== '' ? $msg['sender_name'] : $msg['sender_type'], ENT_QUOTES); ?></span>
                                                            <span class="text-slate-400"><?php echo $isGm ? 'GM' : ($msg['sender_type'] === 'system' ? '系統' : '會員'); ?></span>
                                                            <?php if ($isInternal): ?><span class="px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 border border-amber-200 font-bold">內部</span><?php endif; ?>
                                                            <span class="text-slate-400 font-mono"><?php echo htmlspecialchars($msg['created_at'], ENT_QUOTES); ?></span>
                                                        </div>
                                                        <div class="text-slate-700 leading-relaxed whitespace-pre-wrap break-words"><?php echo htmlspecialchars((string)$msg['content'], ENT_QUOTES); ?></div>
                                                        <?php if (!empty($ticketAttachments[(int)$msg['id']])): ?>
                                                            <div class="flex flex-wrap gap-1.5 mt-2">
                                                                <?php foreach ($ticketAttachments[(int)$msg['id']] as $att): ?>
                                                                    <a href="../<?php echo htmlspecialchars($att['file_path'], ENT_QUOTES); ?>" target="_blank" class="inline-flex items-center gap-1 text-[10px] bg-white border border-slate-200 hover:border-orange-300 text-slate-600 rounded px-2 py-1 transition-colors"><i class="fa-solid fa-paperclip"></i><?php echo htmlspecialchars($att['file_name'], ENT_QUOTES); ?></a>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <div class="space-y-4">
                                <!-- 處理工單 -->
                                <div class="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                                    <div class="font-bold text-slate-700 font-serif pb-2 border-b border-slate-200 flex items-center gap-2"><i class="fa-solid fa-pen-to-square text-orange-600"></i>處理工單</div>

                                    <form action="<?php echo $tkBase; ?>" method="POST" class="space-y-2">
                                        <input type="hidden" name="form_token" value="<?php echo htmlspecialchars($formToken); ?>">
                                        <input type="hidden" name="action" value="support_action">
                                        <input type="hidden" name="sub_action" value="reply">
                                        <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                        <input type="hidden" name="ticket_id" value="<?php echo (int)$selectedTicket['id']; ?>">
                                        <label class="block text-[11px] font-semibold text-slate-700">回覆內容 / 備註</label>
                                        <textarea name="content" rows="3" maxlength="2000" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs form-input-focus" placeholder="輸入要回覆會員的內容…"></textarea>
                                        <label class="flex items-center gap-2 text-[11px] text-slate-600 cursor-pointer"><input type="checkbox" name="is_internal" value="1" class="rounded border-slate-300"> 僅限內部備註（會員不可見）</label>
                                        <button type="submit" class="btn-ice w-full py-2 rounded-lg font-semibold text-xs flex items-center justify-center gap-1.5"><i class="fa-solid fa-paper-plane"></i>送出</button>
                                    </form>

                                    <form action="<?php echo $tkBase; ?>" method="POST" class="space-y-2 pt-3 border-t border-slate-100">
                                        <input type="hidden" name="form_token" value="<?php echo htmlspecialchars($formToken); ?>">
                                        <input type="hidden" name="action" value="support_action">
                                        <input type="hidden" name="sub_action" value="status">
                                        <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                        <input type="hidden" name="ticket_id" value="<?php echo (int)$selectedTicket['id']; ?>">
                                        <label class="block text-[11px] font-semibold text-slate-700">變更狀態</label>
                                        <select name="new_status" class="w-full appearance-none px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                                            <?php foreach ($supStatusMap as $sk => $sv): ?><option value="<?php echo htmlspecialchars($sk, ENT_QUOTES); ?>" <?php echo ($selectedTicket['status'] === $sk) ? 'selected' : ''; ?>><?php echo htmlspecialchars($sv['label'], ENT_QUOTES); ?></option><?php endforeach; ?>
                                        </select>
                                        <input type="text" name="verdict" maxlength="200" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-xs form-input-focus" placeholder="處理結論（結案時填寫）" value="<?php echo htmlspecialchars((string)$selectedTicket['verdict'], ENT_QUOTES); ?>">
                                        <button type="submit" class="w-full py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors">更新狀態</button>
                                    </form>

                                    <form action="<?php echo $tkBase; ?>" method="POST" class="space-y-2 pt-3 border-t border-slate-100">
                                        <input type="hidden" name="form_token" value="<?php echo htmlspecialchars($formToken); ?>">
                                        <input type="hidden" name="action" value="support_action">
                                        <input type="hidden" name="sub_action" value="priority">
                                        <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                        <input type="hidden" name="ticket_id" value="<?php echo (int)$selectedTicket['id']; ?>">
                                        <label class="block text-[11px] font-semibold text-slate-700">調整優先度</label>
                                        <div class="flex gap-2">
                                            <select name="new_priority" class="flex-1 appearance-none px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                                                <?php foreach ($supPrioMap as $pk => $pv): ?><option value="<?php echo htmlspecialchars($pk, ENT_QUOTES); ?>" <?php echo ($selectedTicket['priority'] === $pk) ? 'selected' : ''; ?>><?php echo htmlspecialchars($pv['label'], ENT_QUOTES); ?></option><?php endforeach; ?>
                                            </select>
                                            <button type="submit" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-900 text-white font-semibold text-xs transition-colors whitespace-nowrap">套用</button>
                                        </div>
                                    </form>

                                    <form action="<?php echo $tkBase; ?>" method="POST" class="pt-3 border-t border-slate-100">
                                        <input type="hidden" name="form_token" value="<?php echo htmlspecialchars($formToken); ?>">
                                        <input type="hidden" name="action" value="support_action">
                                        <input type="hidden" name="sub_action" value="assign_self">
                                        <input type="hidden" name="userid" value="<?php echo (int)$selectedAccount['ID']; ?>">
                                        <input type="hidden" name="ticket_id" value="<?php echo (int)$selectedTicket['id']; ?>">
                                        <button type="submit" class="w-full py-2 rounded-lg bg-white border border-sky-300 text-sky-700 hover:bg-sky-50 font-semibold text-xs transition-colors flex items-center justify-center gap-1.5"><i class="fa-solid fa-user-check"></i>指派給自己（<?php echo htmlspecialchars($currentGmUsername, ENT_QUOTES); ?>）</button>
                                    </form>
                                </div>

                                <!-- 操作歷程 -->
                                <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                                    <div class="px-4 py-2.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                                        <span class="font-bold text-slate-700 font-serif flex items-center gap-2"><i class="fa-solid fa-clock-rotate-left text-violet-600"></i>操作歷程</span>
                                        <span class="text-[10px] text-slate-400 font-mono"><?php echo count($ticketStatusLogs); ?> 筆</span>
                                    </div>
                                    <div class="p-4 space-y-2 max-h-80 overflow-y-auto">
                                        <?php if (empty($ticketStatusLogs)): ?>
                                            <div class="py-4 text-center text-slate-400 text-xs">尚無操作紀錄</div>
                                        <?php else: ?>
                                            <?php foreach ($ticketStatusLogs as $log): ?>
                                                <div class="flex items-start gap-2 text-[11px] border-b border-slate-100 pb-2 last:border-0">
                                                    <span class="w-1.5 h-1.5 rounded-full bg-violet-400 mt-1.5 shrink-0"></span>
                                                    <div class="flex-1">
                                                        <div class="text-slate-700"><strong class="text-slate-800"><?php echo htmlspecialchars($log['operator_name'] !== '' ? $log['operator_name'] : $log['operator_type'], ENT_QUOTES); ?></strong> · <?php echo htmlspecialchars($log['note'] !== '' ? $log['note'] : $log['action'], ENT_QUOTES); ?></div>
                                                        <div class="text-slate-400 font-mono"><?php echo htmlspecialchars($log['created_at'], ENT_QUOTES); ?></div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php else: ?>
                    <!-- 工單列表 -->
                    <div class="space-y-4 text-xs">
                        <div class="p-4 rounded-xl bg-orange-50 border border-orange-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div class="space-y-1.5">
                                <span class="font-serif font-bold text-orange-950 text-sm flex items-center gap-2"><i class="fa-solid fa-headset text-orange-600"></i>目標會員工單回報</span>
                                <p class="text-xs text-slate-600 leading-relaxed">檢視並處理會員 #<?php echo (int)$selectedAccount['ID']; ?> 的申訴回報工單，可變更狀態、優先度、指派與回覆會員。</p>
                            </div>
                        </div>

                        <div class="grid grid-cols-3 lg:grid-cols-6 gap-2.5">
                            <div class="rounded-xl border border-slate-200 bg-white p-3"><div class="text-[10px] text-slate-500">總工單</div><div class="text-lg font-extrabold text-slate-800 font-mono leading-tight"><?php echo number_format($selectedSupportStats['total']); ?></div></div>
                            <div class="rounded-xl border border-amber-200 bg-amber-50 p-3"><div class="text-[10px] text-amber-700">待處理</div><div class="text-lg font-extrabold text-amber-700 font-mono leading-tight"><?php echo number_format($selectedSupportStats['open']); ?></div></div>
                            <div class="rounded-xl border border-sky-200 bg-sky-50 p-3"><div class="text-[10px] text-sky-700">處理中</div><div class="text-lg font-extrabold text-sky-700 font-mono leading-tight"><?php echo number_format($selectedSupportStats['processing']); ?></div></div>
                            <div class="rounded-xl border border-violet-200 bg-violet-50 p-3"><div class="text-[10px] text-violet-700">待回覆</div><div class="text-lg font-extrabold text-violet-700 font-mono leading-tight"><?php echo number_format($selectedSupportStats['pending_user']); ?></div></div>
                            <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3"><div class="text-[10px] text-emerald-700">已結案</div><div class="text-lg font-extrabold text-emerald-700 font-mono leading-tight"><?php echo number_format($selectedSupportStats['resolved']); ?></div></div>
                            <div class="rounded-xl border border-slate-200 bg-slate-50 p-3"><div class="text-[10px] text-slate-600">已關閉</div><div class="text-lg font-extrabold text-slate-600 font-mono leading-tight"><?php echo number_format($selectedSupportStats['closed']); ?></div></div>
                        </div>

                        <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                            <div class="px-3.5 py-2.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
                                <span class="text-xs font-bold text-slate-700 font-serif flex items-center gap-1.5"><i class="fa-solid fa-ticket text-orange-600"></i>工單列表</span>
                                <span class="text-[10px] text-slate-500 font-mono">顯示最近 <?php echo count($selectedTickets); ?> 筆</span>
                            </div>
                            <?php if (empty($selectedTickets)): ?>
                                <div class="py-8 text-center text-slate-400 text-xs"><i class="fa-regular fa-folder-open text-xl block mb-2"></i>此會員尚無工單回報紀錄</div>
                            <?php else: ?>
                            <div class="overflow-x-auto">
                                <table class="text-left text-xs acct-orders-table acct-orders-actions acct-support-table">
                                    <colgroup>
                                        <col style="width:150px;"><col style="width:110px;"><col style="width:230px;"><col style="width:88px;"><col style="width:100px;"><col style="width:110px;"><col style="width:90px;"><col style="width:140px;"><col style="width:90px;">
                                    </colgroup>
                                    <thead class="bg-slate-50 text-slate-500 border-b border-slate-200 text-[11px]">
                                        <tr>
                                            <th class="py-2 px-3 whitespace-nowrap">單號</th>
                                            <th class="py-2 px-3 whitespace-nowrap">分類</th>
                                            <th class="py-2 px-3 whitespace-nowrap">主旨</th>
                                            <th class="py-2 px-3 whitespace-nowrap">優先度</th>
                                            <th class="py-2 px-3 whitespace-nowrap">狀態</th>
                                            <th class="py-2 px-3 whitespace-nowrap">受理 GM</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">回覆</th>
                                            <th class="py-2 px-3 whitespace-nowrap">最後更新</th>
                                            <th class="py-2 px-3 text-right whitespace-nowrap">操作</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        <?php foreach ($selectedTickets as $t): $st = $supStatusMap[$t['status']] ?? ['label' => $t['status'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-300', 'dot' => 'bg-slate-400']; $pr = $supPrioMap[$t['priority']] ?? ['label' => $t['priority'], 'badge' => 'bg-slate-100 text-slate-600 border-slate-300']; ?>
                                        <tr class="hover:bg-slate-50/80">
                                            <td class="py-2 px-3 font-mono font-semibold text-slate-700 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($t['ticket_no'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($t['ticket_no'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-slate-600 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($t['category_name'] !== '' ? $t['category_name'] : '未分類', ENT_QUOTES); ?>"><i class="fa-solid <?php echo htmlspecialchars($t['category_icon'] !== '' ? $t['category_icon'] : 'fa-circle', ENT_QUOTES); ?> text-slate-400 mr-1"></i><?php echo htmlspecialchars($t['category_name'] !== '' ? $t['category_name'] : '未分類', ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-slate-700 whitespace-nowrap truncate" title="<?php echo htmlspecialchars($t['subject'], ENT_QUOTES); ?>"><?php echo htmlspecialchars($t['subject'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 whitespace-nowrap"><span class="inline-flex items-center px-2 py-0.5 rounded-full border text-[10px] font-medium <?php echo $pr['badge']; ?>"><?php echo htmlspecialchars($pr['label'], ENT_QUOTES); ?></span></td>
                                            <td class="py-2 px-3 whitespace-nowrap"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium <?php echo $st['badge']; ?>"><span class="w-1.5 h-1.5 rounded-full <?php echo $st['dot']; ?>"></span><?php echo htmlspecialchars($st['label'], ENT_QUOTES); ?></span></td>
                                            <td class="py-2 px-3 text-slate-600 whitespace-nowrap truncate"><?php echo $t['handler'] !== '' ? htmlspecialchars($t['handler'], ENT_QUOTES) : '—'; ?></td>
                                            <td class="py-2 px-3 text-right font-mono text-slate-600 whitespace-nowrap"><?php echo (int)$t['reply_count']; ?></td>
                                            <td class="py-2 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap"><?php echo htmlspecialchars($t['updated_at'] !== null ? $t['updated_at'] : $t['created_at'], ENT_QUOTES); ?></td>
                                            <td class="py-2 px-3 text-right whitespace-nowrap"><a href="<?php echo $supportListUrl . '&amp;ticket=' . (int)$t['id']; ?>" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-orange-300 bg-orange-50 text-orange-700 hover:bg-orange-100 text-[11px] font-semibold transition-colors"><i class="fa-solid fa-pen-to-square text-[10px]"></i>處理</a></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <div class="glass-jade corner-accent rounded-2xl p-8 text-center text-slate-500 shadow-2xl">
                <i class="fa-regular fa-hand-pointer text-3xl text-slate-300 mb-3"></i>
                <p class="text-sm font-serif">請由左側搜尋並選擇一位玩家，即可顯示完整帳號管理面板。</p>
            </div>
            <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 帳號層級管理 子視窗 -->
    <div class="fixed inset-0 flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="tier-modal" style="margin:0; z-index:95;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-5xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="tier-modal-card" style="max-height:92vh;">
            <div class="corner-accent"></div>
            <div class="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-violet-50 border border-violet-200 flex items-center justify-center text-violet-700 text-lg shrink-0"><i class="fa-solid fa-layer-group"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">帳號層級管理
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">account_tiers</span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">新增／編輯帳號層級與類型（名稱、圖示、顏色、等級高低），即時套用於會員中心與後台顯示。</p>
                    </div>
                </div>
                <button type="button" onclick="closeTierModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉"><i class="fa-solid fa-xmark text-lg"></i></button>
            </div>
            <div id="tier-toast" class="hidden p-3 rounded-lg border text-xs items-center gap-2.5" style="margin:12px 20px 0;"></div>
            <div class="flex-1 overflow-y-auto p-5 sm:p-6" style="min-height:0;">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
                    <!-- 層級清單 -->
                    <div class="rounded-xl border border-slate-200 bg-white overflow-hidden">
                        <div class="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                            <span class="font-bold text-slate-700 font-serif text-sm flex items-center gap-2"><i class="fa-solid fa-list text-violet-600"></i>層級清單</span>
                            <button type="button" onclick="resetTierForm()" class="text-xs px-3 py-1.5 rounded-lg bg-violet-600 hover:bg-violet-700 text-white font-semibold transition-colors"><i class="fa-solid fa-plus mr-1"></i>新增層級</button>
                        </div>
                        <div id="tier-list" class="p-3 space-y-2 min-h-[160px]"></div>
                    </div>
                    <!-- 編輯表單 -->
                    <div class="rounded-xl border border-slate-200 bg-white p-4 space-y-3">
                        <div class="font-bold text-slate-700 font-serif text-sm pb-2 border-b border-slate-200 flex items-center gap-2"><i class="fa-solid fa-pen-to-square text-violet-600"></i><span id="tier-form-title">新增層級</span></div>
                        <form id="tier-form" onsubmit="return saveTier(event)" class="space-y-3 text-xs">
                            <input type="hidden" id="tier-id" value="0">
                            <div class="grid grid-cols-2 gap-3">
                                <div><label class="block font-semibold text-slate-700 mb-1">層級名稱</label><input type="text" id="tier-name" maxlength="60" class="w-full px-3 py-2 rounded-lg border border-slate-300 form-input-focus" placeholder="例如：VIP 會員"></div>
                                <div><label class="block font-semibold text-slate-700 mb-1">代碼（英文）</label><input type="text" id="tier-code" maxlength="32" class="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono form-input-focus" placeholder="例如：vip"></div>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div><label class="block font-semibold text-slate-700 mb-1">等級高低</label><input type="number" id="tier-rank" value="0" class="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono form-input-focus" placeholder="數字越大越高"></div>
                                <div><label class="block font-semibold text-slate-700 mb-1">排序</label><input type="number" id="tier-sort" value="0" class="w-full px-3 py-2 rounded-lg border border-slate-300 font-mono form-input-focus"></div>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">圖示 (FontAwesome)</label>
                                    <div class="flex items-center gap-1.5 mb-1.5">
                                        <input type="text" id="tier-icon" maxlength="60" class="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 font-mono form-input-focus" placeholder="fa-crown / fa-brands fa-github">
                                        <button type="button" onclick="openIconPicker()" class="shrink-0 px-3 py-2 rounded-lg bg-violet-600 hover:bg-violet-700 text-white font-semibold flex items-center gap-1.5 whitespace-nowrap cursor-pointer" title="開啟圖示選擇器"><i class="fa-solid fa-icons"></i>選擇</button>
                                    </div>
                                    <div class="flex items-center gap-1.5 text-[10px] text-slate-400">目前：<span id="tier-icon-current"></span></div>
                                </div>
                                <div>
                                    <label class="block font-semibold text-slate-700 mb-1">顏色</label>
                                    <div class="flex items-center gap-2 mb-1.5">
                                        <input type="color" id="tier-color" value="#64748b" class="w-10 h-9 rounded-lg border border-slate-300 cursor-pointer p-0.5">
                                        <input type="text" id="tier-color-text" maxlength="7" class="flex-1 px-3 py-2 rounded-lg border border-slate-300 font-mono form-input-focus" placeholder="#64748b">
                                    </div>
                                    <div id="tier-color-presets" class="flex flex-wrap gap-1.5"></div>
                                </div>
                            </div>
                            <div><label class="block font-semibold text-slate-700 mb-1">說明</label><input type="text" id="tier-desc" maxlength="200" class="w-full px-3 py-2 rounded-lg border border-slate-300 form-input-focus" placeholder="層級說明（選填）"></div>
                            <label class="flex items-center gap-2 text-slate-700 cursor-pointer"><input type="checkbox" id="tier-enabled" checked class="rounded border-slate-300"> 啟用此層級</label>
                            <div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200 flex items-center gap-2"><span class="text-slate-500">預覽：</span><span id="tier-preview"></span></div>
                            <div class="flex items-center justify-end gap-2 pt-1">
                                <button type="button" onclick="resetTierForm()" class="px-4 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 font-semibold">清除</button>
                                <button type="submit" class="px-5 py-2 rounded-lg bg-violet-600 hover:bg-violet-700 text-white font-semibold flex items-center gap-1.5"><i class="fa-solid fa-floppy-disk"></i>儲存</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- 圖示選擇器 子視窗 -->
    <div class="fixed inset-0 flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="icon-picker-modal" style="margin:0; z-index:100;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-3xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="icon-picker-card" style="max-height:90vh;">
            <div class="flex items-start justify-between gap-4 p-5 border-b border-slate-200 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-violet-50 border border-violet-200 flex items-center justify-center text-violet-700 text-base shrink-0"><i class="fa-solid fa-icons"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 font-serif">選擇圖示</h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">從豐富的 FontAwesome 圖示庫挑選，或自行輸入任意圖示代碼。</p>
                    </div>
                </div>
                <button type="button" onclick="closeIconPicker()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer shrink-0" title="關閉"><i class="fa-solid fa-xmark text-lg"></i></button>
            </div>
            <div class="p-4 border-b border-slate-200 space-y-2.5 shrink-0">
                <div class="flex flex-col sm:flex-row gap-2">
                    <div class="relative flex-1">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                        <input type="text" id="icon-search" class="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 text-xs form-input-focus" placeholder="搜尋圖示名稱（例如 crown、coin、dragon）…">
                    </div>
                    <div class="flex items-center gap-1 p-1 rounded-lg bg-slate-100 border border-slate-200 text-xs" id="icon-style-tabs">
                        <button type="button" data-style="fa-solid" class="icon-style-btn px-3 py-1.5 rounded-md font-semibold cursor-pointer">實心</button>
                        <button type="button" data-style="fa-regular" class="icon-style-btn px-3 py-1.5 rounded-md font-semibold cursor-pointer">線條</button>
                        <button type="button" data-style="fa-brands" class="icon-style-btn px-3 py-1.5 rounded-md font-semibold cursor-pointer">品牌</button>
                    </div>
                </div>
                <div class="flex flex-wrap gap-1.5" id="icon-cat-chips"></div>
            </div>
            <div class="p-4 overflow-y-auto acct-icon-scroll" style="flex:1 1 auto; min-height:0;">
                <div class="acct-icon-grid" id="icon-grid"></div>
                <div id="icon-empty" class="hidden py-10 text-center text-slate-400 text-sm">找不到符合的圖示，請嘗試其他關鍵字或使用下方自行輸入。</div>
            </div>
            <div class="p-4 border-t border-slate-200 shrink-0 flex flex-col sm:flex-row sm:items-center gap-2 bg-slate-50">
                <span class="text-[11px] text-slate-500 whitespace-nowrap">自行輸入 / 匯入：</span>
                <input type="text" id="icon-custom" class="flex-1 min-w-0 px-3 py-2 rounded-lg border border-slate-300 font-mono text-xs form-input-focus" placeholder="例如 fa-solid fa-dragon 或 fa-brands fa-github">
                <button type="button" onclick="applyCustomIcon()" class="shrink-0 px-4 py-2 rounded-lg bg-violet-600 hover:bg-violet-700 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer"><i class="fa-solid fa-check"></i>套用</button>
            </div>
        </div>
    </div>

    <!-- 信用管理 子視窗（載入 credit_admin.php） -->
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="credit-modal" style="margin:0;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-6xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="credit-modal-card" style="max-height:92vh;">
            <div class="flex items-start justify-between gap-4 p-4 sm:p-5 border-b border-slate-200">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700 text-lg shrink-0">
                        <i class="fa-solid fa-gauge-high"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            帳號信用管理
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">user_credit</span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">檢視並編輯會員信用分數、等級門檻與系統參數，所有異動即時寫入流水。</p>
                    </div>
                </div>
                <button type="button" onclick="closeCreditModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>
            <div style="flex:1 1 auto; min-height:0; background:#f1f5f9;">
                <iframe id="credit-modal-frame" title="帳號信用管理" data-src="credit_admin.php?embed=1" style="width:100%; height:78vh; border:0; display:block; background:#f1f5f9;"></iframe>
            </div>
        </div>
    </div>

    <!-- 儲值系統設定 子視窗 -->
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="recharge-modal" style="margin:0;">
            <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-4xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="recharge-modal-card" style="max-height:90vh;">
                <div class="corner-accent"></div>

                <!-- 子視窗標題列 -->
                <div class="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200">
                    <div class="flex items-center gap-3">
                        <div class="w-11 h-11 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700 text-lg shrink-0">
                            <i class="fa-solid fa-coins"></i>
                        </div>
                        <div>
                            <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                                儲值系統設定
                                <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">recharge_settings</span>
                            </h2>
                            <p class="text-[11px] text-slate-500 mt-0.5">管理前台儲值方式開關、金額方案與回饋比例，儲存後立即生效。</p>
                        </div>
                    </div>
                    <button type="button" onclick="closeRechargeModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                        <i class="fa-solid fa-xmark text-lg"></i>
                    </button>
                </div>

            <?php $gmBaseMethods = [
                'credit_card'   => ['name' => '線上刷卡', 'desc' => 'Visa / MasterCard / JCB 即時入帳', 'icon' => 'fa-credit-card'],
                'bank_transfer' => ['name' => '銀行轉帳', 'desc' => 'ATM 轉帳 / 網路銀行匯款', 'icon' => 'fa-building-columns'],
                'cvs'           => ['name' => '超商繳費', 'desc' => '7-11 / 全家 / 萊爾富 代碼繳費', 'icon' => 'fa-store'],
                'crypto'        => ['name' => '虛擬貨幣', 'desc' => 'USDT / BTC / ETH 鏈上支付', 'icon' => 'fa-bitcoin-sign'],
            ]; ?>
            <?php $rcMin = (int)($rcConfig['min_amount'] ?? 50); $rcMax = (int)($rcConfig['max_amount'] ?? 100000); ?>

            <form method="POST" action="" class="flex flex-col flex-1" style="min-height:0;">
                <input type="hidden" name="form_token" value="<?php echo $formToken; ?>">
                <input type="hidden" name="action" value="save_recharge">

                <!-- 可滾動內容區 -->
                <div class="p-5 sm:p-6 space-y-6 overflow-y-auto" style="flex:1 1 auto; min-height:0;">

                <!-- 一、儲值方式狀態開關 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-toggle-on text-amber-600"></i> 儲值方式狀態
                    </h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <?php foreach ($gmBaseMethods as $key => $m): ?>
                            <?php $mEnabled = isset($rcMethods[$key]) ? !empty($rcMethods[$key]['enabled']) : true; ?>
                            <?php $mName = (isset($rcMethods[$key]) && !empty($rcMethods[$key]['name'])) ? $rcMethods[$key]['name'] : $m['name']; ?>
                            <div class="rounded-lg border p-3 flex items-center justify-between gap-3 <?php echo $mEnabled ? 'border-amber-200 bg-amber-50/40' : 'border-slate-200 bg-slate-50'; ?>">
                                <div class="flex items-center gap-3">
                                    <div class="w-9 h-9 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-600">
                                        <i class="fa-solid <?php echo $m['icon']; ?>"></i>
                                    </div>
                                    <div>
                                        <div class="flex items-center gap-2">
                                            <span class="font-semibold text-slate-800"><?php echo htmlspecialchars($mName); ?></span>
                                            <span class="text-[10px] <?php echo $mEnabled ? 'text-emerald-600' : 'text-rose-600'; ?> font-medium"><?php echo $mEnabled ? '開啟' : '關閉'; ?></span>
                                        </div>
                                        <p class="text-[10px] text-slate-500"><?php echo htmlspecialchars($m['desc']); ?></p>
                                    </div>
                                </div>
                                <select name="method_enabled[<?php echo $key; ?>]" class="appearance-none rounded border border-slate-300 bg-white pl-3 pr-8 py-1 text-xs form-input-focus">
                                    <option value="1" <?php echo $mEnabled ? 'selected' : ''; ?>>啟用</option>
                                    <option value="0" <?php echo !$mEnabled ? 'selected' : ''; ?>>停用</option>
                                </select>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="text-[10px] text-slate-400 mt-1.5">關閉的儲值方式在前台會顯示「暫時無法使用該支付方式」，且無法提交儲值。</p>
                </div>

                <!-- 二、自訂金額範圍 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-sliders text-amber-600"></i> 自訂金額範圍
                    </h3>
                    <div class="flex flex-wrap gap-3">
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">最低金額（NT$）</label>
                            <input type="number" name="config[min_amount]" value="<?php echo $rcMin; ?>" min="1" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">最高金額（NT$）</label>
                            <input type="number" name="config[max_amount]" value="<?php echo $rcMax; ?>" min="1" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                    </div>
                </div>

                <!-- 三、金額方案與回饋比例 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-chart-simple text-amber-600"></i> 儲值金額方案與回饋比例
                    </h3>
                    <div class="overflow-x-auto rounded-lg border border-slate-200 bg-white">
                        <table class="w-full text-left text-xs">
                            <thead class="bg-slate-50 text-slate-600 font-semibold text-[11px] border-b border-slate-200">
                                <tr>
                                    <th class="py-2 px-3">ID</th>
                                    <th class="py-2 px-3">金額（NT$）</th>
                                    <th class="py-2 px-3">回饋比例（%）</th>
                                    <th class="py-2 px-3">狀態</th>
                                    <th class="py-2 px-3">刪除</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100">
                                <?php foreach ($rcTiers as $t): ?>
                                    <tr>
                                        <td class="py-2 px-3 font-mono text-slate-500">#<?php echo (int)$t['id']; ?></td>
                                        <td class="py-2 px-3">
                                            <input type="number" name="tier[<?php echo (int)$t['id']; ?>][amount]" value="<?php echo (int)$t['amount']; ?>" min="1" class="w-28 px-2 py-1 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </td>
                                        <td class="py-2 px-3">
                                            <input type="number" name="tier[<?php echo (int)$t['id']; ?>][bonus_percent]" value="<?php echo (int)$t['bonus_percent']; ?>" min="0" max="500" class="w-20 px-2 py-1 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                        </td>
                                        <td class="py-2 px-3">
                                            <select name="tier[<?php echo (int)$t['id']; ?>][enabled]" class="appearance-none rounded border border-slate-300 bg-white pl-3 pr-8 py-1 text-[11px] form-input-focus">
                                                <option value="1" <?php echo !empty($t['enabled']) ? 'selected' : ''; ?>>啟用</option>
                                                <option value="0" <?php echo empty($t['enabled']) ? 'selected' : ''; ?>>停用</option>
                                            </select>
                                        </td>
                                        <td class="py-2 px-3">
                                            <label class="inline-flex items-center gap-1 text-rose-600 cursor-pointer">
                                                <input type="checkbox" name="remove_tier[<?php echo (int)$t['id']; ?>]" value="1" class="rounded border-slate-300 text-rose-600">
                                                <span class="text-[11px]">刪除</span>
                                            </label>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (empty($rcTiers)): ?>
                                    <tr>
                                        <td colspan="5" class="py-4 text-center text-slate-400 text-xs">尚無金額方案，請於下方新增。</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="flex flex-wrap items-end gap-3 mt-3">
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">新增金額（NT$）</label>
                            <input type="number" name="new_amount" min="1" placeholder="例如 2000" class="w-36 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">新增回饋比例（%）</label>
                            <input type="number" name="new_bonus_percent" min="0" max="500" placeholder="例如 12" class="w-32 px-2.5 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                        </div>
                        <p class="text-[10px] text-slate-400 pb-1.5">新增方案將於「儲存」時加入，前台以金額遞增顯示。</p>
                    </div>
                </div>

                <!-- 四、金流系統參數 -->
                <div>
                    <h3 class="text-xs font-bold text-slate-800 mb-2 flex items-center gap-1.5">
                        <i class="fa-solid fa-money-check-dollar text-amber-600"></i> 金流系統參數（綠界 ECPay）
                    </h3>
                    <div class="rounded-lg border border-slate-200 bg-white p-4 space-y-3">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">營運環境</label>
                                <select name="gateway[ecpay_env]" class="w-full appearance-none pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs form-input-focus">
                                    <option value="stage" <?php echo ($rcGateway['ecpay_env'] ?? 'stage') !== 'prod' ? 'selected' : ''; ?>>測試環境 (Stage)</option>
                                    <option value="prod" <?php echo ($rcGateway['ecpay_env'] ?? 'stage') === 'prod' ? 'selected' : ''; ?>>正式環境 (Production)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">商家編號 MerchantID</label>
                                <input type="text" name="gateway[ecpay_merchant_id]" value="<?php echo htmlspecialchars($rcGateway['ecpay_merchant_id'] ?? ''); ?>" placeholder="例如 3002607" class="w-full px-3 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                            </div>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">HashKey</label>
                                <div class="relative">
                                    <input type="password" id="ecpay-hash-key" name="gateway[ecpay_hash_key]" value="<?php echo htmlspecialchars($rcGateway['ecpay_hash_key'] ?? ''); ?>" placeholder="留空使用預設測試金鑰" class="w-full pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                    <button type="button" onclick="toggleSecret('ecpay-hash-key', this)" class="absolute inset-y-0 right-0 flex items-center px-2 text-slate-400 hover:text-slate-700 cursor-pointer" tabindex="-1" title="顯示／隱藏">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-medium text-slate-600 mb-1">HashIV</label>
                                <div class="relative">
                                    <input type="password" id="ecpay-hash-iv" name="gateway[ecpay_hash_iv]" value="<?php echo htmlspecialchars($rcGateway['ecpay_hash_iv'] ?? ''); ?>" placeholder="留空使用預設測試金鑰" class="w-full pl-3 pr-8 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                    <button type="button" onclick="toggleSecret('ecpay-hash-iv', this)" class="absolute inset-y-0 right-0 flex items-center px-2 text-slate-400 hover:text-slate-700 cursor-pointer" tabindex="-1" title="顯示／隱藏">
                                        <i class="fa-solid fa-eye text-xs"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div>
                            <label class="block text-[11px] font-medium text-slate-600 mb-1">付款 API 網址（留空則依環境自動套用綠界官方端點）</label>
                            <input type="text" name="gateway[ecpay_action_url]" value="<?php echo htmlspecialchars($rcGateway['ecpay_action_url'] ?? ''); ?>" placeholder="https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5" class="w-full px-3 py-1.5 rounded border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        </div>

                        <div class="flex items-start gap-1.5 text-[10px] text-slate-400 pt-2 border-t border-slate-100">
                            <i class="fa-solid fa-circle-info mt-0.5"></i>
                            <span>回呼網址（ReturnURL）由系統網址自動產生：<span class="font-mono text-slate-500"><?php echo htmlspecialchars(defined('SITE_URL') ? SITE_URL : ''); ?>/recharge_notify.php</span>。金鑰僅儲存於後台資料庫，前台不會顯示。</span>
                        </div>
                    </div>
                    <p class="text-[10px] text-slate-400 mt-1.5">修改後立即套用於新的付款交易；進行中的訂單仍沿用建立時的金鑰與環境。</p>
                </div>

                </div><!-- /可滾動內容區 -->

                <!-- 子視窗底部操作列 -->
                <div class="px-5 sm:px-6 py-4 border-t border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3">
                    <span class="text-[11px] text-slate-400 hidden sm:flex items-center gap-1.5">
                        <i class="fa-solid fa-circle-info"></i> 變更將同步套用至前台儲值中心
                    </span>
                    <div class="flex items-center gap-3" style="margin-left:auto;">
                        <button type="button" onclick="closeRechargeModal()" class="px-5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 font-semibold text-xs transition-colors cursor-pointer">取消</button>
                        <button type="submit" class="btn-vermilion px-6 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <span>儲存所有儲值設定</span>
                        </button>
                    </div>
                </div>
            </form>
            </div><!-- /子視窗卡片 -->
        </div><!-- /子視窗遮罩 -->

    <!-- 訂單管理 子視窗 -->
    <div class="fixed inset-0 flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="order-modal" style="margin:0; z-index:80;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-6xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="order-modal-card" style="max-height:92vh;">
            <div class="corner-accent"></div>

            <!-- 標題列 -->
            <div class="flex items-start justify-between gap-4 p-5 sm:p-6 border-b border-slate-200">
                <div class="flex items-center gap-3">
                    <div class="w-11 h-11 rounded-xl bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700 text-lg shrink-0">
                        <i class="fa-solid fa-receipt"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            <span id="order-modal-title">訂單管理</span>
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">recharge_orders</span>
                            <span id="order-modal-scope" class="hidden items-center gap-1 px-2 py-0.5 rounded-full bg-sky-50 border border-sky-200 text-sky-700 text-[10px] font-mono font-bold"></span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-semibold">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> 即時連線
                            </span>
                        </h2>
                        <p id="order-modal-subtitle" class="text-[11px] text-slate-500 mt-0.5">檢視全部儲值訂單、編輯狀態與金額，並掌握即時營運報表。</p>
                    </div>
                </div>
                <button type="button" onclick="closeOrderModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- 提示訊息 -->
            <div id="order-toast" class="hidden p-3 rounded-lg border text-xs items-center gap-2.5" style="margin:12px 20px 0;"></div>

            <!-- 報表統計 -->
            <div class="order-list-tool px-5 sm:px-6 pt-4">
                <div class="flex items-center justify-between mb-2.5">
                    <div class="flex items-center gap-2 text-xs">
                        <i class="fa-solid fa-chart-column text-sky-600"></i>
                        <span class="font-bold text-slate-700 font-serif">營收報表</span>
                        <span class="text-[11px] text-slate-400 font-mono" id="order-period-label">全部期間</span>
                    </div>
                    <span class="text-[11px] text-slate-400 hidden sm:inline">依所選期間即時統計</span>
                </div>
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <div class="rounded-xl border border-slate-200 bg-white p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0"><i class="fa-solid fa-receipt"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-slate-500">總訂單數</div>
                            <div class="text-lg font-extrabold text-slate-800 font-mono leading-tight" id="stat-count">0</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-amber-600 border border-amber-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-hourglass-half"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-amber-700">待付款</div>
                            <div class="text-lg font-extrabold text-amber-700 font-mono leading-tight" id="stat-pending">0</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-check"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-emerald-700">已付款</div>
                            <div class="text-lg font-extrabold text-emerald-700 font-mono leading-tight" id="stat-paid">0</div>
                            <div class="text-[10px] text-emerald-600">入帳 <span id="stat-points" class="font-mono">0</span> 點</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-rose-200 bg-rose-50/50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-rose-600 border border-rose-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-sack-dollar"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-rose-700">期間實付營收</div>
                            <div class="text-lg font-extrabold text-rose-700 font-mono leading-tight" id="stat-amount">NT$ 0</div>
                            <div class="text-[10px] text-rose-600">平均客單 <span id="stat-avg" class="font-mono">NT$ 0</span></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 期間營收篩選 -->
            <div class="order-list-tool px-5 sm:px-6 pt-4 pb-3 border-b border-slate-200">
                <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-2.5">
                    <div class="flex flex-wrap items-center gap-2">
                        <button type="button" data-period="all" class="order-period-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-infinity"></i> 全部
                        </button>
                        <button type="button" data-period="today" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-day"></i> 本日
                        </button>
                        <button type="button" data-period="yesterday" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-clock-rotate-left"></i> 昨日
                        </button>
                        <button type="button" data-period="this_week" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-week"></i> 本周
                        </button>
                        <button type="button" data-period="last_week" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-minus"></i> 上周
                        </button>
                        <button type="button" data-period="this_month" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-days"></i> 本月
                        </button>
                        <button type="button" data-period="last_month" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-calendar-check"></i> 上月
                        </button>
                        <button type="button" data-period="custom" class="order-period-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                            <i class="fa-solid fa-sliders"></i> 自訂
                        </button>
                    </div>
                    <div id="order-custom-range" class="hidden flex-wrap items-center gap-2">
                        <input type="date" id="period-from" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        <span class="text-slate-400 text-xs">~</span>
                        <input type="date" id="period-to" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                        <button type="button" onclick="applyOrderCustomRange()" class="btn-ice px-3.5 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-filter"></i> 套用
                        </button>
                    </div>
                </div>
            </div>

            <!-- 篩選工具列 -->
            <div class="order-list-tool px-5 sm:px-6 py-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-b border-slate-200">
                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" data-status="all" class="order-filter-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-layer-group"></i> 全部 <span data-count="count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                    <button type="button" data-status="pending" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-amber-50 border-amber-200 text-amber-700">
                        <i class="fa-solid fa-hourglass-half"></i> 待付款 <span data-count="pending_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(180,83,9,0.10);">0</span>
                    </button>
                    <button type="button" data-status="paid" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-emerald-50 border-emerald-200 text-emerald-700">
                        <i class="fa-solid fa-circle-check"></i> 已付款 <span data-count="paid_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(4,120,87,0.10);">0</span>
                    </button>
                    <button type="button" data-status="failed" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-rose-50 border-rose-200 text-rose-700">
                        <i class="fa-solid fa-circle-exclamation"></i> 付款失敗 <span data-count="failed_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(190,18,60,0.10);">0</span>
                    </button>
                    <button type="button" data-status="expired" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-clock"></i> 已逾期 <span data-count="expired_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                    <button type="button" data-status="cancelled" class="order-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-ban"></i> 已取消 <span data-count="cancelled_count" class="ml-0.5 px-1.5 rounded-full text-[10px] font-mono" style="background:rgba(15,23,42,0.08);">0</span>
                    </button>
                </div>
                <div class="relative w-full max-w-xs">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400"><i class="fa-solid fa-magnifying-glass text-xs"></i></span>
                    <input type="text" id="order-search" placeholder="搜尋訂單編號 / 會員 / 交易編號…" class="w-full pl-9 pr-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus transition-all">
                </div>
            </div>

            <!-- 批次處理列 -->
            <div id="order-batch-bar" class="order-list-tool hidden px-5 sm:px-6 py-3 border-b border-sky-200 bg-sky-50 items-center justify-between gap-3 flex-wrap">
                <div class="flex items-center gap-3 text-xs">
                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-sky-600 text-white font-bold">
                        <i class="fa-solid fa-check-double"></i> 已選 <span id="order-selected-count" class="font-mono">0</span> 筆
                    </span>
                    <button type="button" onclick="clearOrderSelection()" class="text-slate-500 hover:text-slate-700 underline text-[11px] cursor-pointer">清除選取</button>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                    <select id="batch-status" class="appearance-none pl-3 pr-8 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                        <option value="paid">設為已付款</option>
                        <option value="cancelled">設為已取消</option>
                        <option value="expired">設為已逾期</option>
                        <option value="failed">設為付款失敗</option>
                        <option value="pending">設為待付款</option>
                    </select>
                    <label class="inline-flex items-center gap-1.5 text-[11px] text-slate-600 px-2.5 py-1.5 rounded-lg border border-emerald-200 bg-white cursor-pointer">
                        <input type="checkbox" id="batch-credit" class="rounded border-slate-300">
                        同時入帳元寶
                    </label>
                    <button type="button" id="batch-apply-btn" onclick="applyBatchUpdate()" class="btn-ice px-4 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                        <i class="fa-solid fa-bolt"></i> 批次套用
                    </button>
                </div>
            </div>

            <!-- 列表檢視 -->
            <div class="flex-1 overflow-y-auto p-4 sm:p-6" id="order-list-view" style="min-height:0;">
                <div id="order-list">
                    <div class="py-16 text-center text-slate-400 text-sm">
                        <i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>
                        載入中…
                    </div>
                </div>
            </div>

            <!-- 編輯檢視 -->
            <div class="hidden flex-1 overflow-y-auto p-5" id="order-edit-view" style="min-height:0;">
                <div class="flex items-center justify-between pb-3 mb-4 border-b border-slate-200">
                    <div class="flex items-center gap-2.5">
                        <button type="button" onclick="showOrderList()" class="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 flex items-center justify-center cursor-pointer" title="返回列表"><i class="fa-solid fa-arrow-left"></i></button>
                        <div>
                            <h3 class="text-sm font-bold text-slate-900 font-serif">編輯訂單</h3>
                            <p class="text-[11px] text-slate-500 font-mono" id="edit-order-no">—</p>
                        </div>
                    </div>
                    <span id="edit-status-badge" class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-[11px] font-bold bg-slate-100 text-slate-600 border-slate-200">
                        <span class="w-1.5 h-1.5 rounded-full bg-slate-400"></span><span id="edit-status-badge-text">—</span>
                    </span>
                </div>

                <form id="order-edit-form" onsubmit="return submitOrderEdit(event)">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-3">
                            <div>
                                <label class="block text-[11px] font-semibold text-slate-700 mb-1">訂單狀態</label>
                                <select id="edit-status" class="w-full appearance-none pl-3 pr-8 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                                    <option value="pending">待付款</option>
                                    <option value="paid">已付款</option>
                                    <option value="failed">付款失敗</option>
                                    <option value="expired">已逾期</option>
                                    <option value="cancelled">已取消</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">儲值金額 (NT$)</label>
                                    <input type="number" min="0" id="edit-amount" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">加贈元寶 (點)</label>
                                    <input type="number" min="0" id="edit-bonus" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                            </div>
                            <div class="grid grid-cols-2 gap-3">
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">總入帳元寶 (點)</label>
                                    <input type="number" min="0" id="edit-total" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                                <div>
                                    <label class="block text-[11px] font-semibold text-slate-700 mb-1">綠界交易編號</label>
                                    <input type="text" maxlength="20" id="edit-trade-no" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs font-mono form-input-focus">
                                </div>
                            </div>
                            <div>
                                <label class="block text-[11px] font-semibold text-slate-700 mb-1">備註 / 處理說明</label>
                                <input type="text" maxlength="200" id="edit-rtn-msg" placeholder="例如：客服手動入帳、異常補單…" class="w-full px-3 py-2 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                            </div>
                        </div>

                        <div class="space-y-3">
                            <div class="rounded-xl border border-slate-200 bg-slate-50/80 p-4 text-xs space-y-2">
                                <div class="font-bold text-slate-700 pb-2 mb-1 border-b border-slate-200">會員與訂單資訊</div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">會員</span><span class="font-mono text-slate-700 truncate" id="edit-user">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">UID</span><span class="font-mono text-slate-700" id="edit-uid">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">付款方式</span><span class="text-slate-700" id="edit-method">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">建立時間</span><span class="font-mono text-slate-700" id="edit-created">—</span></div>
                                <div class="flex justify-between gap-3"><span class="text-slate-400">付款時間</span><span class="font-mono text-slate-700" id="edit-paid-at">—</span></div>
                            </div>
                            <label class="flex items-start gap-2.5 p-3.5 rounded-xl border border-emerald-200 bg-emerald-50 cursor-pointer">
                                <input type="checkbox" id="edit-credit" class="mt-0.5 rounded border-slate-300">
                                <span class="text-[11px] text-slate-600 leading-relaxed">
                                    若狀態設為「已付款」，同時為會員入帳 <strong class="text-emerald-700 font-mono" id="edit-credit-points">0</strong> 點元寶。
                                    <br><span class="text-slate-400">僅在原狀態非「已付款」時執行一次，避免重複入帳。</span>
                                </span>
                            </label>
                        </div>
                    </div>

                    <div class="pt-4 border-t border-slate-200 flex items-center justify-end gap-3" style="margin-top:1rem;">
                        <button type="button" onclick="showOrderList()" class="px-5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-600 font-semibold text-xs transition-colors cursor-pointer">取消</button>
                        <button type="submit" id="edit-submit-btn" class="btn-ice px-6 py-2 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                            <i class="fa-solid fa-floppy-disk"></i>
                            <span>儲存變更</span>
                        </button>
                    </div>
                </form>
            </div>

            <!-- 分頁 -->
            <div class="hidden px-5 sm:px-6 py-3 border-t border-slate-200 bg-slate-50/70 items-center justify-between gap-3" id="order-pager">
                <span class="text-[11px] text-slate-500" id="order-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="order-prev" onclick="changeOrderPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        <i class="fa-solid fa-chevron-left text-[10px]"></i> 上一頁
                    </button>
                    <button type="button" id="order-next" onclick="changeOrderPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        下一頁 <i class="fa-solid fa-chevron-right text-[10px]"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <footer class="relative z-10 border-t border-slate-800/80 bg-[#070a10] py-6 text-center text-xs text-slate-500">
        <div class="max-w-7xl mx-auto px-4 space-y-1.5 font-serif">
            <p class="text-slate-400 font-medium">踏雪笑傲 · GM 管理控制台 (GM Control Center)</p>
            <p class="text-[11px] text-slate-600 font-mono">© 2025 踏雪笑傲運營團隊 All Rights Reserved. 系統操作均納入稽核日誌。</p>
        </div>
    </footer>

    <!-- 登入管理 子視窗 -->
    <div class="fixed inset-0 z-[70] flex items-center justify-center bg-black/75 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-300 px-3 sm:px-4" id="login-modal" style="margin:0; position:fixed; top:0; left:0; right:0; bottom:0; z-index:9999;">
        <div class="glass-panel rounded-2xl shadow-2xl w-full max-w-5xl transform scale-95 transition-transform duration-300 flex flex-col overflow-hidden" id="login-modal-card" style="max-height:90vh;">
            <div class="corner-accent"></div>

            <div class="flex items-start justify-between gap-4 p-4 sm:p-5 border-b border-slate-200 shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-xl bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700 text-base shrink-0">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide font-serif flex items-center gap-2 flex-wrap">
                            登入管理
                            <span class="text-[10px] font-normal text-slate-400 font-mono border border-slate-200 px-1.5 py-0.5 rounded">login_logs</span>
                            <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-semibold">
                                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> 即時稽核
                            </span>
                        </h2>
                        <p class="text-[11px] text-slate-500 mt-0.5">檢視會員登入帳號、來源 IP 與成功／失敗狀態，掌握異常嘗試與鎖定情形。</p>
                    </div>
                </div>
                <button type="button" onclick="closeLoginModal()" class="w-9 h-9 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors flex items-center justify-center cursor-pointer shrink-0" title="關閉">
                    <i class="fa-solid fa-xmark text-lg"></i>
                </button>
            </div>

            <!-- 統計 -->
            <div class="px-4 sm:px-5 pt-4 shrink-0">
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <div class="rounded-xl border border-slate-200 bg-white p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-slate-100 text-slate-600 flex items-center justify-center shrink-0"><i class="fa-solid fa-right-to-bracket"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-slate-500">今日登入嘗試</div>
                            <div class="text-lg font-extrabold text-slate-800 font-mono leading-tight" id="login-stat-today">0</div>
                            <div class="text-[10px] text-slate-400">來源 IP <span id="login-stat-ips" class="font-mono">0</span> 組</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-emerald-200 bg-emerald-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-emerald-600 border border-emerald-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-check"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-emerald-700">今日成功</div>
                            <div class="text-lg font-extrabold text-emerald-700 font-mono leading-tight" id="login-stat-success">0</div>
                            <div class="text-[10px] text-emerald-600">近 7 日 <span id="login-stat-week" class="font-mono">0</span></div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-rose-200 bg-rose-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-rose-600 border border-rose-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-circle-exclamation"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-rose-700">今日失敗</div>
                            <div class="text-lg font-extrabold text-rose-700 font-mono leading-tight" id="login-stat-failed">0</div>
                            <div class="text-[10px] text-rose-600">近 7 日 <span id="login-stat-weekfail" class="font-mono">0</span></div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-amber-200 bg-amber-50 p-3.5 flex items-center gap-3">
                        <div class="w-9 h-9 rounded-lg bg-white text-amber-600 border border-amber-200 flex items-center justify-center shrink-0"><i class="fa-solid fa-lock"></i></div>
                        <div class="min-w-0">
                            <div class="text-[10px] text-amber-700">目前鎖定 IP</div>
                            <div class="text-lg font-extrabold text-amber-700 font-mono leading-tight" id="login-stat-blocked">0</div>
                            <div class="text-[10px] text-amber-600" id="login-lastfail">—</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- 篩選工具列 -->
            <div class="px-4 sm:px-5 py-3.5 mt-3 flex flex-col lg:flex-row lg:items-center justify-between gap-3 border-y border-slate-200 shrink-0">
                <div class="flex flex-wrap items-center gap-2">
                    <button type="button" data-status="all" class="login-filter-btn active inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-slate-100 border-slate-200 text-slate-600">
                        <i class="fa-solid fa-layer-group"></i> 全部
                    </button>
                    <button type="button" data-status="success" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-emerald-50 border-emerald-200 text-emerald-700">
                        <i class="fa-solid fa-circle-check"></i> 成功
                    </button>
                    <button type="button" data-status="failed" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-rose-50 border-rose-200 text-rose-700">
                        <i class="fa-solid fa-circle-exclamation"></i> 失敗
                    </button>
                    <button type="button" data-status="blocked" class="login-filter-btn inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-[11px] font-semibold cursor-pointer bg-amber-50 border-amber-200 text-amber-700">
                        <i class="fa-solid fa-lock"></i> 鎖定
                    </button>
                </div>
                <div class="flex items-center gap-2 flex-wrap">
                    <select id="login-range" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                        <option value="today">今日</option>
                        <option value="7">近 7 日</option>
                        <option value="30">近 30 日</option>
                        <option value="all">全部期間</option>
                    </select>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400"><i class="fa-solid fa-magnifying-glass text-[11px]"></i></span>
                        <input type="text" id="login-search" placeholder="搜尋帳號 / IP" class="pl-8 pr-3 py-1.5 w-48 rounded-lg border border-slate-300 bg-white text-xs form-input-focus">
                    </div>
                    <button type="button" onclick="loadLoginLogs(true)" class="btn-ice px-3.5 py-1.5 rounded-lg font-semibold text-xs flex items-center gap-1.5">
                        <i class="fa-solid fa-rotate-right"></i> 重整
                    </button>
                </div>
            </div>

            <!-- 列表 -->
            <div class="flex-1 min-h-0 overflow-y-auto px-4 sm:px-5 py-4" id="login-list" style="min-height:0;"></div>

            <!-- 分頁 -->
            <div class="px-4 sm:px-5 py-3 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
                <span id="login-pager-info">—</span>
                <div class="flex items-center gap-2">
                    <button type="button" id="login-prev" onclick="changeLoginPage(-1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        <i class="fa-solid fa-chevron-left mr-1"></i> 上一頁
                    </button>
                    <button type="button" id="login-next" onclick="changeLoginPage(1)" class="px-3 py-1.5 rounded-lg border border-slate-300 bg-white text-slate-600 hover:bg-slate-100 text-xs font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer">
                        下一頁 <i class="fa-solid fa-chevron-right ml-1"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script>
        (function initSnow() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = (canvas.width = window.innerWidth);
            let height = (canvas.height = window.innerHeight);

            window.addEventListener('resize', () => {
                width = canvas.width = window.innerWidth;
                height = canvas.height = window.innerHeight;
            });

            const particles = [];
            const count = Math.min(Math.floor(window.innerWidth / 26), 48);

            for (let i = 0; i < count; i++) {
                particles.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    radius: Math.random() * 2.0 + 0.6,
                    speedY: Math.random() * 0.7 + 0.25,
                    speedX: (Math.random() - 0.5) * 0.4,
                    opacity: Math.random() * 0.6 + 0.2
                });
            }

            function render() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    p.y += p.speedY;
                    p.x += p.speedX;

                    if (p.y > height) {
                        p.y = -5;
                        p.x = Math.random() * width;
                    }
                    if (p.x < 0) p.x = width;
                    if (p.x > width) p.x = 0;

                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255, 255, 255, ${p.opacity})`;
                    ctx.shadowBlur = 4;
                    ctx.shadowColor = 'rgba(255, 255, 255, 0.5)';
                    ctx.fill();
                }
                requestAnimationFrame(render);
            }
            render();
        })();

        // 儲值系統設定子視窗控制
        // ===== 信用管理子視窗 =====
        (function initCreditModal() {
            const modal = document.getElementById('credit-modal');
            const card = document.getElementById('credit-modal-card');
            const frame = document.getElementById('credit-modal-frame');
            if (!modal || !card) return;

            window.openCreditModal = function () {
                if (frame && !frame.getAttribute('src')) {
                    frame.setAttribute('src', frame.getAttribute('data-src'));
                }
                modal.classList.remove('opacity-0', 'pointer-events-none');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
                document.body.style.overflow = 'hidden';
            };
            window.closeCreditModal = function () {
                modal.classList.add('opacity-0', 'pointer-events-none');
                modal.classList.remove('opacity-100');
                card.classList.remove('scale-100');
                card.classList.add('scale-95');
                document.body.style.overflow = '';
            };

            modal.addEventListener('click', (e) => {
                if (e.target === modal) window.closeCreditModal();
            });
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.classList.contains('opacity-100')) {
                    window.closeCreditModal();
                }
            });
        })();

        (function initRechargeModal() {
            const modal = document.getElementById('recharge-modal');
            const card = document.getElementById('recharge-modal-card');
            if (!modal || !card) return;

            window.openRechargeModal = function () {
                modal.classList.remove('opacity-0', 'pointer-events-none');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
                document.body.style.overflow = 'hidden';
            };
            window.closeRechargeModal = function () {
                modal.classList.add('opacity-0', 'pointer-events-none');
                modal.classList.remove('opacity-100');
                card.classList.remove('scale-100');
                card.classList.add('scale-95');
                document.body.style.overflow = '';
            };

            // 點擊遮罩關閉
            modal.addEventListener('click', (e) => {
                if (e.target === modal) window.closeRechargeModal();
            });
            // ESC 關閉
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && modal.classList.contains('opacity-100')) {
                    window.closeRechargeModal();
                }
            });

            <?php if ($openRechargeModal): ?>
            // 儲存後自動重新開啟，讓管理員檢視結果
            window.openRechargeModal();
            <?php endif; ?>
        })();

        // 金鑰顯示 / 隱藏切換
        window.toggleSecret = function (inputId, btn) {
            const input = document.getElementById(inputId);
            if (!input) return;
            const reveal = (input.type === 'password');
            input.type = reveal ? 'text' : 'password';
            const icon = btn ? btn.querySelector('i') : null;
            if (icon) {
                icon.className = reveal ? 'fa-solid fa-eye-slash text-xs' : 'fa-solid fa-eye text-xs';
            }
        };

        // ===== 訂單管理 =====
        const GM_FORM_TOKEN = <?php echo json_encode($formToken); ?>;

        const ORDER_STATUS_META = {
            paid:      { text: '已付款',   cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
            pending:   { text: '待付款',   cls: 'bg-amber-50 text-amber-700 border-amber-200',       dot: 'bg-amber-500' },
            failed:    { text: '付款失敗', cls: 'bg-rose-50 text-rose-700 border-rose-200',          dot: 'bg-rose-500' },
            expired:   { text: '已逾期',   cls: 'bg-slate-100 text-slate-600 border-slate-300',       dot: 'bg-slate-400' },
            cancelled: { text: '已取消',   cls: 'bg-slate-100 text-slate-600 border-slate-300',       dot: 'bg-slate-400' }
        };
        const ORDER_DEFAULT_META = { text: '未知', cls: 'bg-slate-100 text-slate-600 border-slate-300', dot: 'bg-slate-400' };

        const orderModal = document.getElementById('order-modal');
        const orderCard = document.getElementById('order-modal-card');
        const orderListEl = document.getElementById('order-list');
        const orderListView = document.getElementById('order-list-view');
        const orderEditView = document.getElementById('order-edit-view');
        const orderPager = document.getElementById('order-pager');
        const orderPagerInfo = document.getElementById('order-pager-info');
        const orderPrev = document.getElementById('order-prev');
        const orderNext = document.getElementById('order-next');
        const orderSearch = document.getElementById('order-search');

        const orderState = { page: 1, pages: 1, status: 'all', q: '', period: 'all', dateFrom: '', dateTo: '', orders: [], index: {}, editing: null, loaded: false, selected: new Set(), uid: 0, pendingEdit: null };
        let orderDebounce = null;
        let orderToastTimer = null;

        function escapeHtml(s) {
            return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
        }
        function orderFmtMoney(n) { return 'NT$ ' + Number(n || 0).toLocaleString(); }
        function orderFmtPoints(n) { return Number(n || 0).toLocaleString(); }
        function orderFmtDT(s) { return s ? String(s).replace('T', ' ').slice(0, 16) : '—'; }

        window.openOrderModal = function (uid, editOrderNo) {
            if (!orderModal) return;
            orderState.uid = Number(uid || 0);
            orderState.pendingEdit = editOrderNo || null;
            orderState.page = 1;
            orderState.loaded = false;
            orderState.selected.clear();
            // 依來源調整標題（全域訂單 / 指定會員歷史訂單）
            const titleEl = document.getElementById('order-modal-title');
            const subEl = document.getElementById('order-modal-subtitle');
            const scopeEl = document.getElementById('order-modal-scope');
            if (orderState.uid > 0) {
                if (titleEl) titleEl.textContent = '會員歷史訂單';
                if (subEl) subEl.textContent = '檢視、編輯與管理會員 #' + orderState.uid + ' 的儲值訂單紀錄。';
                if (scopeEl) { scopeEl.textContent = 'UID #' + orderState.uid; scopeEl.className = 'inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-sky-50 border border-sky-200 text-sky-700 text-[10px] font-mono font-bold'; }
                // 會員情境一律重置篩選，確保能定位到指定訂單
                orderState.status = 'all';
                orderState.period = 'all';
                orderState.q = '';
                const searchEl = document.getElementById('order-search');
                if (searchEl) searchEl.value = '';
                document.querySelectorAll('.order-filter-btn').forEach(b => b.classList.toggle('active', b.getAttribute('data-status') === 'all'));
                document.querySelectorAll('.order-period-btn').forEach(b => b.classList.toggle('active', b.getAttribute('data-period') === 'all'));
                const customWrap = document.getElementById('order-custom-range');
                if (customWrap) customWrap.classList.add('hidden');
            } else {
                if (titleEl) titleEl.textContent = '訂單管理';
                if (subEl) subEl.textContent = '檢視全部儲值訂單、編輯狀態與金額，並掌握即時營運報表。';
                if (scopeEl) scopeEl.className = 'hidden';
            }
            // 指定編輯某筆訂單時，先以訂單編號搜尋，避免該筆不在第一頁而找不到
            if (orderState.pendingEdit) {
                orderState.q = String(orderState.pendingEdit);
                if (orderSearch) orderSearch.value = orderState.q;
            }
            orderModal.classList.remove('opacity-0', 'pointer-events-none');
            orderModal.classList.add('opacity-100');
            if (orderCard) { orderCard.classList.remove('scale-95'); orderCard.classList.add('scale-100'); }
            document.body.style.overflow = 'hidden';
            showOrderList();
            loadOrders(true);
        };
        window.closeOrderModal = function () {
            if (!orderModal) return;
            orderModal.classList.add('opacity-0', 'pointer-events-none');
            orderModal.classList.remove('opacity-100');
            if (orderCard) { orderCard.classList.remove('scale-100'); orderCard.classList.add('scale-95'); }
            // 若帳號查詢視窗仍開著，維持鎖定背景捲動
            const acctModal = document.getElementById('account-modal');
            document.body.style.overflow = (acctModal && acctModal.classList.contains('opacity-100')) ? 'hidden' : '';
        };
        window.showOrderList = function () {
            if (orderListView) orderListView.classList.remove('hidden');
            if (orderEditView) orderEditView.classList.add('hidden');
            // 回到列表：恢復統計／篩選工具列
            document.querySelectorAll('.order-list-tool').forEach(el => el.classList.remove('hidden'));
            orderState.editing = null;
            syncOrderSelectionUI();
            if (orderPager) {
                if (orderState.pages > 1) { orderPager.classList.remove('hidden'); orderPager.classList.add('flex'); }
                else { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
            }
        };
        function showOrderEdit() {
            if (orderListView) orderListView.classList.add('hidden');
            if (orderEditView) orderEditView.classList.remove('hidden');
            if (orderEditView) orderEditView.scrollTop = 0;
            // 編輯時隱藏統計與篩選，讓編輯表單取得完整高度，免去拖拉捲動
            document.querySelectorAll('.order-list-tool').forEach(el => el.classList.add('hidden'));
            if (orderPager) { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
        }

        function showOrderToast(msg, ok) {
            const el = document.getElementById('order-toast');
            if (!el) return;
            el.className = 'mx-5 sm:mx-6 mt-3 p-3 rounded-lg border text-xs flex items-center gap-2.5 '
                + (ok ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700');
            el.innerHTML = '<i class="fa-solid ' + (ok ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><span>' + escapeHtml(msg) + '</span>';
            clearTimeout(orderToastTimer);
            orderToastTimer = setTimeout(() => { el.classList.add('hidden'); }, 3800);
        }

        function setOrderFilter(status) {
            orderState.status = status;
            orderState.page = 1;
            document.querySelectorAll('.order-filter-btn').forEach(btn => {
                btn.classList.toggle('active', btn.getAttribute('data-status') === status);
            });
            loadOrders(true);
        }
        window.changeOrderPage = function (delta) {
            const target = orderState.page + delta;
            if (target < 1 || target > orderState.pages) return;
            orderState.page = target;
            loadOrders(true);
        };

        function loadOrders(showLoading) {
            if (!orderListEl) return;
            if (showLoading) {
                orderListEl.innerHTML = '<div class="py-16 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>載入中…</div>';
            }
            const url = 'gm_orders_api.php?status=' + encodeURIComponent(orderState.status)
                + '&q=' + encodeURIComponent(orderState.q)
                + '&period=' + encodeURIComponent(orderState.period)
                + '&date_from=' + encodeURIComponent(orderState.dateFrom)
                + '&date_to=' + encodeURIComponent(orderState.dateTo)
                + '&uid=' + encodeURIComponent(orderState.uid || 0)
                + '&page=' + encodeURIComponent(orderState.page)
                + '&limit=10';
            fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (!data || !data.ok) {
                        orderListEl.innerHTML = '<div class="py-16 text-center text-rose-500 text-sm"><i class="fa-solid fa-circle-exclamation text-2xl mb-3 block"></i>' + escapeHtml((data && data.message) || '查詢失敗') + '</div>';
                        if (orderPager) { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
                        return;
                    }
                    orderState.loaded = true;
                    renderOrders(data);
                })
                .catch(() => {
                    orderListEl.innerHTML = '<div class="py-16 text-center text-rose-500 text-sm"><i class="fa-solid fa-wifi text-2xl mb-3 block"></i>網路連線異常，請稍後再試。</div>';
                });
        }

        function renderOrders(data) {
            const orders = data.orders || [];
            const stats = data.stats || {};
            orderState.page = Number(data.page || 1);
            orderState.pages = Math.max(1, Number(data.pages || 1));
            orderState.orders = orders;
            orderState.index = {};
            orders.forEach(o => { orderState.index[o.order_no] = o; });

            const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
            const paidCount = Number(stats.paid_count || 0);
            const paidAmount = Number(stats.paid_amount || 0);
            setText('stat-count', Number(stats.count || 0).toLocaleString());
            setText('stat-pending', Number(stats.pending_count || 0).toLocaleString());
            setText('stat-paid', paidCount.toLocaleString());
            setText('stat-points', Number(stats.paid_points || 0).toLocaleString());
            setText('stat-amount', orderFmtMoney(paidAmount));
            setText('stat-avg', orderFmtMoney(paidCount > 0 ? Math.round(paidAmount / paidCount) : 0));

            const periodLabels = {
                all: '全部期間', today: '本日', yesterday: '昨日',
                this_week: '本周', last_week: '上周',
                this_month: '本月', last_month: '上月', custom: '自訂期間'
            };
            let plabel = periodLabels[data.period] || '全部期間';
            if (data.period && data.period !== 'all' && data.date_from && data.date_to) {
                plabel += '（' + data.date_from + ' ~ ' + data.date_to + '）';
            }
            const periodLabelEl = document.getElementById('order-period-label');
            if (periodLabelEl) periodLabelEl.textContent = plabel;

            document.querySelectorAll('[data-count]').forEach(el => {
                const key = el.getAttribute('data-count');
                el.textContent = Number(stats[key] || 0).toLocaleString();
            });

            if (!orders.length) {
                orderListEl.innerHTML = '<div class="py-16 text-center text-slate-400 text-sm"><i class="fa-regular fa-folder-open text-3xl mb-3 block"></i>查無符合的訂單</div>';
            } else {
                orderListEl.innerHTML = `
                <div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">
                    <table class="w-full text-left text-xs whitespace-nowrap">
                        <thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold text-[11px]">
                            <tr>
                                <th class="py-2.5 px-2 w-8 text-center"><input type="checkbox" id="order-select-all" class="rounded border-slate-300 cursor-pointer" title="全選本頁"></th>
                                <th class="py-2.5 px-3">訂單編號</th>
                                <th class="py-2.5 px-3">會員</th>
                                <th class="py-2.5 px-3">付款方式</th>
                                <th class="py-2.5 px-3 text-right">金額</th>
                                <th class="py-2.5 px-3 text-right">元寶</th>
                                <th class="py-2.5 px-3">狀態</th>
                                <th class="py-2.5 px-3">建立時間</th>
                                <th class="py-2.5 px-3 text-right">操作</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100">
                            ${orders.map(o => {
                                const meta = ORDER_STATUS_META[o.status] || ORDER_DEFAULT_META;
                                return `
                                <tr class="hover:bg-slate-50/80 transition-colors">
                                    <td class="py-2.5 px-2 text-center"><input type="checkbox" class="order-row-check rounded border-slate-300 cursor-pointer" data-order="${escapeHtml(o.order_no)}"></td>
                                    <td class="py-2.5 px-3 font-mono text-slate-700 font-semibold">${escapeHtml(o.order_no)}</td>
                                    <td class="py-2.5 px-3">
                                        <div class="font-medium text-slate-800">${escapeHtml(o.username)}</div>
                                        <div class="text-[10px] text-slate-400 font-mono">UID #${Number(o.uid || 0)}</div>
                                    </td>
                                    <td class="py-2.5 px-3 text-slate-600">${escapeHtml(o.method_name)}</td>
                                    <td class="py-2.5 px-3 text-right font-mono text-slate-700">${orderFmtMoney(o.amount)}</td>
                                    <td class="py-2.5 px-3 text-right font-mono text-amber-600">+${orderFmtPoints(o.total_points)}</td>
                                    <td class="py-2.5 px-3">
                                        <span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-bold ${meta.cls}">
                                            <span class="w-1.5 h-1.5 rounded-full ${meta.dot}"></span>${meta.text}
                                        </span>
                                    </td>
                                    <td class="py-2.5 px-3 text-slate-500 font-mono text-[11px]">${orderFmtDT(o.created_at)}</td>
                                    <td class="py-2.5 px-3 text-right">
                                        <button type="button" onclick="editOrder('${escapeHtml(o.order_no)}')" class="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-700 hover:text-sky-700 border border-slate-300 font-medium text-[11px] transition-colors cursor-pointer">
                                            <i class="fa-solid fa-pen-to-square text-[10px]"></i> 編輯
                                        </button>
                                    </td>
                                </tr>`;
                            }).join('')}
                        </tbody>
                    </table>
                </div>`;
            }

            if (orderPager) {
                if (orderState.pages > 1) { orderPager.classList.remove('hidden'); orderPager.classList.add('flex'); }
                else { orderPager.classList.add('hidden'); orderPager.classList.remove('flex'); }
            }
            if (orderPagerInfo) orderPagerInfo.textContent = '第 ' + orderState.page + ' / ' + orderState.pages + ' 頁 · 共 ' + Number(data.total || 0).toLocaleString() + ' 筆';
            if (orderPrev) orderPrev.disabled = orderState.page <= 1;
            if (orderNext) orderNext.disabled = orderState.page >= orderState.pages;

            syncOrderSelectionUI();

            // 由會員歷史訂單直接開啟編輯時，載入完成後自動切換到編輯檢視
            if (orderState.pendingEdit) {
                const pending = orderState.pendingEdit;
                orderState.pendingEdit = null;
                if (orderState.index[pending]) { window.editOrder(pending); }
            }
        }

        function syncOrderSelectionUI() {
            const checks = orderListEl ? orderListEl.querySelectorAll('.order-row-check') : [];
            let checkedOnPage = 0;
            checks.forEach(cb => {
                const on = orderState.selected.has(cb.getAttribute('data-order'));
                cb.checked = on;
                if (on) checkedOnPage++;
            });
            const all = document.getElementById('order-select-all');
            if (all) {
                all.checked = (checks.length > 0 && checkedOnPage === checks.length);
                all.indeterminate = (checkedOnPage > 0 && checkedOnPage < checks.length);
            }
            const bar = document.getElementById('order-batch-bar');
            const cnt = document.getElementById('order-selected-count');
            if (cnt) cnt.textContent = orderState.selected.size;
            if (bar) {
                if (orderState.selected.size > 0) { bar.classList.remove('hidden'); bar.classList.add('flex'); }
                else { bar.classList.add('hidden'); bar.classList.remove('flex'); }
            }
        }

        window.clearOrderSelection = function () {
            orderState.selected.clear();
            syncOrderSelectionUI();
        };

        window.applyBatchUpdate = function () {
            if (orderState.selected.size === 0) {
                showOrderToast('請先勾選要處理的訂單。', false);
                return;
            }
            const status = document.getElementById('batch-status').value;
            const credit = document.getElementById('batch-credit').checked ? '1' : '0';
            const btn = document.getElementById('batch-apply-btn');
            if (btn) { btn.disabled = true; btn.classList.add('opacity-60', 'cursor-not-allowed'); }

            const body = new URLSearchParams();
            body.append('action', 'batch_update');
            body.append('form_token', GM_FORM_TOKEN);
            body.append('status', status);
            body.append('credit', credit);
            orderState.selected.forEach(no => body.append('order_nos[]', no));

            fetch('gm_orders_api.php', { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (data && data.ok) {
                        orderState.selected.clear();
                        loadOrders(false);
                        showOrderToast(data.message || '批次更新完成。', true);
                    } else {
                        showOrderToast((data && data.message) || '批次更新失敗，請稍後再試。', false);
                    }
                })
                .catch(() => showOrderToast('網路連線異常，請稍後再試。', false))
                .finally(() => {
                    if (btn) { btn.disabled = false; btn.classList.remove('opacity-60', 'cursor-not-allowed'); }
                });
        };

        window.setOrderPeriod = function (period) {
            orderState.period = period;
            orderState.page = 1;
            document.querySelectorAll('.order-period-btn').forEach(b => {
                b.classList.toggle('active', b.getAttribute('data-period') === period);
            });
            const customWrap = document.getElementById('order-custom-range');
            if (customWrap) {
                if (period === 'custom') { customWrap.classList.remove('hidden'); customWrap.classList.add('flex'); }
                else { customWrap.classList.add('hidden'); customWrap.classList.remove('flex'); }
            }
            if (period !== 'custom') {
                loadOrders(true);
            }
        };
        window.applyOrderCustomRange = function () {
            const fromEl = document.getElementById('period-from');
            const toEl = document.getElementById('period-to');
            orderState.dateFrom = fromEl ? fromEl.value : '';
            orderState.dateTo = toEl ? toEl.value : '';
            orderState.page = 1;
            loadOrders(true);
        };

        function updateEditCreditPoints() {
            const total = parseInt(document.getElementById('edit-total').value, 10) || 0;
            const cp = document.getElementById('edit-credit-points');
            if (cp) cp.textContent = total.toLocaleString();
            const credit = document.getElementById('edit-credit');
            if (credit) {
                const originalPaid = orderState.editing && orderState.editing.status === 'paid';
                credit.disabled = !!originalPaid;
                if (originalPaid) credit.checked = false;
            }
        }
        function updateEditStatusBadge(status) {
            const meta = ORDER_STATUS_META[status] || ORDER_DEFAULT_META;
            const badge = document.getElementById('edit-status-badge');
            const badgeText = document.getElementById('edit-status-badge-text');
            if (badge) badge.className = 'inline-flex items-center gap-1 px-2.5 py-1 rounded-full border text-[11px] font-bold ' + meta.cls;
            if (badgeText) badgeText.textContent = meta.text;
        }

        window.editOrder = function (orderNo) {
            const o = orderState.index[orderNo];
            if (!o) return;
            orderState.editing = o;
            document.getElementById('edit-order-no').textContent = o.order_no;
            document.getElementById('edit-status').value = ORDER_STATUS_META[o.status] ? o.status : 'pending';
            document.getElementById('edit-amount').value = o.amount;
            document.getElementById('edit-bonus').value = o.bonus;
            document.getElementById('edit-total').value = o.total_points;
            document.getElementById('edit-trade-no').value = o.trade_no || '';
            document.getElementById('edit-rtn-msg').value = o.rtn_msg || '';
            document.getElementById('edit-user').textContent = o.username || '—';
            document.getElementById('edit-uid').textContent = '#' + Number(o.uid || 0);
            document.getElementById('edit-method').textContent = o.method_name || '—';
            document.getElementById('edit-created').textContent = orderFmtDT(o.created_at);
            document.getElementById('edit-paid-at').textContent = orderFmtDT(o.paid_at);
            updateEditStatusBadge(o.status);
            const credit = document.getElementById('edit-credit');
            if (credit) credit.checked = false;
            updateEditCreditPoints();
            showOrderEdit();
        };

        window.submitOrderEdit = function (e) {
            if (e) e.preventDefault();
            const o = orderState.editing;
            if (!o) return false;
            const btn = document.getElementById('edit-submit-btn');
            if (btn) { btn.disabled = true; btn.classList.add('opacity-60', 'cursor-not-allowed'); }

            const body = new URLSearchParams({
                action: 'update_order',
                form_token: GM_FORM_TOKEN,
                order_no: o.order_no,
                status: document.getElementById('edit-status').value,
                amount: document.getElementById('edit-amount').value,
                bonus: document.getElementById('edit-bonus').value,
                total_points: document.getElementById('edit-total').value,
                trade_no: document.getElementById('edit-trade-no').value,
                rtn_msg: document.getElementById('edit-rtn-msg').value,
                credit: document.getElementById('edit-credit').checked ? '1' : '0'
            });

            fetch('gm_orders_api.php', { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json())
                .then(data => {
                    if (data && data.ok) {
                        showOrderList();
                        const activeStatus = orderState.status;
                        document.querySelectorAll('.order-filter-btn').forEach(btn => {
                            btn.classList.toggle('active', btn.getAttribute('data-status') === activeStatus);
                        });
                        loadOrders(true);
                        showOrderToast(data.message || '訂單已更新。', true);
                    } else {
                        showOrderToast((data && data.message) || '更新失敗，請稍後再試。', false);
                    }
                })
                .catch(() => showOrderToast('網路連線異常，請稍後再試。', false))
                .finally(() => {
                    if (btn) { btn.disabled = false; btn.classList.remove('opacity-60', 'cursor-not-allowed'); }
                });
            return false;
        };

        document.querySelectorAll('.order-filter-btn').forEach(btn => {
            btn.addEventListener('click', () => setOrderFilter(btn.getAttribute('data-status') || 'all'));
        });
        document.querySelectorAll('.order-period-btn').forEach(btn => {
            btn.addEventListener('click', () => setOrderPeriod(btn.getAttribute('data-period') || 'all'));
        });
        if (orderListEl) {
            orderListEl.addEventListener('change', (e) => {
                const allBox = e.target.closest('#order-select-all');
                if (allBox) {
                    orderListEl.querySelectorAll('.order-row-check').forEach(cb => {
                        const no = cb.getAttribute('data-order');
                        if (allBox.checked) { orderState.selected.add(no); } else { orderState.selected.delete(no); }
                    });
                    syncOrderSelectionUI();
                    return;
                }
                const rowBox = e.target.closest('.order-row-check');
                if (rowBox) {
                    const no = rowBox.getAttribute('data-order');
                    if (rowBox.checked) { orderState.selected.add(no); } else { orderState.selected.delete(no); }
                    syncOrderSelectionUI();
                }
            });
        }
        if (orderSearch) {
            orderSearch.addEventListener('input', () => {
                clearTimeout(orderDebounce);
                orderDebounce = setTimeout(() => {
                    orderState.q = orderSearch.value.trim();
                    orderState.page = 1;
                    loadOrders(false);
                }, 350);
            });
        }
        const editStatusSelect = document.getElementById('edit-status');
        if (editStatusSelect) {
            editStatusSelect.addEventListener('change', function () { updateEditStatusBadge(this.value); });
        }
        const editTotalInput = document.getElementById('edit-total');
        if (editTotalInput) {
            editTotalInput.addEventListener('input', updateEditCreditPoints);
        }
        if (orderModal) {
            orderModal.addEventListener('click', (e) => { if (e.target === orderModal) window.closeOrderModal(); });
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && orderModal.classList.contains('opacity-100')) {
                    // 訂單視窗為最上層，消費此事件避免同時關閉底下的帳號查詢視窗
                    e.stopImmediatePropagation();
                    window.closeOrderModal();
                }
            });
        }

        /* ================= 登入管理 子視窗 ================= */
        (function () {
            const loginModal = document.getElementById('login-modal');
            const loginCard = document.getElementById('login-modal-card');
            const loginListEl = document.getElementById('login-list');
            const loginPrev = document.getElementById('login-prev');
            const loginNext = document.getElementById('login-next');
            const loginPagerInfo = document.getElementById('login-pager-info');
            const loginSearch = document.getElementById('login-search');
            const loginRange = document.getElementById('login-range');
            if (!loginModal) return;

            const LOGIN_STATUS_META = {
                success: { text: '登入成功', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
                failed:  { text: '登入失敗', cls: 'bg-rose-50 text-rose-700 border-rose-200', dot: 'bg-rose-500' },
                blocked: { text: '已鎖定',   cls: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' }
            };
            const loginState = { page: 1, pages: 1, status: 'all', range: 'today', q: '', loaded: false };
            let loginDebounce = null;

            function loginEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
            function loginFmtDT(s) { return s ? String(s).replace('T', ' ').slice(0, 19) : '—'; }
            function loginShortUA(ua) {
                if (!ua) return '—';
                let label = '未知裝置';
                if (/Edg\//.test(ua)) label = 'Edge';
                else if (/Chrome\//.test(ua) && !/Chromium/.test(ua)) label = 'Chrome';
                else if (/Firefox\//.test(ua)) label = 'Firefox';
                else if (/Safari\//.test(ua) && !/Chrome/.test(ua)) label = 'Safari';
                else if (/MSIE|Trident/.test(ua)) label = 'IE';
                else if (/curl|python|bot|spider|wget/i.test(ua)) label = '自動化程式';
                let os = '';
                if (/Windows/.test(ua)) os = 'Windows';
                else if (/Android/.test(ua)) os = 'Android';
                else if (/iPhone|iPad|iOS/.test(ua)) os = 'iOS';
                else if (/Mac OS X/.test(ua)) os = 'macOS';
                else if (/Linux/.test(ua)) os = 'Linux';
                return os ? (label + ' · ' + os) : label;
            }

            window.openLoginModal = function () {
                loginModal.classList.remove('opacity-0', 'pointer-events-none');
                loginModal.classList.add('opacity-100');
                if (loginCard) { loginCard.classList.remove('scale-95'); loginCard.classList.add('scale-100'); }
                document.body.style.overflow = 'hidden';
                window.loadLoginLogs(!loginState.loaded);
            };
            window.closeLoginModal = function () {
                loginModal.classList.add('opacity-0', 'pointer-events-none');
                loginModal.classList.remove('opacity-100');
                if (loginCard) { loginCard.classList.remove('scale-100'); loginCard.classList.add('scale-95'); }
                document.body.style.overflow = '';
            };

            document.querySelectorAll('.login-filter-btn').forEach(function (btn) {
                btn.addEventListener('click', function () {
                    loginState.status = this.getAttribute('data-status') || 'all';
                    loginState.page = 1;
                    document.querySelectorAll('.login-filter-btn').forEach(function (b) { b.classList.toggle('active', b === btn); });
                    window.loadLoginLogs(true);
                });
            });
            if (loginRange) {
                loginRange.addEventListener('change', function () { loginState.range = this.value; loginState.page = 1; window.loadLoginLogs(true); });
            }
            if (loginSearch) {
                loginSearch.addEventListener('input', function () {
                    clearTimeout(loginDebounce);
                    loginDebounce = setTimeout(function () { loginState.q = loginSearch.value.trim(); loginState.page = 1; window.loadLoginLogs(true); }, 350);
                });
            }

            window.changeLoginPage = function (delta) {
                const target = loginState.page + delta;
                if (target < 1 || target > loginState.pages) return;
                loginState.page = target;
                window.loadLoginLogs(true);
            };

            window.loadLoginLogs = function (showLoading) {
                if (showLoading && loginListEl) {
                    loginListEl.innerHTML = '<div class="py-14 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-2xl mb-3 block"></i>載入中…</div>';
                }
                const params = new URLSearchParams({ status: loginState.status, range: loginState.range, q: loginState.q, page: loginState.page, limit: 20 });
                fetch('gm_login_logs_api.php?' + params.toString(), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(function (data) {
                        if (!data || !data.ok) {
                            if (loginListEl) loginListEl.innerHTML = '<div class="py-14 text-center text-rose-500 text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>' + loginEsc((data && data.message) || '載入失敗') + '</div>';
                            return;
                        }
                        loginState.loaded = true;
                        loginState.pages = data.pages || 1;
                        loginState.page = data.page || 1;
                        renderLoginStats(data.stats);
                        renderLoginRows(data.logs);
                        if (loginPagerInfo) loginPagerInfo.textContent = data.total > 0 ? ('共 ' + Number(data.total).toLocaleString() + ' 筆 · 第 ' + data.page + ' / ' + (data.pages || 1) + ' 頁') : '共 0 筆';
                        if (loginPrev) loginPrev.disabled = (data.page <= 1);
                        if (loginNext) loginNext.disabled = (data.page >= (data.pages || 1));
                    })
                    .catch(function () {
                        if (loginListEl) loginListEl.innerHTML = '<div class="py-14 text-center text-rose-500 text-sm"><i class="fa-solid fa-triangle-exclamation mr-1"></i>網路連線失敗</div>';
                    });
            };

            function setText(id, val) { const el = document.getElementById(id); if (el) el.textContent = val; }
            function renderLoginStats(s) {
                if (!s) return;
                setText('login-stat-today', Number(s.today_total || 0).toLocaleString());
                setText('login-stat-ips', Number(s.unique_ips_today || 0).toLocaleString());
                setText('login-stat-success', Number(s.today_success || 0).toLocaleString());
                setText('login-stat-week', Number(s.week_success || 0).toLocaleString());
                setText('login-stat-failed', Number(s.today_failed || 0).toLocaleString());
                setText('login-stat-weekfail', Number(s.week_failed || 0).toLocaleString());
                setText('login-stat-blocked', Number(s.active_blocked_ips || 0).toLocaleString());
                const lf = s.last_fail;
                setText('login-lastfail', lf ? ('最近失敗：' + (lf.username || '未知') + ' @ ' + (lf.ip || '—')) : '尚無失敗紀錄');
            }

            function renderLoginRows(logs) {
                if (!loginListEl) return;
                if (!logs || logs.length === 0) {
                    loginListEl.innerHTML = '<div class="py-14 text-center text-slate-400 text-sm"><i class="fa-regular fa-folder-open text-2xl mb-3 block"></i>沒有符合條件的登入紀錄</div>';
                    return;
                }
                let html = '<div class="overflow-x-auto rounded-xl border border-slate-200 bg-white">'
                    + '<table class="w-full text-left text-xs"><thead class="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold sticky top-0 z-10"><tr>'
                    + '<th class="py-2.5 px-3 whitespace-nowrap">時間</th>'
                    + '<th class="py-2.5 px-3">帳號</th>'
                    + '<th class="py-2.5 px-3">結果</th>'
                    + '<th class="py-2.5 px-3">來源 IP</th>'
                    + '<th class="py-2.5 px-3">裝置 / 來源</th>'
                    + '</tr></thead><tbody class="divide-y divide-slate-100 font-sans">';
                logs.forEach(function (l) {
                    const meta = LOGIN_STATUS_META[l.status] || { text: l.status, cls: 'bg-slate-100 text-slate-600 border-slate-300', dot: 'bg-slate-400' };
                    const fwd = (l.forwarded && l.forwarded !== l.ip) ? '<div class="text-[10px] text-slate-400 font-mono truncate max-w-[180px]" title="' + loginEsc(l.forwarded) + '">via ' + loginEsc(l.forwarded) + '</div>' : '';
                    html += '<tr class="hover:bg-slate-50/80">'
                        + '<td class="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">' + loginEsc(loginFmtDT(l.created_at)) + '</td>'
                        + '<td class="py-2.5 px-3"><span class="font-semibold text-slate-800">' + loginEsc(l.username || '—') + '</span>' + (l.user_id > 0 ? '<span class="text-[10px] text-slate-400 font-mono ml-1">#' + l.user_id + '</span>' : '') + '</td>'
                        + '<td class="py-2.5 px-3"><span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[10px] font-medium ' + meta.cls + '"><span class="w-1.5 h-1.5 rounded-full ' + meta.dot + '"></span>' + meta.text + '</span>'
                        + (l.reason ? '<div class="text-[10px] text-slate-400 mt-0.5">' + loginEsc(l.reason) + '</div>' : '') + '</td>'
                        + '<td class="py-2.5 px-3 font-mono text-[11px] text-slate-600">' + loginEsc(l.ip || '—') + fwd + '</td>'
                        + '<td class="py-2.5 px-3 text-slate-500"><span class="text-[11px]">' + loginEsc(loginShortUA(l.ua)) + '</span>'
                        + '<div class="text-[10px] text-slate-400 font-mono truncate max-w-[220px]" title="' + loginEsc(l.ua) + '">' + loginEsc(l.ua) + '</div></td>'
                        + '</tr>';
                });
                html += '</tbody></table></div>';
                loginListEl.innerHTML = html;
            }

            loginModal.addEventListener('click', function (e) { if (e.target === loginModal) window.closeLoginModal(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && loginModal.classList.contains('opacity-100')) window.closeLoginModal();
            });
        })();
    </script>
    <script>
        // 帳號操作台分頁切換
        function switchActionTab(tabId) {
            document.querySelectorAll('.tab-pane').forEach(el => el.classList.remove('active'));
            document.querySelectorAll('.tab-btn').forEach(el => {
                el.classList.remove('active');
                el.setAttribute('aria-selected', 'false');
            });
            const pane = document.getElementById(tabId);
            if (pane) pane.classList.add('active');
            const btn = document.getElementById('btn-' + tabId);
            if (btn) {
                btn.classList.add('active');
                btn.setAttribute('aria-selected', 'true');
            }
        }
        // 由工單連結載入時，自動切換到「工單回報」分頁
        (function () {
            var openTab = <?php echo json_encode($supportTicketId > 0 ? 'tab-support' : ''); ?>;
            if (openTab) { switchActionTab(openTab); }
        })();
        // 密碼顯示／隱藏切換
        function togglePasswordVisibility(inputId) {
            const input = document.getElementById(inputId);
            if (input) input.type = input.type === 'password' ? 'text' : 'password';
        }
    </script>

    <script>
        // ===== 左下方浮動多功能選單（玩家帳號查詢 + GM 管理員帳號） =====
        (function initAccountFabMenu() {
            const wrap = document.getElementById('account-fab-wrap');
            const menu = document.getElementById('account-fab-menu');
            const fab = document.getElementById('account-fab');
            if (!wrap || !menu || !fab) return;

            window.toggleAccountFab = function (force) {
                const open = (typeof force === 'boolean') ? force : !menu.classList.contains('is-open');
                menu.classList.toggle('is-open', open);
                wrap.classList.toggle('is-open', open);
                fab.setAttribute('aria-expanded', open ? 'true' : 'false');
            };
            window.setAccountFabVisible = function (visible) {
                wrap.style.display = visible ? '' : 'none';
                if (!visible) window.toggleAccountFab(false);
            };

            // 點擊選單外部或按 Esc 時收合
            document.addEventListener('click', function (e) {
                if (!wrap.contains(e.target)) window.toggleAccountFab(false);
            });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape') window.toggleAccountFab(false);
            });
        })();

        // ===== GM 管理員帳號子視窗 =====
        (function initGmAccountsModal() {
            const modal = document.getElementById('gm-accounts-modal');
            const card = document.getElementById('gm-accounts-modal-card');
            if (!modal || !card) return;

            window.openGmAccountsModal = function () {
                window.toggleAccountFab(false);
                modal.classList.remove('opacity-0', 'pointer-events-none');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
                document.body.style.overflow = 'hidden';
                window.setAccountFabVisible(false);
            };
            window.closeGmAccountsModal = function () {
                modal.classList.add('opacity-0', 'pointer-events-none');
                modal.classList.remove('opacity-100');
                card.classList.remove('scale-100');
                card.classList.add('scale-95');
                document.body.style.overflow = '';
                window.setAccountFabVisible(true);
            };

            modal.addEventListener('click', function (e) { if (e.target === modal) window.closeGmAccountsModal(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && modal.classList.contains('opacity-100')) window.closeGmAccountsModal();
            });

            <?php if ($openGmAccountsModal): ?>
            // 於子視窗內新增／移除帳號後，重新開啟以顯示最新結果
            window.openGmAccountsModal();
            <?php endif; ?>
        })();
    </script>

    <script>
        // ===== 玩家帳號查詢子視窗（左下方浮動按鈕） =====
        (function initAccountModal() {
            const modal = document.getElementById('account-modal');
            const card = document.getElementById('account-modal-card');
            if (!modal || !card) return;

            window.openAccountModal = function () {
                window.toggleAccountFab(false);
                modal.classList.remove('opacity-0', 'pointer-events-none');
                modal.classList.add('opacity-100');
                card.classList.remove('scale-95');
                card.classList.add('scale-100');
                document.body.style.overflow = 'hidden';
                window.setAccountFabVisible(false);
                setTimeout(function () {
                    const q = document.getElementById('account-search-input');
                    if (q) q.focus();
                }, 200);
            };
            window.closeAccountModal = function () {
                modal.classList.add('opacity-0', 'pointer-events-none');
                modal.classList.remove('opacity-100');
                card.classList.remove('scale-100');
                card.classList.add('scale-95');
                document.body.style.overflow = '';
                window.setAccountFabVisible(true);
            };

            modal.addEventListener('click', function (e) { if (e.target === modal) window.closeAccountModal(); });
            document.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && modal.classList.contains('opacity-100')) window.closeAccountModal();
            });

            <?php if ($modalFlag): ?>
            // 僅在子視窗內發起查詢／選取時自動重新開啟（一般訪問不彈出）
            window.openAccountModal();
            <?php endif; ?>
        })();
    </script>

    <script>
    // ===== 帳號層級管理 子視窗 =====
    (function initTierManager() {
        const TIER_API = 'account_tier_api.php';
        const tierModal = document.getElementById('tier-modal');
        const tierCard = document.getElementById('tier-modal-card');
        const tierListEl = document.getElementById('tier-list');
        if (!tierModal || !tierListEl) return;

        let tierData = [];
        let tierToastTimer = null;
        const TIER_ICON_PRESETS = ['fa-user','fa-medal','fa-crown','fa-shield-halved','fa-gem','fa-star','fa-fire','fa-bolt','fa-leaf','fa-dragon','fa-chess-king','fa-award'];
        const TIER_COLOR_PRESETS = ['#64748b','#0ea5e9','#10b981','#f59e0b','#f43f5e','#8b5cf6','#ec4899','#06b6d4','#6366f1','#84cc16'];

        function tierEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
        function safeColor(c) { return /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(c || '') ? c : '#64748b'; }
        function safeIcon(i) {
            let v = String(i || '').toLowerCase().replace(/[^a-z0-9\- ]/g, '').trim().replace(/\s+/g, ' ');
            if (!v) return 'fa-user';
            const map = { fas: 'fa-solid', far: 'fa-regular', fab: 'fa-brands' };
            let style = '', name = '';
            v.split(' ').forEach(function (tok) {
                if (tok === 'fa-solid' || tok === 'fa-regular' || tok === 'fa-brands') style = tok;
                else if (map[tok]) style = map[tok];
                else if (!name && /^fa-[a-z0-9-]+$/.test(tok)) name = tok;
            });
            if (!name) return 'fa-user';
            return (style && style !== 'fa-solid') ? (style + ' ' + name) : name;
        }
        function iconClass(i) { const s = safeIcon(i); return /^fa-(solid|regular|brands) /.test(s) ? s : ('fa-solid ' + s); }
        function tierBadge(t) {
            const color = safeColor(t.color), icon = iconClass(t.icon);
            return '<span style="display:inline-flex;align-items:center;gap:.3rem;padding:.1rem .55rem;border-radius:9999px;font-size:11px;font-weight:700;line-height:1.4;color:' + color + ';background:' + color + '1a;border:1px solid ' + color + '4d;white-space:nowrap"><i class="' + icon + '" style="font-size:.85em"></i>' + tierEsc(t.name || '') + '</span>';
        }
        function tierToast(msg, ok) {
            const el = document.getElementById('tier-toast');
            if (!el) return;
            el.className = 'mx-5 sm:mx-6 mt-3 p-3 rounded-lg border text-xs flex items-center gap-2.5 ' + (ok ? 'border-emerald-200 bg-emerald-50 text-emerald-700' : 'border-rose-300 bg-rose-50 text-rose-700');
            el.innerHTML = '<i class="fa-solid ' + (ok ? 'fa-circle-check' : 'fa-circle-exclamation') + '"></i><span>' + tierEsc(msg) + '</span>';
            clearTimeout(tierToastTimer);
            tierToastTimer = setTimeout(() => el.classList.add('hidden'), 3800);
        }

        window.openTierModal = function () {
            tierModal.classList.remove('opacity-0', 'pointer-events-none');
            tierModal.classList.add('opacity-100');
            if (tierCard) { tierCard.classList.remove('scale-95'); tierCard.classList.add('scale-100'); }
            document.body.style.overflow = 'hidden';
            resetTierForm();
            loadTiers();
        };
        window.closeTierModal = function () {
            tierModal.classList.add('opacity-0', 'pointer-events-none');
            tierModal.classList.remove('opacity-100');
            if (tierCard) { tierCard.classList.remove('scale-100'); tierCard.classList.add('scale-95'); }
            document.body.style.overflow = '';
        };

        function loadTiers() {
            tierListEl.innerHTML = '<div class="py-10 text-center text-slate-400 text-sm"><i class="fa-solid fa-spinner fa-spin text-xl block mb-2"></i>載入中…</div>';
            fetch(TIER_API + '?action=list', { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(r => r.json()).then(d => {
                    if (!d || !d.ok) { tierListEl.innerHTML = '<div class="py-10 text-center text-rose-500 text-sm">載入失敗</div>'; return; }
                    tierData = d.tiers || [];
                    renderTiers();
                }).catch(() => { tierListEl.innerHTML = '<div class="py-10 text-center text-rose-500 text-sm">網路連線失敗</div>'; });
        }
        function renderTiers() {
            if (!tierData.length) { tierListEl.innerHTML = '<div class="py-10 text-center text-slate-400 text-sm">尚無層級，請於右側新增。</div>'; return; }
            tierListEl.innerHTML = tierData.map(t => {
                const on = Number(t.enabled) === 1;
                return '<div class="flex items-center gap-2 p-2.5 rounded-xl border ' + (on ? 'border-slate-200 bg-white' : 'border-slate-200 bg-slate-50 opacity-70') + '">'
                    + '<div class="shrink-0">' + tierBadge(t) + '</div>'
                    + '<div class="flex-1 min-w-0 text-[10px] text-slate-400 font-mono truncate">' + tierEsc(t.code) + ' · rank ' + Number(t.rank || 0) + ' · <span class="text-slate-500">' + Number(t.member_count || 0) + ' 人</span>' + (on ? '' : ' · 停用') + '</div>'
                    + '<button type="button" onclick="editTier(' + Number(t.id) + ')" class="shrink-0 px-2.5 py-1 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-[11px] font-semibold cursor-pointer">編輯</button>'
                    + '<button type="button" onclick="deleteTier(' + Number(t.id) + ')" class="shrink-0 px-2.5 py-1 rounded-lg border border-rose-300 bg-rose-50 text-rose-700 hover:bg-rose-100 text-[11px] font-semibold cursor-pointer">刪除</button>'
                    + '</div>';
            }).join('');
        }
        window.resetTierForm = function () {
            document.getElementById('tier-id').value = 0;
            document.getElementById('tier-name').value = '';
            document.getElementById('tier-code').value = '';
            document.getElementById('tier-icon').value = 'fa-user';
            document.getElementById('tier-color').value = '#64748b';
            document.getElementById('tier-color-text').value = '#64748b';
            document.getElementById('tier-rank').value = 0;
            document.getElementById('tier-sort').value = 0;
            document.getElementById('tier-desc').value = '';
            document.getElementById('tier-enabled').checked = true;
            document.getElementById('tier-form-title').textContent = '新增層級';
            updateTierPreview();
        };
        window.editTier = function (id) {
            const t = tierData.find(x => Number(x.id) === Number(id));
            if (!t) return;
            document.getElementById('tier-id').value = t.id;
            document.getElementById('tier-name').value = t.name || '';
            document.getElementById('tier-code').value = t.code || '';
            document.getElementById('tier-icon').value = safeIcon(t.icon);
            const color = safeColor(t.color);
            document.getElementById('tier-color').value = color;
            document.getElementById('tier-color-text').value = color;
            document.getElementById('tier-rank').value = Number(t.rank || 0);
            document.getElementById('tier-sort').value = Number(t.sort_order || 0);
            document.getElementById('tier-desc').value = t.description || '';
            document.getElementById('tier-enabled').checked = Number(t.enabled) === 1;
            document.getElementById('tier-form-title').textContent = '編輯層級 #' + t.id;
            updateTierPreview();
        };
        window.deleteTier = function (id) {
            const t = tierData.find(x => Number(x.id) === Number(id));
            if (!confirm('確定刪除層級「' + (t ? t.name : id) + '」？相關會員將回到預設層級。')) return;
            const body = new URLSearchParams({ action: 'delete', id: String(id), form_token: GM_FORM_TOKEN });
            fetch(TIER_API, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
                .then(r => r.json()).then(d => { tierToast((d && d.message) || (d && d.ok ? '已刪除' : '刪除失敗'), !!(d && d.ok)); if (d && d.ok) loadTiers(); })
                .catch(() => tierToast('網路連線失敗', false));
        };
        window.pickTierIcon = function (ic) { document.getElementById('tier-icon').value = ic; updateTierPreview(); };
        window.pickTierColor = function (c) { document.getElementById('tier-color').value = c; document.getElementById('tier-color-text').value = c; updateTierPreview(); };
        function updateTierPreview() {
            const el = document.getElementById('tier-preview');
            if (el) el.innerHTML = tierBadge({ name: document.getElementById('tier-name').value || '層級預覽', icon: document.getElementById('tier-icon').value, color: document.getElementById('tier-color-text').value || document.getElementById('tier-color').value });
            const cur = document.getElementById('tier-icon-current');
            if (cur) {
                const v = document.getElementById('tier-icon').value;
                cur.innerHTML = '<i class="' + iconClass(v) + '" style="color:#7c3aed"></i> <code class="text-slate-500">' + tierEsc(v) + '</code>';
            }
        }
        window.saveTier = function (e) {
            e.preventDefault();
            const id = parseInt(document.getElementById('tier-id').value || '0', 10);
            const body = new URLSearchParams({
                action: 'save', form_token: GM_FORM_TOKEN, id: String(id),
                name: document.getElementById('tier-name').value,
                code: document.getElementById('tier-code').value,
                icon: document.getElementById('tier-icon').value,
                color: document.getElementById('tier-color-text').value || document.getElementById('tier-color').value,
                rank: document.getElementById('tier-rank').value,
                sort_order: document.getElementById('tier-sort').value,
                description: document.getElementById('tier-desc').value,
                enabled: document.getElementById('tier-enabled').checked ? '1' : '0'
            });
            fetch(TIER_API, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body.toString() })
                .then(r => r.json()).then(d => {
                    if (d && d.ok) { tierToast(d.message || '已儲存', true); resetTierForm(); loadTiers(); }
                    else { const errs = d && d.errors ? Object.values(d.errors).join('；') : ''; tierToast(((d && d.message) || '儲存失敗') + (errs ? ('：' + errs) : ''), false); }
                }).catch(() => tierToast('網路連線失敗', false));
            return false;
        };

        // 預設圖示／顏色按鈕
        const ip = document.getElementById('tier-icon-presets');
        if (ip) ip.innerHTML = TIER_ICON_PRESETS.map(ic => '<button type="button" onclick="pickTierIcon(\'' + ic + '\')" class="w-7 h-7 rounded-lg border border-slate-200 hover:border-violet-400 hover:bg-violet-50 text-slate-600 flex items-center justify-center text-xs cursor-pointer" title="' + ic + '"><i class="fa-solid ' + ic + '"></i></button>').join('');
        const cp = document.getElementById('tier-color-presets');
        if (cp) cp.innerHTML = TIER_COLOR_PRESETS.map(c => '<button type="button" onclick="pickTierColor(\'' + c + '\')" class="w-6 h-6 rounded-full border border-white shadow cursor-pointer" style="background:' + c + '" title="' + c + '"></button>').join('');

        ['tier-name', 'tier-icon', 'tier-color-text'].forEach(function (id) { const el = document.getElementById(id); if (el) el.addEventListener('input', updateTierPreview); });
        const colorEl = document.getElementById('tier-color');
        if (colorEl) colorEl.addEventListener('input', function () { document.getElementById('tier-color-text').value = this.value; updateTierPreview(); });

        tierModal.addEventListener('click', function (e) { if (e.target === tierModal) closeTierModal(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && tierModal.classList.contains('opacity-100')) closeTierModal(); });

        /* ===== 圖示選擇器 ===== */
        const iconModal = document.getElementById('icon-picker-modal');
        const iconCard = document.getElementById('icon-picker-card');
        const iconGrid = document.getElementById('icon-grid');
        const iconSearch = document.getElementById('icon-search');
        const iconCustom = document.getElementById('icon-custom');
        let iconStyle = 'fa-solid';
        let iconCat = 'all';

        const ICON_CATS = [
            { k: 'all', label: '全部' },
            { k: 'member', label: '會員' },
            { k: 'game', label: '遊戲' },
            { k: 'money', label: '金錢' },
            { k: 'comm', label: '通訊' },
            { k: 'status', label: '狀態' },
            { k: 'media', label: '媒體' },
            { k: 'misc', label: '其他' },
            { k: 'brands', label: '品牌' }
        ];
        const ICON_LIB = [
            ['fa-user','member'],['fa-user-tie','member'],['fa-user-shield','member'],['fa-user-gear','member'],['fa-user-ninja','member'],['fa-user-plus','member'],['fa-users','member'],['fa-user-group','member'],['fa-people-group','member'],['fa-id-badge','member'],['fa-id-card','member'],['fa-address-card','member'],['fa-crown','member'],['fa-medal','member'],['fa-award','member'],['fa-trophy','member'],['fa-star','member'],['fa-gem','member'],['fa-fire','member'],['fa-chess-king','member'],['fa-chess-queen','member'],['fa-chess','member'],['fa-shield-halved','member'],['fa-ranking-star','member'],['fa-certificate','member'],['fa-handshake','member'],['fa-heart','member'],['fa-heart-pulse','member'],['fa-dragon','member'],['fa-dove','member'],['fa-crow','member'],['fa-cat','member'],['fa-dog','member'],['fa-fish','member'],['fa-spider','member'],['fa-horse','member'],['fa-feather','member'],['fa-leaf','member'],['fa-tree','member'],['fa-seedling','member'],['fa-mountain-sun','member'],['fa-snowflake','member'],['fa-meteor','member'],
            ['fa-gamepad','game'],['fa-dice','game'],['fa-dice-d20','game'],['fa-dice-d6','game'],['fa-dice-five','game'],['fa-chess-board','game'],['fa-chess-knight','game'],['fa-chess-rook','game'],['fa-chess-pawn','game'],['fa-chess-bishop','game'],['fa-khanda','game'],['fa-wand-magic-sparkles','game'],['fa-hat-wizard','game'],['fa-broom','game'],['fa-ghost','game'],['fa-bolt','game'],['fa-fire-flame-curved','game'],['fa-explosion','game'],['fa-splotch','game'],['fa-shield','game'],['fa-skull','game'],['fa-crosshairs','game'],['fa-bullseye','game'],['fa-wand-sparkles','game'],['fa-magic','game'],
            ['fa-coins','money'],['fa-sack-dollar','money'],['fa-sack-xmark','money'],['fa-dollar-sign','money'],['fa-money-bill','money'],['fa-money-bill-wave','money'],['fa-money-bill-1','money'],['fa-wallet','money'],['fa-piggy-bank','money'],['fa-credit-card','money'],['fa-vault','money'],['fa-chart-line','money'],['fa-chart-column','money'],['fa-chart-pie','money'],['fa-hand-holding-dollar','money'],['fa-receipt','money'],['fa-tags','money'],['fa-tag','money'],['fa-bag-shopping','money'],['fa-cart-shopping','money'],['fa-store','money'],['fa-scale-balanced','money'],['fa-money-check-dollar','money'],
            ['fa-envelope','comm'],['fa-envelope-open','comm'],['fa-comment','comm'],['fa-comments','comm'],['fa-comment-dots','comm'],['fa-comment-sms','comm'],['fa-bell','comm'],['fa-bullhorn','comm'],['fa-phone','comm'],['fa-mobile-screen','comm'],['fa-paper-plane','comm'],['fa-inbox','comm'],['fa-at','comm'],['fa-headset','comm'],['fa-microphone','comm'],['fa-tower-broadcast','comm'],['fa-tower-cell','comm'],['fa-satellite-dish','comm'],['fa-wifi','comm'],['fa-signal','comm'],
            ['fa-circle-check','status'],['fa-circle-xmark','status'],['fa-circle-exclamation','status'],['fa-circle-info','status'],['fa-circle-question','status'],['fa-circle-plus','status'],['fa-circle-minus','status'],['fa-triangle-exclamation','status'],['fa-ban','status'],['fa-lock','status'],['fa-unlock','status'],['fa-key','status'],['fa-thumbs-up','status'],['fa-thumbs-down','status'],['fa-flag','status'],['fa-bookmark','status'],['fa-clipboard-check','status'],['fa-clipboard-list','status'],['fa-list-check','status'],['fa-check','status'],['fa-xmark','status'],['fa-eye','status'],['fa-eye-slash','status'],['fa-clock','status'],['fa-hourglass-half','status'],['fa-hourglass','status'],['fa-calendar-check','status'],['fa-calendar-day','status'],['fa-calendar-days','status'],['fa-infinity','status'],['fa-power-off','status'],['fa-star-half-stroke','status'],
            ['fa-image','media'],['fa-camera','media'],['fa-video','media'],['fa-music','media'],['fa-film','media'],['fa-photo-film','media'],['fa-play','media'],['fa-pause','media'],['fa-circle-play','media'],['fa-headphones','media'],['fa-volume-high','media'],['fa-pen','media'],['fa-pen-nib','media'],['fa-pen-to-square','media'],['fa-paintbrush','media'],['fa-palette','media'],['fa-brush','media'],['fa-icons','media'],['fa-clapperboard','media'],
            ['fa-download','misc'],['fa-upload','misc'],['fa-cloud','misc'],['fa-cloud-arrow-down','misc'],['fa-cloud-arrow-up','misc'],['fa-database','misc'],['fa-server','misc'],['fa-microchip','misc'],['fa-gear','misc'],['fa-gears','misc'],['fa-sliders','misc'],['fa-wrench','misc'],['fa-screwdriver-wrench','misc'],['fa-hammer','misc'],['fa-toolbox','misc'],['fa-cube','misc'],['fa-cubes','misc'],['fa-box','misc'],['fa-boxes-stacked','misc'],['fa-folder','misc'],['fa-folder-open','misc'],['fa-file','misc'],['fa-file-lines','misc'],['fa-clipboard','misc'],['fa-link','misc'],['fa-paperclip','misc'],['fa-share','misc'],['fa-arrow-up-right-from-square','misc'],['fa-code','misc'],['fa-terminal','misc'],['fa-robot','misc'],['fa-bug','misc'],['fa-magnifying-glass','misc'],['fa-compass','misc'],['fa-map','misc'],['fa-map-location-dot','misc'],['fa-location-dot','misc'],['fa-house','misc'],['fa-building','misc'],['fa-city','misc'],['fa-car','misc'],['fa-rocket','misc'],['fa-plane','misc'],['fa-ship','misc'],['fa-anchor','misc'],['fa-book','misc'],['fa-book-open','misc'],['fa-graduation-cap','misc'],['fa-lightbulb','misc'],['fa-sun','misc'],['fa-moon','misc'],['fa-cloud-sun','misc'],['fa-wind','misc'],['fa-water','misc'],['fa-earth-asia','misc'],['fa-globe','misc'],
            ['fa-github','brands'],['fa-google','brands'],['fa-facebook','brands'],['fa-instagram','brands'],['fa-twitter','brands'],['fa-youtube','brands'],['fa-discord','brands'],['fa-twitch','brands'],['fa-steam','brands'],['fa-apple','brands'],['fa-android','brands'],['fa-windows','brands'],['fa-linux','brands'],['fa-chrome','brands'],['fa-firefox','brands'],['fa-edge','brands'],['fa-safari','brands'],['fa-paypal','brands'],['fa-cc-visa','brands'],['fa-cc-mastercard','brands'],['fa-bitcoin','brands'],['fa-ethereum','brands'],['fa-aws','brands'],['fa-docker','brands'],['fa-node-js','brands'],['fa-php','brands'],['fa-js','brands'],['fa-python','brands'],['fa-java','brands'],['fa-react','brands'],['fa-vuejs','brands'],['fa-angular','brands'],['fa-wordpress','brands'],['fa-shopify','brands'],['fa-telegram','brands'],['fa-line','brands'],['fa-weixin','brands'],['fa-weibo','brands'],['fa-qq','brands'],['fa-tiktok','brands'],
            /* ===== 擴充圖示庫 ===== */
            ['fa-user-astronaut','member'],['fa-user-check','member'],['fa-user-clock','member'],['fa-user-doctor','member'],['fa-user-graduate','member'],['fa-user-injured','member'],['fa-user-large','member'],['fa-user-lock','member'],['fa-user-minus','member'],['fa-user-pen','member'],['fa-user-secret','member'],['fa-user-slash','member'],['fa-user-xmark','member'],['fa-users-gear','member'],['fa-users-rectangle','member'],['fa-users-viewfinder','member'],['fa-person','member'],['fa-person-dress','member'],['fa-person-half-dress','member'],['fa-person-hiking','member'],['fa-person-praying','member'],['fa-person-running','member'],['fa-person-skating','member'],['fa-person-skiing','member'],['fa-person-snowboarding','member'],['fa-person-swimming','member'],['fa-person-walking','member'],['fa-person-dots-from-line','member'],['fa-people-line','member'],['fa-people-pulling','member'],['fa-people-roof','member'],['fa-baby','member'],['fa-baby-carriage','member'],['fa-child','member'],['fa-child-reaching','member'],['fa-id-card-clip','member'],['fa-address-book','member'],['fa-shield-heart','member'],['fa-handshake-angle','member'],['fa-handshake-simple','member'],['fa-heart-crack','member'],['fa-horse-head','member'],['fa-feather-pointed','member'],['fa-fish-fins','member'],['fa-paw','member'],['fa-venus','member'],['fa-mars','member'],['fa-genderless','member'],['fa-snowman','member'],['fa-face-smile','member'],['fa-face-grin-stars','member'],['fa-face-laugh-beam','member'],['fa-face-sad-tear','member'],['fa-face-angry','member'],['fa-face-surprise','member'],['fa-face-meh','member'],['fa-face-grin-hearts','member'],
            ['fa-dice-four','game'],['fa-dice-one','game'],['fa-dice-six','game'],['fa-dice-three','game'],['fa-dice-two','game'],['fa-wand-magic','game'],['fa-broom-ball','game'],['fa-bolt-lightning','game'],['fa-fire-flame-simple','game'],['fa-skull-crossbones','game'],['fa-dungeon','game'],['fa-hippo','game'],['fa-otter','game'],['fa-frog','game'],['fa-book-skull','game'],['fa-scroll','game'],['fa-shield-cat','game'],['fa-shield-dog','game'],['fa-gun','game'],['fa-bomb','game'],['fa-hand-fist','game'],['fa-hand-sparkles','game'],['fa-torii-gate','game'],['fa-d-and-d','game'],
            ['fa-money-bill-1-wave','money'],['fa-money-bill-transfer','money'],['fa-money-bill-trend-up','money'],['fa-money-bill-wheat','money'],['fa-money-bills','money'],['fa-money-check','money'],['fa-money-check-dollar','money'],['fa-chart-simple','money'],['fa-chart-area','money'],['fa-chart-bar','money'],['fa-chart-gantt','money'],['fa-hand-holding-heart','money'],['fa-cart-plus','money'],['fa-scale-unbalanced','money'],['fa-gift','money'],['fa-box-open','money'],['fa-truck-fast','money'],['fa-barcode','money'],['fa-qrcode','money'],['fa-file-invoice','money'],['fa-file-invoice-dollar','money'],['fa-landmark','money'],['fa-building-columns','money'],['fa-hand-holding-dollar','money'],['fa-store','money'],['fa-tags','money'],['fa-bag-shopping','money'],['fa-cart-shopping','money'],['fa-receipt','money'],
            ['fa-envelope-circle-check','comm'],['fa-envelope-open-text','comm'],['fa-comment-dollar','comm'],['fa-comment-medical','comm'],['fa-comment-nodes','comm'],['fa-comment-slash','comm'],['fa-message','comm'],['fa-messages','comm'],['fa-mail-bulk','comm'],['fa-bell-concierge','comm'],['fa-bell-slash','comm'],['fa-phone-volume','comm'],['fa-phone-flip','comm'],['fa-phone-slash','comm'],['fa-mobile-screen-button','comm'],['fa-microphone-lines','comm'],['fa-microphone-slash','comm'],['fa-tower-observation','comm'],['fa-satellite','comm'],['fa-rss','comm'],['fa-podcast','comm'],['fa-bullhorn','comm'],['fa-headset','comm'],['fa-paper-plane','comm'],['fa-at','comm'],['fa-inbox','comm'],
            ['fa-circle-up','status'],['fa-circle-down','status'],['fa-circle-pause','status'],['fa-circle-stop','status'],['fa-unlock-keyhole','status'],['fa-flag-checkered','status'],['fa-check-double','status'],['fa-check-to-slot','status'],['fa-square-check','status'],['fa-square-xmark','status'],['fa-square-plus','status'],['fa-square-minus','status'],['fa-eye-low-vision','status'],['fa-clock-rotate-left','status'],['fa-hourglass-start','status'],['fa-hourglass-end','status'],['fa-calendar-plus','status'],['fa-calendar-xmark','status'],['fa-heart-circle-check','status'],['fa-heart-circle-xmark','status'],['fa-fingerprint','status'],['fa-shield-halved','status'],['fa-ban','status'],['fa-lock','status'],['fa-unlock','status'],['fa-key','status'],['fa-thumbs-up','status'],['fa-thumbs-down','status'],['fa-flag','status'],['fa-bookmark','status'],['fa-eye','status'],['fa-eye-slash','status'],['fa-clock','status'],['fa-infinity','status'],['fa-power-off','status'],
            ['fa-images','media'],['fa-camera-retro','media'],['fa-clapperboard','media'],['fa-headphones-simple','media'],['fa-volume-low','media'],['fa-volume-off','media'],['fa-volume-xmark','media'],['fa-stop','media'],['fa-forward','media'],['fa-backward','media'],['fa-circle-pause','media'],['fa-circle-stop','media'],['fa-pen-fancy','media'],['fa-pen-clip','media'],['fa-paint-roller','media'],['fa-signature','media'],['fa-eraser','media'],['fa-highlighter','media'],['fa-marker','media'],['fa-file-audio','media'],['fa-file-video','media'],['fa-file-image','media'],['fa-compact-disc','media'],['fa-record-vinyl','media'],['fa-radio','media'],['fa-tv','media'],['fa-desktop','media'],['fa-laptop','media'],['fa-tablet','media'],['fa-mobile','media'],
            ['fa-cloud-bolt','misc'],['fa-cloud-moon','misc'],['fa-cloud-showers-heavy','misc'],['fa-hard-drive','misc'],['fa-memory','misc'],['fa-screwdriver','misc'],['fa-boxes-packing','misc'],['fa-folder-plus','misc'],['fa-folder-minus','misc'],['fa-file-code','misc'],['fa-file-csv','misc'],['fa-file-excel','misc'],['fa-file-pdf','misc'],['fa-file-word','misc'],['fa-file-zipper','misc'],['fa-link-slash','misc'],['fa-share-nodes','misc'],['fa-share-from-square','misc'],['fa-code-branch','misc'],['fa-code-commit','misc'],['fa-magnifying-glass-chart','misc'],['fa-compass-drafting','misc'],['fa-map-location','misc'],['fa-location-crosshairs','misc'],['fa-house-chimney','misc'],['fa-house-chimney-window','misc'],['fa-car-side','misc'],['fa-taxi','misc'],['fa-bus','misc'],['fa-truck','misc'],['fa-plane-up','misc'],['fa-helicopter','misc'],['fa-bicycle','misc'],['fa-motorcycle','misc'],['fa-school','misc'],['fa-star-and-crescent','misc'],['fa-star-of-david','misc'],['fa-earth-americas','misc'],['fa-earth-europe','misc'],['fa-globe-oceania','misc'],['fa-binoculars','misc'],['fa-flask','misc'],['fa-vial','misc'],['fa-atom','misc'],['fa-dna','misc'],['fa-braille','misc'],['fa-language','misc'],['fa-font','misc'],['fa-text-height','misc'],['fa-paragraph','misc'],['fa-list','misc'],['fa-list-ul','misc'],['fa-list-ol','misc'],['fa-table','misc'],['fa-table-cells','misc'],['fa-th','misc'],['fa-th-large','misc'],['fa-bars','misc'],['fa-grip','misc'],['fa-grip-vertical','misc'],['fa-ellipsis','misc'],['fa-ellipsis-vertical','misc'],['fa-asterisk','misc'],['fa-diamond','misc'],['fa-puzzle-piece','misc'],['fa-shapes','misc'],['fa-layer-group','misc'],['fa-object-group','misc'],['fa-object-ungroup','misc'],['fa-vector-square','misc'],['fa-bezier-curve','misc'],['fa-swatchbook','misc'],['fa-ruler','misc'],['fa-ruler-combined','misc'],['fa-ruler-horizontal','misc'],['fa-ruler-vertical','misc'],['fa-crop','misc'],['fa-crop-simple','misc'],['fa-mask','misc'],['fa-masks-theater','misc'],['fa-hat-cowboy','misc'],['fa-glasses','misc'],['fa-shirt','misc'],['fa-vest','misc'],['fa-socks','misc'],['fa-shoe-prints','misc'],['fa-ring','misc'],['fa-suitcase','misc'],['fa-umbrella','misc'],['fa-dumpster-fire','misc'],['fa-trailer','misc'],['fa-warehouse','misc'],['fa-industry','misc'],['fa-factory','misc'],['fa-oil-well','misc'],['fa-staff-snake','misc'],['fa-syringe','misc'],['fa-pills','misc'],['fa-prescription-bottle','misc'],['fa-stethoscope','misc'],['fa-hospital','misc'],
            ['fa-gitlab','brands'],['fa-git-alt','brands'],['fa-bitbucket','brands'],['fa-jira','brands'],['fa-slack','brands'],['fa-figma','brands'],['fa-dropbox','brands'],['fa-google-drive','brands'],['fa-digital-ocean','brands'],['fa-cloudflare','brands'],['fa-ubuntu','brands'],['fa-redhat','brands'],['fa-fedora','brands'],['fa-npm','brands'],['fa-yarn','brands'],['fa-whatsapp','brands'],['fa-viber','brands'],['fa-skype','brands'],['fa-pinterest','brands'],['fa-linkedin','brands'],['fa-linkedin-in','brands'],['fa-reddit','brands'],['fa-reddit-alien','brands'],['fa-snapchat','brands'],['fa-tumblr','brands'],['fa-medium','brands'],['fa-quora','brands'],['fa-stack-overflow','brands'],['fa-hacker-news','brands'],['fa-product-hunt','brands'],['fa-dribbble','brands'],['fa-behance','brands'],['fa-flickr','brands'],['fa-vimeo','brands'],['fa-soundcloud','brands'],['fa-spotify','brands'],['fa-apple-pay','brands'],['fa-google-pay','brands'],['fa-cc-apple-pay','brands'],['fa-cc-paypal','brands'],['fa-cc-stripe','brands'],['fa-stripe','brands'],['fa-stripe-s','brands'],['fa-amazon','brands'],['fa-amazon-pay','brands'],['fa-ebay','brands'],['fa-airbnb','brands'],['fa-uber','brands'],['fa-yahoo','brands'],['fa-yandex','brands'],['fa-opera','brands'],['fa-internet-explorer','brands'],['fa-battle-net','brands'],['fa-xbox','brands'],['fa-playstation','brands'],['fa-unity','brands'],['fa-d-and-d-beyond','brands'],['fa-fantasy-flight-games','brands'],['fa-critical-role','brands'],['fa-wizards-of-the-coast','brands'],['fa-jedi','brands'],['fa-jedi-order','brands'],['fa-galactic-republic','brands'],['fa-galactic-senate','brands'],['fa-rebel','brands'],['fa-empire','brands'],['fa-old-republic','brands'],['fa-mandalorian','brands'],['fa-sith','brands'],['fa-swift','brands'],['fa-sass','brands'],['fa-less','brands'],['fa-bootstrap','brands'],['fa-css3','brands'],['fa-css3-alt','brands'],['fa-html5','brands'],['fa-square-js','brands'],['fa-golang','brands'],['fa-rust','brands']
        ];

        window.openIconPicker = function () {
            if (!iconModal) return;
            const cur = safeIcon(document.getElementById('tier-icon').value);
            iconStyle = /^fa-brands /.test(cur) ? 'fa-brands' : (/^fa-regular /.test(cur) ? 'fa-regular' : 'fa-solid');
            iconCat = 'all';
            if (iconSearch) iconSearch.value = '';
            if (iconCustom) iconCustom.value = document.getElementById('tier-icon').value || '';
            updateIconStyleTabs();
            renderIconCats();
            renderIconGrid();
            iconModal.classList.remove('opacity-0', 'pointer-events-none');
            iconModal.classList.add('opacity-100');
            if (iconCard) { iconCard.classList.remove('scale-95'); iconCard.classList.add('scale-100'); }
        };
        window.closeIconPicker = function () {
            if (!iconModal) return;
            iconModal.classList.add('opacity-0', 'pointer-events-none');
            iconModal.classList.remove('opacity-100');
            if (iconCard) { iconCard.classList.remove('scale-100'); iconCard.classList.add('scale-95'); }
        };
        function updateIconStyleTabs() {
            document.querySelectorAll('#icon-style-tabs .icon-style-btn').forEach(function (b) {
                const on = b.getAttribute('data-style') === iconStyle;
                b.className = 'icon-style-btn px-3 py-1.5 rounded-md font-semibold cursor-pointer ' + (on ? 'bg-violet-600 text-white' : 'text-slate-600 hover:bg-white');
            });
        }
        function renderIconCats() {
            const el = document.getElementById('icon-cat-chips');
            if (!el) return;
            el.innerHTML = ICON_CATS.map(function (c) {
                const on = iconCat === c.k;
                return '<button type="button" data-cat="' + c.k + '" class="icon-cat-chip px-2.5 py-1 rounded-full border text-[11px] font-semibold cursor-pointer ' + (on ? 'border-violet-400 bg-violet-50 text-violet-700' : 'border-slate-200 bg-white text-slate-500 hover:border-slate-300') + '">' + c.label + '</button>';
            }).join('');
        }
        function renderIconGrid() {
            if (!iconGrid) return;
            const q = (iconSearch ? iconSearch.value : '').trim().toLowerCase();
            const list = ICON_LIB.filter(function (it) {
                if (iconCat !== 'all' && it[1] !== iconCat) return false;
                if (q && it[0].indexOf(q) < 0) return false;
                return true;
            });
            const empty = document.getElementById('icon-empty');
            if (!list.length) { iconGrid.innerHTML = ''; if (empty) empty.classList.remove('hidden'); return; }
            if (empty) empty.classList.add('hidden');
            const curName = safeIcon(document.getElementById('tier-icon').value).split(' ').pop();
            iconGrid.innerHTML = list.map(function (it) {
                const cls = (iconStyle === 'fa-solid') ? ('fa-solid ' + it[0]) : (iconStyle + ' ' + it[0]);
                const active = (it[0] === curName) ? ' is-active' : '';
                return '<button type="button" class="acct-icon-cell' + active + '" data-icon="' + it[0] + '" title="' + it[0] + '"><i class="' + cls + '"></i><span>' + it[0] + '</span></button>';
            }).join('');
        }
        window.pickTierIconFromPicker = function (name) {
            const cls = (iconStyle === 'fa-solid') ? name : (iconStyle + ' ' + name);
            document.getElementById('tier-icon').value = cls;
            updateTierPreview();
            closeIconPicker();
        };
        window.applyCustomIcon = function () {
            const raw = (iconCustom ? iconCustom.value : '').trim().toLowerCase();
            if (!raw) return;
            let style = '';
            if (/\bfa-brands\b/.test(raw)) style = 'fa-brands';
            else if (/\bfa-regular\b/.test(raw)) style = 'fa-regular';
            else if (/\bfa-solid\b/.test(raw)) style = 'fa-solid';
            const names = raw.match(/fa-[a-z0-9-]+/g) || [];
            let name = '';
            names.forEach(function (n) { if (n !== 'fa-solid' && n !== 'fa-regular' && n !== 'fa-brands') name = n; });
            if (!name) { tierToast('請輸入有效的圖示代碼，例如 fa-solid fa-dragon。', false); return; }
            const eff = style || iconStyle;
            document.getElementById('tier-icon').value = (eff && eff !== 'fa-solid') ? (eff + ' ' + name) : name;
            updateTierPreview();
            closeIconPicker();
        };

        if (iconGrid) iconGrid.addEventListener('click', function (e) {
            const cell = e.target.closest('.acct-icon-cell');
            if (cell) { window.pickTierIconFromPicker(cell.getAttribute('data-icon')); }
        });
        if (iconSearch) iconSearch.addEventListener('input', renderIconGrid);
        const iconCatEl = document.getElementById('icon-cat-chips');
        if (iconCatEl) iconCatEl.addEventListener('click', function (e) {
            const chip = e.target.closest('.icon-cat-chip');
            if (chip) { iconCat = chip.getAttribute('data-cat'); renderIconCats(); renderIconGrid(); }
        });
        document.querySelectorAll('#icon-style-tabs .icon-style-btn').forEach(function (b) {
            b.addEventListener('click', function () { iconStyle = b.getAttribute('data-style'); updateIconStyleTabs(); renderIconGrid(); });
        });
        if (iconModal) iconModal.addEventListener('click', function (e) { if (e.target === iconModal) closeIconPicker(); });

        resetTierForm();
    })();
    </script>
</body>
</html>
