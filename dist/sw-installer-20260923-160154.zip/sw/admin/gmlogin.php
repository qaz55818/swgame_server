<?php
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../register_security.php';

if (isset($_SESSION['gm_username'])) {
    header("Location: gmpanel.php");
    exit();
}

if (!isset($_SESSION['gm_form_token'])) {
    $_SESSION['gm_form_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['gm_form_token'];

$errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $postedToken = (isset($_POST['form_token']) && is_string($_POST['form_token'])) ? $_POST['form_token'] : '';
    if ($postedToken === '' || !hash_equals((string)$_SESSION['gm_form_token'], $postedToken)) {
        $errorMessage = "你的工作階段已過期，請再試一次。";
    } else {
        unset($_SESSION['gm_form_token']);

        $username = strtolower(trim((string)($_POST['username'] ?? '')));
        $password = (string)($_POST['password'] ?? '');

        // 連線失敗不顯示內部錯誤
        $Link = null;
        try {
            $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
        } catch (Throwable $e) {
            $Link = null;
        }

        if (!$Link) {
            $errorMessage = "系統暫時無法使用，請稍後再試。";
        } else {
            mysqli_set_charset($Link, 'utf8');
            $ip = register_client_ip($Link);

            // 後台登入入口限流（滑動視窗，資料庫原子計數）：15 分鐘
            $window = 900;
            $maxIp = 20;
            $maxAcct = 8;
            $ipHits = register_hit($Link, 'gm_login_ip', $ip, $window);
            $acctHits = register_hit($Link, 'gm_login_account', $username, $window);

            if ($ipHits > $maxIp || $acctHits > $maxAcct) {
                register_admin_log($Link, $username, 'gm_login_blocked', $username, 'rate_limited; ip_hits=' . $ipHits, $ip);
                $errorMessage = "嘗試次數過多，基於安全考量請於 15 分鐘後再試。";
            } else {
                $row = null;
                try {
                    $stmt = $Link->prepare("SELECT id, username, password_hash FROM gm_accounts WHERE username = ? LIMIT 1");
                    $stmt->bind_param("s", $username);
                    $stmt->execute();
                    $result = $stmt->get_result();
                    if ($result->num_rows === 1) {
                        $row = $result->fetch_assoc();
                    }
                    $stmt->close();
                } catch (Throwable $e) {
                    $row = null;
                }

                if ($row && !empty($row['password_hash']) && password_verify($password, (string)$row['password_hash'])) {
                    register_admin_log($Link, (string)$row['username'], 'gm_login', (string)$row['username'], 'success', $ip);
                    mysqli_close($Link);
                    session_regenerate_id(true);
                    $_SESSION['gm_username'] = $row['username'];
                    $_SESSION['gm_id'] = $row['id'];
                    header("Location: gmpanel.php");
                    exit();
                }

                register_admin_log($Link, $username, 'gm_login_failed', $username, 'invalid_credentials', $ip);
                usleep(400000);
                $errorMessage = "使用者名稱或密碼不正確。";
            }
            mysqli_close($Link);
        }

        $_SESSION['gm_form_token'] = bin2hex(random_bytes(32));
        $formToken = $_SESSION['gm_form_token'];
    }
}
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · GM 管理後台登入</title>
    <!-- Tailwind 樣式：編譯後靜態檔（不再使用 CDN） -->
    <link rel="stylesheet" href="assets/gmlogin-tailwind.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@400;600;700;900&family=Noto+Sans+TC:wght@300;400;500;700&family=Cinzel:wght@600;700&display=swap" rel="stylesheet">
    <!-- Google Material Symbols -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <style>
        /* 基礎平滑滾動與字體平滑 */
        body {
            font-family: 'Noto Sans TC', sans-serif;
            background-color: #f1f5f9;
            color: #1e293b;
            min-height: 100vh;
            overflow-x: hidden;
            position: relative;
        }

        /* 典雅雪景水墨大氣底色與微紋理 */
        .snow-bg {
            background: 
                radial-gradient(circle at 50% 18%, rgba(224, 242, 254, 0.75) 0%, rgba(241, 245, 249, 0.95) 60%, #e2e8f0 100%);
        }

        /* 水墨山峰遠景裝飾線條 */
        .ink-mountain-glow {
            background-image: 
                radial-gradient(ellipse 900px 380px at 50% -50px, rgba(186, 230, 253, 0.45), transparent 70%),
                radial-gradient(circle at 10% 20%, rgba(244, 63, 94, 0.05), transparent 40%);
        }

        /* 羊脂白玉雙層微光卡片 */
        .jade-card {
            background: rgba(255, 255, 255, 0.94);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(226, 232, 240, 0.95);
            box-shadow: 
                0 4px 6px -1px rgba(15, 23, 42, 0.03),
                0 20px 40px -10px rgba(15, 23, 42, 0.08),
                inset 0 1px 0 rgba(255, 255, 255, 0.9),
                inset 0 0 0 1px rgba(255, 255, 255, 0.6);
            position: relative;
        }

        /* 雙層角隅金石裝飾 (遵循踏雪笑傲組件庫) */
        .corner-decor-tr {
            position: absolute;
            top: 0;
            right: 0;
            width: 24px;
            height: 24px;
            border-top: 2px solid #9f1239;
            border-right: 2px solid #9f1239;
            border-top-right-radius: 8px;
            pointer-events: none;
        }
        .corner-decor-bl {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 24px;
            height: 24px;
            border-bottom: 2px solid #0284c7;
            border-left: 2px solid #0284c7;
            border-bottom-left-radius: 8px;
            pointer-events: none;
        }

        /* 硃砂印章標記 */
        .cinnabar-seal {
            border: 1.5px solid #9f1239;
            color: #9f1239;
            font-family: 'Noto Serif TC', serif;
            font-weight: 700;
            letter-spacing: 1px;
            padding: 1px 5px;
            border-radius: 2px;
            display: inline-block;
            box-shadow: inset 0 0 4px rgba(159, 18, 57, 0.15);
        }

        /* 水墨漸層分隔線 */
        .ink-divider {
            height: 1.5px;
            background: linear-gradient(90deg, transparent 0%, rgba(15, 23, 42, 0.08) 20%, rgba(159, 18, 57, 0.4) 50%, rgba(15, 23, 42, 0.08) 80%, transparent 100%);
        }

        /* 輸入框水墨白玉風格 */
        .input-jade {
            background-color: #ffffff;
            border: 1px solid #cbd5e1;
            transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .input-jade:focus {
            outline: none;
            border-color: #9f1239;
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(159, 18, 57, 0.12);
        }

        /* 硃砂紅主按鈕 */
        .btn-cinnabar {
            background: linear-gradient(135deg, #9f1239 0%, #881337 100%);
            border: 1px solid #9f1239;
            box-shadow: 0 4px 14px rgba(159, 18, 57, 0.28);
            transition: all 0.25s ease;
        }
        .btn-cinnabar:hover {
            background: linear-gradient(135deg, #be123c 0%, #9f1239 100%);
            box-shadow: 0 6px 20px rgba(159, 18, 57, 0.4);
            transform: translateY(-1px);
        }
        .btn-cinnabar:active {
            transform: translateY(0);
            box-shadow: 0 2px 8px rgba(159, 18, 57, 0.25);
        }

        /* 水墨微端飄雪畫布 */
        #snow-canvas {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 1;
            transform: translateZ(0); /* 硬體加速防閃爍 */
        }
    </style>
</head>
<body class="snow-bg ink-mountain-glow flex flex-col justify-between min-h-screen">
    <!-- GPU 硬體加速 Canvas 飄雪背景 (無閃爍優化版) -->
    <canvas id="snow-canvas"></canvas>

    <!-- 頂部精緻簡約導覽工具列 -->
    <header class="relative z-10 w-full px-6 py-4 flex items-center justify-between border-b border-slate-200/80 bg-white/60 backdrop-blur-md">
        <div class="flex items-center gap-3">
            <a href="../index.php" class="flex items-center gap-2 group" title="返回官網首頁">
                <div class="w-8 h-8 rounded-full bg-slate-900 text-white flex items-center justify-center font-serif text-sm font-bold border border-slate-700 shadow-sm group-hover:border-brand-crimson transition-colors">
                    雪
                </div>
                <div class="flex flex-col">
                    <span class="font-serif font-black text-slate-900 tracking-wider text-sm flex items-center gap-1.5">
                        踏雪笑傲
                        <span class="cinnabar-seal text-[10px] leading-tight font-normal">正版</span>
                    </span>
                    <span class="text-[9px] text-slate-600 tracking-widest font-cinzel uppercase">Snow Wanderer Online</span>
                </div>
            </a>
            <div class="h-4 w-px bg-slate-300 mx-1 hidden sm:block"></div>
            <span class="text-xs font-serif text-slate-700 hidden sm:inline-flex items-center gap-1">
                <span class="material-symbols-outlined text-[15px] text-brand-crimson">shield_person</span>
                系統管理後台
            </span>
        </div>

        <div class="flex items-center gap-4 text-xs">
            <div class="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="font-medium tracking-wide">管理授權節點 · 連線正常</span>
            </div>
            <a href="../index.php" class="flex items-center gap-1 text-slate-600 hover:text-brand-crimson transition-colors font-medium">
                <span class="material-symbols-outlined text-sm">arrow_back</span>
                <span>返回官網</span>
            </a>
        </div>
    </header>

    <!-- 主內容區：置中登入卡片 -->
    <main class="relative z-10 flex-1 flex items-center justify-center px-4 py-10">
        <div class="w-full max-w-[440px]">
            <!-- 頂部徽飾與標題 -->
            <div class="text-center mb-6">
                <!-- 意境徽章圖示 -->
                <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white border border-slate-200 shadow-md mb-3 relative group">
                    <div class="absolute inset-0 bg-gradient-to-br from-brand-crimson/5 to-transparent rounded-2xl"></div>
                    <span class="material-symbols-outlined text-3xl text-brand-crimson select-none">admin_panel_settings</span>
                    <!-- 微裝飾角 -->
                    <span class="absolute -top-1 -right-1 w-2.5 h-2.5 border-t-2 border-r-2 border-brand-crimson rounded-tr"></span>
                    <span class="absolute -bottom-1 -left-1 w-2.5 h-2.5 border-b-2 border-l-2 border-brand-frost rounded-bl"></span>
                </div>

                <h1 class="font-serif font-bold text-2xl text-slate-900 tracking-wide flex items-center justify-center gap-2">
                    管理員身分驗證
                    <span class="cinnabar-seal text-xs font-normal">密令</span>
                </h1>
                <p class="text-xs text-slate-700 tracking-wider mt-1.5 font-medium">
                    踏雪笑傲 · 伺服器營運管理控制核心
                </p>
                
                <!-- 水墨漸層分隔線 -->
                <div class="ink-divider w-44 mx-auto mt-4"></div>
            </div>

            <!-- 白玉雙層精雕登入面板 -->
            <div class="jade-card rounded-2xl p-7 sm:p-8">
                <!-- 角隅古典裝飾線 -->
                <div class="corner-decor-tr"></div>
                <div class="corner-decor-bl"></div>

                <!-- 錯誤訊息提示容器 (由 PHP $errorMessage 控制顯示) -->
                <div id="errorMessageContainer" class="<?php echo $errorMessage !== '' ? 'flex' : 'hidden'; ?> mb-5 p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-brand-crimson text-xs items-start gap-2.5 leading-relaxed shadow-sm">
                    <span class="material-symbols-outlined text-base flex-shrink-0 mt-0.5">error</span>
                    <div class="flex-1 font-medium" id="errorMessageText">
                        <?php echo htmlspecialchars($errorMessage !== '' ? $errorMessage : '使用者名稱或密碼不正確，請重新輸入。'); ?>
                    </div>
                </div>

                <!-- 後端 POST 表單：欄位 form_token, username, password -->
                <form id="gmLoginForm" method="POST" action="" class="space-y-5">
                    <!-- 安全性 CSRF 防偽 Token -->
                    <input type="hidden" name="form_token" id="formTokenInput" value="<?php echo htmlspecialchars($formToken); ?>">

                    <!-- 使用者名稱欄位 -->
                    <div>
                        <div class="flex items-center justify-between mb-1.5">
                            <label for="username" class="block text-xs font-semibold text-slate-700 tracking-wide flex items-center gap-1">
                                <span class="material-symbols-outlined text-[15px] text-slate-600">badge</span>
                                管理員帳號
                            </label>
                            <span class="text-[11px] text-slate-600 font-medium">支援英數小寫</span>
                        </div>
                        <div class="relative rounded-lg shadow-sm">
                            <input 
                                type="text" 
                                id="username" 
                                name="username" 
                                required 
                                autofocus 
                                autocomplete="username"
                                placeholder="請輸入管理員帳號"
                                class="input-jade block w-full px-3.5 py-2.5 text-sm rounded-lg text-slate-800 placeholder-slate-400 font-medium"
                            >
                            <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                                <span class="material-symbols-outlined text-base">person</span>
                            </div>
                        </div>
                    </div>

                    <!-- 登入密碼欄位 -->
                    <div>
                        <div class="flex items-center justify-between mb-1.5">
                            <label for="password" class="block text-xs font-semibold text-slate-700 tracking-wide flex items-center gap-1">
                                <span class="material-symbols-outlined text-[15px] text-slate-600">key</span>
                                登入密碼
                            </label>
                            <span class="text-[11px] text-slate-600 font-medium">安全雜湊校驗</span>
                        </div>
                        <div class="relative rounded-lg shadow-sm">
                            <input 
                                type="password" 
                                id="password" 
                                name="password" 
                                required 
                                autocomplete="current-password"
                                placeholder="請輸入安全登入密碼"
                                class="input-jade block w-full px-3.5 py-2.5 text-sm rounded-lg text-slate-800 placeholder-slate-400 font-medium"
                            >
                            <button 
                                type="button" 
                                id="togglePasswordBtn"
                                class="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none transition-colors"
                                title="顯示或隱藏密碼"
                            >
                                <span class="material-symbols-outlined text-base" id="toggleIcon">visibility_off</span>
                            </button>
                        </div>
                    </div>

                    <!-- 系統安全防護提示 -->
                    <div class="pt-1 flex items-center justify-between text-xs text-slate-600">
                        <label class="flex items-center gap-2 cursor-pointer select-none">
                            <input type="checkbox" id="rememberDevice" class="w-3.5 h-3.5 rounded border-slate-300 text-brand-crimson focus:ring-brand-crimson">
                            <span class="text-[11px] font-medium text-slate-700">記住安全工作階段 (當前裝置)</span>
                        </label>
                        <span class="text-[11px] text-slate-600 flex items-center gap-0.5">
                            <span class="material-symbols-outlined text-[13px] text-brand-frost">verified_user</span>
                            TLS 1.3
                        </span>
                    </div>

                    <!-- 送出驗證按鈕 -->
                    <div class="pt-2">
                        <button 
                            type="submit" 
                            id="submitBtn"
                            class="btn-cinnabar w-full py-3 px-4 rounded-xl text-white font-serif font-bold text-sm tracking-widest flex items-center justify-center gap-2 group cursor-pointer"
                        >
                            <span>確認登入控制台</span>
                            <span class="material-symbols-outlined text-base group-hover:translate-x-1 transition-transform">arrow_forward</span>
                        </button>
                    </div>
                </form>

                <!-- 底部安全提示欄 -->
                <div class="mt-6 pt-5 border-t border-slate-100 flex items-start gap-2.5 text-[11px] text-slate-600 leading-relaxed">
                    <span class="material-symbols-outlined text-sm text-brand-gold flex-shrink-0 mt-0.5">lock</span>
                    <p>
                        本後台僅供《踏雪笑傲》授權營運人員進行系統維護與指令管理。全站操作均已納入安全稽核與日誌紀錄，未經授權禁止存取。
                    </p>
                </div>
            </div>

            <!-- 下方快捷輔助資訊 -->
            <div class="text-center mt-6 text-xs text-slate-600 space-y-2">
                <div class="flex items-center justify-center gap-3">
                    <a href="../index.php" class="hover:text-brand-crimson transition-colors font-medium">官方首頁</a>
                    <span class="text-slate-300">·</span>
                    <a href="../login.php" class="hover:text-brand-crimson transition-colors font-medium">一般玩家登入</a>
                    <span class="text-slate-300">·</span>
                    <button type="button" onclick="alert('請洽詢技術團隊或查閱內部維運通訊錄申請權限重置。')" class="hover:text-brand-crimson transition-colors font-medium">
                        權限協助
                    </button>
                </div>
                <p class="text-[11px] text-slate-600 font-cinzel">
                    © 2025 SNOW WANDERER ONLINE. ALL RIGHTS RESERVED.
                </p>
            </div>
        </div>
    </main>

    <!-- 頁面底部安全等級徽標與伺服器資訊 -->
    <footer class="relative z-10 py-3 px-6 text-center border-t border-slate-200/60 bg-white/40 text-[11px] text-slate-600 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div class="flex items-center gap-2">
            <span class="inline-block w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>核心主機狀態：正常運行</span>
            <span class="text-slate-300">|</span>
            <span>加密等級：AES-256 GCM</span>
        </div>
        <div>
            <span>系統版本：v1.8.5 GM-Kernel</span>
        </div>
    </footer>

    <!-- 頁面互動 JavaScript -->
    <script>
        // 1. 密碼顯示/隱藏切換
        const togglePasswordBtn = document.getElementById('togglePasswordBtn');
        const passwordInput = document.getElementById('password');
        const toggleIcon = document.getElementById('toggleIcon');

        if (togglePasswordBtn && passwordInput && toggleIcon) {
            togglePasswordBtn.addEventListener('click', function () {
                const isPassword = passwordInput.getAttribute('type') === 'password';
                passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
                toggleIcon.textContent = isPassword ? 'visibility' : 'visibility_off';
            });
        }

        // 2. 表單提交簡單反饋動效 (防止重複提交)
        const gmForm = document.getElementById('gmLoginForm');
        const submitBtn = document.getElementById('submitBtn');
        if (gmForm && submitBtn) {
            gmForm.addEventListener('submit', function (e) {
                submitBtn.disabled = true;
                submitBtn.classList.add('opacity-80', 'cursor-not-allowed');
                submitBtn.innerHTML = `
                    <svg class="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>身分驗證中...</span>
                `;
            });
        }

        // 3. 高效輕量且無閃爍的 Canvas 飄雪粒子系統 (GPU 加速層)
        (function() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = window.innerWidth;
            let height = window.innerHeight;
            canvas.width = width;
            canvas.height = height;

            window.addEventListener('resize', function() {
                width = window.innerWidth;
                height = window.innerHeight;
                canvas.width = width;
                canvas.height = height;
            });

            // 保持清雅低密度，不搶奪主體注意力
            const particleCount = 38;
            const particles = [];

            for (let i = 0; i < particleCount; i++) {
                particles.push({
                    x: Math.random() * width,
                    y: Math.random() * height,
                    radius: Math.random() * 2 + 0.8,
                    speedY: Math.random() * 0.75 + 0.35,
                    speedX: (Math.random() - 0.5) * 0.4,
                    opacity: Math.random() * 0.5 + 0.25,
                    swing: Math.random() * 2,
                    swingSpeed: Math.random() * 0.02 + 0.01
                });
            }

            function drawParticles() {
                ctx.clearRect(0, 0, width, height);

                for (let i = 0; i < particleCount; i++) {
                    const p = particles[i];
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(186, 230, 253, ${p.opacity})`;
                    ctx.shadowBlur = 4;
                    ctx.shadowColor = "rgba(255, 255, 255, 0.8)";
                    ctx.fill();

                    // 更新位置
                    p.y += p.speedY;
                    p.x += Math.sin(p.swing) * 0.3 + p.speedX;
                    p.swing += p.swingSpeed;

                    // 邊界回繞
                    if (p.y > height) {
                        p.y = -5;
                        p.x = Math.random() * width;
                    }
                    if (p.x > width) p.x = 0;
                    if (p.x < 0) p.x = width;
                }

                requestAnimationFrame(drawParticles);
            }

            drawParticles();
        })();
    </script>
</body>
</html>