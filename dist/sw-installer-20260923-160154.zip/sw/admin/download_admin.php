<?php
/**
 * =============================================================
 *  踏雪笑傲 · 客戶端下載中心 管理後台
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *  資料庫：獨立資料庫 swo_download（見 download_schema.sql）
 *  功能：儀表板、版本發行、備用分流、平台、配備需求、FAQ、系統設定
 * =============================================================
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../download_config.php';

if (!isset($_SESSION['gm_username'])) {
    header('Location: gmlogin.php');
    exit();
}
$currentGm = (string)$_SESSION['gm_username'];

$db = download_db();
$SET = dl_settings_all($db);

if (empty($_SESSION['dl_admin_token'])) {
    $_SESSION['dl_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['dl_admin_token'];

/* ------------------------------------------------------------------
 * 共用小工具
 * ------------------------------------------------------------------ */
function da_flash(string $type, string $msg): void
{
    $_SESSION['dl_flash'] = ['type' => $type, 'msg' => $msg];
}

$notice = '';
$noticeType = 'success';
if (!empty($_SESSION['dl_flash'])) {
    $notice = (string)$_SESSION['dl_flash']['msg'];
    $noticeType = (string)$_SESSION['dl_flash']['type'];
    unset($_SESSION['dl_flash']);
}

/* ------------------------------------------------------------------
 * POST 動作處理（PRG）
 * ------------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (($_POST['form_token'] ?? '') !== $formToken) {
        da_flash('danger', '工作階段已過期，請重新操作。');
        header('Location: download_admin.php');
        exit();
    }
    $action = (string)($_POST['action'] ?? '');
    $redirect = 'download_admin.php?section=releases';

    if ($action === 'save_release') {
        $id          = (int)($_POST['id'] ?? 0);
        $platformCode = trim((string)($_POST['platform_code'] ?? 'pc'));
        $platformId   = 0;
        $stmt = $db->prepare("SELECT `id` FROM `dl_platforms` WHERE `code` = ? LIMIT 1");
        $stmt->bind_param('s', $platformCode);
        $stmt->execute();
        $prow = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        $platformId = $prow ? (int)$prow['id'] : 0;

        $version     = trim((string)($_POST['version'] ?? ''));
        $buildNo     = trim((string)($_POST['build_no'] ?? ''));
        $releaseDate = trim((string)($_POST['release_date'] ?? ''));
        $sizeLabel   = trim((string)($_POST['size_label'] ?? ''));
        $installerUrl = trim((string)($_POST['installer_url'] ?? ''));
        $installerLabel = trim((string)($_POST['installer_label'] ?? ''));
        $coverImage  = trim((string)($_POST['cover_image'] ?? ''));
        $coverEngine = trim((string)($_POST['cover_engine'] ?? ''));
        $coverCaption = trim((string)($_POST['cover_caption'] ?? ''));
        $sha256      = trim((string)($_POST['sha256'] ?? ''));
        $badge       = trim((string)($_POST['badge'] ?? ''));
        $isCurrent   = !empty($_POST['is_current']) ? 1 : 0;
        $enabled     = !empty($_POST['enabled']) ? 1 : 0;
        $sortOrder   = (int)($_POST['sort_order'] ?? 0);
        $notes       = trim((string)($_POST['notes'] ?? ''));

        if ($version === '') {
            da_flash('danger', '版本號不得為空。');
            header('Location: download_admin.php?section=release_editor' . ($id ? '&id=' . $id : ''));
            exit();
        }
        $releaseDateVal = ($releaseDate !== '') ? date('Y-m-d', strtotime($releaseDate)) : null;

        if ($isCurrent) {
            $db->query("UPDATE `dl_releases` SET `is_current` = 0 WHERE `platform_code` = '" . mysqli_real_escape_string($db, $platformCode) . "'");
        }

        if ($id > 0) {
            $stmt = $db->prepare(
                "UPDATE `dl_releases` SET
                    `platform_id`=?, `platform_code`=?, `version`=?, `build_no`=?, `release_date`=?, `size_label`=?,
                    `installer_url`=?, `installer_label`=?, `cover_image`=?, `cover_engine`=?, `cover_caption`=?,
                    `sha256`=?, `badge`=?, `is_current`=?, `enabled`=?, `sort_order`=?, `notes`=?
                 WHERE `id`=?"
            );
            $stmt->bind_param(
                'issssssssssssiiisi',
                $platformId, $platformCode, $version, $buildNo, $releaseDateVal, $sizeLabel,
                $installerUrl, $installerLabel, $coverImage, $coverEngine, $coverCaption,
                $sha256, $badge, $isCurrent, $enabled, $sortOrder, $notes, $id
            );
            $ok = $stmt->execute();
            $stmt->close();
            $relId = $id;
            da_flash($ok ? 'success' : 'danger', $ok ? '版本已更新。' : '更新失敗：' . mysqli_error($db));
        } else {
            $stmt = $db->prepare(
                "INSERT INTO `dl_releases`
                    (`platform_id`,`platform_code`,`version`,`build_no`,`release_date`,`size_label`,
                     `installer_url`,`installer_label`,`cover_image`,`cover_engine`,`cover_caption`,
                     `sha256`,`badge`,`is_current`,`enabled`,`sort_order`,`notes`)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->bind_param(
                'issssssssssssiiis',
                $platformId, $platformCode, $version, $buildNo, $releaseDateVal, $sizeLabel,
                $installerUrl, $installerLabel, $coverImage, $coverEngine, $coverCaption,
                $sha256, $badge, $isCurrent, $enabled, $sortOrder, $notes
            );
            $ok = $stmt->execute();
            $relId = (int)$db->insert_id;
            $stmt->close();
            da_flash($ok ? 'success' : 'danger', $ok ? '已建立新版本。' : '建立失敗：' . mysqli_error($db));
        }

        // 備用分流載點
        if ($relId > 0 && isset($_POST['mirrors']) && is_array($_POST['mirrors'])) {
            foreach ($_POST['mirrors'] as $row) {
                $mId   = (int)($row['id'] ?? 0);
                $mDel  = !empty($row['_delete']);
                $mLabel = trim((string)($row['label'] ?? ''));
                $mSub   = trim((string)($row['sub_label'] ?? ''));
                $mUrl   = trim((string)($row['url'] ?? ''));
                $mIcon  = trim((string)($row['icon'] ?? 'open_in_new'));
                $mEn    = isset($row['enabled']) && (string)$row['enabled'] !== '' ? 1 : 0;
                $mSort  = (int)($row['sort_order'] ?? 0);

                if ($mDel) {
                    if ($mId > 0) { $db->query("DELETE FROM `dl_mirrors` WHERE `id` = " . $mId); }
                    continue;
                }
                if ($mLabel === '' && $mUrl === '') { continue; }
                if ($mId > 0) {
                    $stmt = $db->prepare("UPDATE `dl_mirrors` SET `label`=?,`sub_label`=?,`url`=?,`icon`=?,`enabled`=?,`sort_order`=? WHERE `id`=? AND `release_id`=?");
                    $stmt->bind_param('ssssiiii', $mLabel, $mSub, $mUrl, $mIcon, $mEn, $mSort, $mId, $relId);
                    $stmt->execute();
                    $stmt->close();
                } else {
                    $stmt = $db->prepare("INSERT INTO `dl_mirrors` (`release_id`,`label`,`sub_label`,`url`,`icon`,`enabled`,`sort_order`) VALUES (?,?,?,?,?,?,?)");
                    $stmt->bind_param('issssii', $relId, $mLabel, $mSub, $mUrl, $mIcon, $mEn, $mSort);
                    $stmt->execute();
                    $stmt->close();
                }
            }
        }
        $redirect = 'download_admin.php?section=releases';
    } elseif ($action === 'delete_release') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $db->query("DELETE FROM `dl_mirrors` WHERE `release_id` = " . $id);
            $db->query("DELETE FROM `dl_releases` WHERE `id` = " . $id);
            da_flash('success', '版本發行已刪除。');
        }
    } elseif ($action === 'toggle_release') {
        $id = (int)($_POST['id'] ?? 0);
        $db->query("UPDATE `dl_releases` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $id);
        da_flash('success', '版本啟用狀態已切換。');
    } elseif ($action === 'set_current_release') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $row = null;
            $stmt = $db->prepare("SELECT `platform_code` FROM `dl_releases` WHERE `id` = ? LIMIT 1");
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row) {
                $code = mysqli_real_escape_string($db, (string)$row['platform_code']);
                $db->query("UPDATE `dl_releases` SET `is_current` = 0 WHERE `platform_code` = '" . $code . "'");
                $db->query("UPDATE `dl_releases` SET `is_current` = 1 WHERE `id` = " . $id);
                da_flash('success', '已設為該平台當前版本。');
            }
        }
    } elseif ($action === 'save_platform') {
        $pid    = (int)($_POST['platform_id'] ?? 0);
        $code   = trim((string)($_POST['code'] ?? ''));
        $name   = trim((string)($_POST['name'] ?? ''));
        $nameEn = trim((string)($_POST['name_en'] ?? ''));
        $icon   = trim((string)($_POST['icon'] ?? 'devices'));
        $tagline = trim((string)($_POST['tagline'] ?? ''));
        $accent = trim((string)($_POST['accent'] ?? 'sky'));
        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($code === '' || $name === '') {
            da_flash('danger', '平台代碼與名稱不得為空。');
        } elseif ($pid > 0) {
            $stmt = $db->prepare("UPDATE `dl_platforms` SET `code`=?,`name`=?,`name_en`=?,`icon`=?,`tagline`=?,`accent`=?,`enabled`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('ssssssiii', $code, $name, $nameEn, $icon, $tagline, $accent, $enabled, $sort, $pid);
            $stmt->execute();
            $stmt->close();
            da_flash('success', '平台已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `dl_platforms` (`code`,`name`,`name_en`,`icon`,`tagline`,`accent`,`enabled`,`sort_order`) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->bind_param('ssssssii', $code, $name, $nameEn, $icon, $tagline, $accent, $enabled, $sort);
            $stmt->execute();
            $stmt->close();
            da_flash('success', '平台已新增。');
        }
        $redirect = 'download_admin.php?section=platforms';
    } elseif ($action === 'toggle_platform') {
        $pid = (int)($_POST['platform_id'] ?? 0);
        $db->query("UPDATE `dl_platforms` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $pid);
        da_flash('success', '平台啟用狀態已切換。');
        $redirect = 'download_admin.php?section=platforms';
    } elseif ($action === 'delete_platform') {
        $pid = (int)($_POST['platform_id'] ?? 0);
        $cnt = 0;
        $r = $db->query("SELECT COUNT(*) AS c FROM `dl_releases` WHERE `platform_id` = " . $pid);
        if ($r) { $cnt = (int)$r->fetch_assoc()['c']; }
        if ($cnt > 0) {
            da_flash('danger', '此平台仍有 ' . $cnt . ' 個版本，請先移除版本後再刪除。');
        } else {
            $db->query("DELETE FROM `dl_platforms` WHERE `id` = " . $pid);
            da_flash('success', '平台已刪除。');
        }
        $redirect = 'download_admin.php?section=platforms';
    } elseif ($action === 'save_requirement') {
        $rid    = (int)($_POST['requirement_id'] ?? 0);
        $label  = trim((string)($_POST['label'] ?? ''));
        $icon   = trim((string)($_POST['icon'] ?? 'memory'));
        $minV   = trim((string)($_POST['min_value'] ?? ''));
        $recV   = trim((string)($_POST['rec_value'] ?? ''));
        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($label === '') {
            da_flash('danger', '項目名稱不得為空。');
        } elseif ($rid > 0) {
            $stmt = $db->prepare("UPDATE `dl_requirements` SET `label`=?,`icon`=?,`min_value`=?,`rec_value`=?,`enabled`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('ssssiii', $label, $icon, $minV, $recV, $enabled, $sort, $rid);
            $stmt->execute();
            $stmt->close();
            da_flash('success', '配備需求已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `dl_requirements` (`label`,`icon`,`min_value`,`rec_value`,`enabled`,`sort_order`) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('ssssii', $label, $icon, $minV, $recV, $enabled, $sort);
            $stmt->execute();
            $stmt->close();
            da_flash('success', '配備需求已新增。');
        }
        $redirect = 'download_admin.php?section=requirements';
    } elseif ($action === 'toggle_requirement') {
        $rid = (int)($_POST['requirement_id'] ?? 0);
        $db->query("UPDATE `dl_requirements` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $rid);
        da_flash('success', '配備需求啟用狀態已切換。');
        $redirect = 'download_admin.php?section=requirements';
    } elseif ($action === 'delete_requirement') {
        $rid = (int)($_POST['requirement_id'] ?? 0);
        $db->query("DELETE FROM `dl_requirements` WHERE `id` = " . $rid);
        da_flash('success', '配備需求已刪除。');
        $redirect = 'download_admin.php?section=requirements';
    } elseif ($action === 'save_faq') {
        $fid    = (int)($_POST['faq_id'] ?? 0);
        $tag    = trim((string)($_POST['tag'] ?? ''));
        $question = trim((string)($_POST['question'] ?? ''));
        $note   = trim((string)($_POST['note'] ?? ''));
        $answer = (string)($_POST['answer'] ?? '');
        $enabled = !empty($_POST['enabled']) ? 1 : 0;
        $sort   = (int)($_POST['sort_order'] ?? 0);
        if ($question === '') {
            da_flash('danger', '問題內容不得為空。');
        } elseif ($fid > 0) {
            $stmt = $db->prepare("UPDATE `dl_faqs` SET `tag`=?,`question`=?,`note`=?,`answer`=?,`enabled`=?,`sort_order`=? WHERE `id`=?");
            $stmt->bind_param('ssssiii', $tag, $question, $note, $answer, $enabled, $sort, $fid);
            $stmt->execute();
            $stmt->close();
            da_flash('success', 'FAQ 已更新。');
        } else {
            $stmt = $db->prepare("INSERT INTO `dl_faqs` (`tag`,`question`,`note`,`answer`,`enabled`,`sort_order`) VALUES (?,?,?,?,?,?)");
            $stmt->bind_param('ssssii', $tag, $question, $note, $answer, $enabled, $sort);
            $stmt->execute();
            $stmt->close();
            da_flash('success', 'FAQ 已新增。');
        }
        $redirect = 'download_admin.php?section=faqs';
    } elseif ($action === 'toggle_faq') {
        $fid = (int)($_POST['faq_id'] ?? 0);
        $db->query("UPDATE `dl_faqs` SET `enabled` = IF(`enabled`=1,0,1) WHERE `id` = " . $fid);
        da_flash('success', 'FAQ 啟用狀態已切換。');
        $redirect = 'download_admin.php?section=faqs';
    } elseif ($action === 'delete_faq') {
        $fid = (int)($_POST['faq_id'] ?? 0);
        $db->query("DELETE FROM `dl_faqs` WHERE `id` = " . $fid);
        da_flash('success', 'FAQ 已刪除。');
        $redirect = 'download_admin.php?section=faqs';
    } elseif ($action === 'save_settings') {
        $keys = [
            'hero_badge','hero_title','hero_subtitle','server_status_label','server_status_value',
            'installer_kicker','installer_title','installer_desc','security_badge',
            'requirements_title','requirements_subtitle','requirements_tip','faq_title','faq_subtitle'
        ];
        foreach ($keys as $k) {
            if (array_key_exists('set_' . $k, $_POST)) {
                dl_setting_put($db, $k, trim((string)$_POST['set_' . $k]));
            }
        }
        foreach (['show_server_status','show_mirrors','show_requirements','show_faq'] as $k) {
            dl_setting_put($db, $k, isset($_POST['set_' . $k]) ? '1' : '0');
        }
        da_flash('success', '下載中心設定已儲存並立即生效。');
        $redirect = 'download_admin.php?section=settings';
    }

    header('Location: ' . $redirect);
    exit();
}

/* ------------------------------------------------------------------
 * 讀取資料
 * ------------------------------------------------------------------ */
$section = (string)($_GET['section'] ?? 'dashboard');
$allowed = ['dashboard','releases','release_editor','platforms','requirements','faqs','settings'];
if (!in_array($section, $allowed, true)) { $section = 'dashboard'; }

$platforms = dl_platforms($db, false);
$platformMap = dl_platform_map($db);

$stats = ['releases' => 0, 'platforms' => 0, 'mirrors' => 0, 'requirements' => 0, 'faqs' => 0, 'downloads' => 0];
foreach (['releases' => 'dl_releases', 'platforms' => 'dl_platforms', 'mirrors' => 'dl_mirrors', 'requirements' => 'dl_requirements', 'faqs' => 'dl_faqs'] as $k => $tbl) {
    $r = mysqli_query($db, "SELECT COUNT(*) AS c FROM `$tbl`");
    if ($r) { $stats[$k] = (int)$r->fetch_assoc()['c']; }
}
$r = mysqli_query($db, "SELECT IFNULL(SUM(`download_count`),0) AS c FROM `dl_releases`");
if ($r) { $stats['downloads'] = (int)$r->fetch_assoc()['c']; }

$recentReleases = [];
$res = mysqli_query($db, "SELECT * FROM `dl_releases` ORDER BY `updated_at` DESC LIMIT 6");
if ($res) { $recentReleases = $res->fetch_all(MYSQLI_ASSOC); }

$allReleases = [];
if ($section === 'releases') {
    $res = mysqli_query($db, "SELECT * FROM `dl_releases` ORDER BY `platform_code` ASC, `is_current` DESC, `sort_order` ASC, `id` DESC");
    if ($res) { $allReleases = $res->fetch_all(MYSQLI_ASSOC); }
}

$editRelease = null;
$editMirrors = [];
$isEditRelease = false;
if ($section === 'release_editor') {
    $eid = (int)($_GET['id'] ?? 0);
    if ($eid > 0) {
        $stmt = $db->prepare("SELECT * FROM `dl_releases` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $eid);
        $stmt->execute();
        $editRelease = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($editRelease) {
            $isEditRelease = true;
            $editMirrors = dl_mirrors($db, $eid, false);
        }
    }
}

$allRequirements = [];
if ($section === 'requirements') {
    $allRequirements = dl_requirements($db, false);
}
$allFaqs = [];
if ($section === 'faqs') {
    $allFaqs = dl_faqs($db, false);
}

/* 導覽選單 */
$navItems = [
    ['key' => 'dashboard',    'label' => '總覽儀表板', 'en' => 'Dashboard',   'icon' => 'fa-gauge-high',      'grad' => 'from-slate-600 to-slate-800'],
    ['key' => 'release_editor','label' => '新增版本',  'en' => 'New Release', 'icon' => 'fa-cloud-arrow-up',  'grad' => 'from-rose-600 to-rose-800'],
    ['key' => 'releases',     'label' => '版本發行',   'en' => 'Releases',    'icon' => 'fa-cubes',           'grad' => 'from-sky-600 to-sky-700'],
    ['key' => 'platforms',    'label' => '平台管理',   'en' => 'Platforms',   'icon' => 'fa-desktop',         'grad' => 'from-amber-600 to-amber-800'],
    ['key' => 'requirements', 'label' => '配備需求',   'en' => 'Requirements','icon' => 'fa-microchip',       'grad' => 'from-emerald-600 to-emerald-800'],
    ['key' => 'faqs',         'label' => '疑難排解',   'en' => 'FAQ',         'icon' => 'fa-circle-question', 'grad' => 'from-violet-600 to-violet-800'],
    ['key' => 'settings',     'label' => '系統設定',   'en' => 'Settings',    'icon' => 'fa-sliders',         'grad' => 'from-cyan-600 to-cyan-800'],
];
$activeNav = $section;
if ($section === 'release_editor') { $activeNav = 'releases'; }
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>踏雪笑傲 · 下載中心管理 · GM 控制台</title>
    <link rel="stylesheet" href="assets/tailwind.css">
    <link rel="stylesheet" href="assets/gmpanel-tailwind.css?v=20260919b">
    <link rel="stylesheet" href="assets/download-admin-tailwind.css?v=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        :root { --vermilion: #be123c; --ice-blue: #0284c7; --ink-black: #0b0f19; }
        body {
            background-color: #080c14; color: #1e293b; font-family: 'Noto Serif TC', serif;
            min-height: 100vh;
            background-image:
                radial-gradient(ellipse at 50% 0%, rgba(190, 18, 60, 0.08) 0%, transparent 60%),
                radial-gradient(ellipse at 80% 90%, rgba(2, 132, 199, 0.08) 0%, transparent 50%),
                radial-gradient(ellipse at 20% 60%, rgba(15, 23, 42, 0.8) 0%, transparent 70%);
        }
        #snow-canvas { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; pointer-events: none; z-index: 1; transform: translateZ(0); will-change: transform; }
        .glass-panel {
            background: rgba(255, 255, 255, 0.94); border: 1px solid rgba(226, 232, 240, 0.85);
            backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
            box-shadow: 0 10px 30px -5px rgba(0, 0, 0, 0.25), 0 0 0 1px rgba(255, 255, 255, 0.7) inset;
            position: relative; transform: translateZ(0);
        }
        .corner-accent::before { content: ''; position: absolute; top: 0; left: 0; width: 10px; height: 10px; border-top: 2px solid var(--vermilion); border-left: 2px solid var(--vermilion); pointer-events: none; }
        .corner-accent::after { content: ''; position: absolute; bottom: 0; right: 0; width: 10px; height: 10px; border-bottom: 2px solid var(--ice-blue); border-right: 2px solid var(--ice-blue); pointer-events: none; }
        .ink-divider { height: 1px; background: linear-gradient(90deg, transparent 0%, rgba(190, 18, 60, 0.3) 25%, rgba(2, 132, 199, 0.3) 75%, transparent 100%); }
        .btn-vermilion { background: linear-gradient(135deg, #be123c 0%, #9f1239 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(190,18,60,.25); }
        .btn-vermilion:hover { background: linear-gradient(135deg, #e11d48 0%, #be123c 100%); box-shadow: 0 6px 20px rgba(190,18,60,.38); transform: translateY(-1px); }
        .btn-ice { background: linear-gradient(135deg, #0284c7 0%, #0369a1 100%); color: #fff; transition: all .25s ease; box-shadow: 0 4px 14px rgba(2,132,199,.25); }
        .btn-ice:hover { background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%); box-shadow: 0 6px 20px rgba(2,132,199,.38); transform: translateY(-1px); }
        .na-input, .na-select, .na-textarea {
            width: 100%; padding: .55rem .75rem; font-size: .8rem; color: #0f172a;
            background: #fff; border: 1px solid #cbd5e1; border-radius: .5rem; transition: all .2s ease; font-family: 'Noto Serif TC', serif;
        }
        .na-input:focus, .na-select:focus, .na-textarea:focus { outline: none; border-color: #0284c7; box-shadow: 0 0 0 3px rgba(2,132,199,.15); }
        .na-label { display: block; font-size: .72rem; font-weight: 700; color: #334155; letter-spacing: .06em; margin-bottom: .35rem; }
        .na-help { font-size: .68rem; color: #94a3b8; margin-top: .25rem; }
        .na-nav-btn { position: relative; overflow: hidden; border-radius: .75rem; padding: .7rem .95rem; color: #fff; font-size: .78rem; font-weight: 700; display: flex; align-items: center; gap: .65rem; box-shadow: 0 8px 20px -6px rgba(0,0,0,.45); transition: all .22s ease; text-decoration: none; }
        .na-nav-btn:hover { transform: translateY(-2px); box-shadow: 0 12px 26px -8px rgba(0,0,0,.55); }
        .na-nav-btn.is-active { outline: 2px solid rgba(255,255,255,.85); outline-offset: -2px; }
        .na-nav-btn .na-nav-icon { width: 2rem; height: 2rem; border-radius: .5rem; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.22); flex: none; }
        .na-badge { display: inline-flex; align-items: center; gap: .25rem; padding: .1rem .45rem; border-radius: .375rem; border: 1px solid; font-size: .65rem; font-weight: 700; font-family: 'Manrope', sans-serif; }
        .na-strip { width: 4px; border-radius: 2px; align-self: stretch; flex: none; }
        table.na-table { width: 100%; border-collapse: collapse; }
        table.na-table th { text-align: left; font-size: .68rem; letter-spacing: .08em; text-transform: uppercase; color: #64748b; padding: .6rem .7rem; border-bottom: 1px solid #e2e8f0; background: #f8fafc; white-space: nowrap; }
        table.na-table td { padding: .65rem .7rem; font-size: .78rem; border-bottom: 1px solid #f1f5f9; vertical-align: middle; }
        table.na-table tbody tr:hover { background: #f8fafc; }
        .dl-mirror-row { display: grid; grid-template-columns: 1.2fr 1.4fr 2fr 1fr auto auto; gap: .5rem; align-items: center; }
        @media (max-width: 900px) { .dl-mirror-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body class="relative min-h-screen flex flex-col selection:bg-rose-900 selection:text-white">
    <canvas id="snow-canvas"></canvas>

    <header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <a href="gmpanel.php" class="flex items-center space-x-3.5 no-underline group">
                    <img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
                            <span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-sky-900/80 text-sky-200 border border-sky-700/60 font-medium">下載管理</span>
                        </div>
                        <p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Snow Wanderer Online</p>
                    </div>
                </a>
                <nav class="flex items-center space-x-2 sm:space-x-4">
                    <a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-arrow-left text-slate-400"></i><span class="hidden sm:inline">返回 GM 控制台</span>
                    </a>
                    <a href="download_admin.php?section=releases" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-cubes text-sky-400"></i><span class="hidden sm:inline">版本列表</span>
                    </a>
                    <a href="../swo/download.php" target="_blank" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-eye text-emerald-400"></i><span class="hidden sm:inline">檢視前台</span>
                    </a>
                    <div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
                        <div class="flex items-center space-x-2 bg-slate-900/90 border border-sky-900/50 px-3 py-1 rounded-full text-xs">
                            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                            <span class="text-slate-400">管理員：</span>
                            <span class="font-semibold text-sky-300 font-mono"><?= dl_h($currentGm) ?></span>
                        </div>
                        <a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors" title="登出 GM 控制台">
                            <i class="fa-solid fa-arrow-right-from-bracket mr-1"></i><span class="hidden sm:inline">登出</span>
                        </a>
                    </div>
                </nav>
            </div>
        </div>
    </header>

    <main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">
        <div class="flex flex-col gap-3 pb-3 border-b border-slate-800">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                    <div class="flex items-center gap-2 mb-1">
                        <span class="px-2 py-0.5 text-[11px] font-semibold text-sky-800 bg-sky-50 border border-sky-200 rounded">下載中心系統</span>
                        <span class="text-xs text-slate-400">獨立資料庫 swo_download · 資料同步正常</span>
                    </div>
                    <h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider flex items-center gap-2.5">
                        <span>客戶端下載管理中心</span>
                        <span class="text-xs font-normal text-slate-400 tracking-normal font-sans border border-slate-700 px-2 py-0.5 rounded">Download Control Center</span>
                    </h1>
                </div>
                <div class="flex flex-wrap items-center gap-3 text-xs">
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-cubes text-sky-400"></i><span>版本數：</span>
                        <strong class="text-sky-400 font-mono text-sm font-bold"><?= (int)$stats['releases'] ?></strong><span class="text-slate-500">個</span>
                    </div>
                    <div class="bg-slate-900/80 border border-slate-800 rounded-lg px-3.5 py-2 text-slate-300 flex items-center gap-2.5">
                        <i class="fa-solid fa-download text-emerald-400"></i><span>累計下載：</span>
                        <strong class="text-emerald-400 font-mono text-sm font-bold"><?= number_format((int)$stats['downloads']) ?></strong>
                    </div>
                </div>
            </div>

            <!-- 精美按鈕選單 -->
            <div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-2.5 pt-1">
                <?php foreach ($navItems as $n): ?>
                    <a href="download_admin.php?section=<?= dl_h($n['key']) ?>" class="na-nav-btn bg-gradient-to-br <?= dl_h($n['grad']) ?> <?= $activeNav === $n['key'] ? 'is-active' : '' ?>">
                        <span class="na-nav-icon"><i class="fa-solid <?= dl_h($n['icon']) ?> text-sm"></i></span>
                        <span class="flex flex-col items-start leading-tight">
                            <span><?= dl_h($n['label']) ?></span>
                            <span class="text-[10px] font-normal text-white/70 font-['Cinzel']"><?= dl_h($n['en']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <?php if ($notice !== ''): ?>
            <?php $isDanger = ($noticeType === 'danger'); ?>
            <div class="p-3.5 rounded-lg border text-xs flex items-center justify-between <?= $isDanger ? 'border-rose-500/30 bg-rose-950/40 text-rose-200' : 'border-emerald-500/30 bg-emerald-950/40 text-emerald-200' ?>">
                <div class="flex items-center gap-2.5">
                    <i class="fa-solid <?= $isDanger ? 'fa-circle-exclamation text-rose-400' : 'fa-circle-check text-emerald-400' ?> text-sm"></i>
                    <span><?= dl_h($notice) ?></span>
                </div>
                <span class="text-[11px] font-mono <?= $isDanger ? 'text-rose-400/70' : 'text-emerald-400/70' ?>"><?= date('H:i:s') ?></span>
            </div>
        <?php endif; ?>
<?php if ($section === 'dashboard'): ?>
        <?php
        $cards = [
            ['label' => '版本發行', 'value' => $stats['releases'],     'icon' => 'fa-cubes',           'grad' => 'from-sky-500 to-sky-700',        'sub' => '所有平台版本'],
            ['label' => '下載平台', 'value' => $stats['platforms'],    'icon' => 'fa-desktop',         'grad' => 'from-amber-500 to-amber-700',    'sub' => 'PC / 行動裝置'],
            ['label' => '分流載點', 'value' => $stats['mirrors'],      'icon' => 'fa-share-nodes',     'grad' => 'from-rose-500 to-rose-700',      'sub' => '備用下載來源'],
            ['label' => '配備需求', 'value' => $stats['requirements'], 'icon' => 'fa-microchip',       'grad' => 'from-emerald-500 to-emerald-700','sub' => '硬體規格項目'],
            ['label' => 'FAQ 條目', 'value' => $stats['faqs'],         'icon' => 'fa-circle-question', 'grad' => 'from-violet-500 to-violet-700',  'sub' => '疑難排解'],
            ['label' => '累計下載', 'value' => $stats['downloads'],    'icon' => 'fa-download',        'grad' => 'from-cyan-500 to-cyan-700',      'sub' => '所有版本'],
        ];
        ?>
        <div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
            <?php foreach ($cards as $c): ?>
                <div class="glass-panel corner-accent rounded-xl p-4 text-slate-800">
                    <span class="w-9 h-9 rounded-lg bg-gradient-to-br <?= dl_h($c['grad']) ?> text-white flex items-center justify-center shadow mb-2"><i class="fa-solid <?= dl_h($c['icon']) ?> text-sm"></i></span>
                    <div class="text-2xl font-bold font-mono text-slate-900"><?= number_format((int)$c['value']) ?></div>
                    <div class="text-[11px] font-semibold text-slate-600 mt-0.5"><?= dl_h($c['label']) ?></div>
                    <div class="text-[10px] text-slate-400"><?= dl_h($c['sub']) ?></div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700"><i class="fa-solid fa-clock-rotate-left"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide">最近更新版本</h2>
                        <p class="text-[11px] text-slate-500">依最後編輯時間排序</p>
                    </div>
                </div>
                <a href="download_admin.php?section=releases" class="text-[11px] font-semibold text-sky-700 hover:text-sky-900">查看全部 <i class="fa-solid fa-arrow-right ml-0.5"></i></a>
            </div>
            <div class="overflow-x-auto">
                <table class="na-table">
                    <thead><tr><th>版本</th><th>平台</th><th>大小</th><th>發行日</th><th class="text-center">下載數</th><th class="text-right">操作</th></tr></thead>
                    <tbody>
                    <?php if (empty($recentReleases)): ?><tr><td colspan="6" class="text-center text-slate-400 py-6">尚無版本，立即新增吧！</td></tr><?php endif; ?>
                    <?php foreach ($recentReleases as $rel): $p = $platformMap[$rel['platform_code']] ?? null; ?>
                        <tr>
                            <td class="font-mono font-semibold text-slate-800">
                                <?php if ((int)$rel['is_current'] === 1): ?><span class="na-badge bg-emerald-50 text-emerald-700 border-emerald-200 mr-1">當前</span><?php endif; ?>
                                <?= dl_h($rel['version']) ?>
                            </td>
                            <td class="text-slate-500"><?= dl_h($p['name'] ?? $rel['platform_code']) ?></td>
                            <td class="text-slate-500 text-[11px]"><?= dl_h($rel['size_label']) ?></td>
                            <td class="text-slate-500 text-[11px] font-mono"><?= dl_h($rel['release_date'] ?: '—') ?></td>
                            <td class="text-center font-mono text-slate-500"><?= number_format((int)$rel['download_count']) ?></td>
                            <td class="text-right whitespace-nowrap">
                                <a href="download_admin.php?section=release_editor&id=<?= (int)$rel['id'] ?>" class="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i>編輯</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php elseif ($section === 'releases'): ?>
        <div class="glass-panel corner-accent rounded-xl p-5">
            <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-200">
                <div class="flex items-center gap-2.5">
                    <div class="w-8 h-8 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-center text-sky-700"><i class="fa-solid fa-cubes"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900 tracking-wide">版本發行管理</h2>
                        <p class="text-[11px] text-slate-500">共 <?= count($allReleases) ?> 個版本 · 管理下載連結、校驗碼與備用分流</p>
                    </div>
                </div>
                <a href="download_admin.php?section=release_editor" class="btn-vermilion inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg self-start"><i class="fa-solid fa-cloud-arrow-up"></i> 新增版本</a>
            </div>
            <div class="overflow-x-auto rounded-lg border border-slate-200">
                <table class="na-table">
                    <thead><tr><th>版本</th><th>平台</th><th>大小</th><th>發行日</th><th class="text-center">分流</th><th class="text-center">下載數</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                    <tbody>
                    <?php if (empty($allReleases)): ?><tr><td colspan="8" class="text-center text-slate-400 py-8">尚無版本資料</td></tr><?php endif; ?>
                    <?php foreach ($allReleases as $rel): $p = $platformMap[$rel['platform_code']] ?? null; $mcnt = count(dl_mirrors($db, (int)$rel['id'], false)); ?>
                        <tr>
                            <td class="font-mono font-semibold text-slate-800">
                                <?php if ((int)$rel['is_current'] === 1): ?><span class="na-badge bg-emerald-50 text-emerald-700 border-emerald-200 mr-1">當前</span><?php endif; ?>
                                <?= dl_h($rel['version']) ?><?php if ($rel['build_no'] !== ''): ?><span class="text-slate-400 text-[10px] ml-1">#<?= dl_h($rel['build_no']) ?></span><?php endif; ?>
                            </td>
                            <td class="text-slate-500"><?= dl_h($p['name'] ?? $rel['platform_code']) ?></td>
                            <td class="text-slate-500 text-[11px]"><?= dl_h($rel['size_label']) ?></td>
                            <td class="text-slate-500 text-[11px] font-mono"><?= dl_h($rel['release_date'] ?: '—') ?></td>
                            <td class="text-center font-mono text-slate-500"><?= $mcnt ?></td>
                            <td class="text-center font-mono text-slate-500"><?= number_format((int)$rel['download_count']) ?></td>
                            <td class="text-center">
                                <form method="POST" action="download_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                    <input type="hidden" name="action" value="toggle_release">
                                    <input type="hidden" name="id" value="<?= (int)$rel['id'] ?>">
                                    <button type="submit" class="na-badge <?= (int)$rel['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$rel['enabled'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$rel['enabled'] === 1 ? '啟用' : '停用' ?></button>
                                </form>
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="download_admin.php?section=release_editor&id=<?= (int)$rel['id'] ?>" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium" title="編輯"><i class="fa-solid fa-pen"></i></a>
                                <?php if ((int)$rel['is_current'] !== 1): ?>
                                <form method="POST" action="download_admin.php" class="inline">
                                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                    <input type="hidden" name="action" value="set_current_release">
                                    <input type="hidden" name="id" value="<?= (int)$rel['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 border border-slate-300 text-[11px] font-medium ml-1" title="設為當前版本"><i class="fa-solid fa-star"></i></button>
                                </form>
                                <?php endif; ?>
                                <a href="../swo/download_go.php?id=<?= (int)$rel['id'] ?>" target="_blank" class="px-2 py-1 rounded bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 border border-slate-300 text-[11px] font-medium ml-1" title="測試下載"><i class="fa-solid fa-download"></i></a>
                                <form method="POST" action="download_admin.php" class="inline" onsubmit="return dlConfirmSubmit(this, '確定刪除此版本（含分流載點）？');">
                                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                    <input type="hidden" name="action" value="delete_release">
                                    <input type="hidden" name="id" value="<?= (int)$rel['id'] ?>">
                                    <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1" title="刪除"><i class="fa-solid fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
<?php elseif ($section === 'release_editor'): ?>
        <?php
        $rf = [
            'id' => $editRelease['id'] ?? 0,
            'platform_code' => $editRelease['platform_code'] ?? 'pc',
            'version' => $editRelease['version'] ?? '',
            'build_no' => $editRelease['build_no'] ?? '',
            'release_date' => $editRelease['release_date'] ?? date('Y-m-d'),
            'size_label' => $editRelease['size_label'] ?? '',
            'installer_url' => $editRelease['installer_url'] ?? '',
            'installer_label' => $editRelease['installer_label'] ?? '',
            'cover_image' => $editRelease['cover_image'] ?? '',
            'cover_engine' => $editRelease['cover_engine'] ?? '',
            'cover_caption' => $editRelease['cover_caption'] ?? '',
            'sha256' => $editRelease['sha256'] ?? '',
            'badge' => $editRelease['badge'] ?? '正式版本',
            'is_current' => (int)($editRelease['is_current'] ?? 0),
            'enabled' => (int)($editRelease['enabled'] ?? 1),
            'sort_order' => (int)($editRelease['sort_order'] ?? 0),
            'notes' => $editRelease['notes'] ?? '',
        ];
        ?>
        <form method="POST" action="download_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
            <input type="hidden" name="action" value="save_release">
            <input type="hidden" name="id" value="<?= (int)$rf['id'] ?>">

            <div class="lg:col-span-8 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                        <div class="w-8 h-8 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700"><i class="fa-solid fa-cloud-arrow-up"></i></div>
                        <div>
                            <h2 class="text-base font-bold text-slate-900"><?= $isEditRelease ? '編輯版本' : '新增版本' ?></h2>
                            <p class="text-[11px] text-slate-500">設定版本號、下載連結、校驗碼與備用分流載點</p>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="na-label">所屬平台</label>
                                <select name="platform_code" class="na-select">
                                    <?php foreach ($platforms as $p): ?>
                                        <option value="<?= dl_h($p['code']) ?>" <?= $rf['platform_code'] === $p['code'] ? 'selected' : '' ?>><?= dl_h($p['name']) ?>（<?= dl_h($p['code']) ?>）</option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label class="na-label">版本號 <span class="text-rose-600">*</span></label>
                                <input type="text" name="version" value="<?= dl_h($rf['version']) ?>" class="na-input font-mono" placeholder="v1.8.5" required>
                            </div>
                            <div>
                                <label class="na-label">組建編號</label>
                                <input type="text" name="build_no" value="<?= dl_h($rf['build_no']) ?>" class="na-input font-mono" placeholder="1850">
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="na-label">發行日期</label>
                                <input type="date" name="release_date" value="<?= dl_h($rf['release_date']) ?>" class="na-input">
                            </div>
                            <div>
                                <label class="na-label">檔案大小</label>
                                <input type="text" name="size_label" value="<?= dl_h($rf['size_label']) ?>" class="na-input" placeholder="18.6 GB">
                            </div>
                            <div>
                                <label class="na-label">版本徽章</label>
                                <input type="text" name="badge" value="<?= dl_h($rf['badge']) ?>" class="na-input" placeholder="正式版本">
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="na-label">主程式下載網址</label>
                                <input type="text" name="installer_url" value="<?= dl_h($rf['installer_url']) ?>" class="na-input font-mono text-[11px]" placeholder="https://... 或 #">
                            </div>
                            <div>
                                <label class="na-label">下載按鈕文字</label>
                                <input type="text" name="installer_label" value="<?= dl_h($rf['installer_label']) ?>" class="na-input" placeholder="立即下載完整客戶端 (.exe)">
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div class="md:col-span-2">
                                <label class="na-label">SHA-256 校驗碼</label>
                                <input type="text" name="sha256" value="<?= dl_h($rf['sha256']) ?>" class="na-input font-mono text-[11px]" placeholder="64 位十六進位字串">
                            </div>
                            <div>
                                <label class="na-label">備註</label>
                                <input type="text" name="notes" value="<?= dl_h($rf['notes']) ?>" class="na-input" placeholder="內部備註">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <div class="flex items-center justify-between pb-3 mb-3 border-b border-slate-200">
                        <h2 class="text-sm font-bold text-slate-900"><i class="fa-solid fa-share-nodes text-rose-600 mr-1.5"></i>備用分流載點</h2>
                        <button type="button" onclick="dlAddMirrorRow()" class="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600 text-[11px] font-semibold"><i class="fa-solid fa-plus mr-1"></i>新增載點</button>
                    </div>
                    <div id="mirror-rows" class="space-y-2.5">
                        <?php if (empty($editMirrors)): ?>
                            <div class="dl-mirror-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                                <input type="hidden" name="mirrors[0][id]" value="0">
                                <input class="na-input" name="mirrors[0][label]" placeholder="載點名稱">
                                <input class="na-input" name="mirrors[0][sub_label]" placeholder="載點說明">
                                <input class="na-input font-mono text-[11px]" name="mirrors[0][url]" placeholder="https://...">
                                <input class="na-input" name="mirrors[0][icon]" value="open_in_new" placeholder="圖示">
                                <label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="mirrors[0][enabled]" value="1" checked> 啟用</label>
                                <input type="hidden" name="mirrors[0][sort_order]" value="0">
                                <button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest('.dl-mirror-row').remove()"><i class="fa-solid fa-trash"></i> 移除</button>
                            </div>
                        <?php else: foreach ($editMirrors as $mi => $m): ?>
                            <div class="dl-mirror-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">
                                <input type="hidden" name="mirrors[<?= $mi ?>][id]" value="<?= (int)$m['id'] ?>">
                                <input class="na-input" name="mirrors[<?= $mi ?>][label]" value="<?= dl_h($m['label']) ?>" placeholder="載點名稱">
                                <input class="na-input" name="mirrors[<?= $mi ?>][sub_label]" value="<?= dl_h($m['sub_label']) ?>" placeholder="載點說明">
                                <input class="na-input font-mono text-[11px]" name="mirrors[<?= $mi ?>][url]" value="<?= dl_h($m['url']) ?>" placeholder="https://...">
                                <input class="na-input" name="mirrors[<?= $mi ?>][icon]" value="<?= dl_h($m['icon']) ?>" placeholder="圖示">
                                <label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="mirrors[<?= $mi ?>][enabled]" value="1" <?= (int)$m['enabled'] === 1 ? 'checked' : '' ?>> 啟用</label>
                                <input type="hidden" name="mirrors[<?= $mi ?>][sort_order]" value="<?= (int)$m['sort_order'] ?>">
                                <button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest('.dl-mirror-row').remove()"><i class="fa-solid fa-trash"></i> 移除</button>
                            </div>
                        <?php endforeach; endif; ?>
                    </div>
                    <p class="na-help">載點名稱／說明將顯示於前台主下載卡；網址可填入外部載點。留空的列將被忽略。</p>
                </div>

                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-image text-sky-600 mr-1.5"></i>主視覺與封面</h2>
                    <div class="space-y-4">
                        <div>
                            <label class="na-label">封面圖網址</label>
                            <input type="text" name="cover_image" value="<?= dl_h($rf['cover_image']) ?>" class="na-input font-mono text-[11px]" placeholder="https://...">
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="na-label">引擎標語</label>
                                <input type="text" name="cover_engine" value="<?= dl_h($rf['cover_engine']) ?>" class="na-input" placeholder="DirectX 12 Ultimate">
                            </div>
                            <div>
                                <label class="na-label">封面標語</label>
                                <input type="text" name="cover_caption" value="<?= dl_h($rf['cover_caption']) ?>" class="na-input" placeholder="墨意風骨 · 寒山踏雪">
                            </div>
                        </div>
                        <?php if (!empty($rf['cover_image'])): ?>
                            <div class="border border-slate-200 rounded-lg overflow-hidden"><img src="<?= dl_h($rf['cover_image']) ?>" alt="封面預覽" class="w-full max-h-52 object-cover"></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-4 space-y-6">
                <div class="glass-panel corner-accent rounded-xl p-5">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-sliders text-sky-600 mr-1.5"></i>發行設定</h2>
                    <div class="space-y-3">
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="is_current" value="1" class="w-4 h-4 accent-sky-700" <?= $rf['is_current'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-star text-amber-500"></i> 設為該平台當前版本</label>
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="enabled" value="1" class="w-4 h-4 accent-sky-700" <?= $rf['enabled'] === 1 ? 'checked' : '' ?>> <i class="fa-solid fa-power-off text-emerald-600"></i> 啟用此版本</label>
                        <div>
                            <label class="na-label">排序</label>
                            <input type="number" name="sort_order" value="<?= (int)$rf['sort_order'] ?>" class="na-input">
                        </div>
                    </div>
                    <div class="flex flex-col gap-2 mt-5 pt-4 border-t border-slate-200">
                        <button type="submit" class="btn-vermilion w-full py-2.5 text-sm font-bold rounded-lg flex items-center justify-center gap-2"><i class="fa-solid fa-floppy-disk"></i> <?= $isEditRelease ? '儲存並更新' : '建立版本' ?></button>
                        <a href="download_admin.php?section=releases" class="w-full py-2.5 text-sm font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600 text-center">取消返回</a>
                    </div>
                    <?php if ($isEditRelease): ?>
                        <div class="ink-divider my-4"></div>
                        <div class="text-[11px] text-slate-500 space-y-1">
                            <div><i class="fa-regular fa-clock mr-1"></i>建立：<?= dl_h($editRelease['created_at']) ?></div>
                            <div><i class="fa-solid fa-rotate mr-1"></i>更新：<?= dl_h($editRelease['updated_at']) ?></div>
                            <div><i class="fa-solid fa-download mr-1"></i>下載數：<?= number_format((int)$editRelease['download_count']) ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>
<?php elseif ($section === 'platforms'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700"><i class="fa-solid fa-desktop"></i></div>
                    <div>
                        <h2 class="text-base font-bold text-slate-900">下載平台管理</h2>
                        <p class="text-[11px] text-slate-500">平台代碼（code）為程式識別用，建議沿用既有英文代碼</p>
                    </div>
                </div>
                <div class="overflow-x-auto rounded-lg border border-slate-200">
                    <table class="na-table">
                        <thead><tr><th>平台</th><th>代碼</th><th>版本數</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                        <tbody>
                        <?php foreach ($platforms as $p): $pcnt = count(dl_releases($db, $p['code'], false)); ?>
                            <tr>
                                <td class="font-semibold text-slate-800"><i class="fa-solid <?= $p['icon'] && strpos($p['icon'], 'fa-') === 0 ? dl_h($p['icon']) : 'fa-desktop' ?> text-slate-400 mr-1.5"></i><?= dl_h($p['name']) ?><span class="text-[10px] text-slate-400 ml-1.5"><?= dl_h($p['tagline']) ?></span></td>
                                <td class="font-mono text-[11px] text-slate-500"><?= dl_h($p['code']) ?></td>
                                <td class="font-mono text-slate-600"><?= $pcnt ?></td>
                                <td class="text-center">
                                    <form method="POST" action="download_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_platform">
                                        <input type="hidden" name="platform_id" value="<?= (int)$p['id'] ?>">
                                        <button type="submit" class="na-badge <?= (int)$p['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><span class="w-1.5 h-1.5 rounded-full <?= (int)$p['enabled'] === 1 ? 'bg-emerald-500' : 'bg-slate-400' ?>"></span><?= (int)$p['enabled'] === 1 ? '啟用' : '停用' ?></button>
                                    </form>
                                </td>
                                <td class="text-right whitespace-nowrap">
                                    <button type="button" onclick="dlEditPlatform(<?= htmlspecialchars(json_encode($p, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="download_admin.php" class="inline" onsubmit="return dlConfirmSubmit(this, '確定刪除平台「<?= dl_h($p['name']) ?>」？');">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_platform">
                                        <input type="hidden" name="platform_id" value="<?= (int)$p['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="lg:col-span-4">
                <form method="POST" action="download_admin.php" id="pf-form" class="glass-panel corner-accent rounded-xl p-5">
                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_platform">
                    <input type="hidden" name="platform_id" id="pf-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="pf-title"><i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增平台</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">平台代碼 (code) <span class="text-rose-600">*</span></label><input type="text" name="code" id="pf-code" required class="na-input font-mono text-xs" placeholder="例：pc"></div>
                        <div><label class="na-label">平台名稱 <span class="text-rose-600">*</span></label><input type="text" name="name" id="pf-name" required class="na-input" placeholder="例：電腦端"></div>
                        <div><label class="na-label">英文名稱</label><input type="text" name="name_en" id="pf-name-en" class="na-input" placeholder="PC / Windows"></div>
                        <div><label class="na-label">Material 圖示</label><input type="text" name="icon" id="pf-icon" class="na-input font-mono text-xs" placeholder="desktop_windows"></div>
                        <div><label class="na-label">平台說明</label><input type="text" name="tagline" id="pf-tagline" class="na-input" placeholder="Windows 10 / 11 64-bit"></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">主色系</label>
                                <select name="accent" id="pf-accent" class="na-select">
                                    <option value="sky">sky</option><option value="rose">rose</option><option value="emerald">emerald</option><option value="violet">violet</option><option value="slate">slate</option>
                                </select>
                            </div>
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="pf-sort" value="0" class="na-input"></div>
                        </div>
                        <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="enabled" value="1" id="pf-enabled" class="w-4 h-4 accent-amber-600" checked> 啟用此平台</label>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="dlResetPlatform()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
<?php elseif ($section === 'requirements'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-700"><i class="fa-solid fa-microchip"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">電腦配備需求</h2><p class="text-[11px] text-slate-500">前台「鑑機撫琴」規格表內容</p></div>
                </div>
                <div class="overflow-x-auto rounded-lg border border-slate-200">
                    <table class="na-table">
                        <thead><tr><th>項目</th><th>最低配置</th><th>推薦配置</th><th class="text-center">狀態</th><th class="text-right">操作</th></tr></thead>
                        <tbody>
                        <?php if (empty($allRequirements)): ?><tr><td colspan="5" class="text-center text-slate-400 py-6">尚無項目</td></tr><?php endif; ?>
                        <?php foreach ($allRequirements as $r): ?>
                            <tr>
                                <td class="font-semibold text-slate-800 whitespace-nowrap"><?= dl_h($r['label']) ?></td>
                                <td class="text-slate-600 text-[11px]"><?= dl_h($r['min_value']) ?></td>
                                <td class="text-slate-600 text-[11px]"><?= dl_h($r['rec_value']) ?></td>
                                <td class="text-center">
                                    <form method="POST" action="download_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_requirement">
                                        <input type="hidden" name="requirement_id" value="<?= (int)$r['id'] ?>">
                                        <button type="submit" class="na-badge <?= (int)$r['enabled'] === 1 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-300' ?>"><?= (int)$r['enabled'] === 1 ? '啟用' : '停用' ?></button>
                                    </form>
                                </td>
                                <td class="text-right whitespace-nowrap">
                                    <button type="button" onclick="dlEditRequirement(<?= htmlspecialchars(json_encode($r, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-slate-100 hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="download_admin.php" class="inline" onsubmit="return dlConfirmSubmit(this, '確定刪除此項目？');">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_requirement">
                                        <input type="hidden" name="requirement_id" value="<?= (int)$r['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium ml-1"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="lg:col-span-4">
                <form method="POST" action="download_admin.php" id="rq-form" class="glass-panel corner-accent rounded-xl p-5">
                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_requirement">
                    <input type="hidden" name="requirement_id" id="rq-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="rq-title"><i class="fa-solid fa-circle-plus text-emerald-600 mr-1.5"></i>新增項目</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">項目名稱 <span class="text-rose-600">*</span></label><input type="text" name="label" id="rq-label" required class="na-input" placeholder="例：處理器 (CPU)"></div>
                        <div><label class="na-label">Material 圖示</label><input type="text" name="icon" id="rq-icon" class="na-input font-mono text-xs" placeholder="memory"></div>
                        <div><label class="na-label">最低配置</label><input type="text" name="min_value" id="rq-min" class="na-input" placeholder="Intel Core i5-8400"></div>
                        <div><label class="na-label">推薦配置</label><input type="text" name="rec_value" id="rq-rec" class="na-input" placeholder="Intel Core i7-12700"></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="rq-sort" value="0" class="na-input"></div>
                            <label class="flex items-end gap-2 text-xs text-slate-700 cursor-pointer select-none pb-2"><input type="checkbox" name="enabled" value="1" id="rq-enabled" class="w-4 h-4 accent-emerald-600" checked> 啟用</label>
                        </div>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="dlResetRequirement()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
<?php elseif ($section === 'faqs'): ?>
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div class="lg:col-span-7 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-violet-50 border border-violet-200 flex items-center justify-center text-violet-700"><i class="fa-solid fa-circle-question"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">疑難排解 FAQ</h2><p class="text-[11px] text-slate-500">前台可摺疊問答區塊內容</p></div>
                </div>
                <div class="space-y-3">
                    <?php if (empty($allFaqs)): ?><div class="text-center text-slate-400 py-6">尚無 FAQ</div><?php endif; ?>
                    <?php foreach ($allFaqs as $f): ?>
                        <div class="border border-slate-200 rounded-lg p-3.5 bg-slate-50">
                            <div class="flex items-start justify-between gap-3">
                                <div class="min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="na-badge bg-rose-50 text-rose-700 border-rose-200"><?= dl_h($f['tag']) ?></span>
                                        <?php if ((int)$f['enabled'] !== 1): ?><span class="na-badge bg-slate-100 text-slate-500 border-slate-300">停用</span><?php endif; ?>
                                    </div>
                                    <div class="font-semibold text-slate-800 text-[13px]"><?= dl_h($f['question']) ?></div>
                                    <div class="text-[11px] text-slate-400 mt-0.5"><?= dl_h($f['note']) ?></div>
                                </div>
                                <div class="flex items-center gap-1 flex-none">
                                    <button type="button" onclick="dlEditFaq(<?= htmlspecialchars(json_encode($f, JSON_UNESCAPED_UNICODE), ENT_QUOTES) ?>)" class="px-2 py-1 rounded bg-white hover:bg-sky-100 text-slate-600 hover:text-sky-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-pen"></i></button>
                                    <form method="POST" action="download_admin.php" class="inline">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="toggle_faq">
                                        <input type="hidden" name="faq_id" value="<?= (int)$f['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-white hover:bg-emerald-100 text-slate-600 hover:text-emerald-800 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-power-off"></i></button>
                                    </form>
                                    <form method="POST" action="download_admin.php" class="inline" onsubmit="return dlConfirmSubmit(this, '確定刪除此 FAQ？');">
                                        <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                                        <input type="hidden" name="action" value="delete_faq">
                                        <input type="hidden" name="faq_id" value="<?= (int)$f['id'] ?>">
                                        <button type="submit" class="px-2 py-1 rounded bg-white hover:bg-rose-100 text-slate-600 hover:text-rose-700 border border-slate-300 text-[11px] font-medium"><i class="fa-solid fa-trash"></i></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="lg:col-span-5">
                <form method="POST" action="download_admin.php" id="fq-form" class="glass-panel corner-accent rounded-xl p-5">
                    <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
                    <input type="hidden" name="action" value="save_faq">
                    <input type="hidden" name="faq_id" id="fq-id" value="0">
                    <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200" id="fq-title"><i class="fa-solid fa-circle-plus text-violet-600 mr-1.5"></i>新增 FAQ</h2>
                    <div class="space-y-3">
                        <div><label class="na-label">標籤</label><input type="text" name="tag" id="fq-tag" class="na-input" placeholder="[安裝錯誤]"></div>
                        <div><label class="na-label">問題 <span class="text-rose-600">*</span></label><input type="text" name="question" id="fq-question" required class="na-input" placeholder="問題內容"></div>
                        <div><label class="na-label">問題補充</label><input type="text" name="note" id="fq-note" class="na-input" placeholder="適用情境說明"></div>
                        <div><label class="na-label">解答（支援 HTML）</label><textarea name="answer" id="fq-answer" rows="7" class="na-textarea font-mono text-[11px]" placeholder="<p>解答段落...</p>"></textarea></div>
                        <div class="grid grid-cols-2 gap-3">
                            <div><label class="na-label">排序</label><input type="number" name="sort_order" id="fq-sort" value="0" class="na-input"></div>
                            <label class="flex items-end gap-2 text-xs text-slate-700 cursor-pointer select-none pb-2"><input type="checkbox" name="enabled" value="1" id="fq-enabled" class="w-4 h-4 accent-violet-600" checked> 啟用</label>
                        </div>
                        <div class="flex gap-2 pt-1">
                            <button type="submit" class="btn-vermilion flex-1 py-2 text-xs font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1"></i>儲存</button>
                            <button type="button" onclick="dlResetFaq()" class="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 hover:bg-slate-200 border border-slate-300 text-slate-600">重置</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
<?php elseif ($section === 'settings'): ?>
        <form method="POST" action="download_admin.php" class="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <input type="hidden" name="form_token" value="<?= dl_h($formToken) ?>">
            <input type="hidden" name="action" value="save_settings">
            <div class="lg:col-span-8 glass-panel corner-accent rounded-xl p-5">
                <div class="flex items-center gap-2.5 pb-3 mb-4 border-b border-slate-200">
                    <div class="w-8 h-8 rounded-lg bg-cyan-50 border border-cyan-200 flex items-center justify-center text-cyan-700"><i class="fa-solid fa-sliders"></i></div>
                    <div><h2 class="text-base font-bold text-slate-900">下載中心設定</h2><p class="text-[11px] text-slate-500">即時套用於前台下載頁文案與顯示開關</p></div>
                </div>
                <div class="mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-heading text-sky-500"></i><span>主視覺與狀態</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="md:col-span-2"><label class="na-label">主視覺標籤</label><input type="text" name="set_hero_badge" value="<?= dl_h($SET['hero_badge'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">主視覺標題 (H1)</label><input type="text" name="set_hero_title" value="<?= dl_h($SET['hero_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">主視覺副標</label><textarea name="set_hero_subtitle" rows="2" class="na-textarea"><?= dl_h($SET['hero_subtitle'] ?? '') ?></textarea></div>
                    <div><label class="na-label">伺服器狀態標題</label><input type="text" name="set_server_status_label" value="<?= dl_h($SET['server_status_label'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">伺服器狀態內容</label><input type="text" name="set_server_status_value" value="<?= dl_h($SET['server_status_value'] ?? '') ?>" class="na-input"></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-download text-rose-500"></i><span>主下載卡</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label class="na-label">安裝器英文標籤</label><input type="text" name="set_installer_kicker" value="<?= dl_h($SET['installer_kicker'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">安全保證標語</label><input type="text" name="set_security_badge" value="<?= dl_h($SET['security_badge'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">安裝器標題</label><input type="text" name="set_installer_title" value="<?= dl_h($SET['installer_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">安裝器說明</label><textarea name="set_installer_desc" rows="2" class="na-textarea"><?= dl_h($SET['installer_desc'] ?? '') ?></textarea></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200 mb-3 flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wide"><i class="fa-solid fa-microchip text-emerald-500"></i><span>配備需求與 FAQ</span></div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><label class="na-label">配備需求標題</label><input type="text" name="set_requirements_title" value="<?= dl_h($SET['requirements_title'] ?? '') ?>" class="na-input"></div>
                    <div><label class="na-label">FAQ 標題</label><input type="text" name="set_faq_title" value="<?= dl_h($SET['faq_title'] ?? '') ?>" class="na-input"></div>
                    <div class="md:col-span-2"><label class="na-label">配備需求副標</label><textarea name="set_requirements_subtitle" rows="2" class="na-textarea"><?= dl_h($SET['requirements_subtitle'] ?? '') ?></textarea></div>
                    <div class="md:col-span-2"><label class="na-label">配備需求提醒</label><textarea name="set_requirements_tip" rows="2" class="na-textarea"><?= dl_h($SET['requirements_tip'] ?? '') ?></textarea></div>
                    <div class="md:col-span-2"><label class="na-label">FAQ 副標</label><textarea name="set_faq_subtitle" rows="2" class="na-textarea"><?= dl_h($SET['faq_subtitle'] ?? '') ?></textarea></div>
                </div>
                <div class="mt-5 pt-4 border-t border-slate-200">
                    <button type="submit" class="btn-vermilion px-5 py-2.5 text-sm font-bold rounded-lg"><i class="fa-solid fa-floppy-disk mr-1.5"></i>儲存設定</button>
                </div>
            </div>
            <div class="lg:col-span-4 glass-panel corner-accent rounded-xl p-5">
                <h2 class="text-sm font-bold text-slate-900 pb-2 mb-3 border-b border-slate-200"><i class="fa-solid fa-toggle-on text-sky-600 mr-1.5"></i>顯示開關</h2>
                <div class="space-y-3">
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_server_status" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_server_status'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示伺服器狀態卡</label>
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_mirrors" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_mirrors'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示備用分流載點</label>
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_requirements" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_requirements'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示配備需求區塊</label>
                    <label class="flex items-center gap-2 text-xs text-slate-700 cursor-pointer select-none"><input type="checkbox" name="set_show_faq" value="1" class="w-4 h-4 accent-sky-700" <?= ($SET['show_faq'] ?? '1') === '1' ? 'checked' : '' ?>> 顯示 FAQ 區塊</label>
                </div>
                <div class="ink-divider my-4"></div>
                <ul class="text-[11px] text-slate-500 space-y-2 leading-relaxed list-disc pl-4">
                    <li>版本資訊、下載連結與校驗碼請至「版本發行」管理。</li>
                    <li>主下載卡顯示各平台「當前版本」。</li>
                    <li>所有變更即時生效，無需重新部署。</li>
                </ul>
                <div class="text-[11px] text-slate-400 font-mono mt-3">DB: <?= dl_h(DOWNLOAD_DB_NAME) ?></div>
            </div>
        </form>
<?php endif; ?>
    </main>

    <script>
        (function initSnow() {
            const canvas = document.getElementById('snow-canvas');
            if (!canvas) return;
            const ctx = canvas.getContext('2d');
            let width = (canvas.width = window.innerWidth);
            let height = (canvas.height = window.innerHeight);
            window.addEventListener('resize', () => { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; });
            const particles = [];
            const count = Math.min(Math.floor(window.innerWidth / 28), 42);
            for (let i = 0; i < count; i++) {
                particles.push({ x: Math.random() * width, y: Math.random() * height, radius: Math.random() * 2.0 + 0.6, speedY: Math.random() * 0.7 + 0.25, speedX: (Math.random() - 0.5) * 0.4, opacity: Math.random() * 0.6 + 0.2 });
            }
            function render() {
                ctx.clearRect(0, 0, width, height);
                for (let i = 0; i < particles.length; i++) {
                    const p = particles[i];
                    p.y += p.speedY; p.x += p.speedX;
                    if (p.y > height) { p.y = -5; p.x = Math.random() * width; }
                    if (p.x < 0) p.x = width; if (p.x > width) p.x = 0;
                    ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                    ctx.fillStyle = `rgba(255,255,255,${p.opacity})`; ctx.shadowBlur = 4; ctx.shadowColor = 'rgba(255,255,255,0.5)'; ctx.fill();
                }
                requestAnimationFrame(render);
            }
            render();
        })();
        window.dlConfirmSubmit = function (form, message) { if (!message || window.confirm(message)) { form.submit(); } return false; };
        window.dlEditPlatform = function (p) {
            document.getElementById('pf-id').value = p.id || 0;
            document.getElementById('pf-code').value = p.code || '';
            document.getElementById('pf-name').value = p.name || '';
            document.getElementById('pf-name-en').value = p.name_en || '';
            document.getElementById('pf-icon').value = p.icon || '';
            document.getElementById('pf-tagline').value = p.tagline || '';
            document.getElementById('pf-accent').value = p.accent || 'sky';
            document.getElementById('pf-sort').value = p.sort_order || 0;
            document.getElementById('pf-enabled').checked = String(p.enabled) === '1';
            document.getElementById('pf-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-amber-600 mr-1.5"></i>編輯平台 #' + p.id;
            document.getElementById('pf-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        window.dlResetPlatform = function () {
            document.getElementById('pf-form').reset();
            document.getElementById('pf-id').value = 0;
            document.getElementById('pf-title').innerHTML = '<i class="fa-solid fa-circle-plus text-amber-600 mr-1.5"></i>新增平台';
        };
        window.dlEditRequirement = function (r) {
            document.getElementById('rq-id').value = r.id || 0;
            document.getElementById('rq-label').value = r.label || '';
            document.getElementById('rq-icon').value = r.icon || '';
            document.getElementById('rq-min').value = r.min_value || '';
            document.getElementById('rq-rec').value = r.rec_value || '';
            document.getElementById('rq-sort').value = r.sort_order || 0;
            document.getElementById('rq-enabled').checked = String(r.enabled) === '1';
            document.getElementById('rq-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-emerald-600 mr-1.5"></i>編輯項目 #' + r.id;
            document.getElementById('rq-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        window.dlResetRequirement = function () {
            document.getElementById('rq-form').reset();
            document.getElementById('rq-id').value = 0;
            document.getElementById('rq-title').innerHTML = '<i class="fa-solid fa-circle-plus text-emerald-600 mr-1.5"></i>新增項目';
        };
        window.dlEditFaq = function (f) {
            document.getElementById('fq-id').value = f.id || 0;
            document.getElementById('fq-tag').value = f.tag || '';
            document.getElementById('fq-question').value = f.question || '';
            document.getElementById('fq-note').value = f.note || '';
            document.getElementById('fq-answer').value = f.answer || '';
            document.getElementById('fq-sort').value = f.sort_order || 0;
            document.getElementById('fq-enabled').checked = String(f.enabled) === '1';
            document.getElementById('fq-title').innerHTML = '<i class="fa-solid fa-pen-to-square text-violet-600 mr-1.5"></i>編輯 FAQ #' + f.id;
            document.getElementById('fq-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
        };
        window.dlResetFaq = function () {
            document.getElementById('fq-form').reset();
            document.getElementById('fq-id').value = 0;
            document.getElementById('fq-title').innerHTML = '<i class="fa-solid fa-circle-plus text-violet-600 mr-1.5"></i>新增 FAQ';
        };
        window.dlAddMirrorRow = function () {
            const box = document.getElementById('mirror-rows');
            const idx = box.querySelectorAll('.dl-mirror-row').length;
            const html = '<div class="dl-mirror-row bg-slate-50 border border-slate-200 rounded-lg p-2.5">' +
                '<input type="hidden" name="mirrors[' + idx + '][id]" value="0">' +
                '<input class="na-input" name="mirrors[' + idx + '][label]" placeholder="載點名稱">' +
                '<input class="na-input" name="mirrors[' + idx + '][sub_label]" placeholder="載點說明">' +
                '<input class="na-input font-mono text-[11px]" name="mirrors[' + idx + '][url]" placeholder="https://...">' +
                '<input class="na-input" name="mirrors[' + idx + '][icon]" value="open_in_new" placeholder="圖示">' +
                '<label class="flex items-center gap-1 text-[11px] text-slate-600"><input type="checkbox" name="mirrors[' + idx + '][enabled]" value="1" checked> 啟用</label>' +
                '<input type="hidden" name="mirrors[' + idx + '][sort_order]" value="' + idx + '">' +
                '<button type="button" class="na-badge bg-rose-50 text-rose-700 border-rose-200" onclick="this.closest(\'.dl-mirror-row\').remove()"><i class="fa-solid fa-trash"></i> 移除</button>' +
                '</div>';
            box.insertAdjacentHTML('beforeend', html);
        };
    </script>
</body>
</html>
