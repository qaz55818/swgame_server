<?php
/**
 * =============================================================
 *  踏雪笑傲 · 後台「註冊管理」JSON API
 *  - 所有請求都必須具備有效的 GM Session（伺服器端驗證）。
 *  - 讀取使用 GET；變更操作僅接受 POST 並驗證 CSRF。
 *  - 篩選欄位與狀態值皆使用白名單；所有查詢使用參數化。
 * - 不回傳資料庫錯誤、堆疊或內部路徑。
 * =============================================================
 */
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../register_security.php';

header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex');

// ---- 身分驗證 ----
if (!isset($_SESSION['gm_username']) || $_SESSION['gm_username'] === '') {
    register_json_response(401, ['ok' => false, 'message' => '請先登入 GM 控制台。']);
}
$gmUsername = (string)$_SESSION['gm_username'];

// 後台閒置逾時（8 小時）
app_session_enforce_timeout(60 * 60 * 8);

$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    register_json_response(500, ['ok' => false, 'message' => '資料庫連線失敗。']);
}
mysqli_set_charset($Link, 'utf8mb4');
register_ensure_core_tables($Link);

$clientIp = register_client_ip($Link);

$action = (string)($_REQUEST['action'] ?? 'overview');
$isPost = ($_SERVER['REQUEST_METHOD'] === 'POST');

// 變更操作白名單一律走 POST + CSRF
$mutatingActions = ['save_settings', 'add_block', 'remove_block', 'purge_logs'];
if (in_array($action, $mutatingActions, true)) {
    if (!$isPost) {
        register_json_response(405, ['ok' => false, 'message' => '此操作僅接受 POST。']);
    }
    if (!register_csrf_validate((string)($_POST['csrf_token'] ?? ''))) {
        register_json_response(403, ['ok' => false, 'message' => '安全權杖失效，請重新整理頁面。']);
    }
}

switch ($action) {
    case 'overview':
        api_overview($Link, $clientIp);
        break;
    case 'logs':
        api_logs($Link);
        break;
    case 'log_detail':
        api_log_detail($Link);
        break;
    case 'settings':
        api_settings($Link);
        break;
    case 'save_settings':
        api_save_settings($Link, $gmUsername, $clientIp);
        break;
    case 'blocks':
        api_blocks($Link);
        break;
    case 'add_block':
        api_add_block($Link, $gmUsername, $clientIp);
        break;
    case 'remove_block':
        api_remove_block($Link, $gmUsername, $clientIp);
        break;
    case 'admin_logs':
        api_admin_logs($Link);
        break;
    case 'purge_logs':
        api_purge_logs($Link, $gmUsername, $clientIp);
        break;
    default:
        register_json_response(400, ['ok' => false, 'message' => '未知的操作。']);
}

/* =============================================================
 *  實作
 * ============================================================= */

function api_settings_payload($Link)
{
    $settings = register_settings_load_fresh($Link);
    return [
        'register_enabled'       => (string)($settings['register_enabled'] ?? '1'),
        'closed_notice'          => (string)($settings['closed_notice'] ?? ''),
        'rate_window_seconds'    => (int)($settings['rate_window_seconds'] ?? 300),
        'rate_max_per_ip'        => (int)($settings['rate_max_per_ip'] ?? 5),
        'rate_max_per_account'   => (int)($settings['rate_max_per_account'] ?? 3),
        'rate_max_per_ip_hour'   => (int)($settings['rate_max_per_ip_hour'] ?? 20),
        'rate_cooldown_seconds'  => (int)($settings['rate_cooldown_seconds'] ?? 300),
        'block_duration_seconds' => (int)($settings['block_duration_seconds'] ?? 3600),
        'retention_days'         => (int)($settings['retention_days'] ?? 90),
        'trusted_proxies'        => (string)($settings['trusted_proxies'] ?? ''),
        'email_max_accounts'     => (int)($settings['email_max_accounts'] ?? 1),
        'account_min_length'     => (int)($settings['account_min_length'] ?? 4),
        'account_max_length'     => (int)($settings['account_max_length'] ?? 10),
        'password_min_length'    => (int)($settings['password_min_length'] ?? 4),
        'password_max_length'    => (int)($settings['password_max_length'] ?? 10),
        'forbidden_words'        => (string)($settings['forbidden_words'] ?? ''),
        'forbidden_symbols'      => (string)($settings['forbidden_symbols'] ?? ''),
        'forbidden_email_patterns'=> (string)($settings['forbidden_email_patterns'] ?? ''),
    ];
}

function api_db_clock($Link)
{
    $fallback = ['db_now' => date('Y-m-d H:i:s'), 'offset_seconds' => 0, 'label' => 'UTC+00:00'];
    try {
        $res = $Link->query("SELECT NOW() AS db_now");
        if ($res && ($row = $res->fetch_assoc())) {
            $dbNow = (string)$row['db_now'];
            $offset = strtotime($dbNow) - time();
            // 四捨五入到 15 分鐘，避免秒差造成奇怪標示
            $offset = (int)(round($offset / 900) * 900);
            $sign = $offset < 0 ? '-' : '+';
            $abs = abs($offset);
            $label = sprintf('UTC%s%02d:%02d', $sign, intdiv($abs, 3600), intdiv($abs % 3600, 60));
            return ['db_now' => $dbNow, 'offset_seconds' => $offset, 'label' => $label];
        }
    } catch (Throwable $e) {
    }
    return $fallback;
}

function api_overview($Link, $clientIp)
{
    $settings = register_settings_load_fresh($Link);
    $stats = [
        'today_total' => 0, 'today_success' => 0, 'today_failed' => 0,
        'today_limited' => 0, 'today_blocked' => 0, 'today_disabled' => 0,
        'today_pending' => 0, 'today_unique_ips' => 0,
        'week_success' => 0, 'week_failed' => 0,
        'active_blocks' => 0, 'auto_blocks' => 0, 'manual_blocks' => 0,
        'last_attempt' => null,
    ];
    try {
        $res = $Link->query(
            "SELECT
                COUNT(*) AS total,
                SUM(`status`='success') AS success_c,
                SUM(`status`='failed') AS failed_c,
                SUM(`status`='limited') AS limited_c,
                SUM(`status`='blocked') AS blocked_c,
                SUM(`status`='disabled') AS disabled_c,
                SUM(`status`='pending') AS pending_c,
                COUNT(DISTINCT `ip`) AS ips
             FROM `register_log` WHERE `created_at` >= CURDATE()"
        );
        if ($res && ($row = $res->fetch_assoc())) {
            $stats['today_total'] = (int)$row['total'];
            $stats['today_success'] = (int)$row['success_c'];
            $stats['today_failed'] = (int)$row['failed_c'];
            $stats['today_limited'] = (int)$row['limited_c'];
            $stats['today_blocked'] = (int)$row['blocked_c'];
            $stats['today_disabled'] = (int)$row['disabled_c'];
            $stats['today_pending'] = (int)$row['pending_c'];
            $stats['today_unique_ips'] = (int)$row['ips'];
        }
    } catch (Throwable $e) {
    }
    try {
        $res = $Link->query(
            "SELECT SUM(`status`='success') AS success_c, SUM(`status`='failed') AS failed_c
             FROM `register_log` WHERE `created_at` >= NOW() - INTERVAL 7 DAY"
        );
        if ($res && ($row = $res->fetch_assoc())) {
            $stats['week_success'] = (int)$row['success_c'];
            $stats['week_failed'] = (int)$row['failed_c'];
        }
    } catch (Throwable $e) {
    }
    try {
        $res = $Link->query(
            "SELECT COUNT(*) AS c,
                    SUM(`source`='auto') AS auto_c,
                    SUM(`source`='manual') AS manual_c
             FROM `register_blocks`
             WHERE `active` = 1 AND (`expires_at` IS NULL OR `expires_at` > NOW())"
        );
        if ($res && ($row = $res->fetch_assoc())) {
            $stats['active_blocks'] = (int)$row['c'];
            $stats['auto_blocks'] = (int)$row['auto_c'];
            $stats['manual_blocks'] = (int)$row['manual_c'];
        }
    } catch (Throwable $e) {
    }
    try {
        $res = $Link->query(
            "SELECT `username`, `ip`, `status`, `reason_code`, `created_at`
             FROM `register_log` ORDER BY `id` DESC LIMIT 1"
        );
        if ($res && ($row = $res->fetch_assoc())) {
            $stats['last_attempt'] = $row;
        }
    } catch (Throwable $e) {
    }

    register_json_response(200, [
        'ok'           => true,
        'stats'        => $stats,
        'settings'     => api_settings_payload($Link),
        'thresholds'   => [
            'window_seconds'  => (int)register_setting_int($settings, 'rate_window_seconds', 300),
            'max_per_ip'      => (int)register_setting_int($settings, 'rate_max_per_ip', 5),
            'max_per_account' => (int)register_setting_int($settings, 'rate_max_per_account', 3),
            'max_per_ip_hour' => (int)register_setting_int($settings, 'rate_max_per_ip_hour', 20),
            'cooldown_seconds'=> (int)register_setting_int($settings, 'rate_cooldown_seconds', 300),
        ],
        'clock'        => api_db_clock($Link),
        'result_meta'  => register_result_meta(),
        'reason_labels'=> register_reason_labels(),
        'server_now'   => time(),
    ]);
}

function api_logs($Link)
{
    $result = (string)($_GET['result'] ?? 'all');
    $allowedResults = array_keys(register_result_meta());
    if ($result !== 'all' && !in_array($result, $allowedResults, true)) {
        $result = 'all';
    }
    $reason = (string)($_GET['reason'] ?? 'all');
    $allowedReasons = array_keys(register_reason_labels());
    if ($reason !== 'all' && !in_array($reason, $allowedReasons, true)) {
        $reason = 'all';
    }
    $range = (string)($_GET['range'] ?? 'today');
    if (!in_array($range, ['today', '7', '30', 'all'], true)) {
        $range = 'today';
    }
    $q = trim((string)($_GET['q'] ?? ''));
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = (int)($_GET['limit'] ?? 20);
    if ($limit < 1) { $limit = 20; }
    if ($limit > 100) { $limit = 100; }
    $offset = ($page - 1) * $limit;

    $where = " WHERE 1";
    $types = '';
    $params = [];
    if ($range === 'today') {
        $where .= " AND `created_at` >= CURDATE()";
    } elseif ($range === '7') {
        $where .= " AND `created_at` >= NOW() - INTERVAL 7 DAY";
    } elseif ($range === '30') {
        $where .= " AND `created_at` >= NOW() - INTERVAL 30 DAY";
    }
    if ($result !== 'all') {
        $where .= " AND `status` = ?";
        $types .= 's';
        $params[] = $result;
    }
    if ($reason !== 'all') {
        $where .= " AND `reason_code` = ?";
        $types .= 's';
        $params[] = $reason;
    }
    if ($q !== '') {
        $like = '%' . $q . '%';
        $where .= " AND (`username` LIKE ? OR `ip` LIKE ? OR `email` LIKE ?)";
        $types .= 'sss';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $total = 0;
    try {
        $stmt = $Link->prepare("SELECT COUNT(*) AS c FROM `register_log`" . $where);
        if ($types !== '') { $stmt->bind_param($types, ...$params); }
        $stmt->execute();
        $total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取紀錄失敗。']);
    }
    $pages = $total > 0 ? (int)ceil($total / $limit) : 0;
    if ($pages > 0 && $page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $limit;
    }

    $logs = [];
    try {
        $stmt = $Link->prepare(
            "SELECT `id`,`userid`,`username`,`email`,`ip`,`ip_forwarded`,`user_agent`,`status`,`reason_code`,`reason_text`,`created_at`
             FROM `register_log`" . $where . " ORDER BY `id` DESC LIMIT ? OFFSET ?"
        );
        $listTypes = $types . 'ii';
        $listParams = $params;
        $listParams[] = $limit;
        $listParams[] = $offset;
        $stmt->bind_param($listTypes, ...$listParams);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $logs[] = [
                'id'         => (int)$row['id'],
                'userid'     => (int)$row['userid'],
                'username'   => (string)$row['username'],
                'email'      => (string)$row['email'],
                'ip'         => (string)$row['ip'],
                'forwarded'  => (string)$row['ip_forwarded'],
                'ua'         => mb_substr((string)$row['user_agent'], 0, 512),
                'status'     => (string)$row['status'],
                'reason_code'=> (string)$row['reason_code'],
                'reason_text'=> (string)$row['reason_text'],
                'created_at' => (string)$row['created_at'],
            ];
        }
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取紀錄失敗。']);
    }

    register_json_response(200, [
        'ok'     => true,
        'logs'   => $logs,
        'total'  => $total,
        'page'   => $page,
        'pages'  => $pages,
        'result' => $result,
        'reason' => $reason,
        'range'  => $range,
        'q'      => $q,
        'result_meta'   => register_result_meta(),
        'reason_labels' => register_reason_labels(),
    ]);
}

function api_log_detail($Link)
{
    $id = (int)($_GET['id'] ?? 0);
    if ($id <= 0) {
        register_json_response(400, ['ok' => false, 'message' => '缺少紀錄編號。']);
    }
    try {
        $stmt = $Link->prepare(
            "SELECT `id`,`userid`,`username`,`email`,`ip`,`ip_forwarded`,`user_agent`,`accept_language`,`referer`,`status`,`reason_code`,`reason_text`,`created_at`
             FROM `register_log` WHERE `id` = ? LIMIT 1"
        );
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取紀錄失敗。']);
    }
    if (!$row) {
        register_json_response(404, ['ok' => false, 'message' => '找不到該筆紀錄。']);
    }
    $row['ua'] = mb_substr((string)$row['user_agent'], 0, 512);
    unset($row['user_agent']);
    $row['reason_label'] = register_reason_labels()[$row['reason_code']] ?? '';
    register_json_response(200, ['ok' => true, 'log' => $row]);
}

function api_settings($Link)
{
    register_json_response(200, [
        'ok'       => true,
        'settings' => api_settings_payload($Link),
    ]);
}

function api_save_settings($Link, $gmUsername, $clientIp)
{
    $input = [];
    foreach (register_setting_keys() as $key) {
        if (array_key_exists($key, $_POST)) {
            $input[$key] = $_POST[$key];
        }
    }
    // 核取方塊未送出時視為關閉
    if (!array_key_exists('register_enabled', $_POST)) {
        $input['register_enabled'] = '0';
    }
    $result = register_settings_save($Link, $input, $gmUsername, $clientIp);
    if (!$result['ok']) {
        register_json_response(422, ['ok' => false, 'message' => '設定儲存失敗。', 'errors' => $result['errors']]);
    }
    register_json_response(200, [
        'ok'       => true,
        'message'  => '設定已儲存並立即生效。',
        'settings' => api_settings_payload($Link),
    ]);
}

function api_blocks($Link)
{
    $scope = (string)($_GET['scope'] ?? 'all');
    if (!in_array($scope, ['all', 'ip', 'account'], true)) {
        $scope = 'all';
    }
    $status = (string)($_GET['status'] ?? 'active');
    if (!in_array($status, ['active', 'expired', 'released', 'all'], true)) {
        $status = 'active';
    }
    $q = trim((string)($_GET['q'] ?? ''));
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = (int)($_GET['limit'] ?? 20);
    if ($limit < 1) { $limit = 20; }
    if ($limit > 100) { $limit = 100; }
    $offset = ($page - 1) * $limit;

    $where = " WHERE 1";
    $types = '';
    $params = [];
    if ($scope !== 'all') {
        $where .= " AND `scope` = ?";
        $types .= 's';
        $params[] = $scope;
    }
    if ($status === 'active') {
        $where .= " AND `active` = 1 AND (`expires_at` IS NULL OR `expires_at` > NOW())";
    } elseif ($status === 'expired') {
        $where .= " AND `active` = 1 AND `expires_at` IS NOT NULL AND `expires_at` <= NOW()";
    } elseif ($status === 'released') {
        $where .= " AND `active` = 0";
    }
    if ($q !== '') {
        $like = '%' . $q . '%';
        $where .= " AND (`block_key` LIKE ? OR `reason` LIKE ?)";
        $types .= 'ss';
        $params[] = $like;
        $params[] = $like;
    }

    $total = 0;
    try {
        $stmt = $Link->prepare("SELECT COUNT(*) AS c FROM `register_blocks`" . $where);
        if ($types !== '') { $stmt->bind_param($types, ...$params); }
        $stmt->execute();
        $total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取封鎖名單失敗。']);
    }
    $pages = $total > 0 ? (int)ceil($total / $limit) : 0;
    if ($pages > 0 && $page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $limit;
    }

    $blocks = [];
    try {
        $stmt = $Link->prepare(
            "SELECT `id`,`scope`,`block_key`,`reason`,`source`,`active`,`created_by`,`created_at`,`expires_at`,`released_by`,`released_at`
             FROM `register_blocks`" . $where . " ORDER BY `id` DESC LIMIT ? OFFSET ?"
        );
        $listTypes = $types . 'ii';
        $listParams = $params;
        $listParams[] = $limit;
        $listParams[] = $offset;
        $stmt->bind_param($listTypes, ...$listParams);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $blocks[] = [
                'id'         => (int)$row['id'],
                'scope'      => (string)$row['scope'],
                'key'        => (string)$row['block_key'],
                'reason'     => (string)$row['reason'],
                'source'     => (string)$row['source'],
                'active'     => (int)$row['active'],
                'created_by' => (string)$row['created_by'],
                'created_at' => (string)$row['created_at'],
                'expires_at' => $row['expires_at'],
                'released_by'=> (string)$row['released_by'],
                'released_at'=> $row['released_at'],
            ];
        }
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取封鎖名單失敗。']);
    }

    register_json_response(200, [
        'ok'    => true,
        'blocks'=> $blocks,
        'total' => $total,
        'page'  => $page,
        'pages' => $pages,
        'scope' => $scope,
        'status'=> $status,
        'q'     => $q,
    ]);
}

function api_add_block($Link, $gmUsername, $clientIp)
{
    $scope = (string)($_POST['scope'] ?? 'ip');
    if (!in_array($scope, ['ip', 'account'], true)) {
        register_json_response(422, ['ok' => false, 'message' => '封鎖類型不正確。']);
    }
    $key = trim((string)($_POST['block_key'] ?? ''));
    if ($scope === 'ip') {
        if (!filter_var($key, FILTER_VALIDATE_IP)) {
            register_json_response(422, ['ok' => false, 'message' => '請輸入有效的 IP 位址。']);
        }
    } else {
        $key = strtolower($key);
        if ($key === '' || strlen($key) > 32 || !preg_match('/^[a-z0-9_-]+$/', $key)) {
            register_json_response(422, ['ok' => false, 'message' => '帳號格式不正確。']);
        }
    }
    $reason = mb_substr(trim((string)($_POST['reason'] ?? '')), 0, 255);
    $ttl = null; // 永久
    $ttlHours = (int)($_POST['ttl_hours'] ?? 0);
    if ($ttlHours > 0) {
        $ttl = min(365 * 24 * 3600, $ttlHours * 3600);
    }
    $id = register_block_add($Link, $scope, $key, $reason, 'manual', $ttl, $gmUsername);
    if ($id <= 0) {
        register_json_response(500, ['ok' => false, 'message' => '新增封鎖失敗。']);
    }
    register_admin_log($Link, $gmUsername, 'block_add', $scope . ':' . $key, 'reason=' . $reason . '; ttl_hours=' . $ttlHours, $clientIp);
    register_json_response(200, ['ok' => true, 'message' => '已新增封鎖。', 'id' => $id]);
}

function api_remove_block($Link, $gmUsername, $clientIp)
{
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        register_json_response(422, ['ok' => false, 'message' => '缺少封鎖編號。']);
    }
    // 先取得資訊供稽核
    $info = '';
    try {
        $stmt = $Link->prepare("SELECT `scope`,`block_key` FROM `register_blocks` WHERE `id` = ? LIMIT 1");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($row) {
            $info = $row['scope'] . ':' . $row['block_key'];
        }
    } catch (Throwable $e) {
    }
    if (!register_block_release($Link, $id, $gmUsername)) {
        register_json_response(404, ['ok' => false, 'message' => '找不到可解除的封鎖。']);
    }
    register_admin_log($Link, $gmUsername, 'block_release', $info, 'id=' . $id, $clientIp);
    register_json_response(200, ['ok' => true, 'message' => '已解除封鎖。']);
}

function api_admin_logs($Link)
{
    $filterAction = (string)($_GET['filter_action'] ?? 'all');
    $allowedActions = ['all', 'settings_update', 'block_add', 'block_release', 'purge_logs', 'view_overview'];
    if (!in_array($filterAction, $allowedActions, true)) {
        $filterAction = 'all';
    }
    $q = trim((string)($_GET['q'] ?? ''));
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = (int)($_GET['limit'] ?? 20);
    if ($limit < 1) { $limit = 20; }
    if ($limit > 100) { $limit = 100; }
    $offset = ($page - 1) * $limit;

    $where = " WHERE 1";
    $types = '';
    $params = [];
    if ($filterAction !== 'all') {
        $where .= " AND `action` = ?";
        $types .= 's';
        $params[] = $filterAction;
    }
    if ($q !== '') {
        $like = '%' . $q . '%';
        $where .= " AND (`gm_username` LIKE ? OR `target` LIKE ? OR `detail` LIKE ?)";
        $types .= 'sss';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $total = 0;
    try {
        $stmt = $Link->prepare("SELECT COUNT(*) AS c FROM `register_admin_logs`" . $where);
        if ($types !== '') { $stmt->bind_param($types, ...$params); }
        $stmt->execute();
        $total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取操作紀錄失敗。']);
    }
    $pages = $total > 0 ? (int)ceil($total / $limit) : 0;
    if ($pages > 0 && $page > $pages) {
        $page = $pages;
        $offset = ($page - 1) * $limit;
    }

    $logs = [];
    try {
        $stmt = $Link->prepare(
            "SELECT `id`,`gm_username`,`action`,`target`,`detail`,`ip`,`created_at`
             FROM `register_admin_logs`" . $where . " ORDER BY `id` DESC LIMIT ? OFFSET ?"
        );
        $listTypes = $types . 'ii';
        $listParams = $params;
        $listParams[] = $limit;
        $listParams[] = $offset;
        $stmt->bind_param($listTypes, ...$listParams);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) {
            $logs[] = [
                'id'          => (int)$row['id'],
                'gm_username' => (string)$row['gm_username'],
                'action'      => (string)$row['action'],
                'target'      => (string)$row['target'],
                'detail'      => (string)$row['detail'],
                'ip'          => (string)$row['ip'],
                'created_at'  => (string)$row['created_at'],
            ];
        }
        $stmt->close();
    } catch (Throwable $e) {
        register_json_response(500, ['ok' => false, 'message' => '讀取操作紀錄失敗。']);
    }

    register_json_response(200, [
        'ok'     => true,
        'logs'   => $logs,
        'total'  => $total,
        'page'   => $page,
        'pages'  => $pages,
        'filter_action' => $filterAction,
        'q'      => $q,
    ]);
}

function api_purge_logs($Link, $gmUsername, $clientIp)
{
    $days = (int)($_POST['days'] ?? 0);
    if ($days < 1 || $days > 3650) {
        register_json_response(422, ['ok' => false, 'message' => '請輸入 1-3650 的保留天數。']);
    }
    $batch = (int)($_POST['batch'] ?? 1000);
    $out = register_purge($Link, $days, $batch);
    register_admin_log($Link, $gmUsername, 'purge_logs', 'register_log', 'days=' . $days . '; logs=' . $out['logs'] . '; rate=' . $out['rate'], $clientIp);
    register_json_response(200, [
        'ok'      => true,
        'message' => '已清理 ' . $out['logs'] . ' 筆註冊紀錄與 ' . $out['rate'] . ' 筆限流計數（單批）。',
        'purged'  => $out,
    ]);
}
