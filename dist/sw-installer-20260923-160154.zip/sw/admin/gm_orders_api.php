<?php
/**
 * ==============================================================
 *  GM 訂單管理 API（JSON）
 *  - GET  ：列出訂單、狀態篩選、關鍵字搜尋、分頁與統計報表
 *  - POST ：更新單筆訂單（狀態、金額、點數、交易編號、備註）
 *          可選擇同時為會員入帳元寶（僅在由非付款狀態改為已付款時執行）
 *
 *  僅限已登入 GM 控制台的使用者存取。
 * ==============================================================
 */
session_start();
@include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../ecpay_config.php';
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['gm_username']) || $_SESSION['gm_username'] === '') {
    http_response_code(401);
    echo json_encode(['ok' => false, 'message' => '請先登入 GM 控制台。'], JSON_UNESCAPED_UNICODE);
    exit();
}

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'message' => '資料庫連線失敗。'], JSON_UNESCAPED_UNICODE);
    exit();
}
mysqli_set_charset($Link, 'utf8');

$allowedStatus = ['pending', 'paid', 'failed', 'expired', 'cancelled'];

/**
 * 依期間代碼計算查詢範圍。
 * 回傳 [起始日 Y-m-d, 結束日(不含) Y-m-d]；'all' 或無效期間回傳 null。
 */
function order_period_range($period, $from = '', $to = '')
{
    $today = date('Y-m-d');
    switch ($period) {
        case 'today':
            return [$today, date('Y-m-d', strtotime($today . ' +1 day'))];
        case 'yesterday':
            return [date('Y-m-d', strtotime($today . ' -1 day')), $today];
        case 'this_week':
            $monday = date('Y-m-d', strtotime('monday this week', strtotime($today)));
            return [$monday, date('Y-m-d', strtotime($monday . ' +7 day'))];
        case 'last_week':
            $monday = date('Y-m-d', strtotime('monday last week', strtotime($today)));
            return [$monday, date('Y-m-d', strtotime($monday . ' +7 day'))];
        case 'this_month':
            return [date('Y-m-01'), date('Y-m-01', strtotime('first day of next month'))];
        case 'last_month':
            return [date('Y-m-01', strtotime('first day of last month')), date('Y-m-01')];
        case 'custom':
            $f = preg_match('/^\d{4}-\d{2}-\d{2}$/', $from) ? $from : '';
            $t = preg_match('/^\d{4}-\d{2}-\d{2}$/', $to) ? $to : '';
            if ($f === '' && $t === '') {
                return null;
            }
            $start = ($f !== '') ? $f : '1970-01-01';
            $end   = ($t !== '') ? date('Y-m-d', strtotime($t . ' +1 day')) : date('Y-m-d', strtotime('+1 day'));
            if (strtotime($end) <= strtotime($start)) {
                $end = date('Y-m-d', strtotime($start . ' +1 day'));
            }
            return [$start, $end];
        default:
            return null;
    }
}

$token = (string)($_POST['form_token'] ?? $_GET['form_token'] ?? '');
$csrfOk = isset($_SESSION['form_token']) && hash_equals((string)$_SESSION['form_token'], $token);

/* ----------------------------- POST：更新訂單 ----------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$csrfOk) {
        echo json_encode(['ok' => false, 'message' => '工作階段已過期，請重新整理後再試。'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $action = (string)($_POST['action'] ?? '');

    /* 批次更新多筆訂單 */
    if ($action === 'batch_update') {
        $orderNos = $_POST['order_nos'] ?? [];
        if (!is_array($orderNos) || empty($orderNos)) {
            echo json_encode(['ok' => false, 'message' => '請先選擇要處理的訂單。'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $newStatus = in_array(($_POST['status'] ?? ''), $allowedStatus, true) ? $_POST['status'] : '';
        if ($newStatus === '') {
            echo json_encode(['ok' => false, 'message' => '請選擇有效的目標狀態。'], JSON_UNESCAPED_UNICODE);
            exit();
        }
        $doCredit = ((int)($_POST['credit'] ?? 0) === 1);

        $sel = $Link->prepare("SELECT `id`, `uid`, `status`, `total_points` FROM `recharge_orders` WHERE `order_no` = ? LIMIT 1");
        $updSql = "UPDATE `recharge_orders` SET `status` = ?, `updated_at` = NOW()"
                . ($newStatus === 'paid' ? ", `paid_at` = IFNULL(`paid_at`, NOW())" : "")
                . " WHERE `id` = ?";
        $upd = $Link->prepare($updSql);

        $updated = 0;
        $credited = 0;
        $seen = [];
        foreach ($orderNos as $ono) {
            $ono = trim((string)$ono);
            if ($ono === '' || isset($seen[$ono])) {
                continue;
            }
            $seen[$ono] = true;
            $sel->bind_param("s", $ono);
            $sel->execute();
            $o = $sel->get_result()->fetch_assoc();
            if (!$o) {
                continue;
            }
            $becomesPaid = ($newStatus === 'paid' && $o['status'] !== 'paid');
            $upd->bind_param("si", $newStatus, $o['id']);
            if ($upd->execute()) {
                $updated++;
            }
            if ($doCredit && $becomesPaid && (int)$o['uid'] > 0 && (int)$o['total_points'] > 0) {
                if (recharge_credit_points($Link, (int)$o['uid'], (int)$o['total_points'])) {
                    $credited++;
                }
            }
        }
        $sel->close();
        $upd->close();

        $msg = '已批次處理 ' . $updated . ' 筆訂單。';
        if ($credited > 0) {
            $msg .= ' 並為 ' . $credited . ' 筆訂單完成點數入帳。';
        }
        echo json_encode(['ok' => true, 'message' => $msg, 'updated' => $updated, 'credited' => $credited], JSON_UNESCAPED_UNICODE);
        mysqli_close($Link);
        exit();
    }

    if ($action !== 'update_order') {
        echo json_encode(['ok' => false, 'message' => '不支援的操作。'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $orderNo = trim((string)($_POST['order_no'] ?? ''));
    if ($orderNo === '') {
        echo json_encode(['ok' => false, 'message' => '缺少訂單編號。'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $stmt = $Link->prepare("SELECT `id`, `uid`, `status`, `total_points` FROM `recharge_orders` WHERE `order_no` = ? LIMIT 1");
    $stmt->bind_param("s", $orderNo);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$order) {
        echo json_encode(['ok' => false, 'message' => '找不到該訂單。'], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $oldStatus    = $order['status'];
    $newStatus    = in_array(($_POST['status'] ?? ''), $allowedStatus, true) ? $_POST['status'] : $oldStatus;
    $amount       = max(0, (int)($_POST['amount'] ?? 0));
    $bonus        = max(0, (int)($_POST['bonus'] ?? 0));
    $totalPoints  = max(0, (int)($_POST['total_points'] ?? 0));
    $tradeNo      = mb_substr(trim((string)($_POST['trade_no'] ?? '')), 0, 20);
    $rtnMsg       = mb_substr(trim((string)($_POST['rtn_msg'] ?? '')), 0, 200);
    $doCredit     = ((int)($_POST['credit'] ?? 0) === 1);

    $becomesPaid = ($newStatus === 'paid' && $oldStatus !== 'paid');

    $sql = "UPDATE `recharge_orders`
               SET `status` = ?, `amount` = ?, `bonus` = ?, `total_points` = ?,
                   `trade_no` = ?, `rtn_msg` = ?, `updated_at` = NOW()"
         . ($becomesPaid ? ", `paid_at` = NOW()" : "")
         . " WHERE `id` = ?";
    $stmt = $Link->prepare($sql);
    $stmt->bind_param("siiiissi", $newStatus, $amount, $bonus, $totalPoints, $tradeNo, $rtnMsg, $order['id']);
    $ok = $stmt->execute();
    $stmt->close();

    if (!$ok) {
        echo json_encode(['ok' => false, 'message' => '訂單更新失敗：' . mysqli_error($Link)], JSON_UNESCAPED_UNICODE);
        exit();
    }

    $credited = false;
    if ($doCredit && $becomesPaid && (int)$order['uid'] > 0 && $totalPoints > 0) {
        $credited = recharge_credit_points($Link, (int)$order['uid'], $totalPoints);
    }

    echo json_encode([
        'ok'       => true,
        'message'  => '訂單已更新。' . ($credited ? ' 並已為會員入帳 ' . number_format($totalPoints) . ' 點數。' : ''),
        'credited' => $credited,
    ], JSON_UNESCAPED_UNICODE);
    mysqli_close($Link);
    exit();
}

/* ----------------------------- GET：列表 + 統計 ----------------------------- */
recharge_expire_overdue_orders($Link, 0);

$status = (string)($_GET['status'] ?? 'all');
if ($status !== 'all' && !in_array($status, $allowedStatus, true)) {
    $status = 'all';
}
$q      = trim((string)($_GET['q'] ?? ''));
$uid    = (int)($_GET['uid'] ?? 0); // >0 時僅列出該會員的訂單
$page   = max(1, (int)($_GET['page'] ?? 1));
$limit  = (int)($_GET['limit'] ?? 10);
if ($limit < 1)  { $limit = 10; }
if ($limit > 50) { $limit = 50; }
$offset = ($page - 1) * $limit;

// 期間營收範圍
$period   = (string)($_GET['period'] ?? 'all');
$dateFrom = trim((string)($_GET['date_from'] ?? ''));
$dateTo   = trim((string)($_GET['date_to'] ?? ''));
$range    = order_period_range($period, $dateFrom, $dateTo);

$periodWhere  = "";
$periodTypes  = "";
$periodParams = [];
if ($range !== null) {
    $periodWhere  = " AND `created_at` >= ? AND `created_at` < ?";
    $periodTypes  = "ss";
    $periodParams = [$range[0] . ' 00:00:00', $range[1] . ' 00:00:00'];
}

$where  = "1";
$types  = "";
$params = [];
if ($status !== 'all') {
    $where .= " AND `status` = ?";
    $types .= "s";
    $params[] = $status;
}
if ($q !== '') {
    $where .= " AND (`order_no` LIKE ? OR `username` LIKE ? OR `trade_no` LIKE ?)";
    $like = '%' . $q . '%';
    $types .= "sss";
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}
if ($uid > 0) {
    $where .= " AND `uid` = ?";
    $types .= "i";
    $params[] = $uid;
}
$where .= $periodWhere;
$types .= $periodTypes;
$params = array_merge($params, $periodParams);

// 篩選後總筆數
$countSql = "SELECT COUNT(*) AS c FROM `recharge_orders` WHERE $where";
$stmt = $Link->prepare($countSql);
if ($types !== '') {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
$stmt->close();
$pages = $total > 0 ? (int)ceil($total / $limit) : 0;
if ($page > $pages && $pages > 0) {
    $page = $pages;
    $offset = ($page - 1) * $limit;
}

// 列表
$listSql = "SELECT `id`, `order_no`, `uid`, `username`, `method_key`, `method_name`, `choose_payment`,
                   `amount`, `bonus`, `total_points`, `status`, `rtn_code`, `rtn_msg`, `trade_no`,
                   `payment_type`, `paid_at`, `created_at`
              FROM `recharge_orders`
             WHERE $where
             ORDER BY `id` DESC
             LIMIT ? OFFSET ?";
$stmt = $Link->prepare($listSql);
$listTypes = $types . "ii";
$listParams = $params;
$listParams[] = $limit;
$listParams[] = $offset;
$stmt->bind_param($listTypes, ...$listParams);
$stmt->execute();
$res = $stmt->get_result();
$orders = [];
while ($row = $res->fetch_assoc()) {
    $orders[] = [
        'order_no'     => $row['order_no'],
        'uid'          => (int)$row['uid'],
        'username'     => $row['username'],
        'method_key'   => $row['method_key'],
        'method_name'  => $row['method_name'],
        'choose_payment' => $row['choose_payment'],
        'amount'       => (int)$row['amount'],
        'bonus'        => (int)$row['bonus'],
        'total_points' => (int)$row['total_points'],
        'status'       => $row['status'],
        'rtn_code'     => $row['rtn_code'],
        'rtn_msg'      => $row['rtn_msg'],
        'trade_no'     => $row['trade_no'],
        'payment_type' => $row['payment_type'],
        'paid_at'      => $row['paid_at'],
        'created_at'   => $row['created_at'],
    ];
}
$stmt->close();

// 營運報表統計（依期間，不受狀態/搜尋篩選影響）
$statsSql = "SELECT COUNT(*) AS cnt,
            SUM(`status` = 'pending')   AS pending_count,
            SUM(`status` = 'paid')      AS paid_count,
            SUM(`status` = 'failed')    AS failed_count,
            SUM(`status` = 'expired')   AS expired_count,
            SUM(`status` = 'cancelled') AS cancelled_count,
            SUM(CASE WHEN `status` = 'paid' THEN `amount` ELSE 0 END)       AS paid_amount,
            SUM(CASE WHEN `status` = 'paid' THEN `total_points` ELSE 0 END) AS paid_points
       FROM `recharge_orders`
      WHERE 1" . ($uid > 0 ? " AND `uid` = ?" : "") . $periodWhere;
$stmt = $Link->prepare($statsSql);
$statsTypes = ($uid > 0 ? "i" : "") . $periodTypes;
$statsParams = $periodParams;
if ($uid > 0) {
    array_unshift($statsParams, $uid);
}
if ($statsTypes !== '') {
    $stmt->bind_param($statsTypes, ...$statsParams);
}
$stmt->execute();
$stat = $stmt->get_result()->fetch_assoc();
$stmt->close();

$rangeDisplayFrom = $range ? $range[0] : '';
$rangeDisplayTo   = $range ? date('Y-m-d', strtotime($range[1] . ' -1 day')) : '';

mysqli_close($Link);

echo json_encode([
    'ok'         => true,
    'orders'     => $orders,
    'total'      => $total,
    'page'       => $page,
    'pages'      => $pages,
    'server_now' => time(),
    'period'     => $period,
    'uid_filter' => $uid,
    'date_from'  => $rangeDisplayFrom,
    'date_to'    => $rangeDisplayTo,
    'stats'      => [
        'count'           => (int)($stat['cnt'] ?? 0),
        'pending_count'   => (int)($stat['pending_count'] ?? 0),
        'paid_count'      => (int)($stat['paid_count'] ?? 0),
        'failed_count'    => (int)($stat['failed_count'] ?? 0),
        'expired_count'   => (int)($stat['expired_count'] ?? 0),
        'cancelled_count' => (int)($stat['cancelled_count'] ?? 0),
        'paid_amount'     => (int)($stat['paid_amount'] ?? 0),
        'paid_points'     => (int)($stat['paid_points'] ?? 0),
    ],
], JSON_UNESCAPED_UNICODE);
