<?php
/**
 * =============================================================
 *  踏雪笑傲 · 後台「帳號層級管理」JSON API
 *  - 需以 GM 帳號登入（沿用 gm_accounts / $_SESSION['gm_username']）。
 *  - 讀取使用 GET；變更操作僅接受 POST 並驗證 CSRF（form_token）。
 *  - 所有查詢使用參數化；不回傳資料庫錯誤或堆疊。
 * =============================================================
 */
require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../account_tiers.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex');

function tier_api_reply($http, array $payload)
{
    http_response_code($http);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit();
}

if (!isset($_SESSION['gm_username']) || $_SESSION['gm_username'] === '') {
    tier_api_reply(401, ['ok' => false, 'message' => '請先登入 GM 控制台。']);
}
$gmUsername = (string)$_SESSION['gm_username'];
app_session_enforce_timeout(60 * 60 * 8);

$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    tier_api_reply(500, ['ok' => false, 'message' => '資料庫連線失敗。']);
}
mysqli_set_charset($Link, 'utf8mb4');
account_tier_ensure_tables($Link);

$action = (string)($_REQUEST['action'] ?? 'list');
$isPost = ($_SERVER['REQUEST_METHOD'] === 'POST');
$mutating = ['save', 'delete', 'assign'];
if (in_array($action, $mutating, true)) {
    if (!$isPost) {
        tier_api_reply(405, ['ok' => false, 'message' => '此操作僅接受 POST。']);
    }
    $token = (string)($_POST['form_token'] ?? '');
    if (empty($_SESSION['form_token']) || !hash_equals((string)$_SESSION['form_token'], $token)) {
        tier_api_reply(403, ['ok' => false, 'message' => '安全權杖失效，請重新整理頁面。']);
    }
}

/* ----------------------------- 列表 ----------------------------- */
if ($action === 'list') {
    $tiers = account_tiers_load_all($Link, false);
    // 各層級會員數
    $counts = [];
    try {
        $res = $Link->query("SELECT `tier_id`, COUNT(*) AS c FROM `user_tiers` GROUP BY `tier_id`");
        if ($res) {
            while ($row = $res->fetch_assoc()) {
                $counts[(int)$row['tier_id']] = (int)$row['c'];
            }
        }
    } catch (Throwable $e) {
    }
    $out = [];
    foreach ($tiers as $t) {
        $out[] = [
            'id'           => (int)$t['id'],
            'code'         => (string)$t['code'],
            'name'         => (string)$t['name'],
            'icon'         => (string)$t['icon'],
            'color'        => (string)$t['color'],
            'rank'         => (int)$t['rank'],
            'description'  => (string)$t['description'],
            'enabled'      => (int)$t['enabled'],
            'sort_order'   => (int)$t['sort_order'],
            'member_count' => $counts[(int)$t['id']] ?? 0,
            'updated_at'   => (string)$t['updated_at'],
        ];
    }
    // 會員總數（供參考）
    $totalMembers = 0;
    try {
        $r = $Link->query("SELECT COUNT(*) AS c FROM `user_tiers`");
        if ($r) { $totalMembers = (int)($r->fetch_assoc()['c'] ?? 0); }
    } catch (Throwable $e) {
    }
    tier_api_reply(200, ['ok' => true, 'tiers' => $out, 'assigned_members' => $totalMembers]);
}

/* ----------------------------- 新增／編輯 ----------------------------- */
if ($action === 'save') {
    $id = (int)($_POST['id'] ?? 0);
    $data = [
        'code'        => (string)($_POST['code'] ?? ''),
        'name'        => (string)($_POST['name'] ?? ''),
        'icon'        => (string)($_POST['icon'] ?? 'fa-user'),
        'color'       => (string)($_POST['color'] ?? '#64748b'),
        'rank'        => (int)($_POST['rank'] ?? 0),
        'description' => (string)($_POST['description'] ?? ''),
        'enabled'     => ((string)($_POST['enabled'] ?? '0') === '1') ? 1 : 0,
        'sort_order'  => (int)($_POST['sort_order'] ?? 0),
    ];
    $res = account_tier_save($Link, $data, $id, $gmUsername);
    if (!$res['ok']) {
        tier_api_reply(422, ['ok' => false, 'message' => '層級儲存失敗。', 'errors' => $res['errors']]);
    }
    tier_api_reply(200, ['ok' => true, 'id' => $res['id'], 'message' => ($id > 0 ? '層級已更新。' : '已新增層級。')]);
}

/* ----------------------------- 刪除 ----------------------------- */
if ($action === 'delete') {
    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        tier_api_reply(422, ['ok' => false, 'message' => '缺少層級編號。']);
    }
    if (!account_tier_delete($Link, $id)) {
        tier_api_reply(500, ['ok' => false, 'message' => '刪除失敗，請稍後再試。']);
    }
    tier_api_reply(200, ['ok' => true, 'message' => '層級已刪除，相關會員將回到預設層級。']);
}

/* ----------------------------- 指派會員層級 ----------------------------- */
if ($action === 'assign') {
    $uid = (int)($_POST['uid'] ?? 0);
    $tierId = (int)($_POST['tier_id'] ?? 0);
    if ($uid <= 0) {
        tier_api_reply(422, ['ok' => false, 'message' => '缺少會員編號。']);
    }
    if ($tierId > 0 && !account_tiers_get($Link, $tierId)) {
        tier_api_reply(422, ['ok' => false, 'message' => '指定的層級不存在。']);
    }
    if (!account_tier_assign($Link, $uid, $tierId, $gmUsername)) {
        tier_api_reply(500, ['ok' => false, 'message' => '指派失敗，請稍後再試。']);
    }
    $tier = account_tier_for_user($Link, $uid);
    tier_api_reply(200, ['ok' => true, 'message' => '已更新會員層級。', 'tier' => $tier]);
}

tier_api_reply(400, ['ok' => false, 'message' => '未知的操作。']);
