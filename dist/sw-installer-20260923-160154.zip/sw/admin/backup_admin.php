<?php
/**
 * =============================================================
 *  踏雪笑傲 · 自動備份系統（後台）
 *  -------------------------------------------------------------
 *  功能：
 *    - 全站資料庫完整備份（優先使用 mysqldump，找不到時改用純 PHP 匯出）
 *    - 備份歷程記錄、即時下載、一鍵還原
 *    - 保留份數限制、自動備份頻率設定（自動於到達週期時觸發）
 *  入口：admin/gmpanel.php「系統備份」按鈕，或 admin/backup_admin.php
 *  備份存放：admin/backups（以 .htaccess 禁止外部直接存取）
 * =============================================================
 */

require_once __DIR__ . '/../session_bootstrap.php';
app_session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/backup_lib.php';

/* 需以 GM 身分登入 */
if (!isset($_SESSION['gm_username'])) {
    header('Location: gmlogin.php');
    exit();
}
app_session_enforce_timeout(60 * 60 * 8);
$currentGm = (string)$_SESSION['gm_username'];

if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['form_token'];

/* ---------------- 連線資料庫 ---------------- */
$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    http_response_code(500);
    exit('系統暫時無法使用：無法連線資料庫。');
}
mysqli_set_charset($Link, 'utf8');

bk_ensure_dir();

/* ---------------- 偵測伺服器上所有資料庫 ---------------- */
$allDatabases = bk_list_databases($Link);

/** 由設定取得目前選定的資料庫（過濾不存在者，必要時回退預設資料庫） */
function bk_selected_from_settings($allDatabases)
{
    $s = bk_settings();
    $dbs = bk_normalize_databases($s['databases'] ?? [], $allDatabases);
    if (empty($dbs)) {
        $dbs = bk_normalize_databases([(string)($GLOBALS['DBName'] ?? '')], $allDatabases);
    }
    if (empty($dbs) && !empty($allDatabases)) {
        $dbs = [(string)$allDatabases[0]['name']];
    }
    return $dbs;
}

$selectedDbs = bk_selected_from_settings($allDatabases);

$notice = '';
$noticeType = 'ok';

/* ---------------- 下載備份 ---------------- */
if (($_GET['action'] ?? '') === 'download') {
    $rec = bk_find((string)($_GET['id'] ?? ''));
    $want = (string)($_GET['f'] ?? '');
    $target = null;
    if ($rec) {
        foreach (bk_record_files($rec) as $f) {
            if (($f['status'] ?? 'success') !== 'success' || $f['file'] === '') {
                continue;
            }
            if ($want === '' || (string)$f['file'] === $want) {
                $target = $f;
                break;
            }
        }
    }
    if (!$target) {
        http_response_code(404);
        exit('找不到備份檔案。');
    }
    $path = BK_DIR . '/' . basename((string)$target['file']);
    if (!is_file($path)) {
        http_response_code(404);
        exit('備份檔案已不存在。');
    }
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Content-Type: application/gzip');
    header('Content-Disposition: attachment; filename="' . basename((string)$target['file']) . '"');
    header('Content-Length: ' . filesize($path));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    readfile($path);
    exit();
}

/* ---------------- 表單動作 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postedToken = (isset($_POST['form_token']) && is_string($_POST['form_token'])) ? $_POST['form_token'] : '';
    if ($postedToken === '' || !hash_equals((string)$_SESSION['form_token'], $postedToken)) {
        $notice = '工作階段已過期，請重新整理後再試。';
        $noticeType = 'err';
    } else {
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'save_settings') {
            $settings = bk_settings();
            $settings['enabled'] = isset($_POST['enabled']) ? 1 : 0;
            $settings['interval_value'] = max(1, (int)($_POST['interval_value'] ?? 1));
            $unit = (string)($_POST['interval_unit'] ?? 'days');
            $settings['interval_unit'] = in_array($unit, ['minutes', 'hours', 'days'], true) ? $unit : 'days';
            $settings['retention'] = max(1, min(100, (int)($_POST['retention'] ?? 10)));
            $pickedDbs = bk_normalize_databases($_POST['databases'] ?? [], $allDatabases);
            if (empty($pickedDbs)) {
                $notice = '請至少勾選一個要備份的資料庫。';
                $noticeType = 'err';
            } else {
                $settings['databases'] = $pickedDbs;
                if (isset($_POST['reset_schedule'])) {
                    $settings['last_auto_run'] = 0;
                }
                if (bk_save_settings($settings)) {
                    $selectedDbs = $pickedDbs;
                    $notice = '設定已儲存（資料庫 ' . count($pickedDbs) . ' 個、' . bk_interval_label($settings)
                        . '、保留 ' . $settings['retention'] . ' 份）。';
                } else {
                    $notice = '設定儲存失敗，請確認備份目錄寫入權限。';
                    $noticeType = 'err';
                }
            }
        } elseif ($action === 'backup_now') {
            set_time_limit(0);
            try {
                $rec = bk_run_backup($Link, 'manual', bk_selected_from_settings($allDatabases));
            } catch (Throwable $e) {
                $rec = ['status' => 'failed', 'message' => $e->getMessage()];
            }
            $recStatus = (string)($rec['status'] ?? 'failed');
            if ($recStatus === 'success' || $recStatus === 'partial') {
                $fileCount = count(bk_record_files($rec));
                $notice = ($recStatus === 'partial' ? '部分備份完成：' : '備份完成：')
                    . $fileCount . ' 個資料庫已建立獨立 SQL 檔（' . bk_format_bytes($rec['size'] ?? 0)
                    . '，共 ' . (int)($rec['tables'] ?? 0) . ' 張資料表，耗時 ' . ($rec['duration'] ?? 0) . ' 秒）';
                if (!empty($rec['message'])) {
                    $notice .= '；' . $rec['message'];
                }
                if ($recStatus === 'partial') {
                    $noticeType = 'err';
                }
            } else {
                $notice = '備份失敗：' . ($rec['message'] ?? '未知錯誤');
                $noticeType = 'err';
            }
        } elseif ($action === 'delete') {
            $id = (string)($_POST['id'] ?? '');
            $rec = bk_find($id);
            if (!$rec) {
                $notice = '找不到該筆備份記錄。';
                $noticeType = 'err';
            } else {
                bk_delete_record_files($rec);
                $history = array_values(array_filter(bk_history(), function ($h) use ($id) {
                    return ($h['id'] ?? '') !== $id;
                }));
                bk_save_history($history);
                $notice = '已刪除備份檔與歷程記錄。';
            }
        } elseif ($action === 'restore') {
            $id = (string)($_POST['id'] ?? '');
            $onlyFile = (string)($_POST['file'] ?? '');
            $rec = bk_find($id);
            if (!$rec || empty(bk_record_files($rec))) {
                $notice = '找不到可還原的備份記錄。';
                $noticeType = 'err';
            } else {
                set_time_limit(0);
                try {
                    $res = bk_restore_record($Link, $rec, $onlyFile !== '' ? $onlyFile : null);
                } catch (Throwable $e) {
                    $res = [false, $e->getMessage()];
                }
                if ($res[0]) {
                    $notice = ($onlyFile !== '' ? '所選資料庫已' : '全部資料庫已')
                        . '成功還原至備份「' . $rec['created_at'] . '」。';
                } else {
                    $notice = $res[1];
                    $noticeType = 'err';
                }
            }
        }

        $_SESSION['form_token'] = bin2hex(random_bytes(32));
        $formToken = $_SESSION['form_token'];
    }
}

/* ---------------- 自動備份排程檢查（瀏覽後台時觸發） ---------------- */
$autoRan = null;
if ($_SERVER['REQUEST_METHOD'] === 'GET' && !isset($_GET['action'])) {
    $scheduleSettings = bk_settings();
    if (!empty($scheduleSettings['enabled'])) {
        $interval = bk_interval_seconds($scheduleSettings);
        $last = (int)($scheduleSettings['last_auto_run'] ?? 0);
        if (time() - $last >= $interval) {
            $scheduleSettings['last_auto_run'] = time();
            bk_save_settings($scheduleSettings);
            set_time_limit(0);
            try {
                $autoRan = bk_run_backup($Link, 'auto', bk_selected_from_settings($allDatabases));
            } catch (Throwable $e) {
                $autoRan = ['status' => 'failed', 'message' => $e->getMessage()];
            }
        }
    }
}

/* ---------------- 彙整顯示資料 ---------------- */
$settings = bk_settings();
$history = bk_history();
$selectedDbs = bk_selected_from_settings($allDatabases);
$dbInfo = bk_databases_info($Link, $selectedDbs);
$totalDbs = count($allDatabases);

$successList = array_values(array_filter($history, function ($h) {
    return in_array(($h['status'] ?? ''), ['success', 'partial'], true);
}));
$successCount = count($successList);
$latest = $successList[0] ?? null;
$totalSize = 0.0;
foreach ($successList as $h) {
    $totalSize += (float)($h['size'] ?? 0);
}

$nextRunAt = null;
if (!empty($settings['enabled'])) {
    $last = (int)($settings['last_auto_run'] ?? 0);
    $nextRunAt = max(time(), $last + bk_interval_seconds($settings));
}

$methodLabel = ['mysqldump' => 'mysqldump 引擎', 'php' => 'PHP 內建匯出'];
$activeEngine = (bk_find_binary('dump') && bk_can_exec()) ? 'mysqldump' : 'php';
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>自動備份系統 · 踏雪笑傲 後台</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Noto+Serif+TC:wght@400;600;700;900&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/backup-admin.css">
</head>
<body class="bk-body">

<header class="bk-top">
  <div class="bk-top__inner">
    <div class="bk-brand">
      <div class="bk-brand__logo"><i class="fa-solid fa-database"></i></div>
      <div>
        <div class="bk-brand__name">自動備份系統</div>
        <div class="bk-brand__sub">Auto Backup Center</div>
      </div>
    </div>
    <div class="bk-actions">
      <span class="bk-badge"><i class="fa-solid fa-hard-drive"></i> 偵測到 <?= (int)$totalDbs ?> 個資料庫 · 已選 <?= (int)count($selectedDbs) ?> 個</span>
      <a class="bk-btn bk-btn--ghost" href="gmpanel.php"><i class="fa-solid fa-arrow-left"></i> 返回管理後台首頁</a>
      <a class="bk-btn bk-btn--dark" href="gmlogout.php"><i class="fa-solid fa-right-from-bracket"></i> 登出</a>
    </div>
  </div>
</header>

<div class="bk-wrap">

  <div class="bk-hero">
    <div>
      <h1 class="bk-h1">全站資料庫 · 自動備份中心</h1>
      <p>自動偵測伺服器上所有資料庫，可勾選要備份的範圍；一鍵備份、保存歷程、即時下載與還原。可設定自動備份週期與保留份數，系統將於週期到期後自動執行。</p>
    </div>
    <div class="bk-badge"><i class="fa-solid fa-user-shield"></i> 操作者：<?= bk_h($currentGm) ?></div>
  </div>

  <?php if ($notice !== ''): ?>
  <div class="bk-notice <?= $noticeType === 'err' ? 'bk-notice--err' : '' ?>">
    <i class="fa-solid <?= $noticeType === 'err' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <span><?= bk_h($notice) ?></span>
  </div>
  <?php endif; ?>

  <?php if ($autoRan !== null): $autoOk = in_array(($autoRan['status'] ?? ''), ['success', 'partial'], true); ?>
  <div class="bk-notice <?= $autoOk && ($autoRan['status'] ?? '') === 'success' ? '' : 'bk-notice--err' ?>">
    <i class="fa-solid fa-rotate"></i>
    <span>
      <?php if ($autoOk): ?>
        自動備份已執行：<?= (int)count(bk_record_files($autoRan)) ?> 個資料庫（<?= bk_h(bk_format_bytes($autoRan['size'] ?? 0)) ?>）<?= !empty($autoRan['message']) ? '，' . bk_h($autoRan['message']) : '' ?>
      <?php else: ?>
        自動備份執行失敗：<?= bk_h($autoRan['message'] ?? '未知錯誤') ?>
      <?php endif; ?>
    </span>
  </div>
  <?php endif; ?>

  <!-- 統計 -->
  <div class="bk-stats">
    <div class="bk-stat" style="--accent:#38bdf8;">
      <div class="bk-stat__icon"><i class="fa-solid fa-box-archive"></i></div>
      <div class="bk-stat__label">備份總數</div>
      <div class="bk-stat__value"><?= (int)$successCount ?> <span style="font-size:12px;color:#64748b;">份</span></div>
      <div class="bk-stat__hint">保留上限 <?= (int)$settings['retention'] ?> 份</div>
    </div>
    <div class="bk-stat" style="--accent:#10b981;">
      <div class="bk-stat__icon"><i class="fa-solid fa-clock-rotate-left"></i></div>
      <div class="bk-stat__label">最新備份</div>
      <div class="bk-stat__value" style="font-size:16px;"><?= $latest ? bk_h($latest['created_at']) : '尚無備份' ?></div>
      <div class="bk-stat__hint"><?= $latest ? bk_h(bk_format_bytes($latest['size'])) . ' · ' . bk_h($methodLabel[$latest['method']] ?? $latest['method']) : '請點擊右側立即備份' ?></div>
    </div>
    <div class="bk-stat" style="--accent:#d4af37;">
      <div class="bk-stat__icon"><i class="fa-solid fa-database"></i></div>
      <div class="bk-stat__label">備份範圍</div>
      <div class="bk-stat__value"><?= (int)count($selectedDbs) ?> <span style="font-size:12px;color:#64748b;">個資料庫</span></div>
      <div class="bk-stat__hint"><?= bk_h(bk_format_bytes($dbInfo['size'])) ?> · 共 <?= (int)$dbInfo['tables'] ?> 張表</div>
    </div>
    <div class="bk-stat" style="--accent:#e11d48;">
      <div class="bk-stat__icon"><i class="fa-solid fa-stopwatch"></i></div>
      <div class="bk-stat__label">自動備份</div>
      <div class="bk-stat__value" style="font-size:16px;">
        <?= !empty($settings['enabled']) ? '已啟用' : '已停用' ?>
      </div>
      <div class="bk-stat__hint">
        <?php if (!empty($settings['enabled'])): ?>
          <?= bk_h(bk_interval_label($settings)) ?><?= $nextRunAt ? '，下次約 ' . bk_h(date('m-d H:i', $nextRunAt)) : '' ?>
        <?php else: ?>
          目前不會自動備份
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="bk-grid">

    <!-- 自動備份設定 -->
    <div class="bk-card">
      <div class="bk-card__head">
        <div class="bk-card__icon"><i class="fa-solid fa-sliders"></i></div>
        <div>
          <h2>自動備份設定</h2>
          <span>Schedule &amp; Retention</span>
        </div>
      </div>

      <form method="post" action="backup_admin.php">
        <input type="hidden" name="action" value="save_settings">
        <input type="hidden" name="form_token" value="<?= bk_h($formToken) ?>">

        <div class="bk-field">
          <div class="bk-db-head">
            <label style="margin:0;"><i class="fa-solid fa-layer-group"></i> 備份資料庫範圍</label>
            <div class="bk-db-tools">
              <button type="button" class="bk-btn bk-btn--ghost bk-btn--sm" onclick="bkSelectAllDbs(true)">全選</button>
              <button type="button" class="bk-btn bk-btn--ghost bk-btn--sm" onclick="bkSelectAllDbs(false)">全不選</button>
            </div>
          </div>
          <div class="bk-db-list">
            <?php if (empty($allDatabases)): ?>
              <div class="bk-db-empty">未偵測到任何資料庫。</div>
            <?php else: ?>
              <?php foreach ($allDatabases as $db): ?>
                <label class="bk-db-item">
                  <input type="checkbox" class="bk-db-check" name="databases[]" value="<?= bk_h($db['name']) ?>"
                         <?= in_array($db['name'], $selectedDbs, true) ? 'checked' : '' ?>>
                  <span class="bk-db-checkmark"><i class="fa-solid fa-check"></i></span>
                  <span class="bk-db-name"><?= bk_h($db['name']) ?></span>
                  <span class="bk-db-meta"><?= (int)$db['tables'] ?> 表 · <?= bk_h(bk_format_bytes($db['size'])) ?> · <?= bk_h($db['charset']) ?></span>
                </label>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <p class="bk-desc">系統資料庫（information_schema、mysql、performance_schema、sys）預設不列出；變更勾選後請按「儲存設定」。</p>
        </div>

        <div class="bk-switch" style="margin-bottom:18px;">
          <div class="bk-switch__text">
            <strong>啟用自動備份</strong>
            <span>開啟後，系統會依設定的週期自動備份資料庫。</span>
          </div>
          <label class="bk-toggle">
            <input type="checkbox" name="enabled" value="1" <?= !empty($settings['enabled']) ? 'checked' : '' ?>>
            <span class="bk-toggle__track"></span>
          </label>
        </div>

        <div class="bk-field">
          <label>自動備份頻率</label>
          <div class="bk-inline">
            <input class="bk-input" type="number" name="interval_value" min="1" max="9999"
                   value="<?= (int)$settings['interval_value'] ?>" required>
            <select class="bk-select" name="interval_unit">
              <?php foreach (['minutes' => '分鐘', 'hours' => '小時', 'days' => '天'] as $val => $text): ?>
                <option value="<?= bk_h($val) ?>" <?= ($settings['interval_unit'] === $val) ? 'selected' : '' ?>><?= bk_h($text) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <p class="bk-desc">例如設定「每 1 天」，則距上次自動備份滿 24 小時後，於下次開啟後台時自動執行。</p>
        </div>

        <div class="bk-field">
          <label>保留備份份數</label>
          <input class="bk-input" type="number" name="retention" min="1" max="100"
                 value="<?= (int)$settings['retention'] ?>" required>
          <p class="bk-desc">超過保留份數時，系統會自動刪除最舊的備份檔案，節省硬碟空間（1 ~ 100 份）。</p>
        </div>

        <div class="bk-inline" style="align-items:center;">
          <button type="submit" class="bk-btn bk-btn--primary"><i class="fa-solid fa-floppy-disk"></i> 儲存設定</button>
          <button type="submit" name="reset_schedule" value="1" class="bk-btn bk-btn--ghost" title="將上次自動備份時間歸零，下次開啟即重新排程">
            <i class="fa-solid fa-arrows-rotate"></i> 重設排程
          </button>
        </div>
      </form>
    </div>

    <!-- 立即備份 -->
    <div class="bk-card">
      <div class="bk-card__head">
        <div class="bk-card__icon"><i class="fa-solid fa-bolt"></i></div>
        <div>
          <h2>立即備份</h2>
          <span>Manual Backup</span>
        </div>
      </div>
      <div class="bk-now">
        <div class="bk-now__orb"><i class="fa-solid fa-download"></i></div>
        <div class="bk-now__title">建立所選資料庫快照</div>
        <div class="bk-now__meta">
          備份範圍：<b><?= (int)count($selectedDbs) ?> 個資料庫</b><br>
          <?php if (!empty($selectedDbs)): ?>
            <span class="bk-mono" style="font-size:10.5px;"><?= bk_h(implode('、', array_slice($selectedDbs, 0, 4))) ?><?= count($selectedDbs) > 4 ? ' 等' : '' ?></span><br>
          <?php endif; ?>
          引擎：<?= bk_h($methodLabel[$activeEngine] ?? 'PHP') ?><br>
          <?php if ($latest): ?>
            上次備份：<?= bk_h($latest['created_at']) ?>（<?= bk_h(bk_format_duration(time() - (int)$latest['created_ts'])) ?>前）
          <?php else: ?>
            尚未建立任何備份
          <?php endif; ?>
        </div>
        <form method="post" action="backup_admin.php" onsubmit="return bkBackupConfirm(this);">
          <input type="hidden" name="action" value="backup_now">
          <input type="hidden" name="form_token" value="<?= bk_h($formToken) ?>">
          <button type="submit" class="bk-btn bk-btn--gold bk-btn--lg" style="width:100%;justify-content:center;">
            <i class="fa-solid fa-cloud-arrow-up"></i> 立即備份所選資料庫
          </button>
        </form>
      </div>
    </div>
  </div>

  <!-- 備份歷程 -->
  <div class="bk-card">
    <div class="bk-card__head">
      <div class="bk-card__icon"><i class="fa-solid fa-list-check"></i></div>
      <div>
        <h2>備份歷程記錄</h2>
        <span>History &amp; Restore</span>
      </div>
      <span class="bk-badge" style="margin-left:auto;"><i class="fa-solid fa-coins"></i> 備份總容量 <?= bk_h(bk_format_bytes($totalSize)) ?></span>
    </div>

    <?php if (empty($history)): ?>
      <div class="bk-empty">
        <i class="fa-regular fa-folder-open"></i>
        目前沒有任何備份記錄，點擊「立即備份」建立第一份備份。
      </div>
    <?php else: ?>
      <div class="bk-table-wrap">
        <table class="bk-table">
          <thead>
            <tr>
              <th>時間</th>
              <th>類型</th>
              <th>資料庫</th>
              <th>檔名</th>
              <th>大小</th>
              <th>資料表</th>
              <th>狀態</th>
              <th style="text-align:right;">操作</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($history as $h):
              $st = (string)($h['status'] ?? '');
              $isOk = ($st === 'success');
              $isPartial = ($st === 'partial');
              $recFiles = bk_record_files($h);
              $okFiles = array_values(array_filter($recFiles, function ($f) {
                  return ($f['status'] ?? 'success') === 'success' && $f['file'] !== '';
              }));
              $hDbs = (array)($h['databases'] ?? []);
              if (empty($hDbs)) { $hDbs = ['(未記錄)']; }
          ?>
            <tr>
              <td data-label="時間">
                <div style="font-weight:600;"><?= bk_h($h['created_at'] ?? '—') ?></div>
                <div class="bk-mono"><?= bk_h(bk_format_duration(time() - (int)($h['created_ts'] ?? time()))) ?>前</div>
              </td>
              <td data-label="類型">
                <span class="bk-tag <?= ($h['type'] ?? '') === 'auto' ? 'bk-tag--auto' : 'bk-tag--manual' ?>">
                  <i class="fa-solid <?= ($h['type'] ?? '') === 'auto' ? 'fa-rotate' : 'fa-hand-pointer' ?>"></i>
                  <?= ($h['type'] ?? '') === 'auto' ? '自動' : '手動' ?>
                </span>
              </td>
              <td data-label="資料庫">
                <span title="<?= bk_h(implode('、', $hDbs)) ?>">
                  <?php if (count($hDbs) === 1): ?>
                    <span class="bk-mono"><?= bk_h($hDbs[0]) ?></span>
                  <?php else: ?>
                    <?= (int)count($hDbs) ?> 個
                  <?php endif; ?>
                </span>
              </td>
              <td data-label="備份檔">
                <?php if (count($okFiles) === 1): ?>
                  <span class="bk-mono"><?= bk_h($okFiles[0]['file']) ?></span>
                <?php elseif (count($okFiles) > 1): ?>
                  <span class="bk-tag bk-tag--manual"><i class="fa-solid fa-file-code"></i> <?= count($okFiles) ?> 個獨立 SQL 檔</span>
                <?php else: ?>
                  <span class="bk-mono">—</span>
                <?php endif; ?>
              </td>
              <td data-label="大小"><?= ($isOk || $isPartial) ? bk_h(bk_format_bytes($h['size'] ?? 0)) : '—' ?></td>
              <td data-label="資料表"><?= (int)($h['tables'] ?? 0) ?></td>
              <td data-label="狀態">
                <?php if ($isOk): ?>
                  <span class="bk-tag bk-tag--ok"><i class="fa-solid fa-check"></i> 成功</span>
                <?php elseif ($isPartial): ?>
                  <span class="bk-tag bk-tag--auto" title="<?= bk_h($h['message'] ?? '') ?>"><i class="fa-solid fa-circle-half-stroke"></i> 部分成功</span>
                <?php else: ?>
                  <span class="bk-tag bk-tag--fail" title="<?= bk_h($h['message'] ?? '') ?>"><i class="fa-solid fa-xmark"></i> 失敗</span>
                <?php endif; ?>
              </td>
              <td data-label="操作">
                <div class="bk-row-actions">
                  <?php if (count($okFiles) === 1): ?>
                    <a class="bk-btn bk-btn--sky bk-btn--sm" href="backup_admin.php?action=download&amp;id=<?= bk_h($h['id']) ?>&amp;f=<?= rawurlencode($okFiles[0]['file']) ?>">
                      <i class="fa-solid fa-download"></i> 下載
                    </a>
                  <?php elseif (count($okFiles) > 1): ?>
                    <details class="bk-dl">
                      <summary class="bk-btn bk-btn--sky bk-btn--sm"><i class="fa-solid fa-download"></i> 下載 (<?= count($okFiles) ?>)</summary>
                      <div class="bk-dl__menu">
                        <?php foreach ($okFiles as $f): ?>
                          <a class="bk-dl__item" href="backup_admin.php?action=download&amp;id=<?= bk_h($h['id']) ?>&amp;f=<?= rawurlencode($f['file']) ?>" title="<?= bk_h($f['file']) ?>">
                            <i class="fa-solid fa-database"></i>
                            <span class="bk-dl__db"><?= bk_h($f['db'] !== '' ? $f['db'] : $f['file']) ?></span>
                            <span class="bk-dl__size"><?= bk_h(bk_format_bytes($f['size'])) ?></span>
                          </a>
                        <?php endforeach; ?>
                      </div>
                    </details>
                  <?php endif; ?>

                  <?php if (!empty($okFiles)): ?>
                    <form method="post" action="backup_admin.php" style="margin:0;">
                      <input type="hidden" name="action" value="restore">
                      <input type="hidden" name="form_token" value="<?= bk_h($formToken) ?>">
                      <input type="hidden" name="id" value="<?= bk_h($h['id']) ?>">
                      <button type="button" class="bk-btn bk-btn--gold bk-btn--sm"
                              data-bk-restore
                              data-label="<?= bk_h(implode('、', $hDbs)) ?>"
                              data-time="<?= bk_h($h['created_at']) ?>">
                        <i class="fa-solid fa-clock-rotate-left"></i> 還原
                      </button>
                    </form>
                  <?php endif; ?>

                  <form method="post" action="backup_admin.php" style="margin:0;" onsubmit="return confirm('確定要刪除此備份的所有檔案與記錄嗎？此動作無法復原。');">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="form_token" value="<?= bk_h($formToken) ?>">
                    <input type="hidden" name="id" value="<?= bk_h($h['id']) ?>">
                    <button type="submit" class="bk-btn bk-btn--danger bk-btn--sm"><i class="fa-solid fa-trash"></i></button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="bk-foot">
    踏雪笑傲 · 自動備份系統 &nbsp;|&nbsp; 備份儲存於 <span class="bk-mono">admin/backups</span>，已禁止外部直接存取，僅能由管理員下載。
  </div>
</div>

<!-- 還原確認視窗 -->
<div class="bk-modal" id="bk-restore-modal">
  <div class="bk-modal__box">
    <div class="bk-modal__icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <h3 class="bk-serif">確認還原資料庫？</h3>
    <p>還原會以所選備份覆蓋目前資料庫內容，現有資料將被取代，此動作無法復原。</p>
    <p class="bk-modal__file" id="bk-restore-file"></p>
    <div class="bk-modal__actions">
      <button type="button" class="bk-btn bk-btn--ghost" onclick="bkCloseRestore()"><i class="fa-solid fa-xmark"></i> 取消</button>
      <form method="post" action="backup_admin.php" id="bk-restore-form" style="margin:0;display:contents;">
        <input type="hidden" name="action" value="restore">
        <input type="hidden" name="form_token" value="<?= bk_h($formToken) ?>">
        <input type="hidden" name="id" value="" id="bk-restore-id">
        <input type="hidden" name="file" value="" id="bk-restore-only">
        <button type="submit" class="bk-btn bk-btn--danger"><i class="fa-solid fa-clock-rotate-left"></i> 確認還原</button>
      </form>
    </div>
  </div>
</div>

<script>
(function () {
    var modal = document.getElementById('bk-restore-modal');
    var fileEl = document.getElementById('bk-restore-file');
    var idEl = document.getElementById('bk-restore-id');
    var onlyEl = document.getElementById('bk-restore-only');

    document.querySelectorAll('[data-bk-restore]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var form = btn.closest('form');
            var idInput = form ? form.querySelector('input[name="id"]') : null;
            var onlyInput = form ? form.querySelector('input[name="file"]') : null;
            if (idEl && idInput) { idEl.value = idInput.value; }
            if (onlyEl) { onlyEl.value = onlyInput ? onlyInput.value : ''; }
            if (fileEl) {
                fileEl.textContent = (btn.getAttribute('data-label') || '') + '（' + (btn.getAttribute('data-time') || '') + '）';
            }
            if (modal) { modal.classList.add('is-open'); }
        });
    });

    window.bkCloseRestore = function () {
        if (modal) { modal.classList.remove('is-open'); }
    };

    if (modal) {
        modal.addEventListener('click', function (e) {
            if (e.target === modal) { window.bkCloseRestore(); }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') { window.bkCloseRestore(); }
        });
    }

    window.bkBackupConfirm = function (form) {
        var btn = form.querySelector('button[type="submit"]');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> 備份進行中…';
        }
        return true;
    };

    window.bkSelectAllDbs = function (checked) {
        document.querySelectorAll('.bk-db-check').forEach(function (cb) {
            cb.checked = !!checked;
        });
    };
})();
</script>

</body>
</html>
