<?php
/**
 * =============================================================
 *  踏雪笑傲 · 官方首頁設定中心（後台）
 *  資料庫：sa  →  swo_site_settings
 *  入口：admin/gmpanel.php 的「首頁管理」按鈕，或 admin/site_admin.php
 *  功能：調整前台首頁各項文字、圖片、連結、公告顯示數量等；
 *        圖片可直接輸入路徑／網址，或上傳替換（存於 swo/assets/uploads）。
 * =============================================================
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../swo/site_config.php';

/* 需以 GM 身分登入 */
if (!isset($_SESSION['gm_username'])) {
    header('Location: gmlogin.php');
    exit();
}
$currentGm = (string)$_SESSION['gm_username'];

$db = site_db();
if (!$db) {
    die('無法連線資料庫：' . mysqli_connect_error());
}
site_settings_ensure($db);

if (!isset($_SESSION['form_token'])) {
    $_SESSION['form_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['form_token'];

$notice = '';
$noticeType = 'ok';

/* ---------------- 儲存 ---------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
    if (!isset($_POST['form_token']) || !hash_equals($_SESSION['form_token'], (string)$_POST['form_token'])) {
        $notice = '工作階段已過期，請重新整理後再試。';
        $noticeType = 'err';
    } else {
        $order = 0;
        foreach (site_schema() as $key => $meta) {
            $type = (string)($meta['type'] ?? 'text');
            if ($type === 'image') {
                $uploaded = site_store_upload('file_' . $key, (string)$key);
                $val = ($uploaded !== null) ? $uploaded : trim((string)($_POST[$key] ?? ''));
            } elseif ($type === 'number') {
                $n = (int)($_POST[$key] ?? 0);
                if ($key === 'news_limit') { $n = max(1, min(20, $n)); }
                $val = (string)$n;
            } else {
                $val = trim((string)($_POST[$key] ?? ''));
            }
            site_setting_put($db, (string)$key, $val, $meta, $order++);
        }
        $_SESSION['form_token'] = bin2hex(random_bytes(32));
        $formToken = $_SESSION['form_token'];
        $notice = '首頁設定已成功儲存。';
        $noticeType = 'ok';
    }
}

$S = site_settings_all($db);
$schema = site_schema();
$groups = site_groups();
?>
<!DOCTYPE html>
<html lang="zh-Hant">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>首頁設定中心 · 踏雪笑傲 後台</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Noto+Serif+TC:wght@400;600;700;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/site-admin.css">
</head>
<body>

<!-- 頂部列 -->
<header class="sa-top">
  <div class="sa-top__inner">
    <div class="sa-brand">
      <?php $logo = site_img_url($S['brand_logo'], '../swo/'); ?>
      <?php if ($logo !== ''): ?><img class="sa-brand__logo" src="<?= site_h($logo) ?>" alt="logo"><?php endif; ?>
      <div>
        <div class="sa-brand__name">首頁設定中心</div>
        <div class="sa-brand__sub">Landing Page Manager</div>
      </div>
    </div>
    <div class="sa-actions">
      <span class="sa-db-badge"><i class="fa-solid fa-database"></i> <?= site_h($DBName) ?> · <?= site_h(SITE_SETTINGS_TABLE) ?></span>
      <a class="sa-btn sa-btn--ghost" href="gmpanel.php"><i class="fa-solid fa-gauge-high"></i> 控制台</a>
      <a class="sa-btn sa-btn--ghost" href="../swo/index.php" target="_blank" rel="noopener"><i class="fa-solid fa-arrow-up-right-from-square"></i> 預覽首頁</a>
      <a class="sa-btn sa-btn--dark" href="gmlogout.php"><i class="fa-solid fa-right-from-bracket"></i> 登出</a>
    </div>
  </div>
</header>

<div class="sa-wrap">
  <div class="sa-hero-title">
    <div>
      <h1>官方首頁 · 內容與連結管理</h1>
      <p>調整前台首頁的文字、圖片、連結與公告顯示數量；所有設定儲存於資料庫，即時生效。</p>
    </div>
    <div class="sa-db-badge">操作者：<?= site_h($currentGm) ?></div>
  </div>

  <?php if ($notice !== ''): ?>
  <div class="sa-notice <?= $noticeType === 'err' ? 'sa-notice--err' : 'sa-notice--ok' ?>">
    <i class="fa-solid <?= $noticeType === 'err' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>"></i>
    <span><?= site_h($notice) ?></span>
  </div>
  <?php endif; ?>

  <!-- 分組按鈕選單 -->
  <nav class="sa-menu">
    <?php foreach ($groups as $gkey => $g): ?>
      <a href="#g-<?= site_h($gkey) ?>"><i class="fa-solid <?= site_h($g['icon']) ?>"></i><?= site_h($g['name']) ?></a>
    <?php endforeach; ?>
  </nav>

  <form method="post" enctype="multipart/form-data" action="site_admin.php">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="form_token" value="<?= site_h($formToken) ?>">

    <?php foreach ($groups as $gkey => $g): ?>
      <section class="sa-card" id="g-<?= site_h($gkey) ?>">
        <div class="sa-card__head">
          <span class="sa-card__icon"><i class="fa-solid <?= site_h($g['icon']) ?>"></i></span>
          <div>
            <h2><?= site_h($g['name']) ?></h2>
            <span><?= site_h(strtoupper($gkey)) ?> SETTINGS</span>
          </div>
        </div>
        <div class="sa-grid">
          <?php foreach ($schema as $key => $meta): if (($meta['group'] ?? '') !== $gkey) { continue; } ?>
            <?php
              $type    = (string)($meta['type'] ?? 'text');
              $label   = (string)($meta['label'] ?? $key);
              $desc    = (string)($meta['desc'] ?? ($meta['description'] ?? ''));
              $val     = (string)($S[$key] ?? ($meta['default'] ?? ''));
              $isFull  = in_array($type, ['textarea', 'image'], true);
            ?>
            <div class="sa-field <?= $isFull ? 'sa-field--full' : '' ?>">
              <label for="f-<?= site_h($key) ?>"><?= site_h($label) ?></label>

              <?php if ($type === 'image'): ?>
                <?php $src = site_img_url($val, '../swo/'); ?>
                <div class="sa-img">
                  <div class="sa-img__thumb">
                    <?php if ($src !== ''): ?>
                      <img id="prev-<?= site_h($key) ?>" src="<?= site_h($src) ?>" alt="">
                    <?php else: ?>
                      <span class="ph" id="ph-<?= site_h($key) ?>">無圖片</span>
                    <?php endif; ?>
                  </div>
                  <div class="sa-img__body">
                    <input class="sa-input" type="text" id="f-<?= site_h($key) ?>" name="<?= site_h($key) ?>" value="<?= site_h($val) ?>" placeholder="assets/images/... 或 https://...">
                    <label class="sa-upload"><i class="fa-solid fa-upload"></i> 上傳替換
                      <input type="file" name="file_<?= site_h($key) ?>" accept="image/png,image/jpeg,image/gif,image/webp" hidden
                             onchange="if(this.files[0]){var im=document.getElementById('prev-<?= site_h($key) ?>');if(!im){im=document.createElement('img');im.id='prev-<?= site_h($key) ?>';var ph=document.getElementById('ph-<?= site_h($key) ?>');var box=ph?ph.parentElement:null;if(ph)ph.remove();if(box)box.appendChild(im);}im.src=URL.createObjectURL(this.files[0]);}">
                    </label>
                  </div>
                </div>

              <?php elseif ($type === 'textarea'): ?>
                <textarea class="sa-textarea" id="f-<?= site_h($key) ?>" name="<?= site_h($key) ?>"><?= site_h($val) ?></textarea>

              <?php elseif ($type === 'number'): ?>
                <input class="sa-input" type="number" id="f-<?= site_h($key) ?>" name="<?= site_h($key) ?>" value="<?= site_h($val) ?>" <?= $key === 'news_limit' ? 'min="1" max="20"' : '' ?>>

              <?php elseif ($type === 'select'): ?>
                <select class="sa-select" id="f-<?= site_h($key) ?>" name="<?= site_h($key) ?>">
                  <?php foreach ((array)($meta['options'] ?? []) as $opt): ?>
                    <option value="<?= site_h($opt) ?>" <?= ($val === (string)$opt) ? 'selected' : '' ?>><?= site_h($opt) ?></option>
                  <?php endforeach; ?>
                </select>

              <?php else: ?>
                <input class="sa-input" type="text" id="f-<?= site_h($key) ?>" name="<?= site_h($key) ?>" value="<?= site_h($val) ?>">
              <?php endif; ?>

              <?php if ($desc !== ''): ?><p class="sa-desc"><?= site_h($desc) ?></p><?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endforeach; ?>
  </form>
</div>

<!-- 儲存列 -->
<div class="sa-savebar">
  <div class="sa-savebar__inner">
    <span class="sa-savebar__hint"><i class="fa-solid fa-circle-info"></i> 圖片上傳後請記得按下「儲存設定」。</span>
    <button type="submit" form="" class="sa-btn sa-btn--primary sa-btn--save"
      onclick="var f=document.querySelector('form[action=\'site_admin.php\']');if(f){f.submit();}">
      <i class="fa-solid fa-floppy-disk"></i> 儲存設定
    </button>
  </div>
</div>

</body>
</html>
