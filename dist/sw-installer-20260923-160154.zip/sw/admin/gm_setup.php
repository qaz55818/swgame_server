<?php
// 僅供一次性使用：建立第一筆 gm_accounts 資料，用完後請刪除此檔案。
// 安全性：即使檔案忘記刪除，一旦已存在任何 GM 帳號，本頁即拒絕執行，
// 避免任何人透過此頁面建立新的 GM 帳號。
include_once __DIR__ . '/../config.php';

$message = "";
$fatal = "";

$Link = null;
try {
    $Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName, $port ?? 3306);
} catch (Throwable $e) {
    $Link = null;
}
if (!$Link) {
    $fatal = "資料庫連線失敗，請稍後再試。";
} else {
    $gmCount = 0;
    try {
        $res = $Link->query("SELECT COUNT(*) AS c FROM gm_accounts");
        $gmCount = $res ? (int)($res->fetch_assoc()['c'] ?? 0) : 0;
    } catch (Throwable $e) {
        $gmCount = 0;
    }
    if ($gmCount > 0) {
        $fatal = "系統已完成 GM 初始化，基於安全考量此頁面已停用，請立即刪除 gm_setup.php。";
    }
}

if ($fatal === "" && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = strtolower(trim((string)($_POST['username'] ?? '')));
    $password = (string)($_POST['password'] ?? '');

    if (!preg_match('/^[a-z0-9_-]{3,50}$/', $username)) {
        $message = "使用者名稱格式不正確。";
    } elseif (strlen($password) < 8) {
        $message = "密碼至少需 8 個字元。";
    } else {
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            $stmt = $Link->prepare("INSERT INTO gm_accounts (username, password_hash) VALUES (?, ?)");
            $stmt->bind_param("ss", $username, $hash);
            $stmt->execute();
            $stmt->close();
            $message = "已建立 GM 帳號「" . htmlspecialchars($username, ENT_QUOTES, 'UTF-8') . "」。請立即從伺服器刪除此檔案（gm_setup.php）。";
        } catch (Throwable $e) {
            $message = "建立失敗（使用者名稱可能已存在）。";
        }
    }
}
if ($Link) {
    mysqli_close($Link);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>一次性 GM 設定</title>
    <style>
        body { font-family: sans-serif; background: #0c0d10; color: #e8e6df; padding: 2rem; }
        .box { max-width: 400px; margin: 2rem auto; background: #16181d; padding: 2rem; border-radius: 6px; border: 1px solid #a3172c; }
        input { width: 100%; padding: 0.5rem; margin-bottom: 1rem; background: #1a1c22; color: #fff; border: 1px solid #3a3d44; }
        button { width: 100%; padding: 0.6rem; background: #a3172c; color: #fff; border: none; border-radius: 4px; }
        .msg { background: #2a1216; border: 1px solid #a3172c; padding: 1rem; margin-bottom: 1rem; border-radius: 4px; }
        .warn { color: #ffb84d; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="box">
        <h2>建立第一個 GM 帳號</h2>
        <p class="warn">⚠ 此頁面僅能在尚未有任何 GM 帳號時使用，使用後請立即從伺服器刪除。</p>
        <?php if ($fatal !== ""): ?>
            <div class="msg"><?php echo htmlspecialchars($fatal, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php else: ?>
            <?php if ($message): ?><div class="msg"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
            <form method="POST">
                <input type="text" name="username" placeholder="使用者名稱" required>
                <input type="password" name="password" placeholder="密碼（至少 8 個字元）" required>
                <button type="submit">建立 GM 帳號</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>