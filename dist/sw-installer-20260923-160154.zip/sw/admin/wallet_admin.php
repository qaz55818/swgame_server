<?php
/**
 * =============================================================
 *  踏雪笑傲 · 點數 / 元寶 錢包管理後台（GM 端）
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *
 *  功能：資產總覽、會員搜尋、點數/元寶發放與扣減、交易流水查詢、
 *        兌換紀錄、匯率與顯示名稱設定（彈出子視窗操作）
 * =============================================================
 */
session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../currency.php';

if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
$currentGmUsername = $_SESSION['gm_username'];
$currentGmId = (int)($_SESSION['gm_id'] ?? 0);

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($Link, "utf8");

if (empty($_SESSION['wallet_admin_token'])) {
    $_SESSION['wallet_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['wallet_admin_token'];

function wadmin_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function wadmin_type_label($type) {
    $map = [
        'recharge' => '儲值入帳', 'exchange_in' => '兌換取得', 'exchange_out' => '兌換扣點',
        'admin_grant' => '管理發放', 'admin_deduct' => '管理扣減', 'consume' => '消費',
        'refund' => '退款退回', 'adjust' => '調整', 'register_bonus' => '註冊獎勵',
    ];
    return $map[$type] ?? $type;
}

$notice = '';
$noticeType = 'success';

// ------------------------------------------------------------
// 表單處理（PRG）
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['form_token']) || !hash_equals($_SESSION['wallet_admin_token'], (string)$_POST['form_token'])) {
        $notice = '工作階段已過期，請重新操作。';
        $noticeType = 'danger';
    } else {
        $action = $_POST['action'] ?? '';

        if ($action === 'adjust') {
            $uid = (int)($_POST['uid'] ?? 0);
            $currency = (($_POST['currency'] ?? 'points') === 'yuanbao') ? 'yuanbao' : 'points';
            $direction = (($_POST['direction'] ?? 'grant') === 'deduct') ? 'deduct' : 'grant';
            $amount = abs((int)($_POST['amount'] ?? 0));
            $reason = trim((string)($_POST['reason'] ?? ''));
            $label = $currency === 'yuanbao' ? '元寶' : '點數';

            if ($uid <= 0 || $amount <= 0) {
                $notice = '請輸入有效的會員與數量。';
                $noticeType = 'danger';
            } else {
                $signed = ($direction === 'deduct') ? -$amount : $amount;
                $type = ($direction === 'deduct') ? 'admin_deduct' : 'admin_grant';
                $desc = ($reason !== '' ? $reason : ($direction === 'deduct' ? '管理員扣減' : '管理員發放')) . '（' . $label . '）';
                $res = currency_add($Link, $uid, $currency, $signed, $type, '', $desc, $currentGmUsername);
                if ($res['ok']) {
                    if ($currency === 'yuanbao') {
                        currency_sync_point($Link, $uid, $signed);
                    }
                    $notice = '已' . ($direction === 'deduct' ? '扣減' : '發放') . ' ' . number_format($amount) . ' ' . $label . '（UID ' . $uid . '），餘額 ' . number_format((int)$res['balance']) . '。';
                } else {
                    $notice = '操作失敗：' . $res['message'];
                    $noticeType = 'danger';
                }
            }
        } elseif ($action === 'update_settings') {
            $keys = ['points_name', 'yuanbao_name', 'exchange_enabled', 'exchange_rate', 'exchange_min', 'exchange_fee_percent'];
            $values = [
                'points_name' => mb_substr(trim((string)($_POST['points_name'] ?? '點數')), 0, 20),
                'yuanbao_name' => mb_substr(trim((string)($_POST['yuanbao_name'] ?? '元寶')), 0, 20),
                'exchange_enabled' => ((int)($_POST['exchange_enabled'] ?? 0) === 1) ? '1' : '0',
                'exchange_rate' => (string)max(0.0001, (float)($_POST['exchange_rate'] ?? 1)),
                'exchange_min' => (string)max(1, (int)($_POST['exchange_min'] ?? 1)),
                'exchange_fee_percent' => (string)max(0, min(100, (int)($_POST['exchange_fee_percent'] ?? 0))),
            ];
            $stmt = $Link->prepare("INSERT INTO `currency_settings` (`setting_key`,`setting_value`,`updated_at`) VALUES (?,?,NOW()) ON DUPLICATE KEY UPDATE `setting_value`=VALUES(`setting_value`), `updated_at`=NOW()");
            foreach ($keys as $k) {
                $stmt->bind_param("ss", $k, $values[$k]);
                $stmt->execute();
            }
            $stmt->close();
            $notice = '貨幣設定已更新。';
        } else {
            $notice = '未知的操作。';
            $noticeType = 'danger';
        }

        if ($noticeType !== 'danger') {
            $_SESSION['wallet_admin_notice'] = ['type' => $noticeType, 'msg' => $notice];
            $redir = 'wallet_admin.php';
            $backUid = (int)($_POST['uid'] ?? 0);
            if ($backUid > 0) { $redir .= '?uid=' . $backUid; }
            header("Location: " . $redir);
            exit();
        }
    }
}

$flash = $_SESSION['wallet_admin_notice'] ?? null;
unset($_SESSION['wallet_admin_notice']);
if ($flash) { $notice = $flash['msg']; $noticeType = $flash['type']; }

$settings = currency_load_settings($Link);
$pointsName = $settings['points_name'];
$yuanbaoName = $settings['yuanbao_name'];

// ------------------------------------------------------------
// 資產總覽統計
// ------------------------------------------------------------
$sum = ['total_points' => 0, 'total_yuanbao' => 0, 'wallets' => 0];
$r = mysqli_query($Link, "SELECT IFNULL(SUM(`points`),0) AS p, IFNULL(SUM(`yuanbao`),0) AS y, COUNT(*) AS c FROM `user_wallet`");
if ($r && ($row = $r->fetch_assoc())) {
    $sum['total_points'] = (int)$row['p'];
    $sum['total_yuanbao'] = (int)$row['y'];
    $sum['wallets'] = (int)$row['c'];
}
$today = ['recharge_points' => 0, 'exchange_points' => 0, 'exchange_yuanbao' => 0, 'grants' => 0];
$r = mysqli_query(
    $Link,
    "SELECT
        IFNULL(SUM(CASE WHEN `type`='recharge' AND `currency`='points' THEN `change_amount` ELSE 0 END),0) AS rc,
        IFNULL(SUM(CASE WHEN `type`='exchange_out' AND `currency`='points' THEN -`change_amount` ELSE 0 END),0) AS ex,
        IFNULL(SUM(CASE WHEN `type`='exchange_in' AND `currency`='yuanbao' THEN `change_amount` ELSE 0 END),0) AS exy,
        IFNULL(SUM(CASE WHEN `type` IN ('admin_grant','admin_deduct') THEN 1 ELSE 0 END),0) AS gr
     FROM `currency_ledger` WHERE DATE(`created_at`) = CURDATE()"
);
if ($r && ($row = $r->fetch_assoc())) {
    $today['recharge_points'] = (int)$row['rc'];
    $today['exchange_points'] = (int)$row['ex'];
    $today['exchange_yuanbao'] = (int)$row['exy'];
    $today['grants'] = (int)$row['gr'];
}

// ------------------------------------------------------------
// 會員搜尋 / 列表
// ------------------------------------------------------------
$q = trim((string)($_GET['q'] ?? ''));
$focusUid = (int)($_GET['uid'] ?? 0);
$users = [];
if ($q !== '') {
    $like = '%' . $q . '%';
    if (ctype_digit($q)) {
        $stmt = $Link->prepare(
            "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                    IFNULL(w.`points`,0) AS points, IFNULL(w.`yuanbao`,0) AS yuanbao,
                    IFNULL(w.`total_points_in`,0) AS total_points_in, IFNULL(w.`total_yuanbao_in`,0) AS total_yuanbao_in,
                    w.`updated_at`
             FROM `users` u LEFT JOIN `user_wallet` w ON w.`uid` = u.`ID`
             WHERE u.`ID` = ? OR u.`name` LIKE ? OR u.`email` LIKE ?
             ORDER BY u.`ID` ASC LIMIT 50"
        );
        $uidInt = (int)$q;
        $stmt->bind_param("iss", $uidInt, $like, $like);
    } else {
        $stmt = $Link->prepare(
            "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                    IFNULL(w.`points`,0) AS points, IFNULL(w.`yuanbao`,0) AS yuanbao,
                    IFNULL(w.`total_points_in`,0) AS total_points_in, IFNULL(w.`total_yuanbao_in`,0) AS total_yuanbao_in,
                    w.`updated_at`
             FROM `users` u LEFT JOIN `user_wallet` w ON w.`uid` = u.`ID`
             WHERE u.`name` LIKE ? OR u.`email` LIKE ?
             ORDER BY u.`ID` ASC LIMIT 50"
        );
        $stmt->bind_param("ss", $like, $like);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $users[] = $row; }
    $stmt->close();
} else {
    $r = mysqli_query(
        $Link,
        "SELECT u.`ID`, u.`name`, u.`email`, u.`creatime`,
                IFNULL(w.`points`,0) AS points, IFNULL(w.`yuanbao`,0) AS yuanbao,
                IFNULL(w.`total_points_in`,0) AS total_points_in, IFNULL(w.`total_yuanbao_in`,0) AS total_yuanbao_in,
                w.`updated_at`
         FROM `user_wallet` w JOIN `users` u ON u.`ID` = w.`uid`
         ORDER BY w.`updated_at` DESC LIMIT 30"
    );
    if ($r) { while ($row = $r->fetch_assoc()) { $users[] = $row; } }
}

// ------------------------------------------------------------
// 焦點會員：錢包 + 流水 + 兌換紀錄
// ------------------------------------------------------------
$focus = null;
$focusWallet = null;
$ledger = [];
$exchanges = [];
if ($focusUid > 0) {
    $stmt = $Link->prepare("SELECT `ID`, `name`, `email`, `mobilenumber`, `creatime` FROM `users` WHERE `ID` = ? LIMIT 1");
    $stmt->bind_param("i", $focusUid);
    $stmt->execute();
    $focus = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($focus) {
        $focusWallet = currency_get_wallet($Link, $focusUid);
        $stmt = $Link->prepare("SELECT `currency`,`change_amount`,`balance_after`,`type`,`ref_no`,`description`,`operator`,`created_at` FROM `currency_ledger` WHERE `uid` = ? ORDER BY `id` DESC LIMIT 60");
        $stmt->bind_param("i", $focusUid);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) { $ledger[] = $row; }
        $stmt->close();
        $stmt = $Link->prepare("SELECT `exchange_no`,`points_used`,`rate`,`yuanbao_gained`,`status`,`created_at` FROM `exchange_orders` WHERE `uid` = ? ORDER BY `id` DESC LIMIT 20");
        $stmt->bind_param("i", $focusUid);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) { $exchanges[] = $row; }
        $stmt->close();
    } else {
        $notice = '找不到該會員。';
        $noticeType = 'danger';
    }
}

// 最近兌換紀錄（全站）
$recentExchanges = [];
$r = mysqli_query($Link, "SELECT `exchange_no`,`uid`,`username`,`points_used`,`yuanbao_gained`,`created_at` FROM `exchange_orders` ORDER BY `id` DESC LIMIT 12");
if ($r) { while ($row = $r->fetch_assoc()) { $recentExchanges[] = $row; } }

mysqli_close($Link);

$rateDisplay = rtrim(rtrim(number_format((float)$settings['exchange_rate'], 4, '.', ''), '0'), '.');
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>踏雪笑傲 · 點數元寶管理後台</title>
<link rel="stylesheet" href="assets/tailwind.css">
<link rel="stylesheet" href="assets/wallet-admin-tailwind.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Noto+Sans+TC:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    :root { --vermilion:#be123c; --gold:#d97706; --ice:#0284c7; }
    body {
        background-color:#080c14; color:#1e293b; font-family:'Noto Sans TC','Noto Serif TC',sans-serif; min-height:100vh;
        background-image:
            radial-gradient(ellipse at 50% 0%, rgba(217,119,6,.10) 0%, transparent 60%),
            radial-gradient(ellipse at 80% 90%, rgba(2,132,199,.10) 0%, transparent 50%),
            radial-gradient(ellipse at 20% 60%, rgba(15,23,42,.82) 0%, transparent 70%);
    }
    #snow-canvas { position:fixed; top:0; left:0; width:100vw; height:100vh; pointer-events:none; z-index:1; }
    .glass-panel { background:rgba(255,255,255,.95); border:1px solid rgba(226,232,240,.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); box-shadow:0 10px 30px -5px rgba(0,0,0,.28); position:relative; }
    .corner-accent::before { content:''; position:absolute; top:0; left:0; width:10px; height:10px; border-top:2px solid var(--vermilion); border-left:2px solid var(--vermilion); pointer-events:none; }
    .corner-accent::after { content:''; position:absolute; bottom:0; right:0; width:10px; height:10px; border-bottom:2px solid var(--gold); border-right:2px solid var(--gold); pointer-events:none; }
    .btn-gold { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; transition:all .25s; box-shadow:0 6px 18px -6px rgba(217,119,6,.6); }
    .btn-gold:hover { background:linear-gradient(135deg,#fbbf24,#f59e0b); transform:translateY(-1px); }
    .btn-ice { background:linear-gradient(135deg,#0284c7,#0369a1); color:#fff; transition:all .25s; box-shadow:0 6px 18px -6px rgba(2,132,199,.6); }
    .btn-ice:hover { background:linear-gradient(135deg,#0ea5e9,#0284c7); transform:translateY(-1px); }
    .btn-rose { background:linear-gradient(135deg,#e11d48,#9f1239); color:#fff; transition:all .25s; }
    .btn-rose:hover { background:linear-gradient(135deg,#fb7185,#e11d48); transform:translateY(-1px); }
    .wadmin-input { width:100%; border:1px solid #cbd5e1; border-radius:.6rem; padding:.5rem .7rem; font-size:.8rem; color:#1e293b; background:#fff; transition:all .2s; }
    .wadmin-input:focus { outline:none; border-color:var(--gold); box-shadow:0 0 0 3px rgba(217,119,6,.15); }
    .kpi { position:relative; overflow:hidden; transition:transform .3s cubic-bezier(.34,1.56,.64,1), box-shadow .3s; }
    .kpi:hover { transform:translateY(-4px); box-shadow:0 20px 40px -20px rgba(0,0,0,.55); }
    .coin-float { animation:coinFloat 3s ease-in-out infinite; }
    @keyframes coinFloat { 0%,100%{transform:translateY(0) rotate(0)} 50%{transform:translateY(-6px) rotate(6deg)} }
    .anim-up { animation:fadeInUp .5s cubic-bezier(.22,1,.36,1) both; }
    @keyframes fadeInUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:none} }
    .d1{animation-delay:.05s}.d2{animation-delay:.1s}.d3{animation-delay:.15s}
    .ledger-row { transition:background .15s; }
    .ledger-row:hover { background:#fffbeb; }
    /* 彈出子視窗 */
    .sup-modal { position:fixed; inset:0; z-index:80; display:flex; align-items:center; justify-content:center; padding:1rem; background:rgba(4,7,13,.72); backdrop-filter:blur(4px); opacity:0; visibility:hidden; transition:opacity .25s, visibility .25s; }
    .sup-modal.open { opacity:1; visibility:visible; }
    .sup-modal-card { width:100%; max-width:520px; max-height:90vh; overflow-y:auto; background:#fff; border-radius:1.25rem; border:1px solid rgba(226,232,240,.9); box-shadow:0 40px 90px -30px rgba(0,0,0,.75); transform:translateY(20px) scale(.96); transition:transform .32s cubic-bezier(.34,1.56,.64,1); }
    .sup-modal.open .sup-modal-card { transform:none; }
    .seg input:checked + span { background:linear-gradient(135deg,#f59e0b,#d97706); color:#fff; }
    .seg input:checked + span.grant { background:linear-gradient(135deg,#10b981,#047857); }
    .seg input:checked + span.deduct { background:linear-gradient(135deg,#f43f5e,#be123c); }
    ::-webkit-scrollbar { width:6px; height:6px; }
    ::-webkit-scrollbar-track { background:#0f172a; }
    ::-webkit-scrollbar-thumb { background:#334155; border-radius:3px; }
    .nice-scroll::-webkit-scrollbar-thumb { background:#cbd5e1; }
</style>
</head>
<body class="relative min-h-screen flex flex-col justify-between selection:bg-amber-900 selection:text-white">
<canvas id="snow-canvas"></canvas>

<header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
<div class="flex items-center justify-between h-16">
<a href="gmpanel.php" class="flex items-center space-x-3 no-underline group">
<img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
<div>
<div class="flex items-center space-x-2">
<span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
<span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-amber-900/80 text-amber-200 border border-amber-700/60 font-medium">錢包管理</span>
</div>
<p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Currency Console</p>
</div>
</a>
<nav class="flex items-center space-x-2 sm:space-x-4">
<a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-gauge-high text-slate-400"></i><span class="hidden sm:inline">GM 控制台</span></a>
<a href="wallet_admin.php" class="px-3 py-1.5 text-xs text-amber-300 bg-amber-950/50 border border-amber-800/60 rounded-md flex items-center gap-1.5"><i class="fa-solid fa-coins"></i><span class="hidden sm:inline">錢包管理</span></a>
<a href="support_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-headset text-slate-400"></i><span class="hidden sm:inline">申訴回報</span></a>
<a href="member_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-user-shield text-violet-400"></i><span class="hidden sm:inline">會員權限</span></a>
<div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
<div class="flex items-center space-x-2 bg-slate-900/90 border border-amber-900/50 px-3 py-1 rounded-full text-xs">
<span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
<span class="text-slate-400">管理員：</span>
<span class="font-semibold text-amber-300 font-mono"><?= wadmin_h($currentGmUsername) ?></span>
</div>
<a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors"><i class="fa-solid fa-arrow-right-from-bracket mr-1"></i><span class="hidden sm:inline">登出</span></a>
</div>
</nav>
</div>
</div>
</header>

<main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">

<?php if ($notice !== ''): ?>
<div class="glass-panel corner-accent rounded-xl px-5 py-4 flex items-start gap-3 border-l-4 anim-up <?= $noticeType === 'danger' ? 'border-l-rose-500' : 'border-l-emerald-500' ?>">
<i class="fa-solid <?= $noticeType === 'danger' ? 'fa-circle-exclamation text-rose-600' : 'fa-circle-check text-emerald-600' ?> mt-0.5"></i>
<p class="text-sm text-slate-700"><?= wadmin_h($notice) ?></p>
</div>
<?php endif; ?>

<div class="flex flex-col md:flex-row md:items-end justify-between gap-4 anim-up">
<div>
<div class="flex items-center gap-2 mb-1.5">
<span class="px-2 py-0.5 text-[11px] font-semibold text-amber-800 bg-amber-50 border border-amber-200 rounded">貨幣營運中心</span>
<span class="text-xs text-slate-400">點數儲值・元寶兌換・帳務稽核</span>
</div>
<h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider">點數 / 元寶管理</h1>
</div>
<div class="flex items-center gap-2 flex-wrap">
<button type="button" onclick="openModal('modal-settings')" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center gap-2 shadow-lg"><i class="fa-solid fa-sliders"></i> 貨幣設定</button>
<a href="wallet_admin.php" class="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-slate-700 text-slate-200 text-xs font-semibold no-underline flex items-center gap-2"><i class="fa-solid fa-rotate-right"></i> 重新整理</a>
</div>
</div>

<!-- KPI -->
<div class="grid grid-cols-2 lg:grid-cols-4 gap-4 anim-up d1">
<div class="kpi glass-panel corner-accent rounded-2xl p-5">
<div class="flex items-center justify-between mb-3">
<span class="w-11 h-11 rounded-xl bg-gradient-to-br from-sky-500 to-cyan-400 text-white flex items-center justify-center text-lg shadow coin-float"><i class="fa-solid fa-coins"></i></span>
<span class="text-[10px] font-mono text-sky-500">POINTS</span>
</div>
<p class="text-xs text-slate-500">全站<?= wadmin_h($pointsName) ?>總量</p>
<p class="text-3xl font-extrabold text-sky-700 font-mono"><?= number_format($sum['total_points']) ?></p>
</div>
<div class="kpi glass-panel corner-accent rounded-2xl p-5">
<div class="flex items-center justify-between mb-3">
<span class="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-yellow-400 text-white flex items-center justify-center text-lg shadow coin-float"><i class="fa-solid fa-gem"></i></span>
<span class="text-[10px] font-mono text-amber-500">YUANBAO</span>
</div>
<p class="text-xs text-slate-500">全站<?= wadmin_h($yuanbaoName) ?>總量</p>
<p class="text-3xl font-extrabold text-amber-700 font-mono"><?= number_format($sum['total_yuanbao']) ?></p>
</div>
<div class="kpi glass-panel corner-accent rounded-2xl p-5">
<div class="flex items-center justify-between mb-3">
<span class="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 text-white flex items-center justify-center text-lg shadow"><i class="fa-solid fa-arrow-trend-up"></i></span>
<span class="text-[10px] font-mono text-emerald-500">TODAY</span>
</div>
<p class="text-xs text-slate-500">今日儲值點數</p>
<p class="text-3xl font-extrabold text-emerald-700 font-mono"><?= number_format($today['recharge_points']) ?></p>
</div>
<div class="kpi glass-panel corner-accent rounded-2xl p-5">
<div class="flex items-center justify-between mb-3">
<span class="w-11 h-11 rounded-xl bg-gradient-to-br from-rose-500 to-pink-500 text-white flex items-center justify-center text-lg shadow"><i class="fa-solid fa-right-left"></i></span>
<span class="text-[10px] font-mono text-rose-500">EXCHANGE</span>
</div>
<p class="text-xs text-slate-500">今日兌換（點 → 元寶）</p>
<p class="text-xl font-extrabold text-rose-700 font-mono"><?= number_format($today['exchange_points']) ?> <span class="text-sm text-slate-400">→</span> <?= number_format($today['exchange_yuanbao']) ?></p>
</div>
</div>

<!-- 搜尋 + 設定摘要 -->
<div class="glass-panel corner-accent rounded-2xl p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3 anim-up d2">
<form method="GET" class="flex items-center gap-2 flex-wrap">
<div class="relative">
<i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none"></i>
<input type="text" name="q" value="<?= wadmin_h($q) ?>" placeholder="搜尋會員帳號 / UID / Email" class="wadmin-input !w-72 !pl-8">
</div>
<button type="submit" class="btn-gold px-4 py-2 rounded-lg text-xs font-semibold">查詢</button>
<?php if ($q !== ''): ?><a href="wallet_admin.php" class="text-xs text-slate-500 hover:text-slate-700 no-underline">清除</a><?php endif; ?>
</form>
<div class="flex items-center gap-3 flex-wrap text-[11px]">
<span class="flex items-center gap-1.5 text-slate-500"><i class="fa-solid fa-right-left text-amber-500"></i>匯率：1 <?= wadmin_h($pointsName) ?> ≈ <?= wadmin_h($rateDisplay) ?> <?= wadmin_h($yuanbaoName) ?></span>
<span class="text-slate-300">|</span>
<span class="flex items-center gap-1.5 text-slate-500"><i class="fa-solid fa-sack-dollar text-slate-400"></i>最低兌換 <?= number_format((int)$settings['exchange_min']) ?> 點</span>
<span class="text-slate-300">|</span>
<span class="px-2 py-0.5 rounded-full border <?= ((int)$settings['exchange_enabled'] === 1) ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200' ?>"><?= ((int)$settings['exchange_enabled'] === 1) ? '兌換開放中' : '兌換暫停' ?></span>
</div>
</div>

<?php if ($focus && $focusWallet): ?>
<!-- 焦點會員詳情 -->
<div class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 anim-up d2" id="focus-member">
<div class="flex items-start justify-between gap-4 flex-wrap pb-4 mb-4 border-b border-slate-200">
<div class="flex items-center gap-3">
<div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-600 to-rose-600 text-white flex items-center justify-center text-lg font-bold shadow-md"><?= wadmin_h(mb_strtoupper(mb_substr($focus['name'], 0, 1))) ?></div>
<div>
<div class="flex items-center gap-2">
<span class="font-bold text-slate-800"><?= wadmin_h($focus['name']) ?></span>
<span class="text-[11px] font-mono text-slate-400">UID <?= (int)$focus['ID'] ?></span>
</div>
<p class="text-[11px] text-slate-500"><?= wadmin_h($focus['email'] ?: '未綁定信箱') ?> · 註冊於 <?= wadmin_h($focus['creatime']) ?></p>
</div>
</div>
<div class="flex items-center gap-2">
<button type="button" class="btn-gold px-4 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5"
    data-uid="<?= (int)$focus['ID'] ?>" data-name="<?= wadmin_h($focus['name']) ?>" data-points="<?= (int)$focusWallet['points'] ?>" data-yuanbao="<?= (int)$focusWallet['yuanbao'] ?>"
    onclick="openAdjust(this)"><i class="fa-solid fa-wand-magic-sparkles"></i> 發放 / 扣減</button>
<a href="wallet_admin.php" class="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold no-underline hover:bg-slate-50">關閉</a>
</div>
</div>
<div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
<div class="p-3 rounded-xl bg-sky-50 border border-sky-200"><span class="text-[10px] text-slate-500 block"><?= wadmin_h($pointsName) ?>餘額</span><span class="text-xl font-bold text-sky-700 font-mono"><?= number_format((int)$focusWallet['points']) ?></span></div>
<div class="p-3 rounded-xl bg-amber-50 border border-amber-200"><span class="text-[10px] text-slate-500 block"><?= wadmin_h($yuanbaoName) ?>餘額</span><span class="text-xl font-bold text-amber-700 font-mono"><?= number_format((int)$focusWallet['yuanbao']) ?></span></div>
<div class="p-3 rounded-xl bg-slate-50 border border-slate-200"><span class="text-[10px] text-slate-500 block">累計<?= wadmin_h($pointsName) ?></span><span class="text-xl font-bold text-slate-700 font-mono"><?= number_format((int)$focusWallet['total_points_in']) ?></span></div>
<div class="p-3 rounded-xl bg-slate-50 border border-slate-200"><span class="text-[10px] text-slate-500 block">累計<?= wadmin_h($yuanbaoName) ?></span><span class="text-xl font-bold text-slate-700 font-mono"><?= number_format((int)$focusWallet['total_yuanbao_in']) ?></span></div>
</div>
<div class="grid grid-cols-1 lg:grid-cols-2 gap-5">
<div>
<h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">交易流水（近 60 筆）</h3>
<div class="max-h-80 overflow-y-auto nice-scroll space-y-0.5">
<?php if (empty($ledger)): ?><p class="text-xs text-slate-400 py-4 text-center">尚無流水。</p><?php endif; ?>
<?php foreach ($ledger as $l):
    $isYb = ($l['currency'] === 'yuanbao');
    $pos = ((int)$l['change_amount'] >= 0);
?>
<div class="ledger-row flex items-center gap-3 px-3 py-2 rounded-lg">
<span class="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] <?= $isYb ? 'bg-amber-100 text-amber-700' : 'bg-sky-100 text-sky-700' ?>"><i class="fa-solid <?= $isYb ? 'fa-gem' : 'fa-coins' ?>"></i></span>
<div class="flex-1 min-w-0">
<div class="text-xs text-slate-700 truncate"><?= wadmin_h($l['description'] ?: wadmin_type_label($l['type'])) ?></div>
<div class="text-[10px] text-slate-400 font-mono"><?= wadmin_h($l['created_at']) ?><?= $l['operator'] ? ' · ' . wadmin_h($l['operator']) : '' ?></div>
</div>
<div class="text-right">
<div class="text-xs font-bold font-mono <?= $pos ? 'text-emerald-600' : 'text-rose-600' ?>"><?= $pos ? '+' : '' ?><?= number_format((int)$l['change_amount']) ?></div>
<div class="text-[10px] text-slate-400">餘 <?= number_format((int)$l['balance_after']) ?></div>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
<div>
<h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">兌換紀錄</h3>
<div class="max-h-80 overflow-y-auto nice-scroll space-y-0.5">
<?php if (empty($exchanges)): ?><p class="text-xs text-slate-400 py-4 text-center">尚無兌換。</p><?php endif; ?>
<?php foreach ($exchanges as $e): ?>
<div class="ledger-row flex items-center gap-3 px-3 py-2 rounded-lg">
<span class="w-7 h-7 rounded-lg bg-gradient-to-br from-amber-500 to-rose-500 text-white flex items-center justify-center text-[11px]"><i class="fa-solid fa-right-left"></i></span>
<div class="flex-1 min-w-0">
<div class="text-xs text-slate-700"><?= number_format((int)$e['points_used']) ?> 點 → <span class="text-amber-700 font-semibold"><?= number_format((int)$e['yuanbao_gained']) ?> 元寶</span></div>
<div class="text-[10px] text-slate-400 font-mono"><?= wadmin_h($e['exchange_no']) ?> · <?= wadmin_h($e['created_at']) ?></div>
</div>
<span class="text-[10px] px-2 py-0.5 rounded-full <?= $e['status'] === 'completed' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600 border border-slate-200' ?>"><?= $e['status'] === 'completed' ? '完成' : wadmin_h($e['status']) ?></span>
</div>
<?php endforeach; ?>
</div>
</div>
</div>
</div>
<?php endif; ?>

<!-- 會員錢包列表 -->
<div class="glass-panel corner-accent rounded-2xl overflow-hidden anim-up d3">
<div class="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
<h3 class="text-sm font-bold text-slate-700 flex items-center gap-2"><i class="fa-solid fa-users text-slate-400"></i><?= $q !== '' ? '搜尋結果' : '最近異動會員' ?> <span class="text-[11px] font-normal text-slate-400">（<?= count($users) ?> 筆）</span></h3>
</div>
<div class="overflow-x-auto">
<table class="w-full text-sm">
<thead>
<tr class="bg-slate-50 border-b border-slate-200 text-left text-xs text-slate-500">
<th class="px-4 py-3">會員</th>
<th class="px-4 py-3">Email</th>
<th class="px-4 py-3 text-right"><?= wadmin_h($pointsName) ?></th>
<th class="px-4 py-3 text-right"><?= wadmin_h($yuanbaoName) ?></th>
<th class="px-4 py-3">最近異動</th>
<th class="px-4 py-3 text-right">操作</th>
</tr>
</thead>
<tbody>
<?php if (empty($users)): ?>
<tr><td colspan="6" class="px-4 py-14 text-center">
<div class="w-14 h-14 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 text-xl mb-3"><i class="fa-solid fa-user-slash"></i></div>
<p class="text-slate-500 text-sm"><?= $q !== '' ? '沒有符合條件的會員。' : '尚無錢包資料，請搜尋會員以進行發放。' ?></p>
</td></tr>
<?php else: ?>
<?php foreach ($users as $urow): ?>
<tr class="border-b border-slate-100 hover:bg-amber-50/40 transition-colors">
<td class="px-4 py-3">
<div class="flex items-center gap-2.5">
<span class="w-8 h-8 rounded-lg bg-gradient-to-br from-slate-700 to-slate-900 text-white flex items-center justify-center text-xs font-bold"><?= wadmin_h(mb_strtoupper(mb_substr($urow['name'], 0, 1))) ?></span>
<div>
<a href="wallet_admin.php?q=<?= urlencode($urow['name']) ?>&uid=<?= (int)$urow['ID'] ?>" class="font-semibold text-slate-800 hover:text-amber-700 no-underline text-sm"><?= wadmin_h($urow['name']) ?></a>
<div class="text-[10px] text-slate-400 font-mono">UID <?= (int)$urow['ID'] ?></div>
</div>
</div>
</td>
<td class="px-4 py-3 text-xs text-slate-500"><?= wadmin_h($urow['email'] ?: '—') ?></td>
<td class="px-4 py-3 text-right"><span class="font-bold text-sky-700 font-mono"><?= number_format((int)$urow['points']) ?></span></td>
<td class="px-4 py-3 text-right"><span class="font-bold text-amber-700 font-mono"><?= number_format((int)$urow['yuanbao']) ?></span></td>
<td class="px-4 py-3 text-xs text-slate-500 whitespace-nowrap"><?= wadmin_h($urow['updated_at'] ?: $urow['creatime']) ?></td>
<td class="px-4 py-3">
<div class="flex items-center justify-end gap-1.5">
<button type="button" class="btn-gold px-2.5 py-1.5 rounded-lg text-[11px] font-semibold"
    data-uid="<?= (int)$urow['ID'] ?>" data-name="<?= wadmin_h($urow['name']) ?>" data-points="<?= (int)$urow['points'] ?>" data-yuanbao="<?= (int)$urow['yuanbao'] ?>"
    onclick="openAdjust(this)"><i class="fa-solid fa-wand-magic-sparkles mr-1"></i>發放</button>
<a href="wallet_admin.php?q=<?= urlencode($urow['name']) ?>&uid=<?= (int)$urow['ID'] ?>" class="btn-ice px-2.5 py-1.5 rounded-lg text-[11px] font-semibold no-underline"><i class="fa-solid fa-list mr-1"></i>流水</a>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<!-- 最近兌換 -->
<?php if (!empty($recentExchanges)): ?>
<div class="glass-panel corner-accent rounded-2xl p-5 anim-up d3">
<h3 class="text-sm font-bold text-slate-700 flex items-center gap-2 mb-3"><i class="fa-solid fa-right-left text-slate-400"></i>全站最近兌換</h3>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
<?php foreach ($recentExchanges as $e): ?>
<div class="flex items-center gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
<span class="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-rose-500 text-white flex items-center justify-center text-xs"><i class="fa-solid fa-right-left"></i></span>
<div class="flex-1 min-w-0">
<div class="text-xs font-semibold text-slate-700 truncate"><?= wadmin_h($e['username']) ?> <span class="text-slate-400 font-mono text-[10px]">#<?= (int)$e['uid'] ?></span></div>
<div class="text-[11px] text-slate-500"><?= number_format((int)$e['points_used']) ?> 點 → <span class="text-amber-700"><?= number_format((int)$e['yuanbao_gained']) ?> 元寶</span></div>
<div class="text-[10px] text-slate-400 font-mono"><?= wadmin_h($e['created_at']) ?></div>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
<?php endif; ?>
</main>

<footer class="relative z-10 border-t border-slate-800 bg-[#090d16] py-6 text-center text-xs text-slate-500">
<div class="max-w-7xl mx-auto px-4 space-y-1.5">
<p class="text-slate-400"><a class="hover:text-slate-200 mx-2 no-underline" href="gmpanel.php">GM 控制台</a> · <a class="hover:text-slate-200 mx-2 no-underline" href="wallet_admin.php">錢包管理</a> · <a class="hover:text-slate-200 mx-2 no-underline" href="support_admin.php">申訴回報管理</a></p>
<p class="font-mono">© 2025 踏雪笑傲營運團隊 · Currency Console</p>
</div>
</footer>

<!-- ===== 發放 / 扣減 子視窗 ===== -->
<div class="sup-modal" id="modal-adjust" onclick="modalBackdrop(event,'modal-adjust')">
<div class="sup-modal-card">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5">
<span class="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-rose-500 text-white flex items-center justify-center"><i class="fa-solid fa-wand-magic-sparkles"></i></span>
<div><p class="font-bold text-slate-800 text-sm font-serif">調整會員資產</p><p class="text-[11px] text-slate-400" id="adj-subtitle">—</p></div>
</div>
<button type="button" onclick="closeModal('modal-adjust')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= wadmin_h($formToken) ?>">
<input type="hidden" name="action" value="adjust">
<input type="hidden" name="uid" id="adj-uid" value="">
<div class="grid grid-cols-2 gap-3 text-xs">
<div class="p-2.5 rounded-lg bg-sky-50 border border-sky-200 flex items-center justify-between"><span class="text-slate-500">目前<?= wadmin_h($pointsName) ?></span><b class="text-sky-700 font-mono" id="adj-cur-points">0</b></div>
<div class="p-2.5 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-between"><span class="text-slate-500">目前<?= wadmin_h($yuanbaoName) ?></span><b class="text-amber-700 font-mono" id="adj-cur-yuanbao">0</b></div>
</div>
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">幣別</label>
<div class="grid grid-cols-2 gap-2">
<label class="cursor-pointer"><input type="radio" name="currency" value="points" class="sr-only peer" checked><span class="block text-center py-2.5 rounded-xl border-2 border-slate-200 text-sm font-semibold text-sky-700 peer-checked:border-sky-500 peer-checked:bg-sky-50"><?= wadmin_h($pointsName) ?></span></label>
<label class="cursor-pointer"><input type="radio" name="currency" value="yuanbao" class="sr-only peer"><span class="block text-center py-2.5 rounded-xl border-2 border-slate-200 text-sm font-semibold text-amber-700 peer-checked:border-amber-500 peer-checked:bg-amber-50"><?= wadmin_h($yuanbaoName) ?></span></label>
</div>
</div>
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">操作類型</label>
<div class="grid grid-cols-2 gap-2 seg">
<label class="cursor-pointer"><input type="radio" name="direction" value="grant" class="sr-only" checked><span class="grant block text-center py-2.5 rounded-xl border-2 border-slate-200 text-sm font-semibold text-emerald-700"><i class="fa-solid fa-plus mr-1"></i>發放</span></label>
<label class="cursor-pointer"><input type="radio" name="direction" value="deduct" class="sr-only"><span class="deduct block text-center py-2.5 rounded-xl border-2 border-slate-200 text-sm font-semibold text-rose-700"><i class="fa-solid fa-minus mr-1"></i>扣減</span></label>
</div>
</div>
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">數量</label>
<input type="number" name="amount" min="1" step="1" value="100" class="wadmin-input" required>
</div>
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">原因 / 備註</label>
<textarea name="reason" rows="2" class="wadmin-input" placeholder="例：活動補償、客服補發…"></textarea>
</div>
<p class="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2.5"><i class="fa-solid fa-circle-info mr-1"></i>調整<?= wadmin_h($yuanbaoName) ?>時將同步寫入遊戲 point 表（aid=23）。</p>
<div class="flex items-center justify-end gap-3">
<button type="button" onclick="closeModal('modal-adjust')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-gold px-5 py-2.5 rounded-xl text-xs font-semibold"><i class="fa-solid fa-check mr-1"></i>確認送出</button>
</div>
</form>
</div>
</div>

<!-- ===== 貨幣設定 子視窗 ===== -->
<div class="sup-modal" id="modal-settings" onclick="modalBackdrop(event,'modal-settings')">
<div class="sup-modal-card">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5">
<span class="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-600 to-slate-800 text-white flex items-center justify-center"><i class="fa-solid fa-sliders"></i></span>
<div><p class="font-bold text-slate-800 text-sm font-serif">貨幣與兌換設定</p><p class="text-[11px] text-slate-400">名稱、匯率、最低兌換與開關</p></div>
</div>
<button type="button" onclick="closeModal('modal-settings')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= wadmin_h($formToken) ?>">
<input type="hidden" name="action" value="update_settings">
<div class="grid grid-cols-2 gap-3">
<div><label class="text-xs font-semibold text-slate-600 block mb-1">點數顯示名稱</label><input type="text" name="points_name" maxlength="20" class="wadmin-input" value="<?= wadmin_h($settings['points_name']) ?>"></div>
<div><label class="text-xs font-semibold text-slate-600 block mb-1">元寶顯示名稱</label><input type="text" name="yuanbao_name" maxlength="20" class="wadmin-input" value="<?= wadmin_h($settings['yuanbao_name']) ?>"></div>
</div>
<div class="grid grid-cols-3 gap-3">
<div><label class="text-xs font-semibold text-slate-600 block mb-1">匯率（元寶/點）</label><input type="number" name="exchange_rate" step="0.0001" min="0.0001" class="wadmin-input" value="<?= wadmin_h($settings['exchange_rate']) ?>"></div>
<div><label class="text-xs font-semibold text-slate-600 block mb-1">最低兌換點數</label><input type="number" name="exchange_min" min="1" step="1" class="wadmin-input" value="<?= wadmin_h($settings['exchange_min']) ?>"></div>
<div><label class="text-xs font-semibold text-slate-600 block mb-1">手續費 %</label><input type="number" name="exchange_fee_percent" min="0" max="100" step="1" class="wadmin-input" value="<?= wadmin_h($settings['exchange_fee_percent']) ?>"></div>
</div>
<label class="flex items-center gap-2.5 p-3 rounded-xl border border-slate-200 bg-slate-50 cursor-pointer">
<input type="checkbox" name="exchange_enabled" value="1" class="w-4 h-4 accent-amber-500" <?= ((int)$settings['exchange_enabled'] === 1) ? 'checked' : '' ?>>
<span class="text-sm text-slate-700 font-medium">開放會員點數兌換元寶</span>
</label>
<div class="flex items-center justify-end gap-3">
<button type="button" onclick="closeModal('modal-settings')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-gold px-5 py-2.5 rounded-xl text-xs font-semibold"><i class="fa-solid fa-check mr-1"></i>儲存設定</button>
</div>
</form>
</div>
</div>

<script>
function openModal(id) { var m = document.getElementById(id); if (!m) return; m.classList.add('open'); document.body.style.overflow = 'hidden'; }
function closeModal(id) { var m = document.getElementById(id); if (!m) return; m.classList.remove('open'); document.body.style.overflow = ''; }
function modalBackdrop(e, id) { if (e.target && e.target.id === id) { closeModal(id); } }
document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { document.querySelectorAll('.sup-modal.open').forEach(function (m) { closeModal(m.id); }); } });

function openAdjust(btn) {
    var d = btn.dataset;
    document.getElementById('adj-uid').value = d.uid || '';
    document.getElementById('adj-subtitle').textContent = (d.name || '') + ' · UID ' + (d.uid || '');
    document.getElementById('adj-cur-points').textContent = Number(d.points || 0).toLocaleString('en-US');
    document.getElementById('adj-cur-yuanbao').textContent = Number(d.yuanbao || 0).toLocaleString('en-US');
    openModal('modal-adjust');
}

(function () {
    const canvas = document.getElementById('snow-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth), height = (canvas.height = window.innerHeight);
    window.addEventListener('resize', () => { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; });
    const particles = [];
    const count = Math.min(Math.floor(window.innerWidth / 30), 45);
    for (let i = 0; i < count; i++) { particles.push({ x: Math.random() * width, y: Math.random() * height, radius: Math.random() * 2 + 0.8, speedY: Math.random() * 0.6 + 0.25, speedX: (Math.random() - 0.5) * 0.35, opacity: Math.random() * 0.5 + 0.2, pulsePhase: Math.random() * Math.PI * 2 }); }
    function render() {
        ctx.clearRect(0, 0, width, height);
        for (let i = 0; i < particles.length; i++) {
            const p = particles[i]; p.y += p.speedY; p.x += p.speedX; p.pulsePhase += 0.01;
            if (p.y > height) { p.y = -10; p.x = Math.random() * width; }
            if (p.x > width) p.x = 0; if (p.x < 0) p.x = width;
            const op = Math.max(0.12, Math.min(0.75, p.opacity + Math.sin(p.pulsePhase) * 0.12));
            ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2); ctx.fillStyle = 'rgba(255,248,235,' + op + ')'; ctx.fill();
        }
        requestAnimationFrame(render);
    }
    render();
})();
</script>
</body>
</html>
