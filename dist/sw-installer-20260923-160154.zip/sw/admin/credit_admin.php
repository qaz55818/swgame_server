<?php
/**
 * =============================================================
 *  踏雪笑傲 · 帳號信用管理後台（GM 端）
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *
 *  功能：會員信用查詢、信用分數編輯（設定分數 / 加減分 / 回復預設）、
 *        信用系統參數設定、異動流水查詢
 *  對應資料表：credit_settings / user_credit / credit_ledger
 *  前台顯示：../home.php
 *
 *  支援 ?embed=1 以子視窗（iframe）方式載入，隱藏最外層頁首。
 * =============================================================
 */
session_start();
include_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../credit.php';

if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
$currentGmUsername = (string)$_SESSION['gm_username'];
$currentGmId = (int)($_SESSION['gm_id'] ?? 0);

$embed = !empty($_GET['embed']);

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($Link, "utf8mb4");

credit_ensure_table($Link);

if (empty($_SESSION['credit_admin_token'])) {
    $_SESSION['credit_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['credit_admin_token'];

$notice = '';
$noticeType = 'success';

// ------------------------------------------------------------
// 表單處理（PRG）
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['form_token']) || !hash_equals($_SESSION['credit_admin_token'], (string)$_POST['form_token'])) {
        $notice = '工作階段已過期，請重新操作。';
        $noticeType = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        $uid = (int)($_POST['uid'] ?? 0);
        $backUid = 0;

        if ($action === 'save_settings') {
            $values = [
                'credit_enabled'  => isset($_POST['credit_enabled']) ? '1' : '0',
                'show_on_home'    => isset($_POST['show_on_home']) ? '1' : '0',
                'default_score'   => (string)(int)($_POST['default_score'] ?? 100),
                'min_score'       => (string)(int)($_POST['min_score'] ?? 0),
                'max_score'       => (string)(int)($_POST['max_score'] ?? 1000),
                'tier_excellent'  => (string)(int)($_POST['tier_excellent'] ?? 90),
                'tier_good'       => (string)(int)($_POST['tier_good'] ?? 75),
                'tier_fair'       => (string)(int)($_POST['tier_fair'] ?? 60),
                'tier_poor'       => (string)(int)($_POST['tier_poor'] ?? 40),
                'risk_threshold'  => (string)(int)($_POST['risk_threshold'] ?? 60),
            ];
            if (credit_save_settings($Link, $values)) {
                $notice = '已更新信用系統參數設定。';
            } else {
                $notice = '設定儲存失敗，請稍後再試。';
                $noticeType = 'danger';
            }
            if ($noticeType !== 'danger') {
                $_SESSION['credit_admin_notice'] = ['type' => $noticeType, 'msg' => $notice];
                header("Location: credit_admin.php" . ($embed ? '?embed=1' : ''));
                exit();
            }
        } elseif ($uid <= 0) {
            $notice = '請先選擇要設定的會員。';
            $noticeType = 'danger';
        } elseif ($action === 'save_credit') {
            $mode = $_POST['mode'] ?? 'set';
            $value = (int)($_POST['value'] ?? 0);
            $reason = trim((string)($_POST['reason'] ?? ''));
            $note = trim((string)($_POST['note'] ?? ''));
            if ($mode === 'adjust') {
                $result = credit_adjust($Link, $uid, $value, $reason !== '' ? $reason : '管理員調整信用分數', $currentGmUsername, $note);
            } else {
                $result = credit_write($Link, $uid, $value, 'admin_set', $reason !== '' ? $reason : '管理員設定信用分數', $currentGmUsername, $note);
            }
            if (!empty($result['ok'])) {
                $notice = '會員 UID ' . $uid . ' 信用分數已更新為 ' . (int)$result['score'] . ' 分（'
                    . ($result['delta'] > 0 ? '+' : '') . (int)$result['delta'] . '，'
                    . $result['level']['label'] . '）。';
                $backUid = $uid;
            } else {
                $notice = '更新失敗：' . $result['message'];
                $noticeType = 'danger';
            }
        } elseif ($action === 'reset_credit') {
            $settings = credit_load_settings($Link);
            $default = (int)$settings['default_score'];
            $result = credit_write($Link, $uid, $default, 'reset', '管理員回復預設信用分數', $currentGmUsername, '');
            if (!empty($result['ok'])) {
                $notice = '會員 UID ' . $uid . ' 信用分數已回復預設 ' . $default . ' 分。';
                $backUid = $uid;
            } else {
                $notice = '回復失敗：' . $result['message'];
                $noticeType = 'danger';
            }
        } else {
            $notice = '未知的操作。';
            $noticeType = 'danger';
        }

        if ($noticeType !== 'danger') {
            $_SESSION['credit_admin_notice'] = ['type' => $noticeType, 'msg' => $notice];
            $redir = 'credit_admin.php';
            $qs = [];
            if ($embed) { $qs[] = 'embed=1'; }
            if ($backUid > 0) { $qs[] = 'uid=' . $backUid; }
            if ($qs) { $redir .= '?' . implode('&', $qs); }
            header("Location: " . $redir);
            exit();
        }
    }
}

$flash = $_SESSION['credit_admin_notice'] ?? null;
unset($_SESSION['credit_admin_notice']);
if ($flash) { $notice = $flash['msg']; $noticeType = $flash['type']; }

// ------------------------------------------------------------
// 統計
// ------------------------------------------------------------
$settings = credit_load_settings($Link);
$levelMap = credit_level_map();
$stats = credit_stats($Link, $settings);
$defaultScore = (int)$settings['default_score'];

// ------------------------------------------------------------
// 會員搜尋 / 列表
// ------------------------------------------------------------
$q = trim((string)($_GET['q'] ?? ''));
$focusUid = (int)($_GET['uid'] ?? 0);
$members = [];
$memberSelect = "SELECT u.`ID`, u.`name`, u.`email`, IFNULL(c.`score`, $defaultScore) AS `score`,
                        c.`updated_at`, c.`updated_by`
                 FROM `users` u LEFT JOIN `user_credit` c ON c.`uid` = u.`ID`";
if ($q !== '') {
    $like = '%' . $q . '%';
    if (ctype_digit($q)) {
        $stmt = $Link->prepare($memberSelect . " WHERE u.`ID` = ? OR u.`name` LIKE ? OR u.`email` LIKE ? ORDER BY u.`ID` ASC LIMIT 50");
        $uidInt = (int)$q;
        $stmt->bind_param("iss", $uidInt, $like, $like);
    } else {
        $stmt = $Link->prepare($memberSelect . " WHERE u.`name` LIKE ? OR u.`email` LIKE ? ORDER BY u.`ID` ASC LIMIT 50");
        $stmt->bind_param("ss", $like, $like);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $members[] = $row; }
    $stmt->close();
} else {
    $r = mysqli_query($Link, $memberSelect . " ORDER BY u.`ID` DESC LIMIT 30");
    if ($r) { while ($row = $r->fetch_assoc()) { $members[] = $row; } }
}

// ------------------------------------------------------------
// 焦點會員信用
// ------------------------------------------------------------
$focus = null;
$focusCredit = null;
$focusLevel = null;
$focusLedger = [];
$focusScoreJs = 0;
if ($focusUid > 0) {
    $stmt = $Link->prepare("SELECT `ID`, `name`, `email`, `creatime` FROM `users` WHERE `ID` = ? LIMIT 1");
    $stmt->bind_param("i", $focusUid);
    $stmt->execute();
    $focus = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($focus) {
        $focusCredit = credit_get($Link, $focusUid);
        $focusLevel = $focusCredit['level'];
        $focusScoreJs = (int)$focusCredit['score'];
        $focusLedger = credit_recent_ledger($Link, $focusUid, 12);
    } else {
        $notice = '找不到該會員。';
        $noticeType = 'danger';
    }
}

mysqli_close($Link);

function cad_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function cad_fmt_date($v) {
    if (empty($v) || $v === '0000-00-00 00:00:00') { return '—'; }
    $ts = strtotime($v);
    return $ts ? date('Y-m-d H:i', $ts) : '—';
}

/** 等級色彩對應（前台顯示用） */
$levelColors = [
    'emerald' => ['bg' => '#ecfdf5', 'bd' => '#a7f3d0', 'tx' => '#047857'],
    'sky'     => ['bg' => '#f0f9ff', 'bd' => '#bae6fd', 'tx' => '#0369a1'],
    'amber'   => ['bg' => '#fffbeb', 'bd' => '#fde68a', 'tx' => '#b45309'],
    'orange'  => ['bg' => '#fff7ed', 'bd' => '#fed7aa', 'tx' => '#c2410c'],
    'rose'    => ['bg' => '#fff1f2', 'bd' => '#fecdd3', 'tx' => '#be123c'],
];
function level_color_style($color, $levelColors) {
    $c = $levelColors[$color] ?? $levelColors['sky'];
    return 'background:' . $c['bg'] . ';border-color:' . $c['bd'] . ';color:' . $c['tx'] . ';';
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>踏雪笑傲 · 帳號信用管理</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Noto+Sans+TC:wght@300;400;500;700&display=swap" rel="stylesheet">
<style>
    :root { --vermilion:#be123c; --gold:#d97706; --ice:#0284c7; --emerald:#059669; }
    * { box-sizing:border-box; }
    body {
        margin:0; color:#1e293b; font-family:'Noto Sans TC','Noto Serif TC',sans-serif; min-height:100vh;
        background-color:#080c14;
        background-image:
            radial-gradient(ellipse at 50% 0%, rgba(5,150,105,.14) 0%, transparent 60%),
            radial-gradient(ellipse at 85% 90%, rgba(2,132,199,.10) 0%, transparent 50%),
            radial-gradient(ellipse at 15% 65%, rgba(15,23,42,.82) 0%, transparent 70%);
    }
    body.embed { background:#f1f5f9; background-image:none; }
    a { text-decoration:none; }
    .ca-top { border-bottom:1px solid #1e293b; background:rgba(12,16,26,.92); backdrop-filter:blur(10px); position:sticky; top:0; z-index:30; }
    .ca-wrap { max-width:1260px; margin:0 auto; padding:0 16px; }
    .ca-header { display:flex; align-items:center; justify-content:space-between; height:64px; gap:12px; }
    .ca-logo { display:flex; align-items:center; gap:12px; color:#e2e8f0; }
    .ca-logo img { width:36px; height:36px; border-radius:50%; border:1px solid #334155; padding:2px; background:rgba(255,255,255,.08); }
    .ca-logo .brand { font-family:'Noto Serif TC',serif; font-size:19px; font-weight:700; letter-spacing:.16em; }
    .ca-logo .sub { font-size:10px; color:#94a3b8; letter-spacing:.2em; text-transform:uppercase; font-family:'Cinzel',serif; margin:0; }
    .ca-tag { font-size:10px; letter-spacing:.1em; padding:2px 8px; border-radius:4px; background:rgba(6,78,59,.8); color:#6ee7b7; border:1px solid rgba(16,185,129,.55); margin-left:8px; font-weight:500; }
    .ca-nav { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
    .ca-nav a.link { padding:6px 12px; font-size:12px; color:#cbd5e1; border-radius:6px; transition:.2s; display:flex; align-items:center; gap:6px; }
    .ca-nav a.link:hover { color:#fff; background:rgba(30,41,59,.8); }
    .ca-nav a.link.active { color:#6ee7b7; background:rgba(6,78,59,.5); border:1px solid rgba(16,185,129,.6); }
    .ca-user { display:flex; align-items:center; gap:10px; padding:4px 12px; background:rgba(15,23,42,.9); border:1px solid rgba(16,185,129,.5); border-radius:999px; font-size:12px; color:#94a3b8; }
    .ca-user b { color:#6ee7b7; font-family:monospace; }
    .ca-out { padding:5px 10px; font-size:12px; color:#fb7185; border:1px solid rgba(159,18,57,.5); border-radius:6px; transition:.2s; }
    .ca-out:hover { color:#fecdd3; background:rgba(76,5,25,.5); }

    .ca-main { max-width:1260px; margin:0 auto; padding:28px 16px 60px; }
    body.embed .ca-main { padding:18px 14px 40px; }
    .ca-title { color:#f1f5f9; font-family:'Noto Serif TC',serif; font-size:26px; letter-spacing:.06em; margin:0 0 6px; display:flex; align-items:center; gap:10px; }
    body.embed .ca-title { color:#0f172a; font-size:20px; }
    .ca-title .bar { width:8px; height:26px; background:var(--emerald); border-radius:2px; }
    .ca-desc { color:#94a3b8; font-size:13px; margin:0 0 22px; }
    body.embed .ca-desc { color:#64748b; margin-bottom:16px; }

    .ca-kpis { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:14px; margin-bottom:22px; }
    .ca-kpi { background:rgba(255,255,255,.96); border:1px solid rgba(226,232,240,.9); border-radius:16px; padding:16px 18px; box-shadow:0 12px 30px -14px rgba(0,0,0,.5); }
    .ca-kpi span.k { font-size:12px; color:#64748b; display:block; margin-bottom:6px; }
    .ca-kpi .v { font-size:26px; font-weight:800; font-family:monospace; }
    .ca-kpi .v.emerald { color:#059669; }
    .ca-kpi .v.rose { color:#be123c; }
    .ca-kpi .v.sky { color:#0284c7; }

    .ca-grid { display:grid; grid-template-columns:1fr; gap:20px; }
    @media (min-width:960px) { .ca-grid { grid-template-columns:380px 1fr; align-items:start; } }

    .ca-panel { background:rgba(255,255,255,.97); border:1px solid rgba(226,232,240,.9); border-radius:18px; box-shadow:0 16px 40px -22px rgba(0,0,0,.6); overflow:hidden; }
    .ca-panel-head { padding:15px 20px; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .ca-panel-head h2 { margin:0; font-size:15px; color:#1e293b; font-family:'Noto Serif TC',serif; display:flex; align-items:center; gap:8px; }
    .ca-panel-body { padding:16px 20px; }

    .ca-search { display:flex; gap:8px; }
    .ca-input { flex:1; border:1px solid #cbd5e1; border-radius:9px; padding:9px 12px; font-size:13px; color:#1e293b; background:#fff; transition:.2s; }
    .ca-input:focus { outline:none; border-color:var(--emerald); box-shadow:0 0 0 3px rgba(5,150,105,.12); }
    .ca-btn { border:none; cursor:pointer; border-radius:9px; padding:9px 16px; font-size:13px; font-weight:600; color:#fff; transition:.22s; display:inline-flex; align-items:center; justify-content:center; gap:7px; }
    .ca-btn.emerald { background:linear-gradient(135deg,#10b981,#047857); }
    .ca-btn.emerald:hover { background:linear-gradient(135deg,#34d399,#10b981); transform:translateY(-1px); }
    .ca-btn.rose { background:linear-gradient(135deg,#e11d48,#9f1239); }
    .ca-btn.rose:hover { background:linear-gradient(135deg,#fb7185,#e11d48); transform:translateY(-1px); }
    .ca-btn.ice { background:linear-gradient(135deg,#0284c7,#0369a1); }
    .ca-btn.ice:hover { background:linear-gradient(135deg,#0ea5e9,#0284c7); transform:translateY(-1px); }
    .ca-btn.gray { background:#64748b; }
    .ca-btn.gray:hover { background:#475569; }
    .ca-btn.sm { padding:7px 12px; font-size:12px; }

    .ca-list { list-style:none; margin:14px 0 0; padding:0; max-height:560px; overflow-y:auto; }
    .ca-list li { border:1px solid #e2e8f0; border-radius:12px; margin-bottom:9px; transition:.2s; }
    .ca-list li:hover { border-color:#94a3b8; background:#f8fafc; }
    .ca-list li.active { border-color:var(--emerald); background:#ecfdf5; box-shadow:0 0 0 3px rgba(5,150,105,.08); }
    .ca-list a { display:block; padding:11px 13px; color:inherit; }
    .ca-list .mrow { display:flex; align-items:center; justify-content:space-between; gap:8px; }
    .ca-list .mname { font-weight:700; color:#1e293b; font-size:14px; }
    .ca-list .muid { font-size:11px; color:#94a3b8; font-family:monospace; }
    .ca-list .memail { font-size:11px; color:#64748b; margin-top:2px; word-break:break-all; }
    .ca-list .scoretag { font-size:11px; font-weight:800; font-family:monospace; padding:2px 8px; border-radius:999px; white-space:nowrap; }

    .ca-focus-head { display:flex; align-items:center; gap:14px; flex-wrap:wrap; }
    .ca-focus-avatar { width:52px; height:52px; border-radius:14px; background:linear-gradient(135deg,#059669,#065f46); color:#fff; display:flex; align-items:center; justify-content:center; font-size:22px; font-weight:700; font-family:'Noto Serif TC',serif; }
    .ca-focus-meta h3 { margin:0; font-size:17px; color:#1e293b; }
    .ca-focus-meta p { margin:2px 0 0; font-size:12px; color:#64748b; }

    .ca-score-hero { display:flex; align-items:center; gap:20px; padding:18px; border-radius:16px; margin:16px 0; border:1px solid #e2e8f0; background:linear-gradient(135deg,#f8fafc,#fff); flex-wrap:wrap; }
    .ca-score-ring { width:104px; height:104px; border-radius:50%; display:flex; flex-direction:column; align-items:center; justify-content:center; flex-shrink:0; border:6px solid #10b981; background:#fff; box-shadow:0 10px 26px -12px rgba(5,150,105,.7); }
    .ca-score-ring .num { font-size:34px; font-weight:800; font-family:monospace; line-height:1; color:#0f172a; }
    .ca-score-ring .den { font-size:11px; color:#94a3b8; margin-top:2px; }
    .ca-score-info { flex:1; min-width:180px; }
    .ca-score-info .lvl { display:inline-flex; align-items:center; gap:6px; font-size:12px; font-weight:700; padding:3px 10px; border-radius:999px; border:1px solid; }
    .ca-score-info .desc { font-size:12px; color:#64748b; margin:9px 0 0; line-height:1.55; }
    .ca-score-info .delta { font-size:11px; color:#94a3b8; margin-top:6px; font-family:monospace; }

    .ca-actions { display:flex; gap:9px; flex-wrap:wrap; margin:4px 0 4px; }

    .ca-table { width:100%; border-collapse:collapse; font-size:12px; }
    .ca-table th { text-align:left; color:#64748b; font-weight:600; padding:8px 10px; border-bottom:1px solid #e2e8f0; background:#f8fafc; font-size:11px; white-space:nowrap; }
    .ca-table td { padding:9px 10px; border-bottom:1px solid #f1f5f9; color:#334155; vertical-align:middle; }
    .ca-delta.up { color:#059669; font-weight:700; font-family:monospace; }
    .ca-delta.down { color:#e11d48; font-weight:700; font-family:monospace; }
    .ca-ledger-empty { text-align:center; color:#94a3b8; font-size:12px; padding:26px 0; }

    .ca-empty { text-align:center; padding:60px 20px; color:#94a3b8; }
    .ca-empty i { font-size:46px; margin-bottom:14px; color:#cbd5e1; display:block; }
    .ca-notice { border-radius:14px; padding:13px 18px; font-size:13px; margin-bottom:18px; display:flex; align-items:flex-start; gap:10px; border-left:4px solid; background:#fff; box-shadow:0 8px 24px -16px rgba(0,0,0,.5); }
    .ca-notice.success { border-left-color:#10b981; }
    .ca-notice.danger { border-left-color:#e11d48; }

    /* 子視窗（彈出 UI） */
    .ca-modal { position:fixed; inset:0; z-index:90; display:flex; align-items:center; justify-content:center; padding:16px; background:rgba(4,7,13,.72); backdrop-filter:blur(4px); opacity:0; visibility:hidden; transition:opacity .25s, visibility .25s; }
    .ca-modal.open { opacity:1; visibility:visible; }
    .ca-modal-card { width:100%; max-width:560px; max-height:90vh; overflow-y:auto; background:#fff; border-radius:18px; border:1px solid rgba(226,232,240,.9); box-shadow:0 40px 90px -30px rgba(0,0,0,.75); transform:translateY(20px) scale(.96); transition:transform .32s cubic-bezier(.34,1.56,.64,1); }
    .ca-modal.open .ca-modal-card { transform:none; }
    .ca-modal-head { padding:17px 20px; border-bottom:1px solid #e2e8f0; display:flex; align-items:center; justify-content:space-between; gap:12px; }
    .ca-modal-head .t { display:flex; align-items:center; gap:12px; }
    .ca-modal-head .ico { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:17px; color:#fff; }
    .ca-modal-head h3 { margin:0; font-size:15px; color:#0f172a; font-family:'Noto Serif TC',serif; }
    .ca-modal-head p { margin:2px 0 0; font-size:11px; color:#94a3b8; }
    .ca-modal-body { padding:18px 20px; }
    .ca-modal-foot { padding:14px 20px; border-top:1px solid #e2e8f0; display:flex; justify-content:flex-end; gap:10px; background:#f8fafc; }
    .ca-close { width:34px; height:34px; border-radius:9px; border:none; background:transparent; color:#94a3b8; cursor:pointer; font-size:16px; transition:.2s; }
    .ca-close:hover { color:#334155; background:#f1f5f9; }
    .ca-field { margin-bottom:14px; }
    .ca-field label { display:block; font-size:12px; font-weight:600; color:#475569; margin-bottom:5px; }
    .ca-field input[type=text], .ca-field input[type=number] { width:100%; border:1px solid #cbd5e1; border-radius:9px; padding:9px 12px; font-size:13px; color:#1e293b; background:#fff; }
    .ca-field input:focus { outline:none; border-color:var(--emerald); box-shadow:0 0 0 3px rgba(5,150,105,.12); }
    .ca-field .hint { font-size:11px; color:#94a3b8; margin-top:4px; }
    .ca-grid2 { display:grid; grid-template-columns:1fr 1fr; gap:12px; }
    .ca-radio-row { display:flex; gap:10px; }
    .ca-radio { flex:1; border:1px solid #cbd5e1; border-radius:10px; padding:10px 12px; cursor:pointer; font-size:12px; color:#475569; text-align:center; transition:.2s; }
    .ca-radio input { display:none; }
    .ca-radio.on { border-color:#10b981; background:#ecfdf5; color:#047857; font-weight:700; box-shadow:0 0 0 3px rgba(5,150,105,.1); }
    .ca-switch-row { display:flex; align-items:center; justify-content:space-between; gap:10px; padding:10px 12px; border:1px solid #e2e8f0; border-radius:10px; }
    .ca-switch { position:relative; display:inline-block; width:48px; height:26px; flex-shrink:0; }
    .ca-switch input { opacity:0; width:0; height:0; }
    .ca-switch .slider { position:absolute; cursor:pointer; inset:0; background:#cbd5e1; border-radius:999px; transition:.25s; }
    .ca-switch .slider::before { content:''; position:absolute; height:18px; width:18px; left:4px; top:4px; background:#fff; border-radius:50%; transition:.25s; box-shadow:0 2px 4px rgba(0,0,0,.2); }
    .ca-switch input:checked + .slider { background:linear-gradient(135deg,#10b981,#047857); }
    .ca-switch input:checked + .slider::before { transform:translateX(22px); }
</style>
</head>
<body class="<?= $embed ? 'embed' : '' ?>">

<?php if (!$embed): ?>
<header class="ca-top">
    <div class="ca-wrap ca-header">
        <a href="gmpanel.php" class="ca-logo">
            <img src="../assets/logo.svg" alt="踏雪笑傲">
            <div>
                <div style="display:flex;align-items:center;">
                    <span class="brand">踏雪笑傲</span>
                    <span class="ca-tag">信用管理</span>
                </div>
                <p class="sub">Credit Control Console</p>
            </div>
        </a>
        <nav class="ca-nav">
            <a href="gmpanel.php" class="link"><i class="fa-solid fa-gauge-high"></i><span>GM 控制台</span></a>
            <a href="member_admin.php" class="link"><i class="fa-solid fa-user-shield"></i><span>會員權限</span></a>
            <a href="wallet_admin.php" class="link"><i class="fa-solid fa-coins" style="color:#fbbf24;"></i><span>錢包管理</span></a>
            <a href="credit_admin.php" class="link active"><i class="fa-solid fa-shield-halved"></i><span>信用管理</span></a>
            <div class="ca-user"><i class="fa-solid fa-user-tie" style="color:#6ee7b7;"></i> 管理員：<b><?= cad_h($currentGmUsername) ?></b></div>
            <a href="gmlogout.php" class="ca-out"><i class="fa-solid fa-arrow-right-from-bracket"></i> 登出</a>
        </nav>
    </div>
</header>
<?php endif; ?>

<main class="ca-main">
    <h1 class="ca-title"><span class="bar"></span>帳號信用管理</h1>
    <p class="ca-desc">檢視與調整會員信用分數，並設定信用等級門檻與系統參數；所有異動皆寫入信用流水，預設信用分數為 <?= (int)$defaultScore ?> 分。</p>

    <?php if ($notice !== ''): ?>
    <div class="ca-notice <?= $noticeType === 'danger' ? 'danger' : 'success' ?>">
        <i class="fa-solid <?= $noticeType === 'danger' ? 'fa-circle-exclamation' : 'fa-circle-check' ?>" style="color:<?= $noticeType === 'danger' ? '#e11d48' : '#10b981' ?>;margin-top:2px;"></i>
        <span style="color:#334155;"><?= cad_h($notice) ?></span>
    </div>
    <?php endif; ?>

    <div class="ca-kpis">
        <div class="ca-kpi"><span class="k">會員總數</span><span class="v sky"><?= number_format($stats['total']) ?></span></div>
        <div class="ca-kpi"><span class="k">平均信用分數</span><span class="v emerald"><?= number_format($stats['avg']) ?></span></div>
        <div class="ca-kpi"><span class="k">風險帳號（&lt; <?= (int)$settings['risk_threshold'] ?>）</span><span class="v rose"><?= number_format($stats['risk']) ?></span></div>
        <div class="ca-kpi"><span class="k">信用系統狀態</span><span class="v <?= ((int)$settings['credit_enabled'] === 1) ? 'emerald' : 'rose' ?>" style="font-size:20px;"><?= ((int)$settings['credit_enabled'] === 1) ? '運作中' : '已停用' ?></span></div>
    </div>

    <div class="ca-actions" style="margin-bottom:16px;">
        <button type="button" class="ca-btn ice" onclick="openCreditModal('modal-settings')"><i class="fa-solid fa-sliders"></i>信用系統參數設定</button>
        <a href="credit_admin.php<?= $embed ? '?embed=1' : '' ?>" class="ca-btn gray"><i class="fa-solid fa-rotate"></i>重新整理</a>
    </div>

    <div class="ca-grid">
        <!-- 會員列表 -->
        <section class="ca-panel">
            <div class="ca-panel-head">
                <h2><i class="fa-solid fa-list-ul" style="color:#059669;"></i>會員信用名冊</h2>
                <span style="font-size:11px;color:#94a3b8;">共 <?= count($members) ?> 筆</span>
            </div>
            <div class="ca-panel-body">
                <form method="GET" action="credit_admin.php" class="ca-search">
                    <?php if ($embed): ?><input type="hidden" name="embed" value="1"><?php endif; ?>
                    <input type="text" name="q" class="ca-input" placeholder="帳號 / 暱稱 / Email / UID" value="<?= cad_h($q) ?>">
                    <button type="submit" class="ca-btn emerald"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
                <ul class="ca-list">
                    <?php if (!$members): ?>
                        <li style="border:none;"><div style="text-align:center;color:#94a3b8;font-size:13px;padding:24px 0;">無符合條件的會員</div></li>
                    <?php else: foreach ($members as $m):
                        $mScore = (int)$m['score'];
                        $mLevel = credit_level($mScore, $settings);
                        $mStyle = level_color_style($mLevel['color'], $levelColors);
                        $isActive = ((int)$m['ID'] === $focusUid);
                    ?>
                        <li class="<?= $isActive ? 'active' : '' ?>">
                            <a href="credit_admin.php?<?= $embed ? 'embed=1&amp;' : '' ?>uid=<?= (int)$m['ID'] ?><?= $q !== '' ? '&amp;q=' . urlencode($q) : '' ?>">
                                <div class="mrow">
                                    <span class="mname"><?= cad_h($m['name']) ?></span>
                                    <span class="scoretag" style="<?= $mStyle ?>"><?= $mScore ?> · <?= cad_h($mLevel['label']) ?></span>
                                </div>
                                <div class="muid">UID: <?= (int)$m['ID'] ?><?= !empty($m['updated_at']) ? ' · 更新 ' . cad_h(date('Y-m-d', strtotime($m['updated_at']))) : '' ?></div>
                                <?php if (!empty($m['email'])): ?><div class="memail"><i class="fa-regular fa-envelope"></i> <?= cad_h($m['email']) ?></div><?php endif; ?>
                            </a>
                        </li>
                    <?php endforeach; endif; ?>
                </ul>
            </div>
        </section>

        <!-- 信用編輯 -->
        <section class="ca-panel">
            <?php if (!$focus): ?>
                <div class="ca-empty">
                    <i class="fa-solid fa-shield-halved"></i>
                    <p style="font-size:15px;color:#64748b;margin:0 0 4px;">請從左側選擇會員帳號</p>
                    <p style="font-size:12px;">即可檢視信用分數、異動流水並進行信用評分編輯。</p>
                </div>
            <?php else: ?>
                <div class="ca-panel-head">
                    <h2><i class="fa-solid fa-gauge-high" style="color:#059669;"></i>信用評分</h2>
                    <span style="font-size:11px;color:#94a3b8;">UID <?= (int)$focus['ID'] ?></span>
                </div>
                <div class="ca-panel-body">
                    <div class="ca-focus-head">
                        <div class="ca-focus-avatar"><?= cad_h(mb_strtoupper(mb_substr((string)$focus['name'], 0, 1))) ?></div>
                        <div class="ca-focus-meta">
                            <h3><?= cad_h($focus['name']) ?></h3>
                            <p>UID: <?= (int)$focus['ID'] ?><?php if (!empty($focus['email'])): ?> · <?= cad_h($focus['email']) ?><?php endif; ?></p>
                            <?php if (!empty($focus['creatime']) && $focus['creatime'] !== '0000-00-00 00:00:00'): ?>
                            <p>註冊時間：<?= cad_h(date('Y-m-d', strtotime($focus['creatime']))) ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="ca-score-hero">
                        <div class="ca-score-ring" style="border-color:<?= $levelColors[$focusLevel['color']]['tx'] ?? '#10b981' ?>;">
                            <span class="num"><?= (int)$focusCredit['score'] ?></span>
                            <span class="den">/ <?= (int)$settings['max_score'] ?> 分</span>
                        </div>
                        <div class="ca-score-info">
                            <span class="lvl" style="<?= level_color_style($focusLevel['color'], $levelColors) ?>">
                                <i class="fa-solid fa-circle-check"></i> <?= cad_h($focusLevel['label']) ?>
                            </span>
                            <p class="desc"><?= cad_h($focusLevel['desc']) ?></p>
                            <p class="delta">累計變動：<?= ($focusCredit['total_delta'] > 0 ? '+' : '') . (int)$focusCredit['total_delta'] ?>
                                <?php if (!empty($focusCredit['updated_at'])): ?> · 最後更新 <?= cad_h(cad_fmt_date($focusCredit['updated_at'])) ?><?php endif; ?>
                                <?php if (!empty($focusCredit['updated_by'])): ?> by <?= cad_h($focusCredit['updated_by']) ?><?php endif; ?>
                            </p>
                        </div>
                    </div>

                    <div class="ca-actions">
                        <button type="button" class="ca-btn emerald" onclick="openCreditModal('modal-edit')"><i class="fa-solid fa-pen-to-square"></i>編輯信用分數</button>
                        <form method="POST" action="credit_admin.php?<?= $embed ? 'embed=1&amp;' : '' ?>uid=<?= (int)$focus['ID'] ?>" onsubmit="return confirm('確定將信用分數回復為預設 <?= (int)$defaultScore ?> 分？');" style="display:inline;">
                            <input type="hidden" name="form_token" value="<?= cad_h($formToken) ?>">
                            <input type="hidden" name="action" value="reset_credit">
                            <input type="hidden" name="uid" value="<?= (int)$focus['ID'] ?>">
                            <button type="submit" class="ca-btn gray"><i class="fa-solid fa-rotate-left"></i>回復預設</button>
                        </form>
                    </div>

                    <div style="margin-top:18px;">
                        <h3 style="font-size:13px;color:#334155;font-family:'Noto Serif TC',serif;margin:0 0 8px;display:flex;align-items:center;gap:7px;">
                            <i class="fa-solid fa-clock-rotate-left" style="color:#0284c7;"></i>最近異動流水
                        </h3>
                        <?php if (!$focusLedger): ?>
                            <div class="ca-ledger-empty"><i class="fa-regular fa-folder-open"></i><br>尚無信用異動紀錄</div>
                        <?php else: ?>
                            <div style="overflow-x:auto;border:1px solid #e2e8f0;border-radius:12px;">
                                <table class="ca-table">
                                    <thead><tr><th>時間</th><th>變動</th><th>分數</th><th>原因</th><th>操作者</th></tr></thead>
                                    <tbody>
                                    <?php foreach ($focusLedger as $lg):
                                        $chg = (int)$lg['change_amount'];
                                    ?>
                                        <tr>
                                            <td style="font-family:monospace;color:#64748b;white-space:nowrap;"><?= cad_h(cad_fmt_date($lg['created_at'])) ?></td>
                                            <td class="ca-delta <?= $chg >= 0 ? 'up' : 'down' ?>"><?= ($chg > 0 ? '+' : '') . $chg ?></td>
                                            <td style="font-family:monospace;"><?= (int)$lg['score_before'] ?> → <b><?= (int)$lg['score_after'] ?></b></td>
                                            <td><?= cad_h($lg['reason'] !== '' ? $lg['reason'] : '—') ?></td>
                                            <td style="color:#64748b;"><?= cad_h($lg['operator'] !== '' ? $lg['operator'] : 'system') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>
</main>

<?php if ($focus): ?>
<!-- ===== 信用分數編輯 子視窗 ===== -->
<div class="ca-modal" id="modal-edit" onclick="modalBackdrop(event,'modal-edit')">
    <div class="ca-modal-card">
        <div class="ca-modal-head">
            <div class="t">
                <div class="ico" style="background:linear-gradient(135deg,#10b981,#047857);"><i class="fa-solid fa-pen-to-square"></i></div>
                <div>
                    <h3>編輯信用分數</h3>
                    <p><?= cad_h($focus['name']) ?> · UID <?= (int)$focus['ID'] ?> · 目前 <?= (int)$focusCredit['score'] ?> 分</p>
                </div>
            </div>
            <button type="button" class="ca-close" onclick="closeCreditModal('modal-edit')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="POST" action="credit_admin.php?<?= $embed ? 'embed=1&amp;' : '' ?>uid=<?= (int)$focus['ID'] ?>">
            <input type="hidden" name="form_token" value="<?= cad_h($formToken) ?>">
            <input type="hidden" name="action" value="save_credit">
            <input type="hidden" name="uid" value="<?= (int)$focus['ID'] ?>">
            <div class="ca-modal-body">
                <div class="ca-field">
                    <label>調整模式</label>
                    <div class="ca-radio-row">
                        <label class="ca-radio on" id="mode-set-label">
                            <input type="radio" name="mode" value="set" checked onchange="switchMode(this)">設定為指定分數
                        </label>
                        <label class="ca-radio" id="mode-adjust-label">
                            <input type="radio" name="mode" value="adjust" onchange="switchMode(this)">加 / 減分
                        </label>
                    </div>
                </div>
                <div class="ca-field">
                    <label id="value-label">信用分數（<?= (int)$settings['min_score'] ?> ~ <?= (int)$settings['max_score'] ?>）</label>
                    <input type="number" name="value" id="value-input" value="<?= (int)$focusCredit['score'] ?>" min="<?= (int)$settings['min_score'] ?>" max="<?= (int)$settings['max_score'] ?>" step="1">
                    <div class="hint" id="value-hint">直接指定會員最終信用分數。</div>
                </div>
                <div class="ca-field">
                    <label>異動原因</label>
                    <input type="text" name="reason" maxlength="200" placeholder="例：違規發言扣分 / 客服補償加分">
                </div>
                <div class="ca-field">
                    <label>備註（選填）</label>
                    <input type="text" name="note" maxlength="200" placeholder="內部備註，僅供後台顯示">
                </div>
            </div>
            <div class="ca-modal-foot">
                <button type="button" class="ca-btn gray" onclick="closeCreditModal('modal-edit')">取消</button>
                <button type="submit" class="ca-btn emerald"><i class="fa-solid fa-check"></i>儲存信用分數</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- ===== 信用系統參數設定 子視窗 ===== -->
<div class="ca-modal" id="modal-settings" onclick="modalBackdrop(event,'modal-settings')">
    <div class="ca-modal-card">
        <div class="ca-modal-head">
            <div class="t">
                <div class="ico" style="background:linear-gradient(135deg,#0284c7,#0369a1);"><i class="fa-solid fa-sliders"></i></div>
                <div>
                    <h3>信用系統參數設定</h3>
                    <p>分數上下限、預設分數與等級門檻</p>
                </div>
            </div>
            <button type="button" class="ca-close" onclick="closeCreditModal('modal-settings')"><i class="fa-solid fa-xmark"></i></button>
        </div>
        <form method="POST" action="credit_admin.php<?= $embed ? '?embed=1' : '' ?>">
            <input type="hidden" name="form_token" value="<?= cad_h($formToken) ?>">
            <input type="hidden" name="action" value="save_settings">
            <div class="ca-modal-body">
                <div class="ca-switch-row" style="margin-bottom:12px;">
                    <div>
                        <div style="font-size:13px;font-weight:700;color:#1e293b;">啟用信用系統</div>
                        <div style="font-size:11px;color:#94a3b8;">關閉後將無法調整信用分數。</div>
                    </div>
                    <label class="ca-switch"><input type="checkbox" name="credit_enabled" value="1" <?= ((int)$settings['credit_enabled'] === 1) ? 'checked' : '' ?>><span class="slider"></span></label>
                </div>
                <div class="ca-switch-row" style="margin-bottom:14px;">
                    <div>
                        <div style="font-size:13px;font-weight:700;color:#1e293b;">會員中心顯示信用評分</div>
                        <div style="font-size:11px;color:#94a3b8;">控制前台 home.php 是否顯示信用分數區塊。</div>
                    </div>
                    <label class="ca-switch"><input type="checkbox" name="show_on_home" value="1" <?= ((int)$settings['show_on_home'] === 1) ? 'checked' : '' ?>><span class="slider"></span></label>
                </div>
                <div class="ca-grid2">
                    <div class="ca-field">
                        <label>預設信用分數</label>
                        <input type="number" name="default_score" min="0" max="100000" step="1" value="<?= (int)$settings['default_score'] ?>">
                    </div>
                    <div class="ca-field">
                        <label>風險帳號門檻</label>
                        <input type="number" name="risk_threshold" min="0" max="100000" step="1" value="<?= (int)$settings['risk_threshold'] ?>">
                    </div>
                    <div class="ca-field">
                        <label>分數下限</label>
                        <input type="number" name="min_score" min="0" max="100000" step="1" value="<?= (int)$settings['min_score'] ?>">
                    </div>
                    <div class="ca-field">
                        <label>分數上限</label>
                        <input type="number" name="max_score" min="1" max="100000" step="1" value="<?= (int)$settings['max_score'] ?>">
                    </div>
                </div>
                <div style="font-size:12px;font-weight:700;color:#475569;margin:6px 0 8px;">等級門檻（>= 該分數即屬該等級）</div>
                <div class="ca-grid2">
                    <div class="ca-field"><label>極佳</label><input type="number" name="tier_excellent" min="0" max="100000" step="1" value="<?= (int)$settings['tier_excellent'] ?>"></div>
                    <div class="ca-field"><label>良好</label><input type="number" name="tier_good" min="0" max="100000" step="1" value="<?= (int)$settings['tier_good'] ?>"></div>
                    <div class="ca-field"><label>尚可</label><input type="number" name="tier_fair" min="0" max="100000" step="1" value="<?= (int)$settings['tier_fair'] ?>"></div>
                    <div class="ca-field"><label>待加強</label><input type="number" name="tier_poor" min="0" max="100000" step="1" value="<?= (int)$settings['tier_poor'] ?>"></div>
                </div>
                <p style="font-size:11px;color:#94a3b8;margin:2px 0 0;"><i class="fa-solid fa-circle-info"></i> 低於「待加強」門檻即列為「風險」等級。</p>
            </div>
            <div class="ca-modal-foot">
                <button type="button" class="ca-btn gray" onclick="closeCreditModal('modal-settings')">取消</button>
                <button type="submit" class="ca-btn ice"><i class="fa-solid fa-floppy-disk"></i>儲存設定</button>
            </div>
        </form>
    </div>
</div>

<script>
function openCreditModal(id) {
    var m = document.getElementById(id);
    if (!m) return;
    m.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeCreditModal(id) {
    var m = document.getElementById(id);
    if (!m) return;
    m.classList.remove('open');
    document.body.style.overflow = '';
}
function modalBackdrop(e, id) { if (e.target && e.target.id === id) { closeCreditModal(id); } }
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.ca-modal.open').forEach(function (m) { closeCreditModal(m.id); });
    }
});
function switchMode(radio) {
    var isAdjust = (radio.value === 'adjust');
    document.getElementById('mode-set-label').classList.toggle('on', !isAdjust);
    document.getElementById('mode-adjust-label').classList.toggle('on', isAdjust);
    var input = document.getElementById('value-input');
    var label = document.getElementById('value-label');
    var hint = document.getElementById('value-hint');
    if (isAdjust) {
        input.value = 0;
        input.removeAttribute('min');
        input.removeAttribute('max');
        input.setAttribute('placeholder', '正數加分、負數扣分，例：-10');
        label.textContent = '加 / 減分數（可為負數）';
        hint.textContent = '以目前分數為基準加減；系統會自動限制於分數上下限。';
    } else {
        input.value = <?= (int)$focusScoreJs ?>;
        input.setAttribute('min', '<?= (int)$settings['min_score'] ?>');
        input.setAttribute('max', '<?= (int)$settings['max_score'] ?>');
        input.setAttribute('placeholder', '');
        label.textContent = '信用分數（<?= (int)$settings['min_score'] ?> ~ <?= (int)$settings['max_score'] ?>）';
        hint.textContent = '直接指定會員最終信用分數。';
    }
}
</script>
</body>
</html>
