<?php
/**
 * =============================================================
 *  踏雪笑傲 · 申訴回報管理後台（GM 端）
 *  需以 admin/gmlogin.php 的 gm_accounts 身分登入
 *  管理操作全部寫入 support_status_log，回覆寫入 support_messages
 *
 *  功能：儀表板統計、篩選搜尋、排序、批次操作、彈出子視窗管理、
 *        公開回覆 / 內部備註、指派、狀態與優先度調整、CSV 匯出
 * =============================================================
 */
session_start();
include_once __DIR__ . '/../config.php';

if (!isset($_SESSION['gm_username'])) {
    header("Location: gmlogin.php");
    exit();
}
$currentGmUsername = $_SESSION['gm_username'];
$currentGmId = (int)($_SESSION['gm_id'] ?? 0);

$Link = mysqli_connect($DBHost, $DBUser, $DBPassword, $DBName);
if (!$Link) {
    die("Database connection failed: " . mysqli_connect_error());
}
mysqli_set_charset($Link, "utf8");

if (empty($_SESSION['support_admin_token'])) {
    $_SESSION['support_admin_token'] = bin2hex(random_bytes(32));
}
$formToken = $_SESSION['support_admin_token'];

// ------------------------------------------------------------
// 狀態 / 優先度定義
// ------------------------------------------------------------
$SupportStatuses = [
    'open'         => ['label' => '待處理',     'badge' => 'bg-amber-50 text-amber-700 border-amber-200',       'dot' => 'bg-amber-500',   'strip' => 'bg-amber-500',   'icon' => 'fa-hourglass-half', 'grad' => 'from-amber-400 to-amber-600'],
    'processing'   => ['label' => '處理中',     'badge' => 'bg-sky-50 text-sky-700 border-sky-200',             'dot' => 'bg-sky-500',     'strip' => 'bg-sky-500',     'icon' => 'fa-gears',          'grad' => 'from-sky-400 to-sky-600'],
    'pending_user' => ['label' => '待會員回覆', 'badge' => 'bg-violet-50 text-violet-700 border-violet-200',   'dot' => 'bg-violet-500',  'strip' => 'bg-violet-500',  'icon' => 'fa-comment-dots',   'grad' => 'from-violet-400 to-violet-600'],
    'resolved'     => ['label' => '已結案',     'badge' => 'bg-emerald-50 text-emerald-700 border-emerald-200', 'dot' => 'bg-emerald-500', 'strip' => 'bg-emerald-500', 'icon' => 'fa-circle-check',   'grad' => 'from-emerald-400 to-emerald-600'],
    'closed'       => ['label' => '已關閉',     'badge' => 'bg-slate-100 text-slate-600 border-slate-300',      'dot' => 'bg-slate-400',   'strip' => 'bg-slate-400',   'icon' => 'fa-lock',           'grad' => 'from-slate-400 to-slate-600'],
];
$SupportPriorities = [
    'low'    => ['label' => '低',   'badge' => 'bg-slate-100 text-slate-500 border-slate-200',   'strip' => 'bg-slate-400',  'icon' => 'fa-arrow-down', 'grad' => 'from-slate-300 to-slate-500'],
    'normal' => ['label' => '一般', 'badge' => 'bg-sky-50 text-sky-700 border-sky-200',           'strip' => 'bg-sky-400',    'icon' => 'fa-minus',      'grad' => 'from-sky-300 to-sky-500'],
    'high'   => ['label' => '高',   'badge' => 'bg-orange-50 text-orange-700 border-orange-200',  'strip' => 'bg-orange-400', 'icon' => 'fa-arrow-up',   'grad' => 'from-orange-400 to-orange-600'],
    'urgent' => ['label' => '緊急', 'badge' => 'bg-rose-50 text-rose-700 border-rose-200',        'strip' => 'bg-rose-500',   'icon' => 'fa-fire',       'grad' => 'from-rose-500 to-rose-700'],
];

function sadmin_status_meta($s, $map) {
    return $map[$s] ?? ['label' => $s, 'badge' => 'bg-slate-100 text-slate-600 border-slate-200', 'dot' => 'bg-slate-400', 'strip' => 'bg-slate-400', 'icon' => 'fa-circle', 'grad' => 'from-slate-400 to-slate-600'];
}
function sadmin_priority_meta($p, $map) {
    return $map[$p] ?? ['label' => $p, 'badge' => 'bg-slate-100 text-slate-600 border-slate-200', 'strip' => 'bg-slate-400', 'icon' => 'fa-minus', 'grad' => 'from-slate-300 to-slate-500'];
}
function sadmin_h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** 相對時間（視覺化停滯 / 更新） */
function sadmin_ago($dt) {
    if (empty($dt) || $dt === '0000-00-00 00:00:00') { return '—'; }
    $ts = strtotime($dt);
    if ($ts === false) { return '—'; }
    $d = time() - $ts;
    if ($d < 0) { $d = 0; }
    if ($d < 60) { return '剛剛'; }
    if ($d < 3600) { return floor($d / 60) . ' 分鐘前'; }
    if ($d < 86400) { return floor($d / 3600) . ' 小時前'; }
    if ($d < 2592000) { return floor($d / 86400) . ' 天前'; }
    return date('Y-m-d', $ts);
}
/** 是否需要客服回覆（會員最後發言且仍在進行中） */
function sadmin_needs_reply($t) {
    return (($t['last_reply_by'] ?? '') === 'user') && in_array($t['status'] ?? '', ['open', 'processing'], true);
}
/** 是否停滯超過 24 小時（仍在進行中） */
function sadmin_stale($t) {
    if (!in_array($t['status'] ?? '', ['open', 'processing', 'pending_user'], true)) { return false; }
    $ref = !empty($t['last_reply_at']) ? $t['last_reply_at'] : $t['created_at'];
    $ts = strtotime($ref);
    return $ts !== false && (time() - $ts) > 86400;
}

function sadmin_log($Link, $ticketId, $action, $opId, $opName, $oldStatus, $newStatus, $oldPriority, $newPriority, $assignedTo, $note) {
    $opType = 'gm';
    $stmt = $Link->prepare(
        "INSERT INTO `support_status_log`
            (`ticket_id`,`action`,`operator_type`,`operator_id`,`operator_name`,`old_status`,`new_status`,`old_priority`,`new_priority`,`assigned_to`,`note`)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)"
    );
    $stmt->bind_param("ississsssss", $ticketId, $action, $opType, $opId, $opName, $oldStatus, $newStatus, $oldPriority, $newPriority, $assignedTo, $note);
    $stmt->execute();
    $stmt->close();
}
function sadmin_fetch_ticket($Link, $ticketId) {
    $stmt = $Link->prepare("SELECT t.*, c.`name` AS category_name, c.`icon` AS category_icon FROM `support_tickets` t LEFT JOIN `support_categories` c ON c.`id`=t.`category_id` WHERE t.`id`=? LIMIT 1");
    $stmt->bind_param("i", $ticketId);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $row;
}
function sadmin_apply_status($Link, $ticket, $newStatus, $verdict, $opId, $opName) {
    $id = (int)$ticket['id'];
    $old = $ticket['status'];
    if ($newStatus === 'resolved') {
        $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=NOW(), `closed_at`=NULL WHERE `id`=?");
        $stmt->bind_param("ssi", $newStatus, $verdict, $id);
    } elseif ($newStatus === 'closed') {
        $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=IFNULL(`resolved_at`, NOW()), `closed_at`=NOW() WHERE `id`=?");
        $stmt->bind_param("ssi", $newStatus, $verdict, $id);
    } else {
        $stmt = $Link->prepare("UPDATE `support_tickets` SET `status`=?, `verdict`=?, `resolved_at`=NULL, `closed_at`=NULL WHERE `id`=?");
        $stmt->bind_param("ssi", $newStatus, $verdict, $id);
    }
    $stmt->execute();
    $stmt->close();
    sadmin_log($Link, $id, 'status', $opId, $opName, $old, $newStatus, '', '', '', '狀態更新' . ($verdict !== '' ? '：' . mb_substr($verdict, 0, 180) : ''));
}
function sadmin_apply_priority($Link, $ticket, $newPriority, $opId, $opName) {
    $id = (int)$ticket['id'];
    $stmt = $Link->prepare("UPDATE `support_tickets` SET `priority`=? WHERE `id`=?");
    $stmt->bind_param("si", $newPriority, $id);
    $stmt->execute();
    $stmt->close();
    sadmin_log($Link, $id, 'priority', $opId, $opName, '', '', $ticket['priority'], $newPriority, '', '優先度調整');
}
function sadmin_apply_assign($Link, $ticket, $handler, $opId, $opName) {
    $id = (int)$ticket['id'];
    $stmt = $Link->prepare("UPDATE `support_tickets` SET `handler`=? WHERE `id`=?");
    $stmt->bind_param("si", $handler, $id);
    $stmt->execute();
    $stmt->close();
    sadmin_log($Link, $id, 'assign', $opId, $opName, '', '', '', '', $handler, '指派受理人員');
}

// ------------------------------------------------------------
// 表單處理（PRG）
// ------------------------------------------------------------
$notice = '';
$noticeType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['form_token']) || !hash_equals($_SESSION['support_admin_token'], (string)$_POST['form_token'])) {
        $notice = '工作階段已過期，請重新操作。';
        $noticeType = 'danger';
    } else {
        $action = $_POST['action'] ?? '';
        $ticketId = (int)($_POST['ticket_id'] ?? 0);

        // ---------- 批次操作 ----------
        if ($action === 'bulk_status') {
            $ids = array_values(array_filter(array_map('intval', (array)($_POST['ticket_ids'] ?? [])), function ($v) { return $v > 0; }));
            $newStatus = (string)($_POST['new_status'] ?? '');
            $verdict = trim((string)($_POST['verdict'] ?? ''));
            if (!$ids || !isset($SupportStatuses[$newStatus])) {
                $notice = '批次操作參數不正確。';
                $noticeType = 'danger';
            } else {
                $done = 0;
                foreach ($ids as $id) {
                    $tk = sadmin_fetch_ticket($Link, $id);
                    if (!$tk) { continue; }
                    $v = ($verdict !== '' && $newStatus === 'resolved') ? $verdict : $tk['verdict'];
                    sadmin_apply_status($Link, $tk, $newStatus, $v, $currentGmId, $currentGmUsername);
                    $done++;
                }
                $notice = '已批次將 ' . $done . ' 筆回報單更新為「' . $SupportStatuses[$newStatus]['label'] . '」。';
            }
        } elseif ($action === 'bulk_assign') {
            $ids = array_values(array_filter(array_map('intval', (array)($_POST['ticket_ids'] ?? [])), function ($v) { return $v > 0; }));
            $handler = trim((string)($_POST['handler'] ?? ''));
            if (!$ids) {
                $notice = '請先選取回報單。';
                $noticeType = 'danger';
            } else {
                $done = 0;
                foreach ($ids as $id) {
                    $tk = sadmin_fetch_ticket($Link, $id);
                    if (!$tk) { continue; }
                    sadmin_apply_assign($Link, $tk, $handler, $currentGmId, $currentGmUsername);
                    $done++;
                }
                $notice = '已批次指派 ' . $done . ' 筆回報單給「' . ($handler !== '' ? $handler : '（取消指派）') . '」。';
            }
        } else {
            // ---------- 單筆操作 ----------
            $ticket = $ticketId > 0 ? sadmin_fetch_ticket($Link, $ticketId) : null;
            if (!$ticket) {
                $notice = '找不到指定的回報單。';
                $noticeType = 'danger';
            } elseif ($action === 'status') {
                $newStatus = (string)($_POST['new_status'] ?? '');
                $verdict = trim((string)($_POST['verdict'] ?? ''));
                if (!isset($SupportStatuses[$newStatus])) {
                    $notice = '無效的狀態。';
                    $noticeType = 'danger';
                } else {
                    sadmin_apply_status($Link, $ticket, $newStatus, $verdict, $currentGmId, $currentGmUsername);
                    $notice = '回報單狀態已更新為「' . $SupportStatuses[$newStatus]['label'] . '」。';
                }
            } elseif ($action === 'priority') {
                $newPriority = (string)($_POST['new_priority'] ?? '');
                if (!isset($SupportPriorities[$newPriority])) {
                    $notice = '無效的優先度。';
                    $noticeType = 'danger';
                } else {
                    sadmin_apply_priority($Link, $ticket, $newPriority, $currentGmId, $currentGmUsername);
                    $notice = '優先度已更新為「' . $SupportPriorities[$newPriority]['label'] . '」。';
                }
            } elseif ($action === 'assign') {
                $handler = trim((string)($_POST['handler'] ?? ''));
                sadmin_apply_assign($Link, $ticket, $handler, $currentGmId, $currentGmUsername);
                $notice = '已指派受理人員：' . ($handler !== '' ? $handler : '（取消指派）') . '。';
            } elseif ($action === 'reply') {
                $content = trim((string)($_POST['content'] ?? ''));
                $isInternal = (int)($_POST['is_internal'] ?? 0) === 1 ? 1 : 0;
                if ($content === '') {
                    $notice = '請輸入回覆或備註內容。';
                    $noticeType = 'danger';
                } else {
                    $stmt = $Link->prepare(
                        "INSERT INTO `support_messages` (`ticket_id`,`sender_type`,`sender_id`,`sender_name`,`content`,`is_internal`)
                         VALUES (?, 'gm', ?, ?, ?, ?)"
                    );
                    $stmt->bind_param("iissi", $ticketId, $currentGmId, $currentGmUsername, $content, $isInternal);
                    $stmt->execute();
                    $stmt->close();

                    if ($isInternal === 1) {
                        $stmt = $Link->prepare("UPDATE `support_tickets` SET `internal_note` = CONCAT(IFNULL(`internal_note`,''), ?, '[', NOW(), '] ', ?) WHERE `id`=?");
                        $prefix = ($ticket['internal_note'] ? "\n" : '');
                        $noteText = $currentGmUsername . '：' . $content;
                        $stmt->bind_param("ssi", $prefix, $noteText, $ticketId);
                        $stmt->execute();
                        $stmt->close();
                        sadmin_log($Link, $ticketId, 'note', $currentGmId, $currentGmUsername, '', '', '', '', '', '新增內部備註');
                        $notice = '內部備註已新增（會員不可見）。';
                    } else {
                        $oldStatus = $ticket['status'];
                        $newStatus = in_array($oldStatus, ['open', 'processing'], true) ? 'pending_user' : $oldStatus;
                        $stmt = $Link->prepare("UPDATE `support_tickets` SET `reply_count`=`reply_count`+1, `last_reply_by`='gm', `last_reply_at`=NOW(), `status`=? WHERE `id`=?");
                        $stmt->bind_param("si", $newStatus, $ticketId);
                        $stmt->execute();
                        $stmt->close();
                        sadmin_log($Link, $ticketId, 'reply', $currentGmId, $currentGmUsername, $oldStatus, $newStatus, '', '', '', '客服回覆');
                        $notice = '已回覆會員。';
                    }
                }
            } elseif ($action === 'handler_self') {
                sadmin_apply_assign($Link, $ticket, $currentGmUsername, $currentGmId, $currentGmUsername);
                $notice = '已將此單指派給自己。';
            } else {
                $notice = '未知的操作。';
                $noticeType = 'danger';
            }
        }

        if ($noticeType !== 'danger') {
            $_SESSION['support_admin_notice'] = ['type' => $noticeType, 'msg' => $notice];
            $redir = 'support_admin.php';
            if ($ticketId > 0 && !in_array($action, ['bulk_status', 'bulk_assign'], true)) {
                $redir .= '?ticket=' . $ticketId;
            }
            header("Location: " . $redir);
            exit();
        }
    }
}

$flash = $_SESSION['support_admin_notice'] ?? null;
unset($_SESSION['support_admin_notice']);
if ($flash) {
    $notice = $flash['msg'];
    $noticeType = $flash['type'];
}

// ------------------------------------------------------------
// 參考資料
// ------------------------------------------------------------
$gmList = [];
$res = mysqli_query($Link, "SELECT `username` FROM `gm_accounts` ORDER BY `username` ASC");
if ($res) { while ($row = $res->fetch_assoc()) { $gmList[] = $row['username']; } }

$categories = [];
$res = mysqli_query($Link, "SELECT `id`,`code`,`name` FROM `support_categories` ORDER BY `sort_order` ASC, `id` ASC");
if ($res) { while ($row = $res->fetch_assoc()) { $categories[] = $row; } }

// 統計
$stats = ['total' => 0, 'open' => 0, 'processing' => 0, 'pending_user' => 0, 'resolved' => 0, 'closed' => 0, 'awaiting' => 0];
$res = mysqli_query(
    $Link,
    "SELECT COUNT(*) AS total,
            SUM(status='open') AS open_c,
            SUM(status='processing') AS processing_c,
            SUM(status='pending_user') AS pending_c,
            SUM(status='resolved') AS resolved_c,
            SUM(status='closed') AS closed_c,
            SUM(last_reply_by='user' AND status IN ('open','processing')) AS awaiting_c
     FROM `support_tickets`"
);
if ($res && ($row = $res->fetch_assoc())) {
    $stats['total'] = (int)$row['total'];
    $stats['open'] = (int)$row['open_c'];
    $stats['processing'] = (int)$row['processing_c'];
    $stats['pending_user'] = (int)$row['pending_c'];
    $stats['resolved'] = (int)$row['resolved_c'];
    $stats['closed'] = (int)$row['closed_c'];
    $stats['awaiting'] = (int)$row['awaiting_c'];
}

// ------------------------------------------------------------
// 檢視與篩選
// ------------------------------------------------------------
$view = 'list';
$ticketId = (int)($_GET['ticket'] ?? 0);
if ($ticketId > 0) { $view = 'detail'; }

$ticket = null;
$messages = [];
$attachmentsByMessage = [];
$statusLogs = [];
if ($view === 'detail') {
    $ticket = sadmin_fetch_ticket($Link, $ticketId);
    if (!$ticket) {
        $_SESSION['support_admin_notice'] = ['type' => 'danger', 'msg' => '找不到該回報單。'];
        header("Location: support_admin.php");
        exit();
    }
    $stmt = $Link->prepare("SELECT `id`,`sender_type`,`sender_name`,`sender_id`,`content`,`is_internal`,`created_at` FROM `support_messages` WHERE `ticket_id`=? ORDER BY `id` ASC");
    $stmt->bind_param("i", $ticketId);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) { $messages[] = $row; }
    $stmt->close();

    $stmt = $Link->prepare("SELECT `message_id`,`file_name`,`file_path`,`file_size`,`uploader_type` FROM `support_attachments` WHERE `ticket_id`=? ORDER BY `id` ASC");
    $stmt->bind_param("i", $ticketId);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) {
        $mid = (int)$row['message_id'];
        if (!isset($attachmentsByMessage[$mid])) { $attachmentsByMessage[$mid] = []; }
        $attachmentsByMessage[$mid][] = $row;
    }
    $stmt->close();

    $stmt = $Link->prepare("SELECT `action`,`operator_type`,`operator_name`,`old_status`,`new_status`,`old_priority`,`new_priority`,`assigned_to`,`note`,`created_at` FROM `support_status_log` WHERE `ticket_id`=? ORDER BY `id` ASC");
    $stmt->bind_param("i", $ticketId);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) { $statusLogs[] = $row; }
    $stmt->close();
}

$tickets = [];
$filter = $_GET['status'] ?? 'all';
if (!in_array($filter, ['all', 'awaiting', 'open', 'processing', 'pending_user', 'resolved', 'closed'], true)) { $filter = 'all'; }
$filterCat = (int)($_GET['category'] ?? 0);
$filterPriority = $_GET['priority'] ?? 'all';
if (!in_array($filterPriority, ['all', 'low', 'normal', 'high', 'urgent'], true)) { $filterPriority = 'all'; }
$keyword = trim((string)($_GET['q'] ?? ''));
$sort = $_GET['sort'] ?? 'priority';
if (!in_array($sort, ['priority', 'newest', 'oldest', 'updated'], true)) { $sort = 'priority'; }
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 12;
$offset = ($page - 1) * $perPage;
$totalRows = 0;
$totalPages = 0;

$orderByMap = [
    'priority' => "FIELD(t.`priority`,'urgent','high','normal','low'), t.`id` DESC",
    'newest'   => "t.`id` DESC",
    'oldest'   => "t.`id` ASC",
    'updated'  => "t.`updated_at` DESC",
];
$orderBy = $orderByMap[$sort];

if ($view === 'list') {
    // 組合條件（列表與 CSV 匯出共用）
    $where = "1=1";
    $types = "";
    $params = [];
    if ($filter === 'awaiting') {
        $where .= " AND t.`last_reply_by`='user' AND t.`status` IN ('open','processing')";
    } elseif ($filter !== 'all') {
        $where .= " AND t.`status`=?"; $types .= "s"; $params[] = $filter;
    }
    if ($filterCat > 0) { $where .= " AND t.`category_id`=?"; $types .= "i"; $params[] = $filterCat; }
    if ($filterPriority !== 'all') { $where .= " AND t.`priority`=?"; $types .= "s"; $params[] = $filterPriority; }
    if ($keyword !== '') {
        $where .= " AND (t.`ticket_no` LIKE ? OR t.`subject` LIKE ? OR t.`username` LIKE ?)";
        $like = '%' . $keyword . '%';
        $types .= "sss";
        $params[] = $like; $params[] = $like; $params[] = $like;
    }

    // CSV 匯出
    if (isset($_GET['export']) && $_GET['export'] === 'csv') {
        $stmt = $Link->prepare(
            "SELECT t.`ticket_no`,t.`username`,t.`uid`,c.`name` AS category_name,t.`subject`,t.`priority`,t.`status`,t.`handler`,t.`reply_count`,t.`created_at`,t.`updated_at`
             FROM `support_tickets` t LEFT JOIN `support_categories` c ON c.`id`=t.`category_id`
             WHERE $where ORDER BY $orderBy"
        );
        if ($types !== '') { $stmt->bind_param($types, ...$params); }
        $stmt->execute();
        $r = $stmt->get_result();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="support_tickets_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['單號', '會員帳號', 'UID', '分類', '主旨', '優先度', '狀態', '受理GM', '回覆數', '建立時間', '更新時間'], ',', '"', '');
        while ($row = $r->fetch_assoc()) {
            fputcsv($out, [
                $row['ticket_no'], $row['username'], $row['uid'], $row['category_name'] ?? '',
                $row['subject'], $row['priority'], $row['status'], $row['handler'],
                $row['reply_count'], $row['created_at'], $row['updated_at'],
            ], ',', '"', '');
        }
        fclose($out);
        $stmt->close();
        mysqli_close($Link);
        exit();
    }

    $stmt = $Link->prepare("SELECT COUNT(*) AS c FROM `support_tickets` t WHERE $where");
    if ($types !== '') { $stmt->bind_param($types, ...$params); }
    $stmt->execute();
    $totalRows = (int)($stmt->get_result()->fetch_assoc()['c'] ?? 0);
    $stmt->close();
    $totalPages = $totalRows > 0 ? (int)ceil($totalRows / $perPage) : 0;
    if ($totalPages > 0 && $page > $totalPages) {
        $page = $totalPages;
        $offset = ($page - 1) * $perPage;
    }

    $sql = "SELECT t.*, c.`name` AS category_name, c.`icon` AS category_icon
            FROM `support_tickets` t
            LEFT JOIN `support_categories` c ON c.`id`=t.`category_id`
            WHERE $where
            ORDER BY $orderBy
            LIMIT ? OFFSET ?";
    $stmt = $Link->prepare($sql);
    $lp = $params;
    $lt = $types . "ii";
    $lp[] = $perPage;
    $lp[] = $offset;
    $stmt->bind_param($lt, ...$lp);
    $stmt->execute();
    $r = $stmt->get_result();
    while ($row = $r->fetch_assoc()) { $tickets[] = $row; }
    $stmt->close();
}
mysqli_close($Link);

// 匯出目前查詢字串（供 CSV / 分頁沿用）
$baseQuery = ['status' => $filter, 'category' => $filterCat, 'priority' => $filterPriority, 'q' => $keyword, 'sort' => $sort];
$exportUrl = 'support_admin.php?' . http_build_query(array_merge($baseQuery, ['export' => 'csv']));
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>踏雪笑傲 · 申訴回報管理後台</title>
<link rel="stylesheet" href="assets/tailwind.css">
<!-- 本頁專用：補齊 Tailwind 工具類（依 support_admin.php 內容產生） -->
<link rel="stylesheet" href="assets/support-admin-tailwind.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Noto+Serif+TC:wght@400;500;600;700;900&family=Noto+Sans+TC:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    :root { --vermilion:#be123c; --ice-blue:#0284c7; --ink:#080c14; }
    body {
        background-color:#080c14; color:#1e293b; font-family:'Noto Sans TC','Noto Serif TC',sans-serif; min-height:100vh;
        background-image:
            radial-gradient(ellipse at 50% 0%, rgba(190,18,60,.10) 0%, transparent 60%),
            radial-gradient(ellipse at 80% 90%, rgba(2,132,199,.10) 0%, transparent 50%),
            radial-gradient(ellipse at 20% 60%, rgba(15,23,42,.82) 0%, transparent 70%);
    }
    #snow-canvas { position:fixed; top:0; left:0; width:100vw; height:100vh; pointer-events:none; z-index:1; }
    .glass-panel { background:rgba(255,255,255,.95); border:1px solid rgba(226,232,240,.85); backdrop-filter:blur(16px); -webkit-backdrop-filter:blur(16px); box-shadow:0 10px 30px -5px rgba(0,0,0,.28); position:relative; }
    .corner-accent::before { content:''; position:absolute; top:0; left:0; width:10px; height:10px; border-top:2px solid var(--vermilion); border-left:2px solid var(--vermilion); pointer-events:none; }
    .corner-accent::after { content:''; position:absolute; bottom:0; right:0; width:10px; height:10px; border-bottom:2px solid var(--ice-blue); border-right:2px solid var(--ice-blue); pointer-events:none; }
    .btn-vermilion { background:linear-gradient(135deg,#be123c 0%,#9f1239 100%); color:#fff; transition:all .25s ease; box-shadow:0 6px 18px -6px rgba(190,18,60,.6); }
    .btn-vermilion:hover { background:linear-gradient(135deg,#e11d48 0%,#be123c 100%); transform:translateY(-1px); }
    .btn-ice { background:linear-gradient(135deg,#0284c7 0%,#0369a1 100%); color:#fff; transition:all .25s ease; box-shadow:0 6px 18px -6px rgba(2,132,199,.6); }
    .btn-ice:hover { background:linear-gradient(135deg,#0ea5e9 0%,#0284c7 100%); transform:translateY(-1px); }
    .sadmin-input { width:100%; border:1px solid #cbd5e1; border-radius:.6rem; padding:.5rem .7rem; font-size:.8rem; color:#1e293b; background:#fff; transition:all .2s; }
    .sadmin-input:focus { outline:none; border-color:#0284c7; box-shadow:0 0 0 3px rgba(2,132,199,.15); }
    .filter-chip { transition:all .2s ease; }
    .filter-chip.active { background:linear-gradient(135deg,#0f172a,#334155); color:#fff; border-color:transparent; }
    .msg-internal { background:repeating-linear-gradient(45deg,#fffbeb,#fffbeb 10px,#fef3c7 10px,#fef3c7 20px); border:1px dashed #f59e0b; }
    /* KPI 卡片 */
    .kpi { position:relative; overflow:hidden; transition:transform .3s cubic-bezier(.34,1.56,.64,1), box-shadow .3s; }
    .kpi:hover { transform:translateY(-4px); box-shadow:0 20px 40px -20px rgba(0,0,0,.55); }
    .kpi.active { outline:2px solid #0ea5e9; outline-offset:2px; }
    .kpi-bar { height:4px; border-radius:9999px; background:rgba(148,163,184,.25); overflow:hidden; }
    .kpi-bar > span { display:block; height:100%; border-radius:9999px; }
    /* 表格列 */
    .trow { transition:background .15s ease, box-shadow .15s ease; }
    .trow:hover { background:#f0f9ff; }
    .trow.selected { background:#eff6ff; box-shadow:inset 3px 0 0 #0284c7; }
    .row-strip { position:absolute; left:0; top:0; bottom:0; width:4px; }
    .needs-reply { position:relative; }
    .needs-reply::after { content:''; position:absolute; top:7px; right:7px; width:8px; height:8px; border-radius:9999px; background:#f43f5e; box-shadow:0 0 0 3px rgba(244,63,94,.2); animation:pulseDot 1.8s ease-in-out infinite; }
    @keyframes pulseDot { 0%,100%{opacity:1} 50%{opacity:.35} }
    /* 動畫 */
    @keyframes fadeInUp { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:none} }
    .anim-up { animation:fadeInUp .5s cubic-bezier(.22,1,.36,1) both; }
    .anim-d1{animation-delay:.05s} .anim-d2{animation-delay:.1s} .anim-d3{animation-delay:.15s} .anim-d4{animation-delay:.2s}
    /* 彈出子視窗 */
    .sup-modal { position:fixed; inset:0; z-index:80; display:flex; align-items:center; justify-content:center; padding:1rem; background:rgba(4,7,13,.72); backdrop-filter:blur(4px); -webkit-backdrop-filter:blur(4px); opacity:0; visibility:hidden; transition:opacity .25s ease, visibility .25s ease; }
    .sup-modal.open { opacity:1; visibility:visible; }
    .sup-modal-card { width:100%; max-width:560px; max-height:90vh; overflow-y:auto; background:#fff; border-radius:1.25rem; border:1px solid rgba(226,232,240,.9); box-shadow:0 40px 90px -30px rgba(0,0,0,.75); transform:translateY(20px) scale(.96); transition:transform .32s cubic-bezier(.34,1.56,.64,1); }
    .sup-modal.open .sup-modal-card { transform:none; }
    .sup-modal-card::-webkit-scrollbar { width:6px; }
    .sup-modal-card::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:3px; }
    .prio-opt input:checked + .prio-box { border-color:#0284c7; background:#f0f9ff; box-shadow:0 8px 20px -12px rgba(2,132,199,.7); }
    .status-opt input:checked + .status-box { border-color:#0f172a; background:#f8fafc; box-shadow:0 8px 20px -12px rgba(15,23,42,.6); }
    /* 批次工具列 */
    #bulk-bar { transition:transform .3s cubic-bezier(.34,1.56,.64,1), opacity .25s ease; }
    /* 捲軸 */
    ::-webkit-scrollbar { width:6px; height:6px; }
    ::-webkit-scrollbar-track { background:#0f172a; }
    ::-webkit-scrollbar-thumb { background:#334155; border-radius:3px; }
    .nice-scroll::-webkit-scrollbar-thumb { background:#cbd5e1; }
</style>
</head>
<body class="relative min-h-screen flex flex-col justify-between selection:bg-rose-900 selection:text-white">
<canvas id="snow-canvas"></canvas>

<header class="relative z-20 border-b border-slate-800 bg-[#0c101a]/90 backdrop-blur-md sticky top-0 shadow-lg">
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
<div class="flex items-center justify-between h-16">
<a href="gmpanel.php" class="flex items-center space-x-3 no-underline group">
<img src="../assets/logo.svg" alt="踏雪笑傲" class="w-9 h-9 rounded-full border border-slate-700 p-0.5 bg-white/10 group-hover:scale-105 transition-transform object-cover">
<div>
<div class="flex items-center space-x-2">
<span class="text-xl font-bold tracking-[0.18em] text-slate-100 font-serif">踏雪笑傲</span>
<span class="text-[10px] tracking-widest px-1.5 py-0.5 rounded bg-rose-900/80 text-rose-200 border border-rose-700/60 font-medium">申訴管理</span>
</div>
<p class="text-[10px] text-slate-400 tracking-[0.2em] uppercase font-['Cinzel']">Support Console</p>
</div>
</a>
<nav class="flex items-center space-x-2 sm:space-x-4">
<a href="gmpanel.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-gauge-high text-slate-400"></i><span class="hidden sm:inline">GM 控制台</span></a>
<a href="support_admin.php" class="px-3 py-1.5 text-xs text-sky-400 bg-sky-950/50 border border-sky-800/60 rounded-md flex items-center gap-1.5"><i class="fa-solid fa-headset"></i><span class="hidden sm:inline">申訴回報</span></a>
<a href="member_admin.php" class="px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-800/80 rounded-md transition-colors flex items-center gap-1.5"><i class="fa-solid fa-user-shield text-violet-400"></i><span class="hidden sm:inline">會員權限</span></a>
<div class="flex items-center space-x-2 pl-3 border-l border-slate-700/80">
<div class="flex items-center space-x-2 bg-slate-900/90 border border-rose-900/50 px-3 py-1 rounded-full text-xs">
<span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
<span class="text-slate-400">管理員：</span>
<span class="font-semibold text-rose-300 font-mono"><?= sadmin_h($currentGmUsername) ?></span>
</div>
<a href="gmlogout.php" class="px-2.5 py-1 text-xs text-rose-400 hover:text-rose-200 hover:bg-rose-950/50 border border-rose-900/40 rounded transition-colors" title="登出"><i class="fa-solid fa-arrow-right-from-bracket mr-1"></i><span class="hidden sm:inline">登出</span></a>
</div>
</nav>
</div>
</div>
</header>

<main class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-7 flex-1 w-full space-y-6">

<?php if ($notice !== ''): ?>
<div class="glass-panel corner-accent rounded-xl px-5 py-4 flex items-start gap-3 border-l-4 anim-up <?= $noticeType === 'danger' ? 'border-l-rose-500' : 'border-l-emerald-500' ?>">
<i class="fa-solid <?= $noticeType === 'danger' ? 'fa-circle-exclamation text-rose-600' : 'fa-circle-check text-emerald-600' ?> mt-0.5"></i>
<p class="text-sm text-slate-700"><?= sadmin_h($notice) ?></p>
</div>
<?php endif; ?>

<?php if ($view === 'detail' && $ticket):
    $sm = sadmin_status_meta($ticket['status'], $SupportStatuses);
    $pm = sadmin_priority_meta($ticket['priority'], $SupportPriorities);
    $needsReply = sadmin_needs_reply($ticket);
    $stale = sadmin_stale($ticket);
?>
<!-- ==================== 詳細 / 管理 ==================== -->
<div class="flex items-center justify-between flex-wrap gap-3 anim-up">
<div class="flex items-center gap-3">
<a href="support_admin.php" class="w-10 h-10 rounded-xl bg-white/10 border border-slate-700 text-slate-300 hover:text-white hover:bg-white/20 flex items-center justify-center no-underline transition-colors"><i class="fa-solid fa-arrow-left"></i></a>
<div>
<div class="flex items-center gap-2 flex-wrap mb-1">
<span class="px-2 py-0.5 rounded font-mono text-[11px]" style="background:#fff1f2;color:#be123c;border:1px solid #fecdd3"><?= sadmin_h($ticket['ticket_no']) ?></span>
<span class="text-[11px] px-2.5 py-0.5 rounded-full border font-medium inline-flex items-center gap-1 <?= sadmin_h($sm['badge']) ?>"><span class="w-1.5 h-1.5 rounded-full <?= sadmin_h($sm['dot']) ?>"></span><?= sadmin_h($sm['label']) ?></span>
<span class="text-[11px] px-2.5 py-0.5 rounded-full border font-medium <?= sadmin_h($pm['badge']) ?>">優先度：<?= sadmin_h($pm['label']) ?></span>
<?php if ($needsReply): ?><span class="text-[11px] px-2.5 py-0.5 rounded-full bg-rose-600 text-white font-medium"><i class="fa-solid fa-bell mr-1"></i>待回覆</span><?php endif; ?>
<?php if ($stale): ?><span class="text-[11px] px-2.5 py-0.5 rounded-full bg-orange-100 text-orange-700 border border-orange-200 font-medium"><i class="fa-solid fa-triangle-exclamation mr-1"></i>停滯 &gt; 24h</span><?php endif; ?>
</div>
<h1 class="text-xl sm:text-2xl font-bold text-slate-100 font-serif max-w-2xl"><?= sadmin_h($ticket['subject']) ?></h1>
<p class="text-xs text-slate-400 mt-1">會員 <?= sadmin_h($ticket['username']) ?> · UID <?= (int)$ticket['uid'] ?> · 建立於 <?= sadmin_h($ticket['created_at']) ?>（<?= sadmin_h(sadmin_ago($ticket['created_at'])) ?>）</p>
</div>
</div>
<div class="flex items-center gap-2 flex-wrap">
<a href="support_admin.php" class="px-3.5 py-2 rounded-lg bg-slate-800 text-slate-200 hover:bg-slate-700 text-xs font-semibold no-underline flex items-center gap-1.5"><i class="fa-solid fa-list"></i> 返回列表</a>
<button type="button" onclick="openModal('modal-reply')" class="btn-vermilion px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-reply"></i> 回覆 / 備註</button>
</div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
<!-- 左：資訊與對話 -->
<div class="lg:col-span-2 space-y-5">
<!-- 會員 / 案件資訊 -->
<div class="glass-panel corner-accent rounded-2xl p-5 sm:p-6 anim-up anim-d1">
<div class="flex items-start gap-4 pb-4 mb-4 border-b border-slate-200">
<div class="w-14 h-14 rounded-2xl bg-gradient-to-br from-slate-700 to-slate-900 text-white flex items-center justify-center text-xl font-bold shadow-md"><?= sadmin_h(mb_strtoupper(mb_substr($ticket['username'], 0, 1))) ?></div>
<div class="flex-1">
<div class="flex items-center gap-2 flex-wrap">
<span class="font-bold text-slate-800"><?= sadmin_h($ticket['username']) ?></span>
<span class="text-[11px] font-mono text-slate-400">UID <?= (int)$ticket['uid'] ?></span>
</div>
<div class="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-1.5 mt-2 text-xs">
<span class="text-slate-500"><i class="fa-solid fa-envelope mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['contact_email'] ?: '未提供') ?></span>
<span class="text-slate-500"><i class="fa-solid fa-mobile-screen mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['contact_mobile'] ?: '未提供') ?></span>
<span class="text-slate-500"><i class="fa-solid fa-server mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['server_zone'] ?: '未提供') ?></span>
<span class="text-slate-500"><i class="fa-solid fa-user mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['role_name'] ?: '未提供') ?></span>
<span class="text-slate-500"><i class="fa-solid fa-tag mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['category_name'] ?: $ticket['category_code']) ?></span>
<span class="text-slate-500"><i class="fa-solid fa-user-shield mr-1.5 text-slate-400"></i><?= sadmin_h($ticket['handler'] ?: '尚未指派') ?></span>
</div>
</div>
</div>

<?php if (!empty($ticket['verdict'])): ?>
<div class="mb-4 p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
<span class="text-xs font-bold text-emerald-700 block mb-1"><i class="fa-solid fa-gavel mr-1"></i>處理結論</span>
<p class="text-sm text-emerald-900 leading-relaxed whitespace-pre-wrap"><?= sadmin_h($ticket['verdict']) ?></p>
</div>
<?php endif; ?>

<h3 class="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2"><i class="fa-regular fa-comments text-slate-400"></i>對話與處理紀錄 <span class="text-[11px] font-normal text-slate-400">（<?= count($messages) ?> 則）</span></h3>
<div class="space-y-3 max-h-[560px] overflow-y-auto pr-1 nice-scroll">
<?php if (empty($messages)): ?><p class="text-sm text-slate-400">尚無訊息。</p><?php endif; ?>
<?php foreach ($messages as $m):
    $isUser = ($m['sender_type'] === 'user');
    $isInternal = ((int)$m['is_internal'] === 1);
    $mid = (int)$m['id'];
?>
<div class="rounded-xl p-3.5 <?= $isInternal ? 'msg-internal' : ($isUser ? 'bg-sky-50 border border-sky-200' : 'bg-rose-50 border border-rose-200') ?>">
<div class="flex items-center gap-2 mb-1.5">
<span class="w-6 h-6 rounded-full <?= $isUser ? 'bg-sky-500' : 'bg-rose-600' ?> text-white flex items-center justify-center text-[10px]"><i class="fa-solid <?= $isUser ? 'fa-user' : 'fa-user-shield' ?>"></i></span>
<span class="text-xs font-bold text-slate-700"><?= sadmin_h($m['sender_name']) ?></span>
<span class="text-[10px] text-slate-400"><?= sadmin_h($m['created_at']) ?></span>
<?php if ($isInternal): ?><span class="text-[10px] text-amber-700 bg-amber-100 border border-amber-300 rounded px-1.5"><i class="fa-solid fa-eye-slash mr-1"></i>內部備註</span><?php endif; ?>
</div>
<p class="text-sm text-slate-700 whitespace-pre-wrap leading-relaxed"><?= sadmin_h($m['content']) ?></p>
<?php if (!empty($attachmentsByMessage[$mid])): ?>
<div class="mt-2 flex flex-wrap gap-2">
<?php foreach ($attachmentsByMessage[$mid] as $att): ?>
<a href="../<?= sadmin_h($att['file_path']) ?>" target="_blank" class="text-[11px] bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-600 hover:border-sky-400 hover:text-sky-700 no-underline flex items-center gap-1.5"><i class="fa-solid fa-paperclip"></i><?= sadmin_h($att['file_name']) ?></a>
<?php endforeach; ?>
</div>
<?php endif; ?>
</div>
<?php endforeach; ?>
</div>
</div>
</div>

<!-- 右：操作面板 -->
<div class="space-y-5">
<div class="glass-panel corner-accent rounded-2xl p-5 anim-up anim-d1">
<h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">快速操作</h3>
<div class="grid grid-cols-2 gap-2.5">
<button type="button" onclick="openModal('modal-status')" class="p-3 rounded-xl border border-slate-200 bg-white hover:border-amber-400 hover:bg-amber-50 transition-all text-left group">
<i class="fa-solid fa-sliders text-amber-500 text-lg"></i>
<p class="text-xs font-semibold text-slate-700 mt-1.5">更新狀態</p>
<p class="text-[10px] text-slate-400">結案 / 關閉 / 進行</p>
</button>
<button type="button" onclick="openModal('modal-priority')" class="p-3 rounded-xl border border-slate-200 bg-white hover:border-orange-400 hover:bg-orange-50 transition-all text-left group">
<i class="fa-solid fa-flag text-orange-500 text-lg"></i>
<p class="text-xs font-semibold text-slate-700 mt-1.5">調整優先度</p>
<p class="text-[10px] text-slate-400">低 / 一般 / 高 / 緊急</p>
</button>
<button type="button" onclick="openModal('modal-assign')" class="p-3 rounded-xl border border-slate-200 bg-white hover:border-sky-400 hover:bg-sky-50 transition-all text-left group">
<i class="fa-solid fa-user-shield text-sky-500 text-lg"></i>
<p class="text-xs font-semibold text-slate-700 mt-1.5">指派人員</p>
<p class="text-[10px] text-slate-400">指定受理 GM</p>
</button>
<form method="POST" class="contents">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="handler_self">
<input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
<button type="submit" class="p-3 rounded-xl border border-slate-200 bg-white hover:border-emerald-400 hover:bg-emerald-50 transition-all text-left group">
<i class="fa-solid fa-hand text-emerald-500 text-lg"></i>
<p class="text-xs font-semibold text-slate-700 mt-1.5">指派給自己</p>
<p class="text-[10px] text-slate-400"><?= sadmin_h($currentGmUsername) ?></p>
</button>
</form>
<button type="button" onclick="openModal('modal-reply')" class="p-3 rounded-xl border border-slate-200 bg-white hover:border-rose-400 hover:bg-rose-50 transition-all text-left group col-span-2">
<i class="fa-solid fa-reply text-rose-500 text-lg"></i>
<p class="text-xs font-semibold text-slate-700 mt-1.5">回覆會員 / 內部備註</p>
<p class="text-[10px] text-slate-400">送出公開回覆或僅限內部查看的備註</p>
</button>
</div>
</div>

<div class="glass-panel corner-accent rounded-2xl p-5 anim-up anim-d2">
<h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">管理操作歷程</h3>
<div class="space-y-3 max-h-[420px] overflow-y-auto pr-1 nice-scroll">
<?php if (empty($statusLogs)): ?><p class="text-xs text-slate-400">尚無紀錄。</p><?php endif; ?>
<?php foreach ($statusLogs as $log):
    $actIcon = 'fa-circle';
    $actColor = 'text-slate-400';
    if ($log['action'] === 'status') { $actIcon = 'fa-arrows-rotate'; $actColor = 'text-amber-500'; }
    elseif ($log['action'] === 'close') { $actIcon = 'fa-lock'; $actColor = 'text-slate-500'; }
    elseif ($log['action'] === 'priority') { $actIcon = 'fa-flag'; $actColor = 'text-orange-500'; }
    elseif ($log['action'] === 'assign') { $actIcon = 'fa-user-shield'; $actColor = 'text-sky-500'; }
    elseif ($log['action'] === 'reply') { $actIcon = 'fa-reply'; $actColor = 'text-rose-500'; }
    elseif ($log['action'] === 'note') { $actIcon = 'fa-eye-slash'; $actColor = 'text-amber-600'; }
?>
<div class="flex gap-3">
<span class="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center <?= $actColor ?> text-xs shrink-0"><i class="fa-solid <?= $actIcon ?>"></i></span>
<div class="text-xs min-w-0">
<div class="text-slate-600"><span class="font-semibold text-slate-800"><?= sadmin_h($log['operator_name'] ?: '系統') ?></span> · <?= sadmin_h($log['action']) ?></div>
<?php if ($log['action'] === 'status' || $log['action'] === 'close'): ?>
<div class="text-slate-500">狀態 → <span class="font-medium"><?= sadmin_h(sadmin_status_meta($log['new_status'], $SupportStatuses)['label']) ?></span></div>
<?php elseif ($log['action'] === 'priority'): ?>
<div class="text-slate-500">優先度 → <span class="font-medium"><?= sadmin_h(sadmin_priority_meta($log['new_priority'], $SupportPriorities)['label']) ?></span></div>
<?php elseif ($log['action'] === 'assign'): ?>
<div class="text-slate-500">指派 → <span class="font-medium"><?= sadmin_h($log['assigned_to'] ?: '（無）') ?></span></div>
<?php endif; ?>
<?php if (!empty($log['note'])): ?><div class="text-slate-400 break-words"><?= sadmin_h(mb_substr($log['note'], 0, 120)) ?></div><?php endif; ?>
<div class="text-slate-400 font-mono text-[10px] mt-0.5"><?= sadmin_h($log['created_at']) ?> · <?= sadmin_h(sadmin_ago($log['created_at'])) ?></div>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
</div>
</div>

<!-- ===== 詳細頁彈出子視窗 ===== -->
<!-- 狀態 -->
<div class="sup-modal" id="modal-status" onclick="modalBackdrop(event,'modal-status')">
<div class="sup-modal-card">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center"><i class="fa-solid fa-sliders"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">更新回報狀態</p><p class="text-[11px] text-slate-400"><?= sadmin_h($ticket['ticket_no']) ?></p></div></div>
<button type="button" onclick="closeModal('modal-status')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="status">
<input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
<div class="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
<?php foreach ($SupportStatuses as $key => $meta): ?>
<label class="status-opt cursor-pointer">
<input type="radio" name="new_status" value="<?= sadmin_h($key) ?>" class="sr-only" <?= $ticket['status'] === $key ? 'checked' : '' ?>>
<div class="status-box rounded-xl border-2 border-slate-200 p-3 text-center transition-all hover:border-slate-400">
<span class="w-9 h-9 mx-auto rounded-lg bg-gradient-to-br <?= sadmin_h($meta['grad']) ?> text-white flex items-center justify-center"><i class="fa-solid <?= sadmin_h($meta['icon']) ?>"></i></span>
<p class="text-xs font-semibold text-slate-700 mt-2"><?= sadmin_h($meta['label']) ?></p>
</div>
</label>
<?php endforeach; ?>
</div>
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">處理結論（選填，會員可見）</label>
<textarea name="verdict" rows="3" class="sadmin-input" placeholder="例：已補發道具，請重新登入確認。"><?= sadmin_h($ticket['verdict']) ?></textarea>
</div>
<div class="flex items-center justify-end gap-3 pt-1">
<button type="button" onclick="closeModal('modal-status')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-vermilion px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2"><i class="fa-solid fa-check"></i> 更新狀態</button>
</div>
</form>
</div>
</div>

<!-- 優先度 -->
<div class="sup-modal" id="modal-priority" onclick="modalBackdrop(event,'modal-priority')">
<div class="sup-modal-card" style="max-width:460px">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-orange-400 to-rose-500 text-white flex items-center justify-center"><i class="fa-solid fa-flag"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">調整優先度</p><p class="text-[11px] text-slate-400"><?= sadmin_h($ticket['ticket_no']) ?></p></div></div>
<button type="button" onclick="closeModal('modal-priority')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="priority">
<input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
<div class="grid grid-cols-2 gap-3">
<?php foreach ($SupportPriorities as $key => $meta): ?>
<label class="prio-opt cursor-pointer">
<input type="radio" name="new_priority" value="<?= sadmin_h($key) ?>" class="sr-only" <?= $ticket['priority'] === $key ? 'checked' : '' ?>>
<div class="prio-box rounded-xl border-2 border-slate-200 p-3.5 flex items-center gap-3 transition-all hover:border-slate-400">
<span class="w-9 h-9 rounded-lg bg-gradient-to-br <?= sadmin_h($meta['grad']) ?> text-white flex items-center justify-center"><i class="fa-solid <?= sadmin_h($meta['icon']) ?>"></i></span>
<span class="text-sm font-semibold text-slate-700"><?= sadmin_h($meta['label']) ?></span>
</div>
</label>
<?php endforeach; ?>
</div>
<div class="flex items-center justify-end gap-3 pt-1">
<button type="button" onclick="closeModal('modal-priority')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-ice px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2"><i class="fa-solid fa-check"></i> 更新優先度</button>
</div>
</form>
</div>
</div>

<!-- 指派 -->
<div class="sup-modal" id="modal-assign" onclick="modalBackdrop(event,'modal-assign')">
<div class="sup-modal-card" style="max-width:460px">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 text-white flex items-center justify-center"><i class="fa-solid fa-user-shield"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">指派受理人員</p><p class="text-[11px] text-slate-400"><?= sadmin_h($ticket['ticket_no']) ?></p></div></div>
<button type="button" onclick="closeModal('modal-assign')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="assign">
<input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
<div>
<label class="text-xs font-semibold text-slate-600 block mb-1">受理 GM</label>
<select name="handler" class="sadmin-input">
<option value="">（取消指派）</option>
<?php foreach ($gmList as $gm): ?>
<option value="<?= sadmin_h($gm) ?>" <?= $ticket['handler'] === $gm ? 'selected' : '' ?>><?= sadmin_h($gm) ?><?= $gm === $currentGmUsername ? '（我）' : '' ?></option>
<?php endforeach; ?>
</select>
</div>
<div class="flex items-center justify-end gap-3 pt-1">
<button type="button" onclick="closeModal('modal-assign')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-ice px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2"><i class="fa-solid fa-check"></i> 確認指派</button>
</div>
</form>
</div>
</div>

<!-- 回覆 / 備註 -->
<div class="sup-modal" id="modal-reply" onclick="modalBackdrop(event,'modal-reply')">
<div class="sup-modal-card">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-rose-500 to-rose-700 text-white flex items-center justify-center"><i class="fa-solid fa-reply"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">回覆會員 / 新增備註</p><p class="text-[11px] text-slate-400"><?= sadmin_h($ticket['ticket_no']) ?> · <?= sadmin_h($ticket['subject']) ?></p></div></div>
<button type="button" onclick="closeModal('modal-reply')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="reply">
<input type="hidden" name="ticket_id" value="<?= (int)$ticket['id'] ?>">
<div class="flex rounded-xl bg-slate-100 p-1 text-xs font-semibold">
<label class="flex-1 cursor-pointer">
<input type="radio" name="is_internal" value="0" class="sr-only reply-mode" checked>
<span class="block text-center py-2 rounded-lg bg-white shadow-sm text-rose-700" data-mode-label>公開回覆（會員可見）</span>
</label>
<label class="flex-1 cursor-pointer">
<input type="radio" name="is_internal" value="1" class="sr-only reply-mode">
<span class="block text-center py-2 rounded-lg text-slate-500" data-mode-label>內部備註（僅管理端）</span>
</label>
</div>
<textarea name="content" rows="5" class="sadmin-input" placeholder="輸入回覆內容…" required></textarea>
<div class="flex items-center justify-end gap-3 pt-1">
<button type="button" onclick="closeModal('modal-reply')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-vermilion px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2"><i class="fa-solid fa-paper-plane"></i> 送出</button>
</div>
</form>
</div>
</div>

<?php else: ?>
<!-- ==================== 儀表板 / 列表 ==================== -->
<div class="flex flex-col md:flex-row md:items-end justify-between gap-4 anim-up">
<div>
<div class="flex items-center gap-2 mb-1.5">
<span class="px-2 py-0.5 text-[11px] font-semibold text-rose-800 bg-rose-50 border border-rose-200 rounded">客服支援中心</span>
<span class="text-xs text-slate-400">即時監控所有申訴案件</span>
</div>
<h1 class="text-2xl sm:text-3xl font-bold text-slate-100 font-serif tracking-wider">申訴回報管理</h1>
</div>
<div class="flex items-center gap-2 flex-wrap">
<a href="<?= sadmin_h($exportUrl) ?>" class="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold no-underline flex items-center gap-2 shadow-lg"><i class="fa-solid fa-file-csv"></i> 匯出 CSV</a>
<a href="support_admin.php" class="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 border border-slate-700 text-slate-200 text-xs font-semibold no-underline flex items-center gap-2"><i class="fa-solid fa-rotate-right"></i> 重新整理</a>
</div>
</div>

<!-- KPI 卡片 -->
<div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 anim-up anim-d1">
<?php
$kpis = [
    ['key' => 'all',          'label' => '全部案件',   'value' => $stats['total'],        'icon' => 'fa-layer-group',    'grad' => 'from-slate-600 to-slate-800',   'text' => 'text-slate-800'],
    ['key' => 'awaiting',     'label' => '待回覆',     'value' => $stats['awaiting'],     'icon' => 'fa-bell',           'grad' => 'from-rose-500 to-rose-700',     'text' => 'text-rose-700'],
    ['key' => 'open',         'label' => '待處理',     'value' => $stats['open'],         'icon' => 'fa-hourglass-half', 'grad' => 'from-amber-400 to-amber-600',   'text' => 'text-amber-700'],
    ['key' => 'processing',   'label' => '處理中',     'value' => $stats['processing'],   'icon' => 'fa-gears',          'grad' => 'from-sky-400 to-sky-600',       'text' => 'text-sky-700'],
    ['key' => 'pending_user', 'label' => '待會員回覆', 'value' => $stats['pending_user'], 'icon' => 'fa-comment-dots',   'grad' => 'from-violet-400 to-violet-600', 'text' => 'text-violet-700'],
    ['key' => 'resolved',     'label' => '已結案',     'value' => $stats['resolved'],     'icon' => 'fa-circle-check',   'grad' => 'from-emerald-400 to-emerald-600','text' => 'text-emerald-700'],
];
$baseForKpi = ['category' => $filterCat, 'priority' => $filterPriority, 'q' => $keyword, 'sort' => $sort];
$denom = max(1, (int)$stats['total']);
foreach ($kpis as $k):
    $pct = $stats['total'] > 0 ? round($k['value'] / $denom * 100) : 0;
    $isActive = ($filter === $k['key']);
    $kurl = 'support_admin.php?' . http_build_query(array_merge($baseForKpi, ['status' => $k['key']]));
?>
<a href="<?= sadmin_h($kurl) ?>" class="kpi glass-panel corner-accent rounded-2xl p-4 no-underline block <?= $isActive ? 'active' : '' ?>">
<div class="flex items-center justify-between mb-2.5">
<span class="w-9 h-9 rounded-xl bg-gradient-to-br <?= sadmin_h($k['grad']) ?> text-white flex items-center justify-center shadow"><i class="fa-solid <?= sadmin_h($k['icon']) ?>"></i></span>
<span class="text-[10px] font-mono text-slate-400"><?= $pct ?>%</span>
</div>
<p class="text-[11px] text-slate-500"><?= sadmin_h($k['label']) ?></p>
<p class="text-2xl font-bold <?= sadmin_h($k['text']) ?> font-mono leading-tight"><?= (int)$k['value'] ?></p>
<div class="kpi-bar mt-2"><span class="bg-gradient-to-r <?= sadmin_h($k['grad']) ?>" style="width:<?= $pct ?>%"></span></div>
</a>
<?php endforeach; ?>
</div>

<!-- 狀態分佈條 -->
<?php if ($stats['total'] > 0): ?>
<div class="glass-panel corner-accent rounded-2xl p-5 anim-up anim-d2">
<div class="flex items-center justify-between mb-3 flex-wrap gap-2">
<h3 class="text-xs font-bold text-slate-500 uppercase tracking-wider">狀態分佈</h3>
<div class="flex items-center gap-3 flex-wrap text-[11px]">
<?php foreach (['open','processing','pending_user','resolved','closed'] as $sk):
    $smeta = $SupportStatuses[$sk];
    $cnt = $stats[$sk];
?>
<span class="flex items-center gap-1.5 text-slate-500"><span class="w-2.5 h-2.5 rounded-full <?= sadmin_h($smeta['dot']) ?>"></span><?= sadmin_h($smeta['label']) ?> <b class="text-slate-700"><?= (int)$cnt ?></b></span>
<?php endforeach; ?>
</div>
</div>
<div class="flex h-3 rounded-full overflow-hidden bg-slate-100">
<?php foreach (['open','processing','pending_user','resolved','closed'] as $sk):
    $cnt = $stats[$sk];
    if ($cnt <= 0) continue;
    $w = round($cnt / $denom * 100, 2);
?>
<div class="<?= sadmin_h($SupportStatuses[$sk]['strip']) ?> transition-all" style="width:<?= $w ?>%" title="<?= sadmin_h($SupportStatuses[$sk]['label']) ?> <?= (int)$cnt ?>"></div>
<?php endforeach; ?>
</div>
</div>
<?php endif; ?>

<!-- 篩選工具列 -->
<div class="glass-panel corner-accent rounded-2xl p-4 space-y-3 anim-up anim-d2">
<div class="flex items-center gap-2 flex-wrap">
<?php
$chips = ['all' => ['全部', 'fa-layer-group'], 'awaiting' => ['待回覆', 'fa-bell'], 'open' => ['待處理', 'fa-hourglass-half'], 'processing' => ['處理中', 'fa-gears'], 'pending_user' => ['待會員回覆', 'fa-comment-dots'], 'resolved' => ['已結案', 'fa-circle-check'], 'closed' => ['已關閉', 'fa-lock']];
foreach ($chips as $key => $c):
    $q = ['status' => $key, 'category' => $filterCat, 'priority' => $filterPriority, 'q' => $keyword, 'sort' => $sort];
    $active = ($filter === $key);
?>
<a href="support_admin.php?<?= sadmin_h(http_build_query($q)) ?>" class="filter-chip text-xs px-3 py-1.5 rounded-full border inline-flex items-center gap-1.5 <?= $active ? 'active border-slate-700' : 'border-slate-300 text-slate-600 bg-white/80 hover:border-slate-400' ?>"><i class="fa-solid <?= sadmin_h($c[1]) ?> text-[10px]"></i><?= sadmin_h($c[0]) ?></a>
<?php endforeach; ?>
</div>
<form method="GET" class="flex items-center gap-2 flex-wrap">
<input type="hidden" name="status" value="<?= sadmin_h($filter) ?>">
<select name="category" class="sadmin-input !w-36 !py-2">
<option value="0">全部分類</option>
<?php foreach ($categories as $cat): ?>
<option value="<?= (int)$cat['id'] ?>" <?= $filterCat === (int)$cat['id'] ? 'selected' : '' ?>><?= sadmin_h($cat['name']) ?></option>
<?php endforeach; ?>
</select>
<select name="priority" class="sadmin-input !w-32 !py-2">
<option value="all">全部優先度</option>
<?php foreach ($SupportPriorities as $key => $meta): ?>
<option value="<?= sadmin_h($key) ?>" <?= $filterPriority === $key ? 'selected' : '' ?>><?= sadmin_h($meta['label']) ?></option>
<?php endforeach; ?>
</select>
<select name="sort" class="sadmin-input !w-36 !py-2">
<?php
$sortOptions = ['priority' => '優先度排序', 'newest' => '最新建立', 'oldest' => '最舊建立', 'updated' => '最近更新'];
foreach ($sortOptions as $key => $label): ?>
<option value="<?= sadmin_h($key) ?>" <?= $sort === $key ? 'selected' : '' ?>><?= sadmin_h($label) ?></option>
<?php endforeach; ?>
</select>
<div class="relative">
<i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs pointer-events-none"></i>
<input type="text" name="q" value="<?= sadmin_h($keyword) ?>" placeholder="搜尋單號 / 主旨 / 帳號" class="sadmin-input !w-56 !py-2 !pl-8">
</div>
<button type="submit" class="btn-ice px-4 py-2 rounded-lg text-xs font-semibold">套用篩選</button>
</form>
</div>

<!-- 批次工具列 -->
<div id="bulk-bar" class="hidden glass-panel corner-accent rounded-2xl px-4 py-3 flex items-center justify-between gap-3 bg-gradient-to-r from-sky-950 to-slate-900 border-slate-700">
<div class="flex items-center gap-3 text-slate-100">
<span class="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-400/40 flex items-center justify-center"><i class="fa-solid fa-check-double text-sky-300"></i></span>
<span class="text-sm">已選取 <b id="bulk-count" class="text-sky-300 font-mono">0</b> 筆</span>
</div>
<div class="flex items-center gap-2">
<button type="button" onclick="openBulkStatus()" class="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-white text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-sliders"></i> 批次改狀態</button>
<button type="button" onclick="openBulkAssign()" class="px-3.5 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-white text-xs font-semibold flex items-center gap-1.5"><i class="fa-solid fa-user-shield"></i> 批次指派</button>
<button type="button" onclick="clearSelection()" class="px-3.5 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold">清除</button>
</div>
</div>

<!-- 案件表格 -->
<div class="glass-panel corner-accent rounded-2xl overflow-hidden anim-up anim-d3">
<div class="overflow-x-auto">
<table class="w-full text-sm">
<thead>
<tr class="bg-slate-50 border-b border-slate-200 text-left text-xs text-slate-500">
<th class="px-4 py-3 w-10"><input type="checkbox" id="select-all" class="accent-sky-500 cursor-pointer" onchange="toggleAll(this)"></th>
<th class="px-4 py-3">案件 / 會員</th>
<th class="px-4 py-3">分類</th>
<th class="px-4 py-3">優先度</th>
<th class="px-4 py-3">狀態</th>
<th class="px-4 py-3">受理 GM</th>
<th class="px-4 py-3">更新</th>
<th class="px-4 py-3 text-right">操作</th>
</tr>
</thead>
<tbody>
<?php if (empty($tickets)): ?>
<tr><td colspan="8" class="px-4 py-16 text-center">
<div class="w-16 h-16 mx-auto rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400 text-2xl mb-3"><i class="fa-regular fa-folder-open"></i></div>
<p class="text-slate-500 text-sm">目前沒有符合條件的回報單。</p>
</td></tr>
<?php else: ?>
<?php foreach ($tickets as $t):
    $sm = sadmin_status_meta($t['status'], $SupportStatuses);
    $pm = sadmin_priority_meta($t['priority'], $SupportPriorities);
    $needsReply = sadmin_needs_reply($t);
    $stale = sadmin_stale($t);
    $contentExcerpt = mb_substr(trim((string)$t['content']), 0, 160);
?>
<tr class="trow border-b border-slate-100 relative" data-row-id="<?= (int)$t['id'] ?>">
<td class="px-4 py-3 relative">
<span class="row-strip <?= sadmin_h($sm['strip']) ?>"></span>
<input type="checkbox" class="row-check accent-sky-500 cursor-pointer ml-1" value="<?= (int)$t['id'] ?>" onchange="onRowCheck(this)">
</td>
<td class="px-4 py-3">
<div class="flex items-center gap-2 flex-wrap">
<a href="support_admin.php?ticket=<?= (int)$t['id'] ?>" class="font-semibold text-slate-800 hover:text-rose-700 no-underline"><?= sadmin_h($t['subject']) ?></a>
<?php if ($needsReply): ?><span class="text-[10px] px-1.5 py-0.5 rounded bg-rose-600 text-white font-medium"><i class="fa-solid fa-bell mr-0.5"></i>待回覆</span><?php endif; ?>
<?php if ($stale): ?><span class="text-[10px] px-1.5 py-0.5 rounded bg-orange-100 text-orange-700 border border-orange-200 font-medium">停滯</span><?php endif; ?>
</div>
<div class="text-[11px] text-slate-500 mt-0.5"><span class="font-mono text-slate-400"><?= sadmin_h($t['ticket_no']) ?></span> · <?= sadmin_h($t['username']) ?> · UID <?= (int)$t['uid'] ?> · <i class="fa-regular fa-comment"></i> <?= (int)$t['reply_count'] ?></div>
</td>
<td class="px-4 py-3 text-xs text-slate-600 whitespace-nowrap"><i class="fa-solid <?= sadmin_h($t['category_icon'] ?: 'fa-circle-question') ?> mr-1 text-slate-400"></i><?= sadmin_h($t['category_name'] ?: $t['category_code']) ?></td>
<td class="px-4 py-3"><span class="text-[11px] px-2 py-0.5 rounded-full border font-medium inline-flex items-center gap-1 <?= sadmin_h($pm['badge']) ?>"><span class="w-1.5 h-1.5 rounded-full <?= sadmin_h($pm['strip']) ?>"></span><?= sadmin_h($pm['label']) ?></span></td>
<td class="px-4 py-3"><span class="text-[11px] px-2 py-0.5 rounded-full border font-medium <?= sadmin_h($sm['badge']) ?>"><?= sadmin_h($sm['label']) ?></span></td>
<td class="px-4 py-3 text-xs text-slate-600 whitespace-nowrap"><?= sadmin_h($t['handler'] ?: '—') ?></td>
<td class="px-4 py-3 text-xs text-slate-500 whitespace-nowrap"><span class="font-mono"><?= sadmin_h(date('m-d H:i', strtotime($t['updated_at']))) ?></span><br><span class="text-[10px] text-slate-400"><?= sadmin_h(sadmin_ago($t['updated_at'])) ?></span></td>
<td class="px-4 py-3">
<div class="flex items-center justify-end gap-1.5">
<button type="button" class="btn-ice px-2.5 py-1.5 rounded-lg text-[11px] font-semibold"
    data-preview
    data-id="<?= (int)$t['id'] ?>"
    data-no="<?= sadmin_h($t['ticket_no']) ?>"
    data-subject="<?= sadmin_h($t['subject']) ?>"
    data-member="<?= sadmin_h($t['username']) ?>"
    data-uid="<?= (int)$t['uid'] ?>"
    data-category="<?= sadmin_h($t['category_name'] ?: $t['category_code']) ?>"
    data-status="<?= sadmin_h($sm['label']) ?>"
    data-status-badge="<?= sadmin_h($sm['badge']) ?>"
    data-priority="<?= sadmin_h($pm['label']) ?>"
    data-priority-badge="<?= sadmin_h($pm['badge']) ?>"
    data-handler="<?= sadmin_h($t['handler'] ?: '尚未指派') ?>"
    data-server="<?= sadmin_h($t['server_zone'] ?: '未提供') ?>"
    data-role="<?= sadmin_h($t['role_name'] ?: '未提供') ?>"
    data-email="<?= sadmin_h($t['contact_email'] ?: '未提供') ?>"
    data-created="<?= sadmin_h($t['created_at']) ?>"
    data-content="<?= sadmin_h($contentExcerpt) ?>"
    data-url="support_admin.php?ticket=<?= (int)$t['id'] ?>"
    onclick="openPreview(this)"><i class="fa-solid fa-eye mr-1"></i>檢視</button>
<a href="support_admin.php?ticket=<?= (int)$t['id'] ?>" class="px-2.5 py-1.5 rounded-lg text-[11px] font-semibold bg-slate-800 text-white hover:bg-slate-700 no-underline"><i class="fa-solid fa-pen-to-square mr-1"></i>處理</a>
</div>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

<?php if ($totalPages > 1): ?>
<div class="flex items-center justify-center gap-2">
<?php for ($p = 1; $p <= $totalPages; $p++):
    $q = array_merge($baseQuery, ['page' => $p]);
    $active = ($p === $page);
?>
<a href="support_admin.php?<?= sadmin_h(http_build_query($q)) ?>" class="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-semibold border no-underline transition-colors <?= $active ? 'bg-slate-800 text-white border-slate-800' : 'bg-white/80 text-slate-600 border-slate-300 hover:border-slate-400' ?>"><?= $p ?></a>
<?php endfor; ?>
</div>
<?php endif; ?>

<!-- ===== 列表頁彈出子視窗 ===== -->
<!-- 快速預覽 -->
<div class="sup-modal" id="modal-preview" onclick="modalBackdrop(event,'modal-preview')">
<div class="sup-modal-card">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5">
<span class="w-9 h-9 rounded-xl bg-gradient-to-br from-slate-700 to-slate-900 text-white flex items-center justify-center"><i class="fa-solid fa-file-lines"></i></span>
<div><p class="font-bold text-slate-800 text-sm font-serif" id="pv-subject">—</p><p class="text-[11px] text-slate-400 font-mono" id="pv-no">—</p></div>
</div>
<button type="button" onclick="closeModal('modal-preview')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<div class="p-6 space-y-4">
<div class="flex items-center gap-2 flex-wrap">
<span id="pv-status" class="text-[11px] px-2.5 py-0.5 rounded-full border font-medium">—</span>
<span id="pv-priority" class="text-[11px] px-2.5 py-0.5 rounded-full border font-medium">—</span>
<span class="text-[11px] text-slate-400" id="pv-created">—</span>
</div>
<div class="grid grid-cols-2 gap-3 text-xs">
<div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200"><span class="text-slate-400 block text-[10px]">會員</span><span class="font-semibold text-slate-700" id="pv-member">—</span></div>
<div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200"><span class="text-slate-400 block text-[10px]">分類</span><span class="font-semibold text-slate-700" id="pv-category">—</span></div>
<div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200"><span class="text-slate-400 block text-[10px]">伺服器 / 角色</span><span class="font-semibold text-slate-700" id="pv-server">—</span></div>
<div class="p-2.5 rounded-lg bg-slate-50 border border-slate-200"><span class="text-slate-400 block text-[10px]">受理 GM</span><span class="font-semibold text-slate-700" id="pv-handler">—</span></div>
</div>
<div>
<span class="text-[10px] text-slate-400 block mb-1">申訴內容（節錄）</span>
<p id="pv-content" class="text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-3.5 whitespace-pre-wrap max-h-40 overflow-y-auto nice-scroll">—</p>
</div>
<form method="POST" class="space-y-3 pt-2 border-t border-slate-100">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="reply">
<input type="hidden" name="ticket_id" value="" id="pv-ticket-id">
<label class="text-xs font-semibold text-slate-600">快速回覆</label>
<textarea name="content" rows="3" class="sadmin-input" placeholder="輸入快速回覆內容…"></textarea>
<label class="text-xs text-slate-600 flex items-center gap-2"><input type="checkbox" name="is_internal" value="1" class="accent-amber-500"> 標記為內部備註（會員不可見）</label>
<div class="flex items-center justify-between gap-3">
<a href="#" id="pv-link" class="text-xs font-semibold text-sky-700 hover:underline no-underline"><i class="fa-solid fa-up-right-from-square mr-1"></i>開啟完整處理頁</a>
<button type="submit" class="btn-vermilion px-5 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2"><i class="fa-solid fa-paper-plane"></i> 送出</button>
</div>
</form>
</div>
</div>
</div>

<!-- 批次改狀態 -->
<div class="sup-modal" id="modal-bulk-status" onclick="modalBackdrop(event,'modal-bulk-status')">
<div class="sup-modal-card" style="max-width:480px">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 text-white flex items-center justify-center"><i class="fa-solid fa-sliders"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">批次更新狀態</p><p class="text-[11px] text-slate-400">套用至已選取的回報單</p></div></div>
<button type="button" onclick="closeModal('modal-bulk-status')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" id="bulk-status-form" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="bulk_status">
<div id="bulk-status-ids"></div>
<select name="new_status" class="sadmin-input">
<?php foreach ($SupportStatuses as $key => $meta): ?>
<option value="<?= sadmin_h($key) ?>" <?= $key === 'processing' ? 'selected' : '' ?>><?= sadmin_h($meta['label']) ?></option>
<?php endforeach; ?>
</select>
<textarea name="verdict" rows="2" class="sadmin-input" placeholder="處理結論（僅在「已結案」時套用，選填）"></textarea>
<div class="flex items-center justify-end gap-3">
<button type="button" onclick="closeModal('modal-bulk-status')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-vermilion px-5 py-2.5 rounded-xl text-xs font-semibold"><i class="fa-solid fa-check mr-1"></i>套用</button>
</div>
</form>
</div>
</div>

<!-- 批次指派 -->
<div class="sup-modal" id="modal-bulk-assign" onclick="modalBackdrop(event,'modal-bulk-assign')">
<div class="sup-modal-card" style="max-width:440px">
<div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
<div class="flex items-center gap-2.5"><span class="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 text-white flex items-center justify-center"><i class="fa-solid fa-user-shield"></i></span><div><p class="font-bold text-slate-800 text-sm font-serif">批次指派受理人員</p><p class="text-[11px] text-slate-400">套用至已選取的回報單</p></div></div>
<button type="button" onclick="closeModal('modal-bulk-assign')" class="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100"><i class="fa-solid fa-xmark"></i></button>
</div>
<form method="POST" id="bulk-assign-form" class="p-6 space-y-4">
<input type="hidden" name="form_token" value="<?= sadmin_h($formToken) ?>">
<input type="hidden" name="action" value="bulk_assign">
<div id="bulk-assign-ids"></div>
<select name="handler" class="sadmin-input">
<option value="">（取消指派）</option>
<?php foreach ($gmList as $gm): ?>
<option value="<?= sadmin_h($gm) ?>" <?= $gm === $currentGmUsername ? 'selected' : '' ?>><?= sadmin_h($gm) ?></option>
<?php endforeach; ?>
</select>
<div class="flex items-center justify-end gap-3">
<button type="button" onclick="closeModal('modal-bulk-assign')" class="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs font-semibold hover:bg-slate-50">取消</button>
<button type="submit" class="btn-ice px-5 py-2.5 rounded-xl text-xs font-semibold"><i class="fa-solid fa-check mr-1"></i>套用</button>
</div>
</form>
</div>
</div>
<?php endif; ?>
</main>

<footer class="relative z-10 border-t border-slate-800 bg-[#090d16] py-6 text-center text-xs text-slate-500">
<div class="max-w-7xl mx-auto px-4 space-y-1.5">
<p class="text-slate-400"><a class="hover:text-slate-200 mx-2 no-underline" href="gmpanel.php">GM 控制台</a> · <a class="hover:text-slate-200 mx-2 no-underline" href="support_admin.php">申訴回報管理</a></p>
<p class="font-mono">© 2025 踏雪笑傲營運團隊 · Support Console</p>
</div>
</footer>

<script>
// ---------- 彈出子視窗 ----------
function openModal(id) {
    var m = document.getElementById(id);
    if (!m) return;
    m.classList.add('open');
    document.body.style.overflow = 'hidden';
}
function closeModal(id) {
    var m = document.getElementById(id);
    if (!m) return;
    m.classList.remove('open');
    document.body.style.overflow = '';
}
function modalBackdrop(e, id) {
    if (e.target && e.target.id === id) { closeModal(id); }
}
document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
        document.querySelectorAll('.sup-modal.open').forEach(function (m) { closeModal(m.id); });
    }
});

// ---------- 快速預覽 ----------
function openPreview(btn) {
    var d = btn.dataset;
    document.getElementById('pv-subject').textContent = d.subject || '—';
    document.getElementById('pv-no').textContent = d.no || '—';
    var st = document.getElementById('pv-status');
    st.textContent = d.status || '—';
    st.className = 'text-[11px] px-2.5 py-0.5 rounded-full border font-medium ' + (d.statusBadge || '');
    var pr = document.getElementById('pv-priority');
    pr.textContent = '優先度：' + (d.priority || '—');
    pr.className = 'text-[11px] px-2.5 py-0.5 rounded-full border font-medium ' + (d.priorityBadge || '');
    document.getElementById('pv-created').textContent = '建立於 ' + (d.created || '—');
    document.getElementById('pv-member').textContent = (d.member || '—') + ' · UID ' + (d.uid || '');
    document.getElementById('pv-category').textContent = d.category || '—';
    document.getElementById('pv-server').textContent = (d.server || '—') + ' / ' + (d.role || '—');
    document.getElementById('pv-handler').textContent = d.handler || '—';
    document.getElementById('pv-content').textContent = d.content || '—';
    document.getElementById('pv-ticket-id').value = d.id || '';
    document.getElementById('pv-link').href = d.url || '#';
    openModal('modal-preview');
}

// ---------- 批次選取 ----------
function getSelectedIds() {
    return Array.prototype.slice.call(document.querySelectorAll('.row-check:checked')).map(function (c) { return c.value; });
}
function updateBulkBar() {
    var ids = getSelectedIds();
    var bar = document.getElementById('bulk-bar');
    var cnt = document.getElementById('bulk-count');
    if (cnt) cnt.textContent = ids.length;
    if (bar) {
        if (ids.length > 0) { bar.classList.remove('hidden'); }
        else { bar.classList.add('hidden'); }
    }
}
function onRowCheck(cb) {
    var row = cb.closest('tr');
    if (row) { row.classList.toggle('selected', cb.checked); }
    updateBulkBar();
}
function toggleAll(master) {
    document.querySelectorAll('.row-check').forEach(function (c) {
        c.checked = master.checked;
        var row = c.closest('tr');
        if (row) { row.classList.toggle('selected', c.checked); }
    });
    updateBulkBar();
}
function clearSelection() {
    document.querySelectorAll('.row-check').forEach(function (c) {
        c.checked = false;
        var row = c.closest('tr');
        if (row) { row.classList.remove('selected'); }
    });
    var sa = document.getElementById('select-all');
    if (sa) sa.checked = false;
    updateBulkBar();
}
function fillHidden(containerId, ids) {
    var box = document.getElementById(containerId);
    box.innerHTML = '';
    ids.forEach(function (id) {
        var inp = document.createElement('input');
        inp.type = 'hidden';
        inp.name = 'ticket_ids[]';
        inp.value = id;
        box.appendChild(inp);
    });
}
function openBulkStatus() {
    var ids = getSelectedIds();
    if (ids.length === 0) { return; }
    fillHidden('bulk-status-ids', ids);
    openModal('modal-bulk-status');
}
function openBulkAssign() {
    var ids = getSelectedIds();
    if (ids.length === 0) { return; }
    fillHidden('bulk-assign-ids', ids);
    openModal('modal-bulk-assign');
}

// ---------- 回覆模式標籤切換 ----------
document.querySelectorAll('.reply-mode').forEach(function (radio) {
    radio.addEventListener('change', function () {
        var wrap = radio.closest('.sup-modal-card') || document;
        wrap.querySelectorAll('[data-mode-label]').forEach(function (lbl) {
            lbl.className = 'block text-center py-2 rounded-lg text-slate-500';
        });
        if (radio.checked) {
            radio.nextElementSibling.className = 'block text-center py-2 rounded-lg bg-white shadow-sm text-rose-700';
        }
    });
});

// ---------- 落雪背景 ----------
(function () {
    const canvas = document.getElementById('snow-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);
    window.addEventListener('resize', () => { width = canvas.width = window.innerWidth; height = canvas.height = window.innerHeight; });
    const particles = [];
    const count = Math.min(Math.floor(window.innerWidth / 30), 45);
    for (let i = 0; i < count; i++) {
        particles.push({ x: Math.random() * width, y: Math.random() * height, radius: Math.random() * 2 + 0.8,
            speedY: Math.random() * 0.6 + 0.25, speedX: (Math.random() - 0.5) * 0.35,
            opacity: Math.random() * 0.5 + 0.2, pulsePhase: Math.random() * Math.PI * 2 });
    }
    function render() {
        ctx.clearRect(0, 0, width, height);
        for (let i = 0; i < particles.length; i++) {
            const p = particles[i];
            p.y += p.speedY; p.x += p.speedX; p.pulsePhase += 0.01;
            if (p.y > height) { p.y = -10; p.x = Math.random() * width; }
            if (p.x > width) p.x = 0;
            if (p.x < 0) p.x = width;
            const op = Math.max(0.12, Math.min(0.75, p.opacity + Math.sin(p.pulsePhase) * 0.12));
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(240,249,255,' + op + ')';
            ctx.fill();
        }
        requestAnimationFrame(render);
    }
    render();
})();
</script>
</body>
</html>
